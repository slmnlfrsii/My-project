<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}

$id_users = (int)$_SESSION['id_users'];

$activeTab = strtolower(trim($_GET['tab'] ?? 'tagihan'));
if (!in_array($activeTab, ['tagihan', 'rekap'])) {
    $activeTab = 'tagihan';
}

/* =========================================================================
   1. SKRIP AUTO-BATAL (BATAS WAKTU OPERASIONAL: 30 MENIT)
   ========================================================================= */
$waktu_sekarang = date('Y-m-d H:i:s');
$q_expired = mysqli_query($conn, "
    SELECT s.* 
    FROM sewa s
    LEFT JOIN pembayaran p ON (
        p.id_sewa = s.id 
        OR FIND_IN_SET(s.id, p.id_sewa)
        OR (s.no_tagihan IS NOT NULL AND s.no_tagihan != '' AND EXISTS (
            SELECT 1 FROM sewa s2 
            WHERE s2.no_tagihan = s.no_tagihan 
            AND (p.id_sewa = s2.id OR FIND_IN_SET(s2.id, p.id_sewa))
        ))
    ) AND p.status IN ('Menunggu konfirmasi', 'Lunas', 'Belum lunas')
    WHERE s.id_users = $id_users
    AND p.id IS NULL
    AND s.status NOT IN ('selesai', 'Dibatalkan', 'dibatalkan', 'siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung')
    AND TIMESTAMPDIFF(MINUTE, s.tanggal_buat, '$waktu_sekarang') >= 30
    GROUP BY s.id
");

if ($q_expired && mysqli_num_rows($q_expired) > 0) {
    while ($exp = mysqli_fetch_assoc($q_expired)) {
        $id_sewa_exp = $exp['id'];

        // Simpan ke riwayat sewa_dibatalkan
        $stmt_batal = $conn->prepare("
            INSERT INTO sewa_dibatalkan 
            (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Batal Otomatis', NOW())
        ");
        if ($stmt_batal) {
            $metode_pengambilan = (stripos($exp['metode_pengambilan'], 'antar') !== false || stripos($exp['metode_pengambilan'], 'cod') !== false) ? 'COD' : 'Ambil Ke toko';
            $noTagihanBatal = !empty($exp['no_tagihan']) ? $exp['no_tagihan'] : ('INV-BATAL-' . sprintf('%04d', $id_sewa_exp));
            $stmt_batal->bind_param(
                "issiiidsss",
                $exp['id_users'],
                $noTagihanBatal,
                $exp['nama_produk'],
                $exp['qty'],
                $exp['durasi'],
                $exp['total_harga'],
                $exp['biaya_pengambilan'],
                $metode_pengambilan,
                $exp['gambar'],
                $exp['tanggal_sewa']
            );
            $stmt_batal->execute();
            $stmt_batal->close();
        }

        // Hapus bookingan yang kadaluarsa dari tabel sewa aktif
        mysqli_query($conn, "DELETE FROM sewa WHERE id = $id_sewa_exp");
    }
}

/* =========================================================================
   2. AMBIL DATA TAGIHAN AKTIF
   ========================================================================= */
$query_sewa = "
    SELECT s.*, a.harga_per_hari AS harga_satuan_alat
    FROM sewa s 
    LEFT JOIN alat a ON s.id_alat = a.id
    WHERE s.id_users = $id_users
    AND s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai')
    ORDER BY s.tanggal_buat ASC, s.id ASC
";
$result_sewa = mysqli_query($conn, $query_sewa);

$items_by_invoice = [];

while ($row = mysqli_fetch_assoc($result_sewa)) {

    if (empty($row['no_tagihan'])) {
        $tgl_invoice = !empty($row['tanggal_sewa']) ? date('Ymd', strtotime($row['tanggal_sewa'])) : date('Ymd');
        $row['no_tagihan'] = "INV-" . $tgl_invoice . "-" . sprintf("%04d", $row['id']);
    }

    $harga_satuan = !empty($row['harga_satuan_alat']) ? (float)$row['harga_satuan_alat'] : (float)$row['total_harga'];
    $nama_lc = strtolower($row['nama_produk']);
    $is_consumable = (strpos($nama_lc, 'gas') !== false);

    $subtotal_produk = $is_consumable 
        ? ($harga_satuan * $row['qty']) 
        : ($harga_satuan * $row['qty'] * $row['durasi']);

    $subtotal = $subtotal_produk + $row['biaya_pengambilan'];

    // Perhitungan Tanggal Kembali & Denda
    $tanggal_kembali = date('Y-m-d', strtotime($row['tanggal_sewa'] . ' + ' . $row['durasi'] . ' days'));
    $denda = 0;
    $hari_terlambat = 0;

    if (!$is_consumable) {
        $hari_ini = date('Y-m-d');
        if ($hari_ini > $tanggal_kembali) {
            $selisih = floor((strtotime($hari_ini) - strtotime($tanggal_kembali)) / (60 * 60 * 24));
            if ($selisih > 0) {
                $hari_terlambat = $selisih;
                $denda = $selisih * 10000;
            }
        }
    }

    $row['harga_satuan'] = $harga_satuan;
    $row['is_consumable'] = $is_consumable;
    $row['subtotal_produk'] = $subtotal_produk;
    $row['subtotal'] = $subtotal;
    $row['tanggal_kembali'] = $tanggal_kembali; // [FIXED] Tambahkan key tanggal_kembali
    $row['denda'] = $denda;
    $row['hari_terlambat'] = $hari_terlambat;
    $row['total_bayar'] = $subtotal + $denda;

    $invKey = $row['no_tagihan'];
    $items_by_invoice[$invKey][] = $row;
}

$tagihan = [];
$total_tagihan = 0;
$waktu_checkout_terlama = null;
$jumlah_item_belum_dibayar = 0;
$jumlah_item_sudah_dp = 0;

foreach ($items_by_invoice as $invKey => $itemList) {
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $total_denda = 0;
    $hari_terlambat_max = 0;
    $itemIds = [];

    foreach ($itemList as $it) {
        $total_invoice += $it['total_bayar'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $total_denda += (float)$it['denda'];
        if ($it['hari_terlambat'] > $hari_terlambat_max) {
            $hari_terlambat_max = $it['hari_terlambat'];
        }
        $itemIds[] = (int)$it['id'];
    }

    $idsStr = implode(',', $itemIds);
    $q_pembayaran = mysqli_query($conn, "
        SELECT status, jumlah_bayar 
        FROM pembayaran 
        WHERE id_users = $id_users 
        AND (
            FIND_IN_SET('$invKey', id_sewa)
            OR id_sewa IN ($idsStr)
            OR EXISTS (
                SELECT 1 FROM sewa s3 
                WHERE s3.no_tagihan = '$invKey' 
                AND (pembayaran.id_sewa = s3.id OR FIND_IN_SET(s3.id, pembayaran.id_sewa))
            )
        )
        ORDER BY tanggal_bayar DESC, id DESC
    ");

    $total_dibayar_inv = 0;
    $status_akhir_inv = null;

    if ($q_pembayaran && mysqli_num_rows($q_pembayaran) > 0) {
        while ($pRow = mysqli_fetch_assoc($q_pembayaran)) {
            if ($status_akhir_inv === null) {
                $status_akhir_inv = $pRow['status'];
            }
            if (in_array($pRow['status'], ['Menunggu konfirmasi', 'Belum lunas', 'Lunas'])) {
                $total_dibayar_inv += (float)$pRow['jumlah_bayar'];
            }
        }
    }

    $sisa_invoice = max(0, $total_invoice - $total_dibayar_inv);

    if ($status_akhir_inv === 'Lunas' || $status_akhir_inv === 'ditolak' || ($sisa_invoice <= 0 && $status_akhir_inv !== null && $status_akhir_inv !== 'Belum lunas' && $status_akhir_inv !== 'Menunggu konfirmasi')) {
        continue;
    }

    $primary = $itemList[0];
    $sudah_ada_pembayaran = ($total_dibayar_inv > 0) || in_array($status_akhir_inv, ['Menunggu konfirmasi', 'Belum lunas', 'Lunas']);

    if (!$sudah_ada_pembayaran) {
        $jumlah_item_belum_dibayar += count($itemList);
        $created = !empty($primary['tanggal_buat']) ? $primary['tanggal_buat'] : $primary['tanggal_sewa'];
        if ($waktu_checkout_terlama === null || strtotime($created) < strtotime($waktu_checkout_terlama)) {
            $waktu_checkout_terlama = $created;
        }
    } else {
        $jumlah_item_sudah_dp += count($itemList);
    }

    $total_tagihan += $sisa_invoice;

    $tagihan[] = [
        'no_tagihan' => $invKey,
        'primary_id' => $primary['id'],
        'item_ids' => $itemIds,
        'items' => $itemList,
        'item_count' => count($itemList),
        'total_qty' => $total_qty,
        'durasi' => $primary['durasi'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'tanggal_kembali' => $primary['tanggal_kembali'], // [FIXED] Dimasukkan ke array tagihan
        'tanggal_buat' => $primary['tanggal_buat'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'biaya_pengambilan' => $total_ongkir,
        'denda' => $total_denda,
        'hari_terlambat' => $hari_terlambat_max,
        'total_tagihan_invoice' => $total_invoice,
        'total_dibayar_invoice' => $total_dibayar_inv,
        'sisa_tagihan_invoice' => $sisa_invoice,
        'status' => $status_akhir_inv,
        'sudah_ada_pembayaran' => $sudah_ada_pembayaran
    ];
}

/* =========================================================================
   3. AMBIL DATA REKAP PEMBAYARAN
   ========================================================================= */
$query_bayar = "
    SELECT 
        p.*, 
        COALESCE(
            NULLIF(GROUP_CONCAT(DISTINCT CONCAT(s.nama_produk, ' (x', s.qty, ')') SEPARATOR ', '), ''),
            NULLIF(GROUP_CONCAT(DISTINCT CONCAT(sb.nama_produk, ' (x', sb.qty, ')') SEPARATOR ', '), ''),
            'Item Sewa'
        ) AS nama_produk,
        COALESCE(MIN(s.no_tagihan), MIN(sb.no_tagihan), CONCAT('INV-', DATE_FORMAT(p.tanggal_bayar, '%Y%m%d'), '-', LPAD(p.id, 4, '0'))) AS no_tagihan_db,
        COALESCE(MIN(s.tanggal_sewa), MIN(sb.tanggal_sewa)) AS tanggal_sewa,
        COALESCE(SUM(s.qty), SUM(sb.qty), 1) AS qty,
        COALESCE(MAX(s.durasi), MAX(sb.durasi), 1) AS durasi,
        COALESCE(SUM(s.biaya_pengambilan), SUM(sb.biaya_pengambilan), 0) AS biaya_pengambilan,
        COALESCE(MAX(COALESCE(a.harga_per_hari, s.total_harga, sb.total_harga)), 0) AS harga_satuan_alat
    FROM pembayaran p 
    LEFT JOIN sewa s ON (p.id_sewa = s.id OR FIND_IN_SET(s.id, p.id_sewa))
    LEFT JOIN sewa_dibatalkan sb ON sb.id_users = p.id_users AND (sb.no_tagihan = s.no_tagihan OR sb.no_tagihan LIKE CONCAT('%-', LPAD(p.id_sewa, 4, '0')) OR sb.no_tagihan LIKE CONCAT('%-', LPAD(p.id_sewa, 3, '0')))
    LEFT JOIN alat a ON s.id_alat = a.id
    WHERE p.id_users = $id_users
    AND p.status IN ('Lunas','Belum lunas','ditolak','lunas','belum lunas')
    GROUP BY p.id
    ORDER BY p.tanggal_bayar DESC, p.id DESC
";
$result_bayar = mysqli_query($conn, $query_bayar);

$rekap_pembayaran = [];
while ($row = mysqli_fetch_assoc($result_bayar)) {
    if (!empty($row['no_tagihan_db'])) {
        $row['no_tagihan'] = $row['no_tagihan_db'];
    } else {
        $tgl_inv = !empty($row['tanggal_bayar']) ? date('Ymd', strtotime($row['tanggal_bayar'])) : date('Ymd');
        $row['no_tagihan'] = "INV-" . $tgl_inv . "-" . sprintf("%04d", $row['id']);
    }

    $nama_lc = strtolower($row['nama_produk'] ?? '');
    $is_consumable = (strpos($nama_lc, 'gas') !== false);
    
    $denda = 0;
    if (!$is_consumable && !empty($row['tanggal_sewa'])) {
        $tanggal_kembali = date('Y-m-d', strtotime($row['tanggal_sewa'] . ' + ' . $row['durasi'] . ' days'));
        $hari_ini = date('Y-m-d');
        if ($hari_ini > $tanggal_kembali) {
            $selisih = floor((strtotime($hari_ini) - strtotime($tanggal_kembali)) / (60 * 60 * 24));
            if ($selisih > 0) $denda = $selisih * 10000;
        }
    }

    $row['harga_satuan'] = (float)$row['harga_satuan_alat'];
    $row['is_consumable'] = $is_consumable;
    $row['denda'] = $denda;

    $items_bayar = [];
    $id_sewa_clean = array_values(array_filter(array_map('intval', explode(',', $row['id_sewa']))));
    if (!empty($id_sewa_clean)) {
        $id_sewa_csv = implode(',', $id_sewa_clean);
        $qItm = mysqli_query($conn, "
            SELECT s.*, COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat, COALESCE(a.gambar, s.gambar) AS gambar_alat
            FROM sewa s
            LEFT JOIN alat a ON s.id_alat = a.id
            WHERE s.id IN ($id_sewa_csv)
            ORDER BY s.id ASC
        ");
        if ($qItm && mysqli_num_rows($qItm) > 0) {
            while ($it = mysqli_fetch_assoc($qItm)) {
                $is_gas_it = (stripos($it['nama_produk'], 'gas') !== false);
                $hg_sat = (float)$it['harga_satuan_alat'];
                $it['subtotal_produk'] = $is_gas_it ? ($hg_sat * $it['qty']) : ($hg_sat * $it['qty'] * $it['durasi']);
                $items_bayar[] = $it;
            }
        }
    }
    if (empty($items_bayar)) {
        $safeNoTag = mysqli_real_escape_string($conn, $row['no_tagihan']);
        $qSb = mysqli_query($conn, "
            SELECT sb.*, sb.total_harga AS harga_satuan_alat, sb.gambar AS gambar_alat
            FROM sewa_dibatalkan sb
            WHERE sb.id_users = $id_users 
            AND (sb.no_tagihan = '$safeNoTag' OR sb.no_tagihan LIKE '%-" . sprintf('%04d', $row['id_sewa']) . "')
        ");
        if ($qSb && mysqli_num_rows($qSb) > 0) {
            while ($it = mysqli_fetch_assoc($qSb)) {
                $is_gas_it = (stripos($it['nama_produk'], 'gas') !== false);
                $hg_sat = (float)$it['harga_satuan_alat'];
                $it['subtotal_produk'] = $is_gas_it ? ($hg_sat * $it['qty']) : ($hg_sat * $it['qty'] * $it['durasi']);
                $items_bayar[] = $it;
            }
        }
    }
    $row['items'] = $items_bayar;

    $rawBukti = $row['bukti_pembayaran'] ?? '';
    $buktiPaths = [];
    if (!empty($rawBukti)) {
        $bFiles = array_filter(array_map('trim', explode(',', $rawBukti)));
        foreach ($bFiles as $bF) {
            if (file_exists('bukti_pembayaran/' . $bF)) {
                $buktiPaths[] = 'bukti_pembayaran/' . $bF;
            } elseif (file_exists('admin/uploads/pembayaran/' . $bF)) {
                $buktiPaths[] = 'admin/uploads/pembayaran/' . $bF;
            } elseif (file_exists('admin/uploads/alat/' . $bF)) {
                $buktiPaths[] = 'admin/uploads/alat/' . $bF;
            } else {
                $buktiPaths[] = 'bukti_pembayaran/' . $bF;
            }
        }
    }
    $row['bukti_paths'] = $buktiPaths;
    $row['bukti_path'] = $buktiPaths[0] ?? '';

    $rekap_pembayaran[] = $row;
}

$ada_pending = false;
foreach ($tagihan as $t) {
    if ($t['status'] === 'Menunggu konfirmasi') {
        $ada_pending = true;
        break;
    }
}

$sisa_detik_autobatal = 0;
if ($waktu_checkout_terlama) {
    $waktu_expired = strtotime($waktu_checkout_terlama) + (30 * 60);
    $sisa_detik_autobatal = $waktu_expired - time();
    if ($sisa_detik_autobatal < 0) $sisa_detik_autobatal = 0;
}

$jumlah_item_belum_dibayar = 0;
$jumlah_item_sudah_dp = 0;
foreach ($tagihan as $t) {
    $sudah_bayar_item = ($t['sudah_ada_pembayaran'] ?? false) || ((float)($t['total_dibayar_invoice'] ?? 0) > 0) || in_array($t['status'] ?? '', ['Menunggu konfirmasi', 'Belum lunas', 'Lunas']);
    if (!$sudah_bayar_item) {
        $jumlah_item_belum_dibayar += (int)($t['item_count'] ?? 1);
    } else {
        $jumlah_item_sudah_dp += (int)($t['item_count'] ?? 1);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tagihan & Riwayat Pembayaran - Semar Outdoor</title>
    
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <style>
        :root {
            --brand-dark: #12282a;
            --brand-teal: #162d2f;
            --brand-green: #0e4430;
            --brand-gold: #c27803;
            --brand-gold-glow: #ffc107;
            --bg-body: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
        }

        * { box-sizing: border-box; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            overflow-x: hidden;
        }

        .page-header {
            background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
            color: #ffffff;
            padding: 95px 20px 30px;
            text-align: center;
        }

        .page-title {
            font-family: 'Quicksand', sans-serif;
            font-size: clamp(1.5rem, 3vw, 2.1rem);
            font-weight: 800;
            margin-bottom: 6px;
        }

        .page-subtitle {
            color: #cbd5e1;
            font-size: 0.9rem;
            max-width: 540px;
            margin: 0 auto;
        }

        .content-section { padding: 24px 0 60px; }

        .info-card-notice {
            background: #ffffff;
            border-left: 4px solid var(--brand-teal);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
            padding: 10px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 14px;
            font-size: 0.85rem;
        }

        .timer-card-notice {
            background: #fffbeb;
            border: 1px solid #fef3c7;
            border-left: 4px solid #f59e0b;
            border-radius: 10px;
            padding: 10px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
            font-size: 0.85rem;
        }

        .custom-nav-tabs {
            border-bottom: 2px solid #e2e8f0;
            gap: 8px;
            margin-bottom: 18px;
        }

        .custom-nav-tabs .nav-link {
            border: none;
            color: var(--text-muted);
            font-weight: 700;
            font-size: 0.88rem;
            padding: 8px 16px;
            border-radius: 8px 8px 0 0;
            transition: all 0.2s ease;
            background: transparent;
        }

        .custom-nav-tabs .nav-link.active {
            color: var(--brand-teal);
            border-bottom: 3px solid var(--brand-gold);
            background: transparent;
        }

        .card-tagihan {
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.07);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
            padding: 12px 14px;
            margin-bottom: 0;
            position: relative;
            transition: all 0.2s ease;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }

        .card-tagihan:hover {
            box-shadow: 0 6px 16px rgba(0,0,0,0.06);
            border-color: rgba(194, 120, 3, 0.35);
        }

        .checkbox-tagihan-wrap {
            position: absolute;
            top: 12px;
            left: 12px;
            z-index: 2;
        }

        .checkbox-tagihan {
            width: 18px;
            height: 18px;
            accent-color: var(--brand-green);
            cursor: pointer;
        }

        .tagihan-body-wrap {
            padding-left: 24px;
            display: flex;
            flex-direction: column;
            height: 100%;
            justify-content: space-between;
        }

        .img-tagihan-thumb {
            width: 46px;
            height: 46px;
            object-fit: cover;
            border-radius: 6px;
            flex-shrink: 0;
            background: #f1f5f9;
        }

        .tagihan-info-main {
            width: 100%;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .tagihan-item-title {
            font-size: 0.90rem;
            font-weight: 700;
            color: var(--brand-teal);
            margin-bottom: 3px;
            font-family: 'Quicksand', sans-serif;
        }

        .tagihan-pill-code {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 4px;
            background: #e2e8f0;
            color: #475569;
            display: inline-block;
            margin-bottom: 4px;
        }

        .total-floating-bar {
            background: #ffffff;
            border-radius: 12px;
            padding: 12px 18px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.06);
            border: 1px solid rgba(0,0,0,0.06);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 16px;
        }

        .btn-pay-action {
            background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
            color: #ffffff;
            font-weight: 700;
            font-size: 0.92rem;
            padding: 8px 18px;
            border-radius: 8px;
            border: none;
            transition: all 0.25s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-pay-action:hover:not(:disabled) {
            background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 14px rgba(194, 120, 3, 0.35);
            color: #ffffff;
        }

        .btn-pay-action:disabled {
            background: #94a3b8;
            cursor: not-allowed;
        }

        .table-responsive {
            background: #ffffff !important;
            border-radius: 10px !important;
            border: 1px solid #e2e8f0 !important;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02) !important;
            overflow-x: auto !important;
        }

        .table {
            margin-bottom: 0 !important;
            font-size: 0.84rem !important;
            border-collapse: collapse !important;
        }

        .table thead th {
            background-color: #f1f5f9 !important;
            color: #334155 !important;
            font-size: 0.76rem !important;
            font-weight: 700 !important;
            text-transform: uppercase !important;
            letter-spacing: 0.5px !important;
            padding: 9px 10px !important;
            border-bottom: 2px solid #cbd5e1 !important;
            white-space: nowrap !important;
            vertical-align: middle !important;
        }

        .table tbody td {
            padding: 8px 10px !important;
            vertical-align: middle !important;
            border-color: #f1f5f9 !important;
            color: #1e293b !important;
            line-height: 1.35 !important;
        }

        .table tbody tr:hover { background-color: #f8fafc !important; }

        footer, .footer-semar {
            background: #0b1d1f !important;
            color: #e2e8f0;
            padding-top: 65px;
        }

        .footer-brand-logo {
            height: 42px;
            width: auto;
            max-height: 42px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }

        .footer-brand-name {
            font-family: 'Quicksand', sans-serif;
            font-size: 1.25rem;
            font-weight: 800;
            color: #ffffff;
            letter-spacing: 0.4px;
        }

        .footer-title {
            color: #ffffff;
            font-size: 1.05rem;
            font-weight: 700;
            margin-bottom: 18px;
            position: relative;
            padding-bottom: 8px;
        }

        .footer-title::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 32px;
            height: 2px;
            background: #f59e0b;
            border-radius: 2px;
        }

        .footer-links-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links-list li { margin-bottom: 10px; }

        .footer-links-list a {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .footer-links-list a:hover { color: #fde047; }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 14px;
            font-size: 0.9rem;
            color: #cbd5e1;
        }

        .footer-contact-item i {
            color: #fde047;
            margin-top: 4px;
        }

        .footer-contact-item a {
            color: #cbd5e1;
            text-decoration: none;
        }

        .footer-contact-item a:hover { color: #fde047; }

        .footer-map-container {
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-map-container iframe {
            display: block;
            width: 100%;
            height: 170px;
            border: 0;
        }

        .footer-copy-bar {
            background: #061112;
            padding: 20px 0;
            margin-top: 50px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            font-size: 0.85rem;
            color: #64748b;
        }

        @media (max-width: 768px) {
            .page-header { padding: 85px 16px 20px !important; }
            .page-title { font-size: 1.35rem !important; }
            .page-subtitle { font-size: 0.82rem !important; }
            .content-section { padding: 16px 0 40px !important; }
            .info-card-notice, .timer-card-notice {
                padding: 8px 12px !important;
                font-size: 0.78rem !important;
                margin-bottom: 10px !important;
            }
            .custom-nav-tabs .nav-link {
                font-size: 0.8rem !important;
                padding: 6px 12px !important;
            }
            .card-tagihan {
                padding: 10px 12px !important;
                margin-bottom: 8px !important;
                border-radius: 10px !important;
            }
            .checkbox-tagihan-wrap {
                top: 10px !important;
                left: 10px !important;
            }
            .tagihan-body-wrap {
                padding-left: 24px !important;
                gap: 10px !important;
            }
            .img-tagihan-thumb {
                width: 50px !important;
                height: 50px !important;
                border-radius: 6px !important;
            }
            .tagihan-item-title { font-size: 0.88rem !important; }
            .total-floating-bar {
                padding: 10px 12px !important;
                border-radius: 10px !important;
                flex-direction: column !important;
                gap: 8px !important;
                align-items: stretch !important;
            }
            .total-floating-bar .d-flex { justify-content: space-between !important; }
            .btn-pay-action {
                width: 100% !important;
                justify-content: center !important;
                font-size: 0.85rem !important;
                padding: 8px 14px !important;
            }
        }
    </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Tagihan & Riwayat Pembayaran</h1>
      <p class="page-subtitle">Pantau status pembayaran sewa aktif serta rekap histori transaksi Anda.</p>
    </div>
  </section>

  <div class="content-section">
    <div class="container">
        
        <!-- Notifikasi Informasi Ketentuan Tagihan -->
        <div class="info-card-notice">
            <i class="fas fa-info-circle fs-3 text-primary flex-shrink-0"></i>
            <div>
                <strong class="d-block text-dark fw-bold mb-1">Informasi Tagihan & Ketentuan Denda:</strong>
                <span class="text-muted small">
                    Periksa tagihan aktif yang perlu diselesaikan. Denda keterlambatan berlaku sebesar Rp 10.000 / hari jika alat terlambat dikembalikan melewati masa sewa (tidak berlaku untuk gas sekali pakai).
                </span>
            </div>
        </div>

        <!-- Notifikasi Hitung Mundur Auto Batal -->
        <?php if ($sisa_detik_autobatal > 0 && $jumlah_item_belum_dibayar > 0): ?>
            <div class="timer-card-notice" id="boxAlertAutoBatal">
                <i class="fas fa-stopwatch fs-3 text-warning flex-shrink-0"></i>
                <div>
                    <strong class="d-block text-dark fw-bold mb-1">
                        <i class="fas fa-clock text-warning me-1"></i> Batas Waktu Pembayaran (Item Belum Dibayar):
                    </strong>
                    <span class="text-dark small">
                        Segera lakukan pembayaran untuk <strong><?= $jumlah_item_belum_dibayar ?> item berstatus Belum Dibayar</strong> sebelum waktu habis: <strong class="text-danger fs-6 ms-1 font-monospace" id="timerCount">--:--</strong>. 
                        <?php if ($jumlah_item_sudah_dp > 0): ?>
                            <br><span class="text-success fw-semibold"><i class="fas fa-shield-alt me-1"></i> <?= $jumlah_item_sudah_dp ?> item yang sudah dibayar DP / Menunggu Konfirmasi aman dan <u>TIDAK AKAN</u> dibatalkan.</span>
                        <?php endif; ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Nav Tabs -->
        <ul class="nav custom-nav-tabs" id="tagihanTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link <?= ($activeTab === 'tagihan') ? 'active' : '' ?>" id="tagihan-tab" data-bs-toggle="tab" data-bs-target="#tagihan" type="button" role="tab" aria-controls="tagihan" aria-selected="<?= ($activeTab === 'tagihan') ? 'true' : 'false' ?>">
                    <i class="fas fa-file-invoice-dollar me-1"></i> Tagihan Aktif (<?= count($tagihan) ?>)
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link <?= ($activeTab === 'rekap') ? 'active' : '' ?>" id="rekap-tab" data-bs-toggle="tab" data-bs-target="#rekap" type="button" role="tab" aria-controls="rekap" aria-selected="<?= ($activeTab === 'rekap') ? 'true' : 'false' ?>">
                    <i class="fas fa-receipt me-1"></i> Rekap Histori Pembayaran (<?= count($rekap_pembayaran) ?>)
                </button>
            </li>
        </ul>

        <div class="tab-content" id="tagihanTabsContent">
            <!-- TAB 1: TAGIHAN AKTIF -->
            <div class="tab-pane fade <?= ($activeTab === 'tagihan') ? 'show active' : '' ?>" id="tagihan" role="tabpanel" aria-labelledby="tagihan-tab">
                <?php if (count($tagihan) > 0): ?>
                    <!-- Toolbar Pilih Semua & Info Antrean FIFO -->
                    <div class="d-flex flex-wrap justify-content-between align-items-center bg-white p-3 rounded-4 border mb-3 shadow-sm gap-2">
                        <div class="form-check d-flex align-items-center gap-2 mb-0">
                            <input class="form-check-input" type="checkbox" id="selectAllTagihan" style="width: 20px; height: 20px; accent-color: var(--brand-green); cursor: pointer;">
                            <label class="form-check-label fw-bold small text-dark cursor-pointer mb-0" for="selectAllTagihan" style="cursor: pointer;">
                                Pilih Semua Tagihan (<?= count($tagihan) ?> Tagihan)
                            </label>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-light text-dark border small py-2 px-3 rounded-pill">
                                <i class="fas fa-layer-group text-warning me-1"></i> Prioritas Antrean FIFO Aktif
                            </span>
                        </div>
                    </div>

                    <form action="pembayaran.php" method="POST" id="form-bayar-tagihan">
                    <div class="row g-3">
                    <?php 
                    $no_antrean = 1;
                    $fifo_idx = 0;
                    foreach ($tagihan as $inv): 
                        $item_sudah_bayar = ($inv['total_dibayar_invoice'] > 0) || in_array($inv['status'], ['Menunggu konfirmasi', 'Belum lunas', 'Lunas']);
                        $is_pending = ($inv['status'] === 'Menunggu konfirmasi');
                    ?>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="card-tagihan">
                                <div class="checkbox-tagihan-wrap">
                                    <?php if ($is_pending): ?>
                                        <input 
                                            type="checkbox" 
                                            disabled 
                                            class="checkbox-tagihan" 
                                            style="opacity: 0.35; cursor: not-allowed;" 
                                            title="Sedang menunggu verifikasi pembayaran admin"
                                        >
                                    <?php else: ?>
                                        <input 
                                            type="checkbox" 
                                            class="checkbox-tagihan" 
                                            data-card-id="<?= $inv['primary_id'] ?>"
                                            data-sisa="<?= $inv['sisa_tagihan_invoice'] ?>"
                                            data-status="<?= $inv['status'] ?>"
                                            data-fifo-idx="<?= $fifo_idx++ ?>"
                                            data-antrean="<?= $no_antrean ?>"
                                            id="checkbox-<?= $inv['primary_id'] ?>"
                                        >
                                        <?php foreach ($inv['items'] as $it): ?>
                                            <input type="checkbox" name="id_sewa[]" value="<?= $it['id'] ?>" class="hidden-sewa-input hidden-sewa-<?= $inv['primary_id'] ?>" style="display:none;">
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="tagihan-body-wrap">
                                    <div class="tagihan-info-main">
                                        <!-- Header: Antrean, No Tagihan, Status, Batas Bayar -->
                                        <div class="d-flex flex-wrap align-items-center gap-1.5 mb-2 pb-1 border-bottom">
                                            <span class="tagihan-pill-code mb-0" style="background: #e0f2fe; color: #0369a1; font-weight: 700;">
                                                <i class="fas fa-list-ol me-1"></i> Antrean #<?= $no_antrean++ ?>
                                            </span>
                                            <span class="tagihan-pill-code mb-0 fw-bold"><?= $inv['no_tagihan'] ?></span>
                                            <?php if ($item_sudah_bayar): ?>
                                                <?php if ($inv['status'] === 'Menunggu konfirmasi'): ?>
                                                    <span class="badge bg-primary text-white" style="font-size: 0.72rem;"><i class="fas fa-clock me-1"></i>Menunggu Konfirmasi</span>
                                                <?php elseif ($inv['status'] === 'Belum lunas' || $inv['total_dibayar_invoice'] > 0): ?>
                                                    <span class="badge bg-warning text-dark" style="font-size: 0.72rem;"><i class="fas fa-coins me-1"></i>DP Terbayar</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info text-dark" style="font-size: 0.72rem;"><?= htmlspecialchars($inv['status']) ?></span>
                                                <?php endif; ?>
                                                <span class="badge bg-success bg-opacity-10 text-success border border-success" style="font-size: 0.72rem;"><i class="fas fa-shield-alt me-1"></i>Aman Auto-Batal</span>
                                            <?php elseif ($inv['status'] === 'ditolak'): ?>
                                                <span class="badge bg-danger text-white" style="font-size: 0.72rem;"><i class="fas fa-times-circle me-1"></i>Ditolak</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary" style="font-size: 0.72rem;">Belum Dibayar</span>
                                                <?php if ($sisa_detik_autobatal > 0): ?>
                                                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger ms-auto" style="font-size: 0.72rem;">
                                                        <i class="fas fa-stopwatch me-1"></i>Batas: <span class="timerCardBadge">--:--</span>
                                                    </span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>

                                        <!-- Main Thumbnail & Title -->
                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <img src="admin/uploads/alat/<?= $inv['items'][0]['gambar'] ?>" alt="<?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>" class="img-tagihan-thumb" />
                                            <div class="flex-grow-1 overflow-hidden">
                                                <h6 class="tagihan-item-title mb-0 fw-bold text-dark text-truncate">
                                                    <?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>
                                                </h6>
                                                <?php if (count($inv['items']) > 1): ?>
                                                    <span class="text-muted" style="font-size: 0.74rem;">+<?= count($inv['items']) - 1 ?> alat lainnya</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <!-- Mini List of Items -->
                                        <div class="bg-light px-2 py-1.5 rounded-2 border mb-2" style="font-size: 0.74rem;">
                                            <div class="row g-1">
                                                <?php foreach ($inv['items'] as $it): ?>
                                                    <div class="col-sm-6 col-12 d-flex align-items-center gap-1.5 py-0.5">
                                                        <img src="admin/uploads/alat/<?= $it['gambar'] ?>" alt="alat" style="width: 20px; height: 20px; object-fit: cover; border-radius: 3px;" class="border flex-shrink-0">
                                                        <span class="small text-dark fw-semibold text-truncate" style="font-size: 0.73rem;"><?= htmlspecialchars($it['nama_produk']) ?></span>
                                                        <span class="badge bg-white text-dark border ms-1 flex-shrink-0" style="font-size: 0.68rem; padding: 1px 4px;">x<?= $it['qty'] ?></span>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 0.74rem;">
                                            <span>Total: <strong><?= $inv['total_qty'] ?> unit</strong> &bull; <strong><?= $inv['durasi'] ?> hari</strong></span>
                                            <span>Mulai: <strong><?= date('d M Y', strtotime($inv['tanggal_sewa'])) ?></strong></span>
                                        </div>

                                        <?php if ($inv['denda'] > 0): ?>
                                            <div class="text-danger small fw-bold mb-2">
                                                <i class="fas fa-exclamation-circle me-1"></i> Denda Keterlambatan: Rp<?= number_format($inv['denda'], 0, ',', '.') ?> (<?= $inv['hari_terlambat'] ?> hari)
                                            </div>
                                        <?php endif; ?>

                                        <div class="d-flex flex-wrap justify-content-between align-items-center mt-auto pt-2 border-top gap-1">
                                            <div>
                                                <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Sisa Tagihan (Pelunasan)</small>
                                                <span class="fw-bold text-danger" style="font-size: 0.95rem;">Rp<?= number_format($inv['sisa_tagihan_invoice'], 0, ',', '.') ?></span>
                                                <?php if ($inv['total_dibayar_invoice'] > 0): ?>
                                                    <small class="text-primary d-block" style="font-size: 0.68rem;">(DP: Rp<?= number_format($inv['total_dibayar_invoice'], 0, ',', '.') ?>)</small>
                                                <?php endif; ?>
                                            </div>

                                            <div class="d-flex gap-1.5">
                                                <button type="button" class="btn btn-outline-secondary btn-sm px-2.5 py-1" style="font-size: 0.76rem; border-radius: 6px;" data-bs-toggle="modal" data-bs-target="#detailInvoiceModal<?= $inv['primary_id'] ?>">
                                                    <i class="fas fa-info-circle me-1"></i> Rincian
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Detail Invoice -->
                            <div class="modal fade" id="detailInvoiceModal<?= $inv['primary_id'] ?>" tabindex="-1" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
                                <div class="modal-content rounded-4 border-0 shadow">
                                  <div class="modal-header bg-dark text-white" style="background-color: var(--brand-teal) !important;">
                                    <h5 class="modal-title fw-bold"><i class="fas fa-receipt me-2 text-warning"></i> Detail Tagihan: <?= $inv['no_tagihan'] ?></h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                  </div>
                                  <div class="modal-body p-4">
                                    <div class="row g-3 mb-3 p-3 bg-light rounded-3 border">
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Nomor Tagihan</small>
                                        <div class="fw-bold text-primary"><?= $inv['no_tagihan'] ?></div>
                                      </div>
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Status Tagihan</small>
                                        <div>
                                            <span class="badge bg-secondary"><?= htmlspecialchars($inv['status']) ?></span>
                                            <?php if ($item_sudah_bayar): ?>
                                                <span class="badge bg-success bg-opacity-10 text-success border border-success small ms-1"><i class="fas fa-shield-alt me-1"></i>Aman dari Auto-Batal</span>
                                            <?php endif; ?>
                                        </div>
                                      </div>
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Metode Pengambilan</small>
                                        <div class="fw-semibold text-dark"><?= htmlspecialchars($inv['metode_pengambilan']) ?></div>
                                      </div>
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Jadwal Sewa</small>
                                        <div class="fw-semibold text-dark"><?= date('d M Y', strtotime($inv['tanggal_sewa'])) ?> s/d <?= date('d M Y', strtotime($inv['tanggal_kembali'])) ?> (<?= $inv['durasi'] ?> Hari)</div>
                                      </div>
                                    </div>

                                    <div class="modal-section-title mb-2 fw-bold text-dark">
                                      <i class="fas fa-boxes me-1 text-primary"></i> Rincian Perlengkapan yang Disewa:
                                    </div>
                                    <div class="table-responsive mb-3">
                                      <table class="table table-hover align-middle border">
                                        <thead class="table-light">
                                          <tr>
                                            <th>Alat</th>
                                            <th class="text-center">Jumlah</th>
                                            <th class="text-end">Harga / Hari</th>
                                            <th class="text-end">Subtotal</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php foreach ($inv['items'] as $item): ?>
                                          <tr>
                                            <td>
                                              <div class="d-flex align-items-center gap-2">
                                                <img src="admin/uploads/alat/<?= $item['gambar'] ?>" alt="Alat" style="width: 40px; height: 40px; object-fit: cover; border-radius: 6px;" class="border flex-shrink-0">
                                                <span class="fw-semibold text-dark"><?= htmlspecialchars($item['nama_produk']) ?></span>
                                              </div>
                                            </td>
                                            <td class="text-center fw-bold"><?= $item['qty'] ?> unit</td>
                                            <!-- [FIXED] Penggunaan variabel harga_satuan & subtotal_produk -->
                                            <td class="text-end">Rp<?= number_format($item['harga_satuan'], 0, ',', '.') ?></td>
                                            <td class="text-end fw-bold">Rp<?= number_format($item['subtotal_produk'], 0, ',', '.') ?></td>
                                          </tr>
                                          <?php endforeach; ?>
                                        </tbody>
                                      </table>
                                    </div>

                                    <div class="p-3 bg-light rounded-3 border">
                                      <?php if ($inv['denda'] > 0): ?>
                                        <div class="d-flex justify-content-between mb-1 text-danger">
                                          <span>Denda Keterlambatan (<?= $inv['hari_terlambat'] ?> hari)</span>
                                          <span class="fw-bold">Rp<?= number_format($inv['denda'], 0, ',', '.') ?></span>
                                        </div>
                                      <?php endif; ?>
                                      <div class="d-flex justify-content-between mb-1">
                                        <span class="text-muted">Total Tagihan Transaksi</span>
                                        <span class="fw-bold">Rp<?= number_format($inv['total_tagihan_invoice'], 0, ',', '.') ?></span>
                                      </div>
                                      <div class="d-flex justify-content-between mb-1">
                                        <span class="text-muted">DP / Pembayaran Masuk</span>
                                        <span class="text-primary fw-bold">Rp<?= number_format($inv['total_dibayar_invoice'], 0, ',', '.') ?></span>
                                      </div>
                                      <hr class="my-2">
                                      <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold fs-6 text-dark">Sisa yang Harus Dibayar:</span>
                                        <span class="fw-bold fs-5 text-danger">Rp<?= number_format($inv['sisa_tagihan_invoice'], 0, ',', '.') ?></span>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </div>

                    <!-- Floating Total & Bayar Bar -->
                    <div class="total-floating-bar">
                        <div>
                            <span class="text-muted small d-block">Total Tagihan Dipilih:</span>
                            <span class="fs-4 fw-bold text-success">Rp <span id="totalDipilih">0</span></span>
                        </div>
                        <button type="submit" id="btnBayar" class="btn-pay-action" <?= $ada_pending ? 'data-pending="true"' : '' ?> disabled>
                            <i class="fas fa-credit-card"></i> Bayar Tagihan
                        </button>
                    </div>
                    </form>
                <?php else: ?>
                    <div class="card p-5 text-center rounded-4 border-0 shadow-sm">
                        <i class="fas fa-check-circle fs-1 text-success mb-3"></i>
                        <h4 class="fw-bold mb-1">Tidak Ada Tagihan Aktif</h4>
                        <p class="text-muted mb-0">Semua tagihan Anda telah lunas atau Anda belum memiliki pemesanan aktif saat ini.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- TAB 2: REKAP HISTORI PEMBAYARAN -->
            <div class="tab-pane fade <?= ($activeTab === 'rekap') ? 'show active' : '' ?>" id="rekap" role="tabpanel" aria-labelledby="rekap-tab">
                <?php if (count($rekap_pembayaran) > 0): ?>
                    <div class="row g-3">
                    <?php foreach ($rekap_pembayaran as $bayar): 
                        $statusRaw = strtolower(trim($bayar['status'] ?? ''));
                        $statusBadgeClass = 'bg-secondary';
                        if ($statusRaw === 'lunas') $statusBadgeClass = 'bg-success';
                        elseif ($statusRaw === 'belum lunas') $statusBadgeClass = 'bg-warning text-dark';
                        elseif ($statusRaw === 'ditolak') $statusBadgeClass = 'bg-danger';

                        $itemsList = $bayar['items'] ?? [];
                        $firstItem = !empty($itemsList) ? $itemsList[0] : null;
                        $gambarUtama = !empty($firstItem['gambar_alat']) ? $firstItem['gambar_alat'] : (!empty($firstItem['gambar']) ? $firstItem['gambar'] : '');
                        $totalUnitAlat = 0;
                        if (!empty($itemsList)) {
                            foreach ($itemsList as $it) {
                                $totalUnitAlat += (int)($it['qty'] ?? 1);
                            }
                        } else {
                            $totalUnitAlat = (int)($bayar['qty'] ?? 1);
                        }
                    ?>
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="card-tagihan">
                                <div class="tagihan-body-wrap" style="padding-left: 0;">
                                    <div class="tagihan-info-main">
                                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-2 pb-1 border-bottom">
                                            <div class="d-flex align-items-center gap-1.5 flex-wrap">
                                                <span class="tagihan-pill-code mb-0 fw-bold"><?= htmlspecialchars($bayar['no_tagihan']) ?></span>
                                                <span class="badge <?= $statusBadgeClass ?> px-2 py-0.5 rounded" style="font-size: 0.72rem;"><?= htmlspecialchars($bayar['status']) ?></span>
                                                <?php if ($statusRaw === 'ditolak'): ?>
                                                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-2 py-0.5 rounded" style="font-size: 0.72rem;"><i class="fas fa-undo-alt me-1"></i>Dana DP Dikembalikan</span>
                                                <?php endif; ?>
                                                <span class="badge bg-light text-dark border px-2 py-0.5 rounded" style="font-size: 0.72rem;"><i class="fas fa-wallet me-1"></i><?= htmlspecialchars($bayar['metode']) ?></span>
                                            </div>
                                            <span class="text-muted" style="font-size: 0.73rem;">
                                                <i class="far fa-clock me-1"></i> <?= date('d M Y H:i', strtotime($bayar['tanggal_bayar'])) ?> WIB
                                            </span>
                                        </div>

                                        <div class="d-flex align-items-center gap-2 mb-2">
                                            <?php if (!empty($gambarUtama) && file_exists('admin/uploads/alat/' . $gambarUtama)): ?>
                                                <img src="admin/uploads/alat/<?= htmlspecialchars($gambarUtama) ?>" alt="<?= htmlspecialchars($bayar['nama_produk']) ?>" class="img-tagihan-thumb" />
                                            <?php elseif (!empty($bayar['bukti_path'])): ?>
                                                <img src="<?= htmlspecialchars($bayar['bukti_path']) ?>" alt="Bukti" class="img-tagihan-thumb border" style="object-fit: cover;" onerror="this.outerHTML='<div class=\'img-tagihan-thumb d-flex align-items-center justify-content-center bg-light border\'><i class=\'fas fa-receipt text-muted\'></i></div>';" />
                                            <?php else: ?>
                                                <div class="img-tagihan-thumb d-flex align-items-center justify-content-center bg-light border">
                                                    <i class="fas fa-receipt text-muted"></i>
                                                </div>
                                            <?php endif; ?>

                                            <div class="flex-grow-1 overflow-hidden">
                                                <h6 class="tagihan-item-title mb-0 fw-bold text-dark text-truncate">
                                                    <?= htmlspecialchars(!empty($firstItem['nama_produk']) ? $firstItem['nama_produk'] : $bayar['nama_produk']) ?>
                                                </h6>
                                                <?php if (count($itemsList) > 1): ?>
                                                    <span class="text-muted" style="font-size: 0.74rem;">+<?= count($itemsList) - 1 ?> alat lainnya</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <?php if (!empty($itemsList)): ?>
                                            <div class="bg-light px-2 py-1.5 rounded-2 border mb-2" style="font-size: 0.74rem;">
                                                <div class="row g-1">
                                                    <?php foreach ($itemsList as $it): 
                                                        $imgIt = !empty($it['gambar_alat']) ? $it['gambar_alat'] : (!empty($it['gambar']) ? $it['gambar'] : '');
                                                    ?>
                                                        <div class="col-sm-6 col-12 d-flex align-items-center gap-1.5 py-0.5">
                                                            <?php if (!empty($imgIt) && file_exists('admin/uploads/alat/' . $imgIt)): ?>
                                                                <img src="admin/uploads/alat/<?= htmlspecialchars($imgIt) ?>" alt="alat" style="width: 20px; height: 20px; object-fit: cover; border-radius: 3px;" class="border flex-shrink-0">
                                                            <?php else: ?>
                                                                <div style="width: 20px; height: 20px; border-radius: 3px;" class="bg-white border d-flex align-items-center justify-content-center flex-shrink-0">
                                                                    <i class="fas fa-campground text-muted" style="font-size: 0.65rem;"></i>
                                                                </div>
                                                            <?php endif; ?>
                                                            <span class="small text-dark fw-semibold text-truncate" style="font-size: 0.73rem;"><?= htmlspecialchars($it['nama_produk']) ?></span>
                                                            <span class="badge bg-white text-dark border ms-1 flex-shrink-0" style="font-size: 0.68rem; padding: 1px 4px;">x<?= $it['qty'] ?></span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 0.74rem;">
                                            <span>Total: <strong><?= $totalUnitAlat ?> unit</strong> &bull; <strong><?= $bayar['is_consumable'] ? '-' : $bayar['durasi'] . ' hari' ?></strong></span>
                                            <span>Status: <strong><?= $statusRaw === 'ditolak' ? 'Ditolak' : 'Terverifikasi' ?></strong></span>
                                        </div>

                                        <div class="d-flex flex-wrap justify-content-between align-items-center mt-auto pt-2 border-top gap-1">
                                            <div>
                                                <?php if ($statusRaw === 'ditolak'): ?>
                                                    <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Uang Masuk (DP Refund)</small>
                                                    <span class="fw-bold text-danger" style="font-size: 0.95rem;">Rp<?= number_format($bayar['jumlah_bayar'], 0, ',', '.') ?></span>
                                                <?php else: ?>
                                                    <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Jumlah Dibayar</small>
                                                    <span class="fw-bold text-success" style="font-size: 0.95rem;">Rp<?= number_format($bayar['jumlah_bayar'], 0, ',', '.') ?></span>
                                                    <?php if (!empty($bayar['total_tagihan']) && (float)$bayar['total_tagihan'] > (float)$bayar['jumlah_bayar']): ?>
                                                        <small class="text-danger d-block" style="font-size: 0.68rem;">(Sisa: Rp<?= number_format((float)$bayar['total_tagihan'] - (float)$bayar['jumlah_bayar'], 0, ',', '.') ?>)</small>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>

                                            <div class="d-flex align-items-center gap-1.5">
                                                <?php if (in_array($statusRaw, ['lunas', 'belum lunas'])): ?>
                                                    <a href="cetak_invoice.php?id=<?= (int)$bayar['id']; ?>&from=user" target="_blank" class="btn btn-outline-success btn-sm px-2.5 py-1" style="font-size: 0.76rem; border-radius: 6px;" title="Cetak / Unduh Struk Invoice Resmi">
                                                        <i class="fas fa-file-invoice me-1"></i> Struk
                                                    </a>
                                                <?php endif; ?>
                                                <button type="button" class="btn btn-outline-secondary btn-sm px-2.5 py-1" style="font-size: 0.76rem; border-radius: 6px;" data-bs-toggle="modal" data-bs-target="#detailBayarModal<?= $bayar['id'] ?>">
                                                    <i class="fas fa-receipt me-1"></i> Detail
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Modal Detail Pembayaran -->
                            <div class="modal fade" id="detailBayarModal<?= $bayar['id'] ?>" tabindex="-1" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
                                <div class="modal-content rounded-4 border-0 shadow">
                                  <div class="modal-header bg-dark text-white" style="background-color: var(--brand-teal) !important;">
                                    <h5 class="modal-title fw-bold"><i class="fas fa-receipt me-2 text-warning"></i> Detail Riwayat Pembayaran: <?= htmlspecialchars($bayar['no_tagihan']) ?></h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                  </div>
                                  <div class="modal-body p-4">
                                    <?php if ($statusRaw === 'ditolak'): ?>
                                        <div class="alert alert-danger d-flex align-items-start gap-3 p-3 rounded-3 mb-3 border border-danger border-opacity-25 shadow-sm">
                                            <i class="fas fa-undo-alt fs-2 text-danger flex-shrink-0 mt-1"></i>
                                            <div>
                                                <strong class="d-block text-danger mb-1" style="font-size: 1.02rem;">
                                                    <i class="fas fa-info-circle me-1"></i> Informasi Pengembalian Dana (Refund DP)
                                                </strong>
                                                <div class="text-dark small leading-relaxed">
                                                    Pembayaran ini berstatus <strong>Ditolak</strong> oleh Admin. Uang yang telah Anda bayarkan sebagai uang muka (DP) sebesar <strong class="text-danger fs-6">Rp<?= number_format($bayar['jumlah_bayar'], 0, ',', '.') ?></strong> <strong>telah dikembalikan sepenuhnya</strong> ke rekening / e-wallet Anda. Silakan periksa mutasi rekening Anda atau hubungi admin Semar Outdoor jika memerlukan konfirmasi lebih lanjut.
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <div class="row g-3 mb-3 p-3 bg-light rounded-3 border">
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Nomor Tagihan</small>
                                        <div class="fw-bold text-primary"><?= htmlspecialchars($bayar['no_tagihan']) ?></div>
                                      </div>
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Status Pembayaran</small>
                                        <div>
                                            <span class="badge <?= $statusBadgeClass ?> px-2 py-1"><?= htmlspecialchars($bayar['status']) ?></span>
                                            <?php if ($statusRaw === 'ditolak'): ?>
                                                <span class="badge bg-danger bg-opacity-10 text-danger border border-danger small ms-1"><i class="fas fa-undo-alt me-1"></i>Dana DP Dikembalikan</span>
                                            <?php endif; ?>
                                        </div>
                                      </div>
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Metode Pembayaran</small>
                                        <div class="fw-semibold text-dark"><?= htmlspecialchars($bayar['metode']) ?></div>
                                      </div>
                                      <div class="col-sm-6">
                                        <small class="text-muted d-block">Waktu Transaksi</small>
                                        <div class="fw-semibold text-dark"><?= date('d M Y - H:i:s', strtotime($bayar['tanggal_bayar'])) ?> WIB</div>
                                      </div>
                                    </div>

                                    <?php if (!empty($itemsList)): ?>
                                    <div class="modal-section-title mb-2 fw-bold text-dark">
                                      <i class="fas fa-boxes me-1 text-primary"></i> Daftar Alat dalam Pembayaran Ini:
                                    </div>
                                    <div class="table-responsive mb-3">
                                      <table class="table table-bordered table-hover align-middle mb-0 small">
                                        <thead class="table-light text-center">
                                          <tr>
                                            <th style="width: 50px;">Foto</th>
                                            <th>Nama Produk</th>
                                            <th style="width: 60px;">Jumlah</th>
                                            <th style="width: 100px;">Harga Satuan</th>
                                            <th style="width: 110px;">Subtotal</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php foreach ($itemsList as $it): 
                                            $imgItModal = !empty($it['gambar_alat']) ? $it['gambar_alat'] : (!empty($it['gambar']) ? $it['gambar'] : '');
                                          ?>
                                            <tr>
                                              <td class="text-center">
                                                <?php if (!empty($imgItModal) && file_exists('admin/uploads/alat/' . $imgItModal)): ?>
                                                    <img src="admin/uploads/alat/<?= htmlspecialchars($imgItModal) ?>" alt="alat" style="width: 38px; height: 38px; object-fit: cover; border-radius: 4px;" class="border">
                                                <?php else: ?>
                                                    <div style="width: 38px; height: 38px; border-radius: 4px;" class="bg-light border d-flex align-items-center justify-content-center mx-auto">
                                                        <i class="fas fa-campground text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                              </td>
                                              <td><strong><?= htmlspecialchars($it['nama_produk']) ?></strong></td>
                                              <td class="text-center fw-bold"><?= $it['qty'] ?></td>
                                              <td class="text-end">Rp<?= number_format($it['harga_satuan_alat'], 0, ',', '.') ?></td>
                                              <td class="text-end fw-bold text-success">Rp<?= number_format($it['subtotal_produk'], 0, ',', '.') ?></td>
                                            </tr>
                                          <?php endforeach; ?>
                                        </tbody>
                                      </table>
                                    </div>
                                    <?php endif; ?>

                                    <div class="bg-light p-3 rounded-3 border mb-3">
                                        <?php if ($statusRaw === 'ditolak'): ?>
                                            <div class="d-flex justify-content-between mb-1">
                                                <span class="text-muted">Uang yang Sempat Dibayarkan (DP):</span>
                                                <span class="fw-bold text-danger fs-5">Rp<?= number_format($bayar['jumlah_bayar'], 0, ',', '.') ?></span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-1 small">
                                                <span class="text-muted">Status Pengembalian Dana:</span>
                                                <span class="badge bg-danger text-white"><i class="fas fa-undo-alt me-1"></i>Dikembalikan 100% (Refund)</span>
                                            </div>
                                            <?php if (!empty($bayar['total_tagihan'])): ?>
                                            <div class="d-flex justify-content-between mb-1 small text-muted">
                                                <span>Total Nilai Tagihan Awal:</span>
                                                <span class="fw-semibold">Rp<?= number_format($bayar['total_tagihan'], 0, ',', '.') ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <hr class="my-2">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="fw-bold text-dark small">Sisa Tagihan:</span>
                                                <span class="fw-bold text-secondary">Rp 0 <small class="text-danger fw-normal">(Pesanan Telah Dibatalkan)</small></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="d-flex justify-content-between mb-1">
                                                <span class="text-muted">Jumlah yang Dibayarkan:</span>
                                                <span class="fw-bold text-success fs-5">Rp<?= number_format($bayar['jumlah_bayar'], 0, ',', '.') ?></span>
                                            </div>
                                            <?php if (!empty($bayar['total_tagihan'])): ?>
                                            <div class="d-flex justify-content-between mb-1 small text-muted">
                                                <span>Total Nilai Tagihan:</span>
                                                <span class="fw-semibold">Rp<?= number_format($bayar['total_tagihan'], 0, ',', '.') ?></span>
                                            </div>
                                            <?php if ((float)$bayar['total_tagihan'] > (float)$bayar['jumlah_bayar']): ?>
                                            <div class="d-flex justify-content-between mb-1 small">
                                                <span class="text-danger fw-semibold">Sisa yang Belum Dibayar:</span>
                                                <span class="text-danger fw-bold">Rp<?= number_format((float)$bayar['total_tagihan'] - (float)$bayar['jumlah_bayar'], 0, ',', '.') ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Lampiran Bukti Transfer -->
                                    <?php if (!empty($bayar['bukti_paths'])): ?>
                                        <div class="p-3 bg-white rounded-3 border">
                                            <small class="text-muted d-block mb-2 fw-semibold text-center"><i class="fas fa-image me-1 text-primary"></i> Lampiran Bukti Transfer / Pembayaran:</small>
                                            <div class="row g-2 justify-content-center">
                                                <?php foreach ($bayar['bukti_paths'] as $idxB => $bPath): 
                                                    $bTitle = (count($bayar['bukti_paths']) > 1)
                                                        ? ($idxB === 0 ? '1. Bukti DP (Uang Muka)' : '2. Bukti Pelunasan')
                                                        : 'Bukti Pembayaran';
                                                ?>
                                                    <div class="<?= count($bayar['bukti_paths']) > 1 ? 'col-sm-6 col-12' : 'col-12' ?> text-center">
                                                        <div class="border rounded-3 p-2 bg-light h-100 d-flex flex-column align-items-center justify-content-between">
                                                            <small class="fw-bold text-secondary mb-1" style="font-size: 0.76rem;"><?= $bTitle ?></small>
                                                            <a href="<?= htmlspecialchars($bPath) ?>" target="_blank" title="Klik untuk memperbesar">
                                                                <img src="<?= htmlspecialchars($bPath) ?>" alt="<?= $bTitle ?>" class="img-fluid rounded-2 border shadow-sm" style="max-height: 200px; object-fit: contain; background: #fff;" onerror="this.onerror=null; this.src='assets/images/no-image.png';">
                                                            </a>
                                                            <a href="<?= htmlspecialchars($bPath) ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3 mt-2" style="font-size: 0.74rem;">
                                                                <i class="fas fa-external-link-alt me-1"></i> Buka Gambar Penuh
                                                            </a>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-3 text-muted bg-white rounded-3 border">
                                            <i class="fas fa-money-bill-wave fs-3 text-secondary mb-2 d-block"></i>
                                            <span>Pembayaran Tunai / Tanpa Lampiran Bukti Transfer</span>
                                        </div>
                                    <?php endif; ?>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="card p-5 text-center rounded-4 border-0 shadow-sm">
                        <i class="fas fa-receipt fs-1 text-muted mb-3"></i>
                        <h4 class="fw-bold mb-1">Belum Ada Riwayat Pembayaran</h4>
                        <p class="text-muted mb-0">Riwayat pembayaran dengan status Lunas, Belum Lunas, atau Ditolak akan tercatat rapi di halaman ini.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
  </div>

  <!-- Footer -->
  <footer id="kontak" class="footer-semar">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    let totalDetik = <?= (int)$sisa_detik_autobatal ?>;
    const timerElem = document.getElementById('timerCount');
    const timerCardBadges = document.querySelectorAll('.timerCardBadge');

    if (totalDetik > 0 && timerElem) {
        const countdownInterval = setInterval(() => {
            if (totalDetik <= 0) {
                clearInterval(countdownInterval);
                Swal.fire({
                    icon: 'warning',
                    title: 'Batas Waktu Pembayaran Habis!',
                    text: 'Item yang belum dibayar otomatis dibatalkan oleh sistem. Item yang sudah dibayar DP tetap tersimpan aman.',
                    confirmButtonColor: '#0e4430',
                    allowOutsideClick: false
                }).then(() => {
                    window.location.reload();
                });
            } else {
                let menit = Math.floor(totalDetik / 60);
                let detik = totalDetik % 60;
                let formattedTime = (menit < 10 ? '0' + menit : menit) + ':' + (detik < 10 ? '0' + detik : detik);
                timerElem.textContent = formattedTime;
                timerCardBadges.forEach(el => el.textContent = formattedTime);
                totalDetik--;
            }
        }, 1000);
    }

    const formBayar = document.getElementById('form-bayar-tagihan');
    const btnBayar = document.getElementById('btnBayar');
    const selectAllCheckbox = document.getElementById('selectAllTagihan');
    const itemCheckboxes = Array.from(document.querySelectorAll('.checkbox-tagihan:not(:disabled)'));

    function hitungTotalDipilih() {
        let total = 0;
        let checkedCount = 0;

        itemCheckboxes.forEach(chk => {
            const cardId = chk.dataset.cardId;
            const hiddenInputs = document.querySelectorAll('.hidden-sewa-' + cardId);

            if (chk.checked) {
                checkedCount++;
                const sisa = parseInt(chk.dataset.sisa) || 0;
                total += sisa;
                hiddenInputs.forEach(h => h.checked = true);
            } else {
                hiddenInputs.forEach(h => h.checked = false);
            }
        });

        if (selectAllCheckbox) {
            selectAllCheckbox.checked = (checkedCount === itemCheckboxes.length && itemCheckboxes.length > 0);
            selectAllCheckbox.indeterminate = (checkedCount > 0 && checkedCount < itemCheckboxes.length);
        }

        const totalEl = document.getElementById('totalDipilih');
        if (totalEl) {
            totalEl.textContent = total.toLocaleString('id-ID');
        }

        if (btnBayar) {
            btnBayar.disabled = (total === 0 || checkedCount === 0);
        }
    }

    itemCheckboxes.forEach((chk, index) => {
        chk.addEventListener('click', function(e) {
            const isChecked = this.checked;

            if (isChecked) {
                let autoCheckedEarlier = false;
                for (let i = 0; i < index; i++) {
                    if (!itemCheckboxes[i].checked) {
                        itemCheckboxes[i].checked = true;
                        autoCheckedEarlier = true;
                    }
                }
                if (autoCheckedEarlier) {
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2500,
                        timerProgressBar: true,
                        icon: 'info',
                        title: 'Antrean tagihan sebelumnya otomatis dipilih (Prinsip FIFO).'
                    });
                }
            } else {
                let autoUncheckedLater = false;
                for (let i = index + 1; i < itemCheckboxes.length; i++) {
                    if (itemCheckboxes[i].checked) {
                        itemCheckboxes[i].checked = false;
                        autoUncheckedLater = true;
                    }
                }
                if (autoUncheckedLater) {
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2500,
                        timerProgressBar: true,
                        icon: 'info',
                        title: 'Antrean berikutnya otomatis dibatalkan karena antrean sebelumnya tidak dipilih (FIFO).'
                    });
                }
            }

            hitungTotalDipilih();
        });
    });

    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            const isChecked = this.checked;
            itemCheckboxes.forEach(chk => {
                chk.checked = isChecked;
            });
            hitungTotalDipilih();
        });
    }

    if (formBayar) {
        formBayar.addEventListener('submit', function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Lanjutkan ke Pembayaran?',
                text: "Pastikan item tagihan yang Anda pilih sudah sesuai urutan antrean.",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#0e4430',
                confirmButtonText: 'Ya, Lanjutkan',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    formBayar.submit();
                }
            });
        });
    }

    if (window.location.hash === '#rekap') {
        const rekapBtn = document.getElementById('rekap-tab');
        if (rekapBtn) {
            const tab = bootstrap.Tab.getOrCreateInstance(rekapBtn);
            tab.show();
        }
    }
  </script>
</body>
</html>