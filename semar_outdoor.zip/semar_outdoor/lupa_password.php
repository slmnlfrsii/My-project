<?php
session_start();
if (isset($_SESSION['id_users']) || (isset($_SESSION['role']) && $_SESSION['role'] === 'users')) {
  header("Location: index.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>Lupa Kata Sandi – Semar Outdoor</title>
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    *, *::before, *::after {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    html, body {
      min-height: 100vh;
    }

    body {
      background: url('assets/images/g.jpg') center/cover no-repeat fixed;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px 14px;
    }

    .wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      max-width: 440px;
      width: 100%;
      margin: auto;
    }

    .auth-card {
      width: 100%;
      background: #fff;
      padding: 28px 24px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18);
    }

    .auth-card h2 {
      font-size: 23px;
      color: rgb(0, 0, 0);
      font-weight: 700;
      text-align: center;
      margin-bottom: 2px;
    }

    .auth-card p.subtitle {
      font-size: 13px;
      color: #64748b;
      text-align: center;
      margin-bottom: 4px;
      line-height: 1.45;
    }

    form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    form input {
      width: 100%;
      padding: 11px 20px;
      font-size: 14px;
      border: 1px solid #c1c1c1;
      border-radius: 30px;
      outline: none;
      transition: border 0.25s, box-shadow 0.25s;
      background-color: #fff;
    }

    form input:focus {
      border-color: rgb(25, 76, 84);
      box-shadow: 0 0 0 3px rgba(25, 76, 84, 0.12);
    }

    .btn.submit-btn {
      width: 100%;
      padding: 11px 0;
      font-size: 14.5px;
      font-weight: 600;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      background: rgb(25, 76, 84);
      color: #fff;
      transition: transform 0.15s, opacity 0.15s;
      margin-top: 4px;
    }

    .btn.submit-btn:hover {
      opacity: 0.92;
      color: #fff;
    }

    .btn.submit-btn:active {
      transform: scale(0.98);
    }

    .back-prompt {
      text-align: center;
      font-size: 13px;
      color: #64748b;
      margin-top: 4px;
    }

    .back-prompt a {
      color: rgb(25, 76, 84);
      font-weight: 700;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .back-prompt a:hover {
      text-decoration: underline;
      color: #102123;
    }

    @media (max-width: 480px) {
      body {
        padding: 16px 12px;
      }

      .auth-card {
        padding: 22px 18px;
        border-radius: 16px;
        gap: 14px;
      }

      .auth-card h2 {
        font-size: 20px;
      }

      .auth-card p.subtitle {
        font-size: 12px;
      }

      form input {
        padding: 9.5px 18px;
        font-size: 13.5px;
        border-radius: 25px;
      }

      .btn.submit-btn {
        padding: 10px 0;
        font-size: 14px;
        border-radius: 25px;
      }

      .back-prompt {
        font-size: 12px;
      }
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="auth-card">
      <h2>Lupa Kata Sandi</h2>
      <p class="subtitle">Masukkan alamat email yang terdaftar untuk menerima kode verifikasi reset kata sandi.</p>

      <form action="proses_lupa_password.php" method="post">
        <input type="email" name="email" placeholder="Masukkan Alamat Email" autocomplete="email" inputmode="email" required />
        <button type="submit" class="btn submit-btn">Kirim Kode Verifikasi</button>
        <div class="back-prompt">
          Ingat kata sandi? <a href="login.php">Masuk di sini</a>
        </div>
      </form>
    </div>
  </div>

  <!-- SweetAlert2 status popup -->
  <?php if (isset($_GET['status'])): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      <?php if ($_GET['status'] === 'email_tidak_ditemukan'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Email Tidak Ditemukan',
          text: 'Alamat email tidak terdaftar dalam sistem.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
      <?php elseif ($_GET['status'] === 'invalid_email'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Format Email Salah',
          text: 'Harap masukkan format email yang valid.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
      <?php elseif ($_GET['status'] === 'gagal_kirim'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Pengiriman Gagal',
          text: 'Terjadi kendala saat mengirim email verifikasi. Silakan coba lagi.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
      <?php endif; ?>
    });
  </script>
  <?php endif; ?>
</body>
</html>
