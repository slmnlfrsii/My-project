<?php
session_start();
include 'koneksi.php';

$email = trim($_POST['email'] ?? '');
$token = trim($_POST['token'] ?? '');
$otp = trim($_POST['otp'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';

if (empty($email) || (empty($otp) && empty($token))) {
    header("Location: lupa_password.php");
    exit;
}

if (strlen($password) < 6) {
    header("Location: reset_password.php?token=" . urlencode($token) . "&email=" . urlencode($email) . "&status=password_pendek");
    exit;
}

if ($password !== $confirm_password) {
    header("Location: reset_password.php?token=" . urlencode($token) . "&email=" . urlencode($email) . "&status=password_tidak_sama");
    exit;
}

// Cek validitas OTP / Token dan masa aktif (15 menit)
$stmt = $conn->prepare("SELECT id FROM password_resets WHERE email = ? AND (otp = ? OR token = ?) AND expires_at >= NOW() ORDER BY id DESC LIMIT 1");
$stmt->bind_param("sss", $email, $otp, $token);
$stmt->execute();
$res = $stmt->get_result();

if (!$res || $res->num_rows === 0) {
    header("Location: reset_password.php?token=" . urlencode($token) . "&email=" . urlencode($email) . "&status=otp_salah");
    exit;
}
$stmt->close();

// Update password baru di tabel users
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
$stmtUpdate = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmtUpdate->bind_param("ss", $hashedPassword, $email);

if ($stmtUpdate->execute()) {
    $stmtUpdate->close();

    // Hapus data token reset yang sudah digunakan
    $stmtDel = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
    $stmtDel->bind_param("s", $email);
    $stmtDel->execute();
    $stmtDel->close();

    // Bersihkan session reset
    unset($_SESSION['reset_email'], $_SESSION['reset_token'], $_SESSION['reset_otp_preview']);

    header("Location: login.php?status=reset_sukses");
    exit;
} else {
    $stmtUpdate->close();
    header("Location: reset_password.php?token=" . urlencode($token) . "&email=" . urlencode($email) . "&status=gagal");
    exit;
}
?>
