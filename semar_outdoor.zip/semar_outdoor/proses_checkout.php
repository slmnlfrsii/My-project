<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pemesanan Berhasil - Semar Outdoor</title>
    
    <!-- CSS & SweetAlert2 -->
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            color: #ffffff;
        }
    </style>
</head>
<body>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'success',
                title: '<span style="font-family: \'Quicksand\', sans-serif; font-weight: 800; color: #162d2f;">Pemesanan Berhasil!</span>',
                html: `
                    <div style="font-size: 0.95rem; color: #475569; line-height: 1.6; margin-top: 8px;">
                        Pesanan sewa Anda telah berhasil dicatat oleh sistem.<br>
                        Silakan lakukan pembayaran <strong>Minimal Uang Muka (DP)</strong> sebesar Rp 10.000 atau Pelunasan untuk mengunci ketersediaan alat.
                    </div>
                `,
                confirmButtonText: '<i class="fas fa-file-invoice-dollar me-1"></i> Ke Halaman Tagihan',
                confirmButtonColor: '#0e4430',
                allowOutsideClick: false,
                customClass: {
                    popup: 'rounded-4 shadow-lg border-0',
                    confirmButton: 'px-4 py-2 rounded-pill fw-bold'
                }
            }).then((result) => {
                window.location.href = "tagihan.php";
            });

            // Auto redirect setelah 8 detik jika pengguna tidak menekan tombol
            setTimeout(function() {
                window.location.href = "tagihan.php";
            }, 8000);
        });
    </script>
</body>
</html>
