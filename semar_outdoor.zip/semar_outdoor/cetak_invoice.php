<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

// Cek hak akses (Bisa diakses oleh User pemilik invoice atau Admin yang sedang login)
$is_admin = isset($_SESSION['id_admin']);
$id_users_session = isset($_SESSION['id_users']) ? (int)$_SESSION['id_users'] : 0;

if (!$is_admin && $id_users_session <= 0) {
    header("Location: login.php");
    exit();
}

$id_pembayaran = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$no_tagihan = isset($_GET['no_tagihan']) ? trim($_GET['no_tagihan']) : '';
$id_sewa_param = isset($_GET['id_sewa']) ? (int)$_GET['id_sewa'] : 0;

// Load Logo Base64
$logoFile = __DIR__ . '/assets/images/logo.png';
$logoBase64 = '';
if (file_exists($logoFile)) {
    $logoBase64 = 'data:image/png;base64,' . base64_encode(file_get_contents($logoFile));
}

// 1. Cari data pembayaran utama
$payment = null;
if ($id_pembayaran > 0) {
    $qPay = mysqli_query($conn, "
        SELECT p.*, u.nama AS nama_user, u.email AS email_user, u.no_hp AS no_telp_user,
               adm.nama AS nama_admin, adm.email AS email_admin, adm.foto AS foto_admin
        FROM pembayaran p
        LEFT JOIN users u ON p.id_users = u.id
        LEFT JOIN admin adm ON p.id_admin = adm.id
        WHERE p.id = $id_pembayaran
    ");
    $payment = mysqli_fetch_assoc($qPay);
} elseif (!empty($no_tagihan)) {
    // Cari berdasarkan no_tagihan
    $safeTag = mysqli_real_escape_string($conn, $no_tagihan);
    $qPay = mysqli_query($conn, "
        SELECT p.*, u.nama AS nama_user, u.email AS email_user, u.no_hp AS no_telp_user,
               adm.nama AS nama_admin, adm.email AS email_admin, adm.foto AS foto_admin
        FROM pembayaran p
        LEFT JOIN users u ON p.id_users = u.id
        LEFT JOIN admin adm ON p.id_admin = adm.id
        WHERE EXISTS (
            SELECT 1 FROM sewa s 
            WHERE s.no_tagihan = '$safeTag' 
            AND (p.id_sewa = s.id OR FIND_IN_SET(s.id, p.id_sewa))
        )
        ORDER BY p.tanggal_bayar DESC, p.id DESC
        LIMIT 1
    ");
    $payment = mysqli_fetch_assoc($qPay);
} elseif ($id_sewa_param > 0) {
    $qPay = mysqli_query($conn, "
        SELECT p.*, u.nama AS nama_user, u.email AS email_user, u.no_hp AS no_telp_user,
               adm.nama AS nama_admin, adm.email AS email_admin, adm.foto AS foto_admin
        FROM pembayaran p
        LEFT JOIN users u ON p.id_users = u.id
        LEFT JOIN admin adm ON p.id_admin = adm.id
        WHERE FIND_IN_SET('$id_sewa_param', p.id_sewa)
        ORDER BY p.tanggal_bayar DESC, p.id DESC
        LIMIT 1
    ");
    $payment = mysqli_fetch_assoc($qPay);
}

// Keamanan: Jika user biasa, pastikan hanya bisa membuka invoice miliknya sendiri
if (!$is_admin && $payment && (int)$payment['id_users'] !== $id_users_session) {
    die("Akses ditolak: Anda tidak memiliki izin untuk melihat invoice ini.");
}

// 2. Cari seluruh item sewa yang berkaitan dengan transaksi ini
$items_sewa = [];
$total_subtotal_items = 0;
$total_ongkir = 0;
$total_denda = 0;
$inv_number = '';
$metode_pengambilan = 'Ambil Ke Toko';
$tanggal_sewa_display = '';
$durasi_display = 1;
$user_info = [
    'nama' => $payment['nama_user'] ?? 'Pelanggan',
    'email' => $payment['email_user'] ?? '',
    'no_hp' => $payment['no_telp_user'] ?? '-'
];

if ($payment) {
    $id_sewa_list = array_map('intval', explode(',', $payment['id_sewa']));
    $first_sewa_id = $id_sewa_list[0] ?? 0;
    
    // Ambil no_tagihan dari sewa pertama
    if ($first_sewa_id > 0) {
        $qFirst = mysqli_query($conn, "SELECT no_tagihan FROM sewa WHERE id = $first_sewa_id");
        if ($rF = mysqli_fetch_assoc($qFirst)) {
            if (!empty($rF['no_tagihan'])) {
                $inv_number = $rF['no_tagihan'];
            }
        }
    }

    if (!empty($inv_number)) {
        // Ambil semua item dengan no_tagihan ini
        $safeInv = mysqli_real_escape_string($conn, $inv_number);
        $qItems = mysqli_query($conn, "
            SELECT s.*, COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat, a.gambar AS gambar_alat
            FROM sewa s
            LEFT JOIN alat a ON s.id_alat = a.id
            WHERE s.no_tagihan = '$safeInv'
            ORDER BY s.id ASC
        ");
    } else {
        // Ambil berdasarkan id_list
        $id_csv = implode(',', $id_sewa_list);
        $qItems = mysqli_query($conn, "
            SELECT s.*, COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat, a.gambar AS gambar_alat
            FROM sewa s
            LEFT JOIN alat a ON s.id_alat = a.id
            WHERE s.id IN ($id_csv)
            ORDER BY s.id ASC
        ");
    }

    if ($qItems && mysqli_num_rows($qItems) > 0) {
        while ($rowItem = mysqli_fetch_assoc($qItems)) {
            if (empty($inv_number) && !empty($rowItem['no_tagihan'])) {
                $inv_number = $rowItem['no_tagihan'];
            }
            $metode_pengambilan = $rowItem['metode_pengambilan'] ?? $metode_pengambilan;
            $tanggal_sewa_display = $rowItem['tanggal_sewa'] ?? $tanggal_sewa_display;
            $durasi_display = (int)($rowItem['durasi'] ?? 1);

            $harga_satuan = (float)$rowItem['harga_satuan_alat'];
            $is_gas = (stripos($rowItem['nama_produk'], 'gas') !== false);
            $sub_item = ($harga_satuan * (int)$rowItem['qty'] * ($is_gas ? 1 : (int)$rowItem['durasi']));
            $total_subtotal_items += $sub_item;
            $total_ongkir += (float)$rowItem['biaya_pengambilan'];

            // Denda
            $denda = 0;
            if (!$is_gas && !empty($rowItem['tanggal_sewa'])) {
                $tglKembali = date('Y-m-d', strtotime($rowItem['tanggal_sewa'] . ' + ' . $rowItem['durasi'] . ' days'));
                $tglCek = !empty($rowItem['tanggal_dikembalikan']) ? date('Y-m-d', strtotime($rowItem['tanggal_dikembalikan'])) : date('Y-m-d');
                if ($tglCek > $tglKembali) {
                    $selisih = floor((strtotime($tglCek) - strtotime($tglKembali)) / 86400);
                    if ($selisih > 0) {
                        $denda = $selisih * 10000;
                    }
                }
            }
            $total_denda += $denda;

            $rowItem['harga_satuan_val'] = $harga_satuan;
            $rowItem['subtotal_val'] = $sub_item;
            $rowItem['denda_val'] = $denda;
            $items_sewa[] = $rowItem;
        }
    }
}

// Fallback no_tagihan
if (empty($inv_number)) {
    $inv_number = !empty($no_tagihan) ? $no_tagihan : ('INV-' . date('Ymd', strtotime($payment['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $payment['id'] ?? 1));
}

// Hitung total seluruh pembayaran yang sudah masuk untuk invoice ini
$total_sudah_dibayar = 0;
if (!empty($inv_number) && $payment) {
    $safeInv = mysqli_real_escape_string($conn, $inv_number);
    $qAllBayar = mysqli_query($conn, "
        SELECT SUM(jumlah_bayar) AS total_masuk 
        FROM pembayaran 
        WHERE (
            id_sewa = '{$payment['id_sewa']}'
            OR FIND_IN_SET('{$payment['id_sewa']}', id_sewa)
            OR EXISTS (SELECT 1 FROM sewa s3 WHERE s3.no_tagihan = '$safeInv' AND (pembayaran.id_sewa = s3.id OR FIND_IN_SET(s3.id, pembayaran.id_sewa)))
        )
        AND status IN ('Lunas', 'Belum lunas')
    ");
    if ($rAB = mysqli_fetch_assoc($qAllBayar)) {
        $total_sudah_dibayar = (float)($rAB['total_masuk'] ?? 0);
    }
}
if ($total_sudah_dibayar == 0 && $payment) {
    $total_sudah_dibayar = (float)($payment['jumlah_bayar'] ?? 0);
}

$grand_total = ($total_subtotal_items > 0) ? ($total_subtotal_items + $total_ongkir + $total_denda) : (float)($payment['total_tagihan'] ?? 0);
$sisa_tagihan_akhir = max(0, $grand_total - $total_sudah_dibayar);
$status_bayar = $payment['status'] ?? 'Menunggu konfirmasi';
$is_lunas = (strtolower(trim($status_bayar)) === 'lunas' || $sisa_tagihan_akhir <= 0);

// Nama admin verifikator
$nama_admin_verifikasi = !empty($payment['nama_admin']) ? $payment['nama_admin'] : 'Admin Operasional Semar Outdoor';
$tanggal_konfirmasi_display = !empty($payment['tanggal_konfirmasi']) 
    ? date('d F Y, H:i', strtotime($payment['tanggal_konfirmasi'])) . ' WIB'
    : (!empty($payment['tanggal_bayar']) ? date('d F Y, H:i', strtotime($payment['tanggal_bayar'])) . ' WIB' : date('d F Y, H:i') . ' WIB');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Invoice Pembayaran #<?= htmlspecialchars($inv_number) ?> - Semar Outdoor</title>
    
    <!-- Fonts & Bootstrap 5 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --brand-green: #0e4430;
            --brand-green-dark: #09281c;
            --brand-gold: #c27803;
            --text-dark: #0f172a;
            --text-muted: #64748b;
            --border-color: #cbd5e1;
        }

        * { box-sizing: border-box; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 12px;
            color: var(--text-dark);
            background-color: #f1f5f9;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }

        @page {
            size: A4 portrait;
            margin: 12mm 14mm 12mm 14mm;
        }

        .invoice-card {
            max-width: 820px;
            margin: 24px auto;
            background: #ffffff;
            padding: 36px 42px;
            border-radius: 14px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: 1px solid #e2e8f0;
            position: relative;
        }

        .no-print-bar {
            max-width: 820px;
            margin: 20px auto 0 auto;
            padding: 12px 20px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid #e2e8f0;
        }

        /* Kop Surat */
        .kop-invoice {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2.5px solid var(--brand-green);
            padding-bottom: 16px;
            margin-bottom: 20px;
            position: relative;
        }

        .kop-invoice::after {
            content: "";
            position: absolute;
            bottom: -5px;
            left: 0;
            right: 0;
            height: 1px;
            background: var(--brand-green);
        }

        .kop-brand-wrap {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .kop-logo {
            width: 76px;
            height: 76px;
            object-fit: contain;
            border-radius: 50%;
            padding: 2px;
            background: #ffffff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border: 1px solid #e2e8f0;
        }

        .kop-title {
            font-size: 21px;
            font-weight: 800;
            color: var(--brand-green);
            letter-spacing: 0.8px;
            margin: 0 0 2px 0;
            text-transform: uppercase;
        }

        .kop-sub {
            font-size: 11px;
            font-weight: 600;
            color: #334155;
            margin: 0 0 3px 0;
        }

        .kop-desc {
            font-size: 9.5px;
            color: var(--text-muted);
            margin: 0;
            line-height: 1.4;
        }

        /* Invoice Meta Header */
        .inv-meta-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            background: #f8fafc;
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 14px 18px;
            margin-bottom: 20px;
        }

        .inv-number-badge {
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 14px;
            font-weight: 800;
            color: var(--brand-green);
        }

        .badge-status-lunas {
            display: inline-block;
            background-color: #dcfce7;
            color: #15803d;
            border: 1.5px solid #86efac;
            font-weight: 800;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-status-dp {
            display: inline-block;
            background-color: #fef3c7;
            color: #b45309;
            border: 1.5px solid #fcd34d;
            font-weight: 800;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Table */
        .inv-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 11px;
        }

        .inv-table th {
            background-color: var(--brand-green) !important;
            color: #ffffff !important;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 9.5px;
            letter-spacing: 0.4px;
            padding: 8px 10px;
            border: 1px solid var(--brand-green-dark);
            text-align: center;
        }

        .inv-table td {
            padding: 8px 10px;
            border: 1px solid var(--border-color);
            vertical-align: middle;
        }

        .inv-table tbody tr:nth-child(even) {
            background-color: #f8fafc;
        }

        /* Verification Admin Box */
        .admin-verification-box {
            background: #f0fdf4;
            border: 1.5px dashed #86efac;
            border-radius: 10px;
            padding: 14px 18px;
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            page-break-inside: avoid;
        }

        .admin-badge-avatar {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: var(--brand-green);
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: bold;
            border: 2px solid #ffffff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        /* Watermark */
        .watermark-status {
            position: absolute;
            top: 45%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-25deg);
            font-size: 75px;
            font-weight: 900;
            color: rgba(14, 68, 48, 0.05);
            text-transform: uppercase;
            letter-spacing: 6px;
            pointer-events: none;
            user-select: none;
            z-index: 0;
            border: 8px solid rgba(14, 68, 48, 0.05);
            padding: 10px 30px;
            border-radius: 16px;
        }

        @media print {
            .no-print, .no-print-bar {
                display: none !important;
            }
            body {
                background: #ffffff !important;
                padding: 0 !important;
            }
            .invoice-card {
                max-width: 100% !important;
                width: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
                border: none !important;
                box-shadow: none !important;
            }
        }
    </style>
</head>
<body>

<!-- Toolbar Screen -->
<div class="no-print-bar no-print">
    <div>
        <?php 
        $from = $_GET['from'] ?? '';
        
        // 1. Jika dibuka dari sisi User / Pelanggan (Tagihan)
        if ($from === 'user' || $from === 'tagihan') {
            $back_url = "tagihan.php?tab=rekap";
            $back_label = "Kembali ke Halaman Tagihan";
        } 
        // 2. Jika dibuka dari sisi Admin Pembayaran
        elseif ($from === 'admin' || $from === 'pembayaran') {
            $back_url = "admin/pembayaran/pembayaran.php";
            $back_label = "Kembali ke Pembayaran Admin";
        } 
        // 3. Jika dibuka dari sisi Admin Pengembalian
        elseif ($from === 'pengembalian_admin') {
            $back_url = "admin/pengembalian/pengembalian.php";
            $back_label = "Kembali ke Pengembalian Admin";
        } 
        // 4. Jika dibuka dari sisi Admin Riwayat
        elseif ($from === 'riwayat_admin') {
            $back_url = "admin/riwayat/riwayat.php";
            $back_label = "Kembali ke Riwayat Sewa Admin";
        } 
        // 5. Fallback otomatis berdasarkan session aktif
        elseif ($is_admin && !$id_users_session) {
            $back_url = "admin/pembayaran/pembayaran.php";
            $back_label = "Kembali ke Pembayaran Admin";
        } else {
            $back_url = "tagihan.php?tab=rekap";
            $back_label = "Kembali ke Halaman Tagihan";
        }
        ?>
        <a href="<?= $back_url ?>" class="btn btn-outline-secondary btn-sm fw-bold">
            <i class="fa fa-arrow-left me-1"></i> <?= $back_label ?>
        </a>
    </div>
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-danger btn-sm fw-bold px-4 shadow-sm" onclick="window.print()">
            <i class="fa fa-print me-1"></i> Cetak / Simpan PDF Struk
        </button>
    </div>
</div>

<!-- Lembar Struk Invoice -->
<div class="invoice-card">
    <!-- Watermark Background -->
    <div class="watermark-status">
        <?= $is_lunas ? 'LUNAS' : 'TERVERIFIKASI DP' ?>
    </div>

    <!-- Kop Surat Toko -->
    <div class="kop-invoice">
        <div class="kop-brand-wrap">
            <?php if (!empty($logoBase64)): ?>
                <img src="<?= $logoBase64 ?>" alt="Logo Semar Outdoor" class="kop-logo">
            <?php endif; ?>
            <div>
                <h1 class="kop-title">SEMAR OUTDOOR EQUIPMENT</h1>
                <p class="kop-sub">Rental & Persewaan Perlengkapan Camping, Pendakian, & Alat Petualangan Outdoor</p>
                <p class="kop-desc">
                    Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466<br>
                    <span>WhatsApp/Telp: 08xx-xxxx-xxxx</span> &bull; <span>Email: semaroutdoor@gmail.com</span> &bull; <span>Instagram: @semaroutdoor</span>
                </p>
            </div>
        </div>
        <div class="text-end">
            <span class="badge bg-dark text-white py-2 px-3 fw-bold font-monospace" style="font-size: 10px; letter-spacing: 0.5px;">
                STRUK PEMBAYARAN RESMI
            </span>
        </div>
    </div>

    <!-- Info Tagihan & Penyewa -->
    <div class="inv-meta-grid">
        <div>
            <div class="text-muted small mb-1" style="font-size: 9.5px; text-transform: uppercase; font-weight: 700;">Nomor Invoice / Tagihan:</div>
            <div class="inv-number-badge mb-2"><?= htmlspecialchars($inv_number) ?></div>
            <div class="small text-muted">
                Tanggal Sewa: <strong><?= !empty($tanggal_sewa_display) ? date('d F Y', strtotime($tanggal_sewa_display)) : '-' ?></strong> (Durasi: <?= $durasi_display ?> Hari)<br>
                Metode Pengambilan: <strong><?= htmlspecialchars($metode_pengambilan) ?></strong>
            </div>
        </div>
        <div class="text-end">
            <div class="text-muted small mb-1" style="font-size: 9.5px; text-transform: uppercase; font-weight: 700;">Status Pembayaran:</div>
            <div class="mb-2">
                <span class="<?= $is_lunas ? 'badge-status-lunas' : 'badge-status-dp' ?>">
                    <i class="fas <?= $is_lunas ? 'fa-check-circle' : 'fa-hourglass-half' ?> me-1"></i>
                    <?= $is_lunas ? 'LUNAS' : 'BELUM LUNAS (UANG MUKA / DP)' ?>
                </span>
            </div>
            <div class="small text-muted">
                Nama Penyewa: <strong><?= htmlspecialchars($user_info['nama']) ?></strong><br>
                Email: <?= htmlspecialchars($user_info['email']) ?>
            </div>
        </div>
    </div>

    <!-- Tabel Rincian Sewa -->
    <table class="inv-table">
        <thead>
            <tr>
                <th style="width: 35px;">No</th>
                <th style="text-align: left;">Nama Perlengkapan / Produk</th>
                <th style="width: 60px;">Qty</th>
                <th style="width: 70px;">Durasi</th>
                <th style="width: 120px; text-align: right;">Harga Satuan</th>
                <th style="width: 130px; text-align: right;">Subtotal</th>
            </tr>
        </thead>
        <tbody>
        <?php 
        $no = 1;
        if (!empty($items_sewa)):
            foreach ($items_sewa as $it):
        ?>
            <tr>
                <td class="text-center fw-bold"><?= $no++ ?></td>
                <td><strong><?= htmlspecialchars($it['nama_produk']) ?></strong></td>
                <td class="text-center fw-bold"><?= (int)$it['qty'] ?> unit</td>
                <td class="text-center"><?= (int)$it['durasi'] ?> hari</td>
                <td class="text-end">Rp <?= number_format($it['harga_satuan_val'], 0, ',', '.') ?></td>
                <td class="text-end fw-bold">Rp <?= number_format($it['subtotal_val'], 0, ',', '.') ?></td>
            </tr>
        <?php 
            endforeach;
        else:
        ?>
            <tr>
                <td class="text-center fw-bold">1</td>
                <td><strong>Peralatan Camping & Outdoor</strong></td>
                <td class="text-center fw-bold">1 unit</td>
                <td class="text-center">-</td>
                <td class="text-end">Rp <?= number_format($payment['total_tagihan'] ?? 0, 0, ',', '.') ?></td>
                <td class="text-end fw-bold">Rp <?= number_format($payment['total_tagihan'] ?? 0, 0, ',', '.') ?></td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <!-- Rincian Kalkulasi Pembayaran -->
    <div class="row g-3">
        <div class="col-6">
            <div class="p-3 bg-light rounded-3 border h-100">
                <h6 class="fw-bold mb-2 text-dark" style="font-size: 11px; text-transform: uppercase;">
                    <i class="fas fa-wallet text-success me-1"></i> Informasi Pembayaran
                </h6>
                <div class="small text-muted mb-1">
                    Metode Pembayaran: <strong><?= htmlspecialchars($payment['metode'] ?? 'Transfer / Tunai') ?></strong>
                </div>
                <div class="small text-muted mb-1">
                    Waktu Pembayaran: <strong><?= !empty($payment['tanggal_bayar']) ? date('d/m/Y H:i', strtotime($payment['tanggal_bayar'])) . ' WIB' : '-' ?></strong>
                </div>
                <div class="small text-muted">
                    No. Ref Transaksi: <span class="font-monospace fw-bold text-dark">TRX-<?= sprintf('%05d', $payment['id'] ?? 1) ?></span>
                </div>
            </div>
        </div>

        <div class="col-6">
            <div class="p-3 bg-light rounded-3 border">
                <div class="d-flex justify-content-between small mb-1">
                    <span class="text-muted">Subtotal Produk:</span>
                    <span class="fw-semibold">Rp <?= number_format($total_subtotal_items, 0, ',', '.') ?></span>
                </div>
                <?php if ($total_ongkir > 0): ?>
                    <div class="d-flex justify-content-between small mb-1">
                        <span class="text-muted">Biaya Pengambilan / Ongkir:</span>
                        <span class="fw-semibold">Rp <?= number_format($total_ongkir, 0, ',', '.') ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($total_denda > 0): ?>
                    <div class="d-flex justify-content-between small text-danger mb-1">
                        <span>Denda Keterlambatan:</span>
                        <span class="fw-bold">+ Rp <?= number_format($total_denda, 0, ',', '.') ?></span>
                    </div>
                <?php endif; ?>
                <div class="d-flex justify-content-between fw-bold pt-1 border-top mb-1">
                    <span>Total Tagihan:</span>
                    <span>Rp <?= number_format($grand_total, 0, ',', '.') ?></span>
                </div>
                <div class="d-flex justify-content-between fw-bold text-success mb-1">
                    <span>Jumlah yang Sudah Dibayar:</span>
                    <span>Rp <?= number_format($total_sudah_dibayar, 0, ',', '.') ?></span>
                </div>
                <div class="d-flex justify-content-between fw-bold <?= ($sisa_tagihan_akhir > 0) ? 'text-danger' : 'text-success' ?> pt-1 border-top" style="font-size: 13px;">
                    <span>Sisa Tagihan:</span>
                    <span><?= ($sisa_tagihan_akhir > 0) ? 'Rp ' . number_format($sisa_tagihan_akhir, 0, ',', '.') : 'LUNAS (Rp 0)' ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- KOTAK VERIFIKASI ADMIN RESMI -->
    <div class="admin-verification-box">
        <div class="d-flex align-items-center gap-3">
            <div class="admin-badge-avatar">
                <i class="fas fa-user-shield"></i>
            </div>
            <div>
                <span class="badge bg-success bg-opacity-25 text-success border border-success fw-bold px-2 py-1 mb-1" style="font-size: 8.5px;">
                    <i class="fas fa-check-double me-1"></i> TELAH DIKONFIRMASI OLEH ADMIN
                </span>
                <h6 class="fw-bold mb-0 text-dark" style="font-size: 13px;">
                    <?= htmlspecialchars($nama_admin_verifikasi) ?>
                </h6>
                <small class="text-muted" style="font-size: 9.5px;">
                    Petugas Kasir & Verifikasi Pembayaran &bull; Semar Outdoor Management
                </small>
            </div>
        </div>
        <div class="text-end">
            <div class="text-muted" style="font-size: 9px; text-transform: uppercase; font-weight: 700;">Waktu Konfirmasi:</div>
            <div class="fw-bold text-dark" style="font-size: 11px;"><?= $tanggal_konfirmasi_display ?></div>
            <span class="text-success fw-bold" style="font-size: 9px;">
                <i class="fas fa-shield-alt me-1"></i> Data Sah & Terverifikasi
            </span>
        </div>
    </div>

    <!-- Footer Catatan Struk -->
    <div class="text-center text-muted mt-4 pt-3 border-top" style="font-size: 9.5px;">
        <p class="mb-1">Terima kasih telah mempercayakan petualangan camping & outdoor Anda kepada <strong>Semar Outdoor Equipment</strong>.</p>
        <p class="mb-0 text-muted">Simpan struk ini sebagai bukti pembayaran dan bukti pengambilan / pengembalian alat.</p>
    </div>
</div>

</body>
</html>
