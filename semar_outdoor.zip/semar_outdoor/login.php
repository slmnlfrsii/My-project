<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login – Healing Outdoor</title>
  <link rel="stylesheet" href="assets/css/navbar.css">
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="assets/css/login.css">
  <!-- SweetAlert2 CDN -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>body {
  background: url("assets/images/g.jpg") center/cover no-repeat fixed;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}</style>
</head>
<body>
<?php include 'navbar.php'; ?>

  <div class="wrapper">
    <!-- Logo + Teks -->
    <div class="banner">
      <img src="assets/images/logo.png"
     alt="Logo"
     class="logo"
     style="width:250px;">
      <h2>Semar Outdoor</h2>
      <p>Rental alat outdoor berkualitas</p>
    </div>

    <!-- Card Login -->
    <div class="login-card">
      <h2>Login</h2>
      <form action="proses_login.php" method="post">
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <a href="#" class="forgot">Forgot Password?</a>
        <div class="actions">
          <button type="submit" class="btn login">Login</button>
          <button type="button" class="btn signup" onclick="window.location.href='register.php'">Register</button>
        </div>
      </form>
    </div>
  </div>

  <?php if (isset($_GET['status'])): ?>
    <script>
      document.addEventListener("DOMContentLoaded", function () {
        if (typeof Swal !== "undefined") {
          <?php if ($_GET['status'] === 'registered'): ?>
            Swal.fire({
              icon: 'success',
              title: 'Registrasi Berhasil',
              text: 'Silakan login untuk melanjutkan.',
              confirmButtonColor: '#28a745'
            });
          <?php elseif ($_GET['status'] === 'failed'): ?>
            Swal.fire({
              icon: 'error',
              title: 'Login Gagal',
              text: 'Email atau password salah!',
              confirmButtonColor: '#d10d1d'
            });
          <?php elseif ($_GET['status'] === 'success'): ?>
            Swal.fire({
              icon: 'success',
              title: 'Login Berhasil',
              text: 'Selamat datang kembali!',
              confirmButtonColor: '#28a745'
            });
          <?php endif; ?>
        } else {
          console.error("SweetAlert2 gagal dimuat.");
        }
      });
    </script>
  <?php endif; ?>
</body>
</html>
