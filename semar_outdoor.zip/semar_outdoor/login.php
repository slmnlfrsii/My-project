<?php
session_start();
if (isset($_SESSION['id_users']) || (isset($_SESSION['role']) && $_SESSION['role'] === 'users')) {
  header("Location: index.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Login – Semar Outdoor</title>
  
  <!-- 1. Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  
  <!-- 2. Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  
  <!-- 🌟 3. FONT AWESOME JS (SVG RENDERING - SOLUSI ANTI KOTAK KOSONG) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js" crossorigin="anonymous"></script>

  <!-- 4. Stylesheet Lokal -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link rel="stylesheet" href="assets/css/login.css?v=<?= time() ?>">
  
  <!-- SweetAlert2 CDN -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  
  <style>
    html, body {
      min-height: 100vh;
    }

    body {
      background: url("assets/images/g.jpg") center/cover no-repeat fixed;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      padding: 16px 14px;
      padding-top: 60px; /* Posisi form ditarik lebih ke atas */
      min-height: 100vh;
      box-sizing: border-box;
    }

    .wrapper {
      margin-top: 15px;
    }

    /* Styling tombol login */
    .btn.login {
      width: 100%;
      padding: 11px 0;
      font-size: 14.5px;
      font-weight: 600;
      border: none;
      border-radius: 30px;
      background: rgb(25, 76, 84) !important;
      color: #ffffff !important;
      cursor: pointer;
      transition: transform 0.15s, opacity 0.15s;
      margin-top: 4px;
    }

    .btn.login:hover {
      opacity: 0.92;
      color: #ffffff !important;
    }

    .btn.login:active {
      transform: scale(0.98);
    }

    .register-prompt {
      text-align: center;
      font-size: 13.5px;
      color: #64748b;
      margin-top: 4px;
    }

    .register-prompt a {
      color: rgb(25, 76, 84);
      font-weight: 700;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .register-prompt a:hover {
      text-decoration: underline;
      color: #102123;
    }

    /* Penyesuaian khusus tampilan Android / Mobile */
    @media (max-width: 768px) {
      body {
        padding: 12px;
        padding-top: 55px;
      }

      .wrapper {
        margin-top: 10px;
        flex-direction: column !important;
        width: 100% !important;
        max-width: 380px !important;
      }

      .banner, .login-card {
        width: 100% !important;
        box-sizing: border-box;
      }

      .banner {
        margin-bottom: 12px;
      }

      .banner .logo {
        width: 130px !important;
        height: auto;
      }

      .banner h2 {
        font-size: 1.35rem;
        margin-bottom: 2px;
      }

      .banner p {
        font-size: 0.82rem;
        margin-bottom: 8px;
      }

      .login-card {
        padding: 20px 16px;
      }

      .login-card input {
        width: 100% !important;
        box-sizing: border-box;
      }
    }
  </style>
</head>
<body>

  <!-- Header Navbar -->
  <?php include 'navbar.php'; ?>

  <div class="wrapper">
    <!-- Logo + Teks -->
    <div class="banner">
      <img src="assets/images/logo.png" alt="Logo" class="logo" style="width:250px;">
      <h2>Semar Outdoor</h2>
      <p>Rental alat outdoor berkualitas</p>
    </div>

    <!-- Card Login -->
    <div class="login-card">
      <h2>Login</h2>
      <form action="proses_login.php" method="post">
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <a href="lupa_password.php" class="forgot">Lupa Kata Sandi?</a>
        
        <button type="submit" class="btn login">Login</button>
        
        <div class="register-prompt">
          Belum punya akun? <a href="register.php">Daftar di sini</a>
        </div>
      </form>
    </div>
  </div>

  <!-- Script JS Bootstrap Bundle (Wajib untuk membuka menu collapse navbar di HP) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Notifikasi SweetAlert2 -->
  <?php if (isset($_GET['status'])): ?>
    <script>
      document.addEventListener("DOMContentLoaded", function () {
        if (typeof Swal !== "undefined") {
          <?php if ($_GET['status'] === 'registered'): ?>
            Swal.fire({
              icon: 'success',
              title: 'Registrasi Berhasil',
              text: 'Silakan login untuk melanjutkan.',
              confirmButtonColor: 'rgb(25, 76, 84)'
            });
          <?php elseif ($_GET['status'] === 'reset_sukses'): ?>
            Swal.fire({
              icon: 'success',
              title: 'Kata Sandi Berhasil Diubah',
              text: 'Silakan masuk menggunakan kata sandi baru Anda.',
              confirmButtonColor: 'rgb(25, 76, 84)'
            });
          <?php elseif ($_GET['status'] === 'failed'): ?>
            Swal.fire({
              icon: 'error',
              title: 'Login Gagal',
              text: 'Email atau password salah!',
              confirmButtonColor: 'rgb(25, 76, 84)'
            });
          <?php elseif ($_GET['status'] === 'success'): ?>
            Swal.fire({
              icon: 'success',
              title: 'Login Berhasil',
              text: 'Selamat datang kembali!',
              confirmButtonColor: 'rgb(25, 76, 84)'
            });
          <?php endif; ?>
        }
      });
    </script>
  <?php endif; ?>

</body>
</html>