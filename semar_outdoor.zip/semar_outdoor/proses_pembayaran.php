<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
include 'koneksi.php';

// Helper function untuk merender alert SweetAlert interaktif (mencegah blank page)
function renderSweetAlert($icon, $title, $text, $redirectUrl = null) {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($title) ?> - Semar Outdoor</title>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Quicksand:wght@700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
        <style>
            body {
                font-family: 'Plus Jakarta Sans', sans-serif;
                background-color: #0e4430;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
            }
        </style>
    </head>
    <body>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon: '<?= $icon ?>',
                    title: '<?= addslashes($title) ?>',
                    text: '<?= addslashes($text) ?>',
                    confirmButtonColor: '<?= ($icon === "success") ? "#0e4430" : "#dc3545" ?>',
                    confirmButtonText: '<?= ($icon === "success") ? "Lihat Tagihan" : "Kembali & Lengkapi Form" ?>',
                    allowOutsideClick: false
                }).then((result) => {
                    <?php if ($redirectUrl): ?>
                        window.location.href = '<?= $redirectUrl ?>';
                    <?php else: ?>
                        window.history.back();
                    <?php endif; ?>
                });
            });
        </script>
    </body>
    </html>
    <?php
    exit();
}

if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: tagihan.php");
    exit();
}

$id_users = (int)$_SESSION['id_users'];
$id_sewa_array = $_POST['id_sewa'] ?? [];
$metode = trim($_POST['metode'] ?? '');
$tipe_pembayaran = trim($_POST['tipe_pembayaran'] ?? '');
$jumlah_bayar = (float)($_POST['jumlah_bayar'] ?? 0);
$tanggal_bayar = date('Y-m-d H:i:s');

// 1. Validasi Sewa Terpilih
if (empty($id_sewa_array)) {
    renderSweetAlert('warning', 'Tidak Ada Tagihan Dipilih', 'Silakan pilih minimal satu item sewa yang akan dibayar dari daftar tagihan Anda.', 'tagihan.php');
}

// 2. Validasi Metode Pembayaran
if (empty($metode)) {
    renderSweetAlert('warning', 'Metode Pembayaran Kosong', 'Silakan pilih metode transfer bank atau e-wallet (BCA, BRI, GoPay, atau DANA) terlebih dahulu.');
}

// 3. Validasi Jenis Pembayaran (Wajib Dipilih: DP atau Lunas)
if (empty($tipe_pembayaran) || !in_array($tipe_pembayaran, ['dp', 'lunas'])) {
    renderSweetAlert('warning', 'Jenis Pembayaran Belum Dipilih', 'Anda wajib menentukan opsi pembayaran (Bayar Uang Muka DP atau Pelunasan Penuh).');
}

// 4. Validasi File Bukti Pembayaran
if (!isset($_FILES['bukti']) || $_FILES['bukti']['error'] !== UPLOAD_ERR_OK || empty($_FILES['bukti']['name'])) {
    renderSweetAlert('warning', 'Bukti Transfer Belum Diunggah', 'Silakan unggah foto atau screenshot bukti transfer pembayaran Anda!');
}

$file_tmp = $_FILES["bukti"]["tmp_name"];
$file_ext = strtolower(pathinfo($_FILES["bukti"]["name"], PATHINFO_EXTENSION));
$allowed_ext = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];

if (!in_array($file_ext, $allowed_ext)) {
    renderSweetAlert('error', 'Format File Tidak Didukung', 'Hanya file gambar (JPG, PNG, WEBP) atau PDF yang diperbolehkan untuk bukti pembayaran.');
}

/* AMBIL DATA SEWA DENGAN HARGA SATUAN DARI TABEL ALAT */
$id_list = implode(",", array_map('intval', $id_sewa_array));

$query = "
SELECT s.*, COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat,
(
    CASE 
        WHEN LOWER(s.nama_produk) LIKE '%gas%'
        THEN 0
        WHEN CURDATE() > DATE_ADD(s.tanggal_sewa, INTERVAL s.durasi DAY)
        THEN DATEDIFF(CURDATE(), DATE_ADD(s.tanggal_sewa, INTERVAL s.durasi DAY)) * 10000
        ELSE 0
    END
) AS denda
FROM sewa s
LEFT JOIN alat a ON s.id_alat = a.id
WHERE s.id IN ($id_list)
ORDER BY s.tanggal_buat ASC, s.id ASC
";

$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    renderSweetAlert('error', 'Terjadi Kesalahan Sistem', 'Gagal memproses kalkulasi tagihan sewa. Silakan hubungi admin.');
}

$total_semua_tagihan_fix = 0;
$invoices_terpilih = [];
while ($row = mysqli_fetch_assoc($result)) {
    $harga_satuan = (float)$row['harga_satuan_alat'];
    $nama_lc = strtolower($row['nama_produk']);
    $is_consumable = (strpos($nama_lc, 'gas') !== false);

    // Hitung Subtotal Produk Presisi
    $subtotal_produk = $is_consumable 
        ? ($harga_satuan * (int)$row['qty']) 
        : ($harga_satuan * (int)$row['qty'] * (int)$row['durasi']);

    $total_tagihan_item = $subtotal_produk + (float)$row['biaya_pengambilan'] + (float)$row['denda'];
    $total_semua_tagihan_fix += $total_tagihan_item;

    if (!empty($row['no_tagihan'])) {
        $invoices_terpilih[$row['no_tagihan']][] = (int)$row['id'];
    }
}

// Cek histori pembayaran sebelumnya (jika ada DP terdahulu)
$total_sudah_dibayar = 0;
$existingPaymentId = null;
$existingJumlahBayar = 0;

foreach ($invoices_terpilih as $invNum => $iIds) {
    $idsCsv = implode(',', $iIds);
    $qBayar = mysqli_query($conn, "
        SELECT id, jumlah_bayar, status 
        FROM pembayaran
        WHERE id_users = $id_users
        AND status IN ('Lunas','Belum lunas','Menunggu konfirmasi')
        AND (
            FIND_IN_SET('$invNum', id_sewa)
            OR id_sewa IN ($idsCsv)
            OR EXISTS (
                SELECT 1 FROM sewa s4 
                WHERE s4.no_tagihan = '$invNum' 
                AND (pembayaran.id_sewa = s4.id OR FIND_IN_SET(s4.id, pembayaran.id_sewa))
            )
        )
        ORDER BY id ASC LIMIT 1
    ");
    if ($qBayar && $rB = mysqli_fetch_assoc($qBayar)) {
        if ($existingPaymentId === null) {
            $existingPaymentId = (int)$rB['id'];
            $existingJumlahBayar = (float)($rB['jumlah_bayar'] ?? 0);
        }
        $total_sudah_dibayar += (float)($rB['jumlah_bayar'] ?? 0);
    }
}

$sisa_tagihan = max(0, $total_semua_tagihan_fix - $total_sudah_dibayar);

// 5. VALIDASI LOGIKA DP vs LUNAS BERDASARKAN NOMINAL SISA TAGIHAN
if ($sisa_tagihan <= 10000) {
    // Jika tagihan Rp 10.000 atau kurang: DP TIDAK TERSEDIA, WAJIB LUNAS
    if ($tipe_pembayaran === 'dp') {
        renderSweetAlert('error', 'Fitur DP Tidak Tersedia', 'Fitur DP hanya tersedia untuk total tagihan di atas Rp 10.000. Untuk tagihan Rp 10.000 atau kurang wajib bayar lunas.');
    }
    $jumlah_bayar = $sisa_tagihan;
} else {
    // Jika tagihan > Rp 10.000: DP dan Lunas tersedia
    if ($tipe_pembayaran === 'dp') {
        if ($jumlah_bayar < 10000) {
            renderSweetAlert('error', 'Nominal DP Kurang', 'Minimal pembayaran uang muka (DP) adalah Rp 10.000.');
        }
        if ($jumlah_bayar % 1000 !== 0) {
            renderSweetAlert('error', 'Format Nominal Salah', 'Nominal pembayaran harus berupa kelipatan ribuan genap (contoh: 10.000, 15.000, 20.000, dst.).');
        }
        if ($jumlah_bayar > $sisa_tagihan) {
            renderSweetAlert('error', 'Nominal Melebihi Tagihan', 'Nominal DP tidak boleh melebihi sisa tagihan (Rp ' . number_format($sisa_tagihan, 0, ',', '.') . '). Silakan pilih opsi Bayar Lunas Penuh.');
        }
    } else {
        // Pelunasan penuh
        $jumlah_bayar = $sisa_tagihan;
    }
}

/* UPLOAD BUKTI */
$target_dir = "bukti_pembayaran/";
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true);
}

$file_name = time() . "_" . uniqid() . "." . $file_ext;
$target_file = $target_dir . $file_name;

if (!move_uploaded_file($file_tmp, $target_file)) {
    renderSweetAlert('error', 'Gagal Mengunggah Bukti', 'Terjadi kendala saat menyimpan berkas bukti pembayaran di server. Silakan coba kembali.');
}

$id_sewa_combined = implode(",", array_map('intval', $id_sewa_array));
$status = 'Menunggu konfirmasi';

if ($existingPaymentId !== null) {
    // 🔥 PELUNASAN / PEMBAYARAN LANJUTAN: UPDATE RECORD INVOICE YANG SUDAH ADA (TIDAK MEMBUAT DUPLIKAT)
    $total_bayar_akumulasi = $existingJumlahBayar + $jumlah_bayar;
    if ($total_bayar_akumulasi > $total_semua_tagihan_fix) {
        $total_bayar_akumulasi = $total_semua_tagihan_fix;
    }

    // Gabungkan bukti DP lama dan bukti pelunasan baru agar admin & user bisa melihat keduanya
    $existingBukti = '';
    $qOldBukti = mysqli_query($conn, "SELECT bukti_pembayaran FROM pembayaran WHERE id = $existingPaymentId");
    if ($qOldBukti && $rOld = mysqli_fetch_assoc($qOldBukti)) {
        $existingBukti = trim($rOld['bukti_pembayaran'] ?? '');
    }

    $combinedBukti = $file_name;
    if (!empty($existingBukti)) {
        $combinedBukti = $existingBukti . ',' . $file_name;
    }

    $stmt = $conn->prepare("
        UPDATE pembayaran 
        SET id_sewa = ?,
            metode = ?,
            bukti_pembayaran = ?,
            jumlah_bayar = ?,
            total_tagihan = ?,
            status = ?,
            tanggal_bayar = ?
        WHERE id = ?
    ");

    if (!$stmt) {
        renderSweetAlert('error', 'Gagal Menyimpan Transaksi', 'Koneksi database terganggu saat memperbarui pembayaran: ' . $conn->error);
    }

    $stmt->bind_param(
        "sssddssi",
        $id_sewa_combined,
        $metode,
        $combinedBukti,
        $total_bayar_akumulasi,
        $total_semua_tagihan_fix,
        $status,
        $tanggal_bayar,
        $existingPaymentId
    );

    if (!$stmt->execute()) {
        renderSweetAlert('error', 'Gagal Mengeksekusi Pembayaran', 'Gagal memperbarui catatan pembayaran di sistem: ' . $stmt->error);
    }
    $stmt->close();
} else {
    // PEMBAYARAN BARU: INSERT RECORD INVOICE PERTAMA KALI
    $stmt = $conn->prepare("
        INSERT INTO pembayaran 
        (id_users, id_sewa, metode, bukti_pembayaran, jumlah_bayar, total_tagihan, status, tanggal_bayar)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        renderSweetAlert('error', 'Gagal Menyimpan Transaksi', 'Koneksi database terganggu saat menyimpan data pembayaran: ' . $conn->error);
    }

    $stmt->bind_param(
        "isssddss",
        $id_users,
        $id_sewa_combined,
        $metode,
        $file_name,
        $jumlah_bayar,
        $total_semua_tagihan_fix,
        $status,
        $tanggal_bayar
    );

    if (!$stmt->execute()) {
        renderSweetAlert('error', 'Gagal Mengeksekusi Pembayaran', 'Gagal memasukkan catatan pembayaran ke sistem: ' . $stmt->error);
    }
    $stmt->close();
}

// Tampilkan SweetAlert sukses
renderSweetAlert('success', 'Pembayaran Berhasil Dikirim!', 'Konfirmasi pembayaran Anda telah diterima dan sedang menunggu verifikasi dari admin.', 'tagihan.php');
?>