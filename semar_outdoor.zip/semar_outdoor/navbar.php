<?php
// Pastikan session aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$currentPage = basename($_SERVER['PHP_SELF']);
$userName = $_SESSION['nama_users'] ?? $_SESSION['nama'] ?? 'Pengguna';
$isLoggedIn = isset($_SESSION['id_users']);
?>

<!-- FontAwesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<!-- CSS Navbar Eksternal -->
<link rel="stylesheet" href="assets/css/navbar.css">

<style>
  /* Navbar Utama */
  .navbar-custom {
    background-color: #162d2f !important;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    padding: 8px 0;
  }
  .navbar-logo-img {
    height: 38px;
    width: auto;
    object-fit: contain;
  }
  .navbar-brand-text {
    font-weight: 700;
    font-size: 1.1rem;
    color: #ffffff;
    margin-left: 8px;
  }

  /* Style Tombol Desktop */
  .btn-desktop-login {
    background-color: transparent !important;
    color: #ffffff !important;
    border: 1.5px solid #ffffff !important;
    border-radius: 20px !important;
    padding: 4px 14px !important;
    font-size: 0.80rem !important;
    font-weight: 600 !important;
    transition: all 0.2s ease;
  }
  .btn-desktop-login:hover {
    background-color: rgba(255, 255, 255, 0.15) !important;
    color: #ffffff !important;
  }

  .btn-desktop-register {
    background-color: #ffb703 !important;
    color: #102123 !important;
    border: none !important;
    border-radius: 20px !important;
    padding: 5px 14px !important;
    font-size: 0.80rem !important;
    font-weight: 700 !important;
    box-shadow: 0 2px 6px rgba(255, 183, 3, 0.25);
    transition: all 0.2s ease;
  }
  .btn-desktop-register:hover {
    background-color: #ffa200 !important;
    color: #000000 !important;
  }

  /* =========================================================
     OFFCANVAS MOBILE STYLING (SPACE TOMBOL DISESUAIKAN)
     ========================================================= */
  @media (max-width: 991.98px) {
    .custom-offcanvas {
      max-width: 82% !important;
      width: 280px !important;
      border: none !important;
    }
    
    .custom-offcanvas .offcanvas-header {
      background-color: #162d2f !important;
      color: #ffffff !important;
      padding: 12px 16px !important;
    }

    .custom-offcanvas .offcanvas-body {
      background-color: #ffffff !important;
      color: #2c3e50 !important;
      display: block !important;
      padding: 10px 16px 16px 16px !important;
      overflow-y: auto;
    }

    .navbar-nav {
      margin-top: 0 !important;
      padding-top: 0 !important;
      flex-grow: 0 !important;
    }
    .navbar-nav .nav-item {
      margin-bottom: 2px;
    }
    .navbar-nav .nav-link {
      display: flex;
      align-items: center;
      padding: 8px 12px !important;
      border-radius: 8px;
      font-size: 0.85rem;
      font-weight: 600;
      color: #2c3e50 !important;
      transition: all 0.2s ease;
      border-left: 3px solid transparent;
    }

    .nav-icon-mobile {
      width: 22px;
      text-align: center;
      margin-right: 8px;
      font-size: 0.88rem;
      color: #4a5d6e;
    }

    .navbar-nav .nav-link.active {
      background-color: #e8f5f3 !important;
      color: #162d2f !important;
      border-left: 3px solid #162d2f !important;
      font-weight: 700;
    }
    .navbar-nav .nav-link.active .nav-icon-mobile {
      color: #162d2f !important;
    }

    .offcanvas-user-section {
      margin-top: 14px;
      padding-top: 14px;
      border-top: 1px solid #e9ecef;
    }

    /* Container Pembungkus Tombol dengan Jarak (Gap) */
    .mobile-btn-wrapper {
      display: flex;
      flex-direction: column;
      gap: 10px !important; /* Jarak/Space antara Tombol Masuk & Daftar */
    }

    /* Tombol Masuk / Login Mobile */
    a.btn-mobile-login,
    button.btn-mobile-login,
    .btn-mobile-login {
      background-color: #162d2f !important;
      color: #ffffff !important;
      border: none !important;
      border-radius: 8px !important;
      padding: 8px 12px !important;
      font-size: 0.82rem !important;
      font-weight: 700 !important;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.12);
      text-decoration: none !important;
    }
    .btn-mobile-login i {
      color: #ffffff !important;
      font-size: 0.90rem !important;
    }

    /* Tombol Daftar Akun Mobile */
    a.btn-mobile-register,
    button.btn-mobile-register,
    .btn-mobile-register {
      background-color: #fff8e7 !important;
      color: #8a5300 !important;
      border: 1px solid #ffe0b2 !important;
      border-radius: 8px !important;
      padding: 8px 12px !important;
      font-size: 0.82rem !important;
      font-weight: 700 !important;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      text-decoration: none !important;
    }
    .btn-mobile-register i {
      color: #8a5300 !important;
      font-size: 0.90rem !important;
    }

    .mobile-user-card {
      display: flex;
      align-items: center;
      gap: 8px;
      background: #f8f9fa;
      padding: 6px 10px;
      border-radius: 8px;
      border: 1px solid #e9ecef;
    }
    .mobile-user-avatar {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.80rem;
      background: #162d2f;
      color: #ffffff;
    }
    .mobile-user-label {
      font-size: 0.62rem;
      color: #6c757d;
      display: block;
    }
    .mobile-user-name {
      font-weight: 700;
      font-size: 0.80rem;
      color: #162d2f;
    }
    .btn-mobile-profile,
    .btn-mobile-logout {
      border-radius: 8px;
      padding: 7px 10px;
      font-size: 0.82rem;
      font-weight: 600;
      width: 100%;
      display: flex;
      align-items: center;
    }
  }

  @media (min-width: 992px) {
    .account-pill-desktop {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 5px 12px;
      border-radius: 20px;
      background: rgba(255, 255, 255, 0.1);
      color: #ffffff;
    }
    .avatar-mini {
      width: 26px;
      height: 26px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      background: rgba(255, 255, 255, 0.2);
    }
    .user-name-short {
      font-size: 0.85rem;
      font-weight: 600;
      max-width: 110px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }
</style>

<header>
  <nav class="navbar navbar-expand-lg fixed-top navbar-dark navbar-custom">
    <div class="container-fluid px-3 px-lg-4">
      <a class="navbar-brand d-flex align-items-center" href="index.php">
        <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="navbar-logo-img">
        <span class="navbar-brand-text">Semar Outdoor</span>
      </a>

      <!-- Tombol Hamburger Mobile -->
      <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
        aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Offcanvas Menu Drawer -->
      <div class="offcanvas offcanvas-end custom-offcanvas" tabindex="-1" id="offcanvasNavbar"
        aria-labelledby="offcanvasNavbarLabel">
        
        <div class="offcanvas-header">
          <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="navbar-logo-img">
            <span class="navbar-brand-text">Semar Outdoor</span>
          </a>
          <button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body">
          <!-- Menu Navigasi Utama -->
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-lg-3 align-items-lg-center">
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'index.php') ? 'active' : '' ?>" href="index.php">
                <i class="fas fa-home nav-icon-mobile d-lg-none"></i><span>Beranda</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'ketentuan.php') ? 'active' : '' ?>" href="ketentuan.php">
                <i class="fas fa-file-contract nav-icon-mobile d-lg-none"></i><span>Ketentuan</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'alat.php') ? 'active' : '' ?>" href="alat.php">
                <i class="fas fa-campground nav-icon-mobile d-lg-none"></i><span>Alat</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'keranjang.php') ? 'active' : '' ?>" href="keranjang.php">
                <i class="fas fa-shopping-cart nav-icon-mobile d-lg-none"></i><span>Keranjang</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'tagihan.php') ? 'active' : '' ?>" href="tagihan.php">
                <i class="fas fa-file-invoice-dollar nav-icon-mobile d-lg-none"></i><span>Tagihan</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'riwayat_sewa.php') ? 'active' : '' ?>" href="riwayat_sewa.php">
                <i class="fas fa-history nav-icon-mobile d-lg-none"></i><span>Riwayat Sewa</span>
              </a>
            </li>

            <!-- DESKTOP ONLY: Menu Akun / Profil (>= 992px) -->
            <?php if ($currentPage !== 'login.php' && $currentPage !== 'register.php'): ?>
              <?php if ($isLoggedIn): ?>
                <li class="nav-item dropdown d-none d-lg-block ms-lg-2">
                  <a class="nav-link nav-link-account-desktop dropdown-toggle <?= ($currentPage == 'profile.php') ? 'active' : '' ?>" href="#" id="desktopUserDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" title="Menu Akun">
                    <div class="account-pill-desktop">
                      <div class="avatar-mini">
                        <i class="fas fa-user"></i>
                      </div>
                      <span class="user-name-short"><?= htmlspecialchars($userName) ?></span>
                      <i class="fas fa-chevron-down chevron-icon small"></i>
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end shadow desktop-dropdown-menu" aria-labelledby="desktopUserDropdown">
                    <li class="dropdown-user-header px-3 py-2">
                      <div class="small text-muted">Masuk sebagai</div>
                      <div class="fw-bold text-dark text-truncate" style="max-width: 180px;"><?= htmlspecialchars($userName) ?></div>
                    </li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li>
                      <a class="dropdown-item py-2 <?= ($currentPage == 'profile.php') ? 'active' : '' ?>" href="profile.php">
                        <i class="fas fa-user-cog me-2"></i>Profil Saya
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item py-2 text-danger" href="logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                      </a>
                    </li>
                  </ul>
                </li>
              <?php else: ?>
                <li class="nav-item d-none d-lg-flex align-items-center gap-2 ms-lg-3">
                  <a href="login.php" class="btn btn-desktop-login">
                    <i class="fas fa-sign-in-alt me-1"></i> Masuk
                  </a>
                  <a href="register.php" class="btn btn-desktop-register">
                    <i class="fas fa-user-plus me-1"></i> Daftar
                  </a>
                </li>
              <?php endif; ?>
            <?php endif; ?>
          </ul>

          <!-- MOBILE ONLY: User Profile & Actions (< 992px) -->
          <div class="offcanvas-user-section d-lg-none">
            <?php if ($isLoggedIn): ?>
              <div class="mobile-user-card mb-2">
                <div class="mobile-user-avatar">
                  <i class="fas fa-user"></i>
                </div>
                <div class="mobile-user-meta text-truncate">
                  <span class="mobile-user-label">Masuk sebagai</span>
                  <div class="mobile-user-name text-truncate"><?= htmlspecialchars($userName) ?></div>
                </div>
              </div>
              <div class="mobile-btn-wrapper mt-2">
                <a href="profile.php" class="btn btn-mobile-profile <?= ($currentPage == 'profile.php') ? 'active' : '' ?>">
                  <i class="fas fa-user-cog me-2"></i> Profil Saya
                </a>
                <a href="logout.php" class="btn btn-mobile-logout">
                  <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
              </div>
            <?php else: ?>
              <div class="mobile-btn-wrapper">
                <?php if ($currentPage !== 'login.php'): ?>
                  <a href="login.php" class="btn btn-mobile-login">
                    <i class="fas fa-sign-in-alt"></i> Masuk / Login
                  </a>
                <?php endif; ?>
                <?php if ($currentPage !== 'register.php'): ?>
                  <a href="register.php" class="btn btn-mobile-register">
                    <i class="fas fa-user-plus"></i> Daftar Akun
                  </a>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>

        </div>
      </div>
    </div>
  </nav>
</header>