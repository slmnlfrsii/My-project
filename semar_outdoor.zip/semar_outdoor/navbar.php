<?php
// Pastikan session aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$currentPage = basename($_SERVER['PHP_SELF']);
$userName = $_SESSION['nama_users'] ?? $_SESSION['nama'] ?? 'Pengguna';
$isLoggedIn = isset($_SESSION['id_users']);
?>

<!-- FontAwesome CDN agar ikon selalu tampil sempurna -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<!-- CSS Navbar & Offcanvas Responsive -->
<link rel="stylesheet" href="assets/css/navbar.css">

<header>
  <nav class="navbar navbar-expand-lg fixed-top navbar-dark navbar-custom">
    <div class="container-fluid px-lg-4">
      <a class="navbar-brand" href="index.php">
        <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="navbar-logo-img">
        <span class="navbar-brand-text">Semar Outdoor</span>
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
        aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="offcanvas offcanvas-end custom-offcanvas" tabindex="-1" id="offcanvasNavbar"
        aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
          <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="navbar-logo-img">
            <span class="navbar-brand-text">Semar Outdoor</span>
          </a>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body">
          <!-- Menu Navigasi Utama -->
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-lg-3 align-items-lg-center">
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'index.php') ? 'active' : '' ?>" href="index.php">
                <i class="fas fa-home nav-icon-mobile d-lg-none"></i><span>Beranda</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'ketentuan.php') ? 'active' : '' ?>" href="ketentuan.php">
                <i class="fas fa-file-contract nav-icon-mobile d-lg-none"></i><span>Ketentuan</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'alat.php') ? 'active' : '' ?>" href="alat.php">
                <i class="fas fa-campground nav-icon-mobile d-lg-none"></i><span>Alat</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'keranjang.php') ? 'active' : '' ?>" href="keranjang.php">
                <i class="fas fa-shopping-cart nav-icon-mobile d-lg-none"></i><span>Keranjang</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'tagihan.php') ? 'active' : '' ?>" href="tagihan.php">
                <i class="fas fa-file-invoice-dollar nav-icon-mobile d-lg-none"></i><span>Tagihan</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'riwayat_sewa.php') ? 'active' : '' ?>" href="riwayat_sewa.php">
                <i class="fas fa-history nav-icon-mobile d-lg-none"></i><span>Riwayat Sewa</span>
              </a>
            </li>

            <!-- DESKTOP ONLY: Menu Akun / Profil (>= 992px) -->
            <?php if ($currentPage !== 'login.php' && $currentPage !== 'register.php'): ?>
              <?php if ($isLoggedIn): ?>
                <li class="nav-item dropdown d-none d-lg-block ms-lg-2">
                  <a class="nav-link nav-link-account-desktop dropdown-toggle <?= ($currentPage == 'profile.php') ? 'active' : '' ?>" href="#" id="desktopUserDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" title="Menu Akun">
                    <div class="account-pill-desktop">
                      <div class="avatar-mini">
                        <i class="fas fa-user"></i>
                      </div>
                      <span class="user-name-short"><?= htmlspecialchars($userName) ?></span>
                      <i class="fas fa-chevron-down chevron-icon"></i>
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end shadow desktop-dropdown-menu" aria-labelledby="desktopUserDropdown">
                    <li class="dropdown-user-header px-3 py-2">
                      <div class="small text-muted">Masuk sebagai</div>
                      <div class="fw-bold text-dark text-truncate" style="max-width: 180px;"><?= htmlspecialchars($userName) ?></div>
                    </li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li>
                      <a class="dropdown-item py-2 <?= ($currentPage == 'profile.php') ? 'active' : '' ?>" href="profile.php">
                        <i class="fas fa-user-cog me-2 text-success"></i>Profil Saya
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item py-2 text-danger" href="logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                      </a>
                    </li>
                  </ul>
                </li>
              <?php else: ?>
                <li class="nav-item d-none d-lg-flex align-items-center gap-2 ms-lg-3">
                  <a href="login.php" class="btn btn-desktop-login">
                    <i class="fas fa-sign-in-alt me-1"></i> Masuk
                  </a>
                  <a href="register.php" class="btn btn-desktop-register">
                    <i class="fas fa-user-plus me-1"></i> Daftar
                  </a>
                </li>
              <?php endif; ?>
            <?php endif; ?>
          </ul>

          <!-- MOBILE ONLY: User Profile & Actions (< 992px) -->
          <div class="offcanvas-user-section d-lg-none">
            <?php if ($isLoggedIn): ?>
              <div class="mobile-user-card mb-3">
                <div class="mobile-user-avatar">
                  <i class="fas fa-user"></i>
                </div>
                <div class="mobile-user-meta">
                  <span class="mobile-user-label">Masuk sebagai</span>
                  <div class="mobile-user-name text-truncate"><?= htmlspecialchars($userName) ?></div>
                </div>
              </div>
              <div class="mobile-user-actions">
                <a href="profile.php" class="btn btn-mobile-profile <?= ($currentPage == 'profile.php') ? 'active' : '' ?>">
                  <i class="fas fa-user-cog me-2"></i> Profil Saya
                </a>
                <a href="logout.php" class="btn btn-mobile-logout">
                  <i class="fas fa-sign-out-alt me-2"></i> Logout
                </a>
              </div>
            <?php else: ?>
              <div class="mobile-guest-section">
                <?php if ($currentPage !== 'login.php'): ?>
                  <a href="login.php" class="btn btn-mobile-login">
                    <i class="fas fa-sign-in-alt me-2"></i> Masuk / Login
                  </a>
                <?php endif; ?>
                <?php if ($currentPage !== 'register.php'): ?>
                  <a href="register.php" class="btn btn-mobile-register">
                    <i class="fas fa-user-plus me-2"></i> Daftar Akun
                  </a>
                <?php endif; ?>
              </div>
            <?php endif; ?>
          </div>

        </div>
      </div>
    </div>
  </nav>
</header>
