<?php
// Pastikan session aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!-- FontAwesome CDN agar ikon titik 3 / menu selalu tampil sempurna -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
/* Navbar Brand & Logo */
.navbar-brand {
  font-family: 'Quicksand', 'Plus Jakarta Sans', sans-serif;
  font-weight: 700;
  font-size: 1.25rem;
  letter-spacing: 0.5px;
  display: inline-flex;
  align-items: center;
  gap: 12px;
  padding: 4px 0;
  transition: opacity 0.2s ease;
  text-decoration: none;
}

.navbar-brand:hover {
  opacity: 0.92;
}

.navbar-logo-img {
  height: 42px;
  width: auto;
  max-height: 42px;
  object-fit: contain;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.25));
  transition: transform 0.3s ease;
}

.navbar-brand:hover .navbar-logo-img {
  transform: scale(1.06);
}

.navbar-brand-text {
  font-weight: 800;
  font-size: 1.25rem;
  color: #ffffff;
  letter-spacing: 0.4px;
}

/* Tombol Dropdown Akun (Titik 3) */
.nav-link-account-menu {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 38px !important;
  height: 38px !important;
  border-radius: 50% !important;
  color: #f8f9fa !important;
  font-size: 1.15rem !important;
  padding: 0 !important;
  transition: all 0.2s ease !important;
  background: rgba(255, 255, 255, 0.1) !important;
  border: 1px solid rgba(255, 255, 255, 0.2) !important;
  cursor: pointer;
}

.nav-link-account-menu::after {
  display: none !important;
}

.nav-link-account-menu:hover,
.nav-link-account-menu:focus {
  background: rgba(255, 255, 255, 0.25) !important;
  color: #ffcc33 !important;
  transform: scale(1.06);
}

.nav-link-account-menu.active {
  background: #8e5a12 !important;
  color: #ffffff !important;
  border-color: #ffcc33 !important;
}

@media (max-width: 991.98px) {
  .nav-item-account-dropdown {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid rgba(0,0,0,0.08);
  }
}
</style>

<header>
  <nav class="navbar navbar-expand-lg fixed-top navbar-dark" style="background-color: #162d2f; box-shadow: 0 4px 16px rgba(0,0,0,0.2);">
    <div class="container-fluid px-lg-4">
      <a class="navbar-brand" href="index.php">
        <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="navbar-logo-img">
        <span class="navbar-brand-text">Semar Outdoor</span>
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
        aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
        aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header" style="background-color: #162d2f;">
          <a class="navbar-brand" href="index.php">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="navbar-logo-img">
            <span class="navbar-brand-text">Semar Outdoor</span>
          </a>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>

        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 align-items-lg-center">

            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'index.php') ? 'active' : '' ?>" href="index.php">Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'ketentuan.php') ? 'active' : '' ?>" href="ketentuan.php">Ketentuan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'alat.php') ? 'active' : '' ?>" href="alat.php">Alat</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'keranjang.php') ? 'active' : '' ?>" href="keranjang.php">Keranjang</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'tagihan.php') ? 'active' : '' ?>" href="tagihan.php">Tagihan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?= ($currentPage == 'riwayat_sewa.php') ? 'active' : '' ?>" href="riwayat_sewa.php">Riwayat Sewa</a>
            </li>

            <!-- Menu Dropdown Titik Tiga (Profil & Login - Tersembunyi saat di halaman login) -->
            <?php if ($currentPage !== 'login.php'): ?>
              <li class="nav-item dropdown nav-item-account-dropdown ms-lg-2">
                <a class="nav-link nav-link-account-menu <?= in_array($currentPage, ['profile.php', 'register.php']) ? 'active' : '' ?>" href="#" id="userMenuDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" title="Menu Akun">
                  <i class="fas fa-ellipsis-v"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="userMenuDropdown" style="border-radius: 10px; min-width: 180px;">
                  <?php if (isset($_SESSION['id_users'])): ?>
                    <li>
                      <h6 class="dropdown-header text-truncate" style="max-width: 200px;">
                        <i class="fas fa-user-circle me-1 text-muted"></i> <?= htmlspecialchars($_SESSION['nama'] ?? 'Pengguna') ?>
                      </h6>
                    </li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li>
                      <a class="dropdown-item py-2 <?= ($currentPage == 'profile.php') ? 'active' : '' ?>" href="profile.php">
                        <i class="fas fa-user-cog me-2 text-success"></i>Profil Saya
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item py-2 text-danger" href="logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                      </a>
                    </li>
                  <?php else: ?>
                    <li>
                      <a class="dropdown-item py-2" href="login.php">
                        <i class="fas fa-sign-in-alt me-2 text-primary"></i>Login
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item py-2 <?= ($currentPage == 'register.php') ? 'active' : '' ?>" href="register.php">
                        <i class="fas fa-user-plus me-2 text-success"></i>Daftar Akun
                      </a>
                    </li>
                  <?php endif; ?>
                </ul>
              </li>
            <?php endif; ?>

          </ul>
        </div>
      </div>
    </div>
  </nav>
</header>
