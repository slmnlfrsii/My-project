<?php
session_start();
include 'koneksi.php';

$email = trim($_POST['email'] ?? '');

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: lupa_password.php?status=invalid_email");
    exit;
}

// Cek apakah email terdaftar di tabel users
$stmt = $conn->prepare("SELECT id, nama, email FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
    header("Location: lupa_password.php?status=email_tidak_ditemukan");
    exit;
}

$user = $result->fetch_assoc();
$namaUser = $user['nama'];

// Generate OTP (6 digit angka) & Secure Token
$otp = sprintf("%06d", mt_rand(100000, 999999));
$token = bin2hex(random_bytes(32));
$created_at = date('Y-m-d H:i:s');
$expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));

// Hapus token lama untuk email ini
$stmtDel = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
$stmtDel->bind_param("s", $email);
$stmtDel->execute();
$stmtDel->close();

// Simpan token & OTP baru
$stmtIns = $conn->prepare("INSERT INTO password_resets (email, token, otp, created_at, expires_at) VALUES (?, ?, ?, ?, ?)");
$stmtIns->bind_param("sssss", $email, $token, $otp, $created_at, $expires_at);
$stmtIns->execute();
$stmtIns->close();

// Susun URL reset langsung
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$uriDir = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$resetUrl = $protocol . $host . $uriDir . "/reset_password.php?token=" . urlencode($token) . "&email=" . urlencode($email);

// Kirim Email Verifikasi
$subject = "Kode Verifikasi Reset Kata Sandi - Semar Outdoor";

$message = "
<!DOCTYPE html>
<html>
<head>
  <meta charset='UTF-8'>
  <style>
    body { font-family: 'Poppins', Arial, sans-serif; background-color: #f8fafc; color: #1e293b; margin: 0; padding: 20px; }
    .email-container { max-width: 520px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.08); border: 1px solid #e2e8f0; }
    .email-header { background-color: #162d2f; padding: 25px 20px; text-align: center; color: #ffffff; }
    .email-header h1 { margin: 0; font-size: 22px; font-weight: 700; }
    .email-header p { margin: 4px 0 0 0; font-size: 13px; color: #e2e8f0; opacity: 0.9; }
    .email-body { padding: 30px 24px; }
    .greeting { font-size: 15px; font-weight: 600; margin-bottom: 12px; }
    .text { font-size: 13.5px; line-height: 1.6; color: #475569; margin-bottom: 20px; }
    .otp-box { background: #f1f5f9; border: 2px dashed #162d2f; border-radius: 12px; padding: 16px; text-align: center; margin: 20px 0; }
    .otp-code { font-size: 32px; font-weight: 800; letter-spacing: 6px; color: #162d2f; }
    .otp-info { font-size: 12px; color: #64748b; margin-top: 6px; }
    .btn-reset { display: block; width: 220px; margin: 20px auto 0 auto; padding: 12px 20px; background: #162d2f; color: #ffffff !important; text-align: center; text-decoration: none; font-weight: 700; font-size: 14px; border-radius: 30px; }
    .footer { text-align: center; font-size: 12px; color: #94a3b8; padding: 20px; border-top: 1px solid #f1f5f9; }
  </style>
</head>
<body>
  <div class='email-container'>
    <div class='email-header'>
      <h1>Semar Outdoor</h1>
      <p>Verifikasi Reset Kata Sandi Akun</p>
    </div>
    <div class='email-body'>
      <div class='greeting'>Halo, " . htmlspecialchars($namaUser) . "!</div>
      <div class='text'>
        Kami menerima permintaan untuk mereset kata sandi akun Anda. Gunakan kode verifikasi (OTP) di bawah ini untuk melanjutkan:
      </div>
      <div class='otp-box'>
        <div class='otp-code'>" . $otp . "</div>
        <div class='otp-info'>*Kode ini berlaku selama 15 menit.</div>
      </div>
      <div class='text' style='text-align: center;'>
        Atau Anda dapat langsung klik tombol di bawah ini:
      </div>
      <a href='" . $resetUrl . "' class='btn-reset'>Reset Kata Sandi</a>
      <div class='text' style='margin-top: 24px; font-size: 12px; color: #94a3b8;'>
        Jika Anda tidak merasa melakukan permintaan ini, silakan abaikan email ini dengan aman.
      </div>
    </div>
    <div class='footer'>
      &copy; " . date('Y') . " Semar Outdoor - Rental Alat Outdoor Berkualitas.
    </div>
  </div>
</body>
</html>
";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: Semar Outdoor <no-reply@semaroutdoor.com>" . "\r\n";

// Kirim Email Verifikasi
@mail($email, $subject, $message, $headers);

// Simpan session bantuan verifikasi
$_SESSION['reset_email'] = $email;
$_SESSION['reset_token'] = $token;
$_SESSION['reset_otp_preview'] = $otp;

header("Location: reset_password.php?token=" . urlencode($token) . "&email=" . urlencode($email) . "&status=kode_terkirim");
exit;
?>
