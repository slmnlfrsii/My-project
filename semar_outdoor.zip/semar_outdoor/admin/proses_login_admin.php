<?php
session_start();
include '../koneksi.php';

// Retrieve and trim email and password from POST data
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

// Check if email or password is empty
if (empty($email) || empty($password)) {
    header("Location: index.php?status=failed");
    exit;
}

// Prepare statement to select admin user by email
$stmt = $conn->prepare("SELECT id, nama, email, password FROM admin WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Verify if user exists and password is correct
if ($result && $result->num_rows === 1) {
    $admin = $result->fetch_assoc();
    if (password_verify($password, $admin['password'])) {
        // Set session variables for logged in admin
        $_SESSION['id_admin'] = $admin['id'];
        $_SESSION['nama_admin'] = $admin['nama'];
        $_SESSION['role'] = 'admin';

        header("Location: dashboard/dashboard.php?status=success");
        exit;
    }
}

// If login fails, redirect back to login page with failed status
header("Location: index.php?status=failed");
exit;
?>
