<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login Admin – Semar Outdoor</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/login.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    html, body {
      min-height: 100vh;
    }
    body {
      background: url("../assets/images/g.jpg") center/cover no-repeat fixed;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start; /* Posisi diubah ke atas, bukan tengah vertikal */
      padding: 16px;
      padding-top: 75px;
    }
    .wrapper {
      margin-top: 25px; /* Menentukan jarak dari navbar */
    }
    .btn:active {
      animation: clickAnimation 0.3s ease;
    }
    @keyframes clickAnimation {
      0% { transform: scale(1); }
      50% { transform: scale(0.95); }
      100% { transform: scale(1); }
    }

    /* Media Query Khusus Android / Layar HP */
    @media (max-width: 768px) {
      body {
        padding: 12px;
        padding-top: 60px; /* Jarak pas dari navbar fixed */
      }
      .wrapper {
        margin-top: 10px; /* Form ditarik lebih naik lagi pada Android */
        flex-direction: column !important;
        width: 100% !important;
        max-width: 380px !important;
      }
      .banner, .login-card {
        width: 100% !important;
      }
      .banner {
        margin-bottom: 10px;
      }
      .banner .logo {
        width: 120px !important; /* Ukuran logo dirampingkan agar form naik */
        height: auto;
      }
      .banner h2 {
        font-size: 1.3rem;
        margin-bottom: 2px;
      }
      .banner p {
        font-size: 0.82rem;
        margin-bottom: 6px;
      }
      .login-card {
        padding: 18px 16px;
      }
      .login-card input {
        width: 100% !important;
        box-sizing: border-box;
      }
    }
  </style>
</head>
<body>

<header>
  <nav class="navbar navbar-expand-lg fixed-top navbar-dark" style="background-color: #162d2f;">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">
        <img src="../assets/images/logo.png" alt="Logo" width="50" height="40" class="d-inline-block align-text-top">
        Semar Outdoor
      </a>
    </div>
  </nav>
</header>

<div class="wrapper">
  <div class="banner">
    <img src="../assets/images/logo.png"
      alt="Logo"
      class="logo"
      style="width:250px;">
    <h2>Semar Outdoor</h2>
    <p>Admin Panel Login</p>
  </div>

  <div class="login-card">
    <h2>Login Admin</h2>
    <form action="proses_login_admin.php" method="post">
      <input type="email" name="email" placeholder="Email" required />
      <input type="password" name="password" placeholder="Password" required />
      <div class="actions">
        <button type="submit" class="btn login">Login</button>
      </div>
    </form>
  </div>
</div>

<?php if (isset($_GET['status'])): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      if (typeof Swal !== "undefined") {
        <?php if ($_GET['status'] === 'failed'): ?>
          Swal.fire({
            icon: 'error',
            title: 'Login Gagal',
            text: 'Email atau password salah!',
            confirmButtonColor: '#d10d1d'
          });
        <?php endif; ?>
      }
    });
  </script>
<?php endif; ?>

</body>
</html>