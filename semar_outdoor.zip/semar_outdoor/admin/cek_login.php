<?php
if (!isset($_SESSION['id_admin'])) {
    $in_subfolder = (basename(dirname($_SERVER['PHP_SELF'])) !== 'admin');
    $redirect_path = $in_subfolder ? '../index.php?status=not_logged_in' : 'index.php?status=not_logged_in';
    header("Location: " . $redirect_path);
    exit();
}
?>
