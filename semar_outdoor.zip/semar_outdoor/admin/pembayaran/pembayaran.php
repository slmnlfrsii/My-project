<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';

// Load Logo Base64 agar selalu tampil sempurna di cetak PDF dan popup print
$logoFile = __DIR__ . '/../../assets/images/logo.png';
$logoBase64 = '';
if (file_exists($logoFile)) {
    $logoBase64 = 'data:image/png;base64,' . base64_encode(file_get_contents($logoFile));
}

// Tab Aktif (Default: semua/menunggu, atau belum_lunas, lunas, ditolak)
$activeTab = strtolower(trim($_GET['tab'] ?? 'semua'));
if (!in_array($activeTab, ['semua', 'belum_lunas', 'lunas', 'ditolak'])) {
    $activeTab = 'semua';
}

/* =========================================================================
   [FIFO LOGIC] 1. QUERY ANTREAN VERIFIKASI PEMBAYARAN ADMIN (FIFO)
   - Pembayaran yang masuk diurutkan secara First-In, First-Out (tanggal_bayar ASC, id ASC)
   ========================================================================= */
$pembayaranQuery = mysqli_query($conn, "
    SELECT 
        pembayaran.*, 
        users.nama, 
        users.email, 
        adm.nama AS nama_admin,
        adm.foto AS foto_admin,
        COALESCE(
            NULLIF(GROUP_CONCAT(DISTINCT s.no_tagihan SEPARATOR ', '), ''),
            NULLIF(GROUP_CONCAT(DISTINCT sb.no_tagihan SEPARATOR ', '), ''),
            CONCAT('INV-', DATE_FORMAT(pembayaran.tanggal_bayar, '%Y%m%d'), '-', LPAD(pembayaran.id, 4, '0'))
        ) AS no_tagihan_formatted,
        COALESCE(
            NULLIF(GROUP_CONCAT(DISTINCT CONCAT(s.nama_produk, ' (x', s.qty, ')') SEPARATOR ', '), ''),
            NULLIF(GROUP_CONCAT(DISTINCT CONCAT(sb.nama_produk, ' (x', sb.qty, ')') SEPARATOR ', '), ''),
            'Item Sewa (Dibatalkan)'
        ) AS nama_produk_list,
        COALESCE(MIN(s.tanggal_buat), MIN(sb.dibatalkan_pada)) AS tanggal_buat
    FROM pembayaran 
    JOIN users ON pembayaran.id_users = users.id
    LEFT JOIN admin adm ON pembayaran.id_admin = adm.id
    LEFT JOIN sewa s ON FIND_IN_SET(s.id, pembayaran.id_sewa)
    LEFT JOIN sewa_dibatalkan sb ON sb.id_users = pembayaran.id_users AND (sb.no_tagihan = s.no_tagihan OR sb.no_tagihan LIKE CONCAT('%-', LPAD(pembayaran.id_sewa, 4, '0')) OR sb.no_tagihan LIKE CONCAT('%-', LPAD(pembayaran.id_sewa, 3, '0')))
    GROUP BY pembayaran.id
    ORDER BY pembayaran.tanggal_bayar ASC, pembayaran.id ASC
");

// Klasifikasi data ke dalam 4 kelompok tab
$listSemua = [];      // Menunggu konfirmasi
$listBelumLunas = []; // Belum lunas
$listLunas = [];      // Lunas
$listDitolak = [];    // Ditolak
$allPayments = [];

if ($pembayaranQuery && mysqli_num_rows($pembayaranQuery) > 0) {
    while ($row = mysqli_fetch_assoc($pembayaranQuery)) {
        if (!empty($row['no_tagihan_formatted'])) {
            $row['no_tagihan'] = $row['no_tagihan_formatted'];
        }
        if (!empty($row['nama_produk_list'])) {
            $row['nama_produk'] = $row['nama_produk_list'];
        }
        $allPayments[] = $row;
        $st = strtolower(trim($row['status'] ?? ''));
        if ($st === 'lunas') {
            $listLunas[] = $row;
        } elseif ($st === 'ditolak') {
            $listDitolak[] = $row;
        } elseif ($st === 'belum lunas') {
            $listBelumLunas[] = $row;
        } else {
            // 'menunggu konfirmasi' / default
            $listSemua[] = $row;
        }
    }
}

// Urutkan histori Lunas & Ditolak dari yang paling baru (DESC) untuk histori
usort($listLunas, function($a, $b) {
    return strtotime($b['tanggal_bayar']) <=> strtotime($a['tanggal_bayar']);
});
usort($listDitolak, function($a, $b) {
    return strtotime($b['tanggal_bayar']) <=> strtotime($a['tanggal_bayar']);
});

/* =========================================================================
   [FILTER PERIODE BULAN & TAHUN]
   ========================================================================= */
$filterBulan = isset($_GET['bulan']) ? trim($_GET['bulan']) : date('m');
$filterTahun = isset($_GET['tahun']) ? trim($_GET['tahun']) : (string)date('Y');

$filterListByPeriod = function($list, $bulan, $tahun) {
    if ($bulan === 'semua' && $tahun === 'semua') {
        return $list;
    }
    return array_values(array_filter($list, function($row) use ($bulan, $tahun) {
        $tgl = !empty($row['tanggal_bayar']) ? $row['tanggal_bayar'] : ($row['tanggal_buat'] ?? '');
        if (empty($tgl)) return true;
        $rowBln = (int)date('n', strtotime($tgl));
        $rowThn = (int)date('Y', strtotime($tgl));
        if ($bulan !== 'semua' && $rowBln !== (int)$bulan) {
            return false;
        }
        if ($tahun !== 'semua' && $rowThn !== (int)$tahun) {
            return false;
        }
        return true;
    }));
};

$listSemuaFiltered      = $filterListByPeriod($listSemua, $filterBulan, $filterTahun);
$listBelumLunasFiltered = $filterListByPeriod($listBelumLunas, $filterBulan, $filterTahun);
$listLunasFiltered      = $filterListByPeriod($listLunas, $filterBulan, $filterTahun);
$listDitolakFiltered    = $filterListByPeriod($listDitolak, $filterBulan, $filterTahun);

// Daftar tahun dinamis dari database
$yearsList = [];
$currY = (int)date('Y');
for ($y = $currY; $y >= $currY - 2; $y--) {
    $yearsList[] = $y;
}
$qY = mysqli_query($conn, "SELECT DISTINCT YEAR(tanggal_bayar) AS y FROM pembayaran WHERE tanggal_bayar IS NOT NULL AND YEAR(tanggal_bayar) > 2000 UNION SELECT DISTINCT YEAR(tanggal_buat) AS y FROM sewa WHERE tanggal_buat IS NOT NULL AND YEAR(tanggal_buat) > 2000");
if ($qY) {
    while ($yr = mysqli_fetch_assoc($qY)) {
        if (!empty($yr['y'])) $yearsList[] = (int)$yr['y'];
    }
}
$yearsList = array_values(array_unique($yearsList));
rsort($yearsList);

// Paginasi
$itemsPerPage = 12;

// Paginasi Belum Lunas
$pageBelumLunas = max(1, (int)($_GET['page_belum_lunas'] ?? ($_GET['page'] ?? 1)));
$totalItemsBelumLunas = count($listBelumLunasFiltered);
$totalPagesBelumLunas = max(1, ceil($totalItemsBelumLunas / $itemsPerPage));
$pageBelumLunas = min($pageBelumLunas, $totalPagesBelumLunas);
$offsetBelumLunas = ($pageBelumLunas - 1) * $itemsPerPage;

// Paginasi Lunas
$pageLunas = max(1, (int)($_GET['page_lunas'] ?? ($_GET['page'] ?? 1)));
$totalItemsLunas = count($listLunasFiltered);
$totalPagesLunas = max(1, ceil($totalItemsLunas / $itemsPerPage));
$pageLunas = min($pageLunas, $totalPagesLunas);
$offsetLunas = ($pageLunas - 1) * $itemsPerPage;
$listLunasPaginated = array_slice($listLunasFiltered, $offsetLunas, $itemsPerPage);

// Paginasi Ditolak
$pageDitolak = max(1, (int)($_GET['page_ditolak'] ?? ($_GET['page'] ?? 1)));
$totalItemsDitolak = count($listDitolakFiltered);
$totalPagesDitolak = max(1, ceil($totalItemsDitolak / $itemsPerPage));
$pageDitolak = min($pageDitolak, $totalPagesDitolak);
$offsetDitolak = ($pageDitolak - 1) * $itemsPerPage;
$listDitolakPaginated = array_slice($listDitolakFiltered, $offsetDitolak, $itemsPerPage);

/* =========================================================================
   [FIFO LOGIC] 2. SMART FIFO & QUEUE LOCKING PADA ANTREAN PEMBAYARAN
   ========================================================================= */

// --- 2A. FIFO Lock untuk TAB 1 (Menunggu Konfirmasi) ---
// Diurutkan terlama ke terbaru (ASC) agar antrean #1 tampil di atas
usort($listSemuaFiltered, function($a, $b) {
    return strtotime($a['tanggal_bayar']) <=> strtotime($b['tanggal_bayar']);
});

$queueCounter = 1;
$hasPendingConfirmationBefore = false;
$blockingQueueNo = 1;

foreach ($listSemuaFiltered as &$item) {
    $item['queue_no'] = $queueCounter++;
    $st = strtolower(trim($item['status'] ?? ''));

    if ($hasPendingConfirmationBefore) {
        $item['is_locked'] = true;
        $item['blocking_queue_no'] = $blockingQueueNo;
    } else {
        $item['is_locked'] = false;
        $item['blocking_queue_no'] = null;
    }

    if ($st === 'menunggu konfirmasi' || empty($st)) {
        if (!$hasPendingConfirmationBefore) {
            $blockingQueueNo = $item['queue_no'];
        }
        $hasPendingConfirmationBefore = true;
    }
}
unset($item);

// --- 2B. FIFO Lock untuk TAB 2 (Belum Lunas) ---
// Diurutkan terlama ke terbaru (ASC) agar antrean #1 pelunasan tampil di posisi paling atas
usort($listBelumLunasFiltered, function($a, $b) {
    return strtotime($a['tanggal_bayar']) <=> strtotime($b['tanggal_bayar']);
});

$queueCounterBL = 1;
$hasPendingBLBefore = false;
$blockingQueueNoBL = 1;

foreach ($listBelumLunasFiltered as &$item) {
    $item['queue_no'] = $queueCounterBL++;

    if ($hasPendingBLBefore) {
        $item['is_locked'] = true;
        $item['blocking_queue_no'] = $blockingQueueNoBL;
    } else {
        $item['is_locked'] = false;
        $item['blocking_queue_no'] = null;
    }

    if (!$hasPendingBLBefore) {
        $blockingQueueNoBL = $item['queue_no'];
    }
    $hasPendingBLBefore = true;
}
unset($item);

// Re-slice data paginasi Belum Lunas (tetap berurutan ASC agar #1 berada di paling atas)
$listBelumLunasPaginated = array_slice($listBelumLunasFiltered, $offsetBelumLunas, $itemsPerPage);


function statusLabel($status) {
    $st = strtolower(trim($status ?? ''));
    switch ($st) {
        case 'belum lunas':
            return '<span class="badge bg-warning text-dark">Belum lunas</span>';
        case 'lunas':
            return '<span class="badge bg-success">Lunas</span>';
        case 'ditolak':
            return '<span class="badge bg-danger">Ditolak</span>';
        default:
            return '<span class="badge bg-primary">Menunggu konfirmasi</span>';
    }
}

function renderPaginationBar($currentPage, $totalPages, $totalItems, $itemsCount, $pageParam = 'page') {
    if ($totalPages <= 1) return '';
    ob_start(); ?>
    <nav aria-label="Navigasi Halaman" class="d-flex flex-column align-items-center mt-4 mb-2">
      <ul class="pagination pagination-sm mb-1 shadow-sm rounded-pill overflow-hidden">
        <li class="page-item <?= ($currentPage <= 1) ? 'disabled' : '' ?>">
          <a class="page-link px-3" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $currentPage - 1])) ?>">
            <i class="fas fa-chevron-left me-1"></i> Sebelumnya
          </a>
        </li>

        <?php
        $startPage = max(1, $currentPage - 2);
        $endPage = min($totalPages, $currentPage + 2);
        if ($startPage > 1) {
            echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, [$pageParam => 1])) . '">1</a></li>';
            if ($startPage > 2) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
        for ($p = $startPage; $p <= $endPage; $p++): ?>
          <li class="page-item <?= ($p == $currentPage) ? 'active' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $p])) ?>"><?= $p ?></a>
          </li>
        <?php endfor;
        if ($endPage < $totalPages) {
            if ($endPage < $totalPages - 1) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, [$pageParam => $totalPages])) . '">' . $totalPages . '</a></li>';
        }
        ?>

        <li class="page-item <?= ($currentPage >= $totalPages) ? 'disabled' : '' ?>">
          <a class="page-link px-3" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $currentPage + 1])) ?>">
            Berikutnya <i class="fas fa-chevron-right ms-1"></i>
          </a>
        </li>
      </ul>
      <div class="text-muted small mt-1" style="font-size: 0.73rem;">
        Menampilkan <strong><?= $itemsCount ?></strong> dari total <strong><?= $totalItems ?></strong> transaksi (Halaman <?= $currentPage ?> dari <?= $totalPages ?>)
      </div>
    </nav>
    <?php
    return ob_get_clean();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Data Pembayaran - Admin Semar Outdoor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { background: #f8f9fa; }
        .nav-pills .nav-link.active {
            background-color: #0e4430;
            color: white;
            font-weight: 600;
        }
        .nav-pills .nav-link {
            color: #334155;
            font-weight: 500;
        }
        .card-locked {
            opacity: 0.85;
            background-color: #fdfefe;
        }
    </style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
  <!-- Header Bar -->
  <div class="admin-page-header">
    <div>
      <div class="admin-header-title">
        <i class="fas fa-cash-register me-2 text-warning"></i>Data Transaksi Pembayaran
      </div>
    </div>
    <div class="admin-header-actions">
      <button class="btn btn-outline-danger btn-admin-header flex-shrink-0" onclick="window.location.href='cetak_semua_pembayaran.php?bulan=<?= urlencode($filterBulan) ?>&tahun=<?= urlencode($filterTahun) ?>'" title="Cetak Laporan">
        <i class="fa fa-print me-1.5"></i> Laporan
      </button>
      <div style="width: 220px;">
        <input type="text" id="liveSearchPembayaran" class="form-control search-input-admin" placeholder="Cari transaksi...">
      </div>
    </div>
  </div>

  <!-- Flash Messages -->
  <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
      <i class="fas fa-check-circle me-1.5"></i> <?= $_SESSION['success']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
  <?php endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
      <i class="fas fa-exclamation-triangle me-1.5"></i> <?= $_SESSION['error']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
  <?php endif; ?>

  <!-- Filter Periode -->
  <div class="card p-3 mb-3 border-0 shadow-sm rounded-3 bg-white">
    <form method="GET" class="row g-2 align-items-center">
      <?php if (!empty($activeTab) && $activeTab !== 'semua'): ?>
        <input type="hidden" name="tab" value="<?= htmlspecialchars($activeTab) ?>">
      <?php endif; ?>

      <div class="col-md-4 col-6">
        <label class="form-label text-muted small mb-1 fw-bold"><i class="fas fa-calendar-alt me-1 text-primary"></i> Filter Bulan</label>
        <select name="bulan" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="semua" <?= ($filterBulan === 'semua') ? 'selected' : '' ?>>Semua Bulan</option>
          <?php
          $namaBulan = [
            '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
            '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
            '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
          ];
          foreach ($namaBulan as $blnNum => $blnTxt): ?>
            <option value="<?= $blnNum ?>" <?= ($filterBulan === $blnNum) ? 'selected' : '' ?>><?= $blnTxt ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 col-6">
        <label class="form-label text-muted small mb-1 fw-bold"><i class="fas fa-calendar me-1 text-primary"></i> Filter Tahun</label>
        <select name="tahun" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="semua" <?= ($filterTahun === 'semua') ? 'selected' : '' ?>>Semua Tahun</option>
          <?php foreach ($yearsList as $y): ?>
            <option value="<?= $y ?>" <?= ($filterTahun == $y) ? 'selected' : '' ?>><?= $y ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 col-12">
        <label class="form-label text-muted small mb-1 fw-bold"><i class="fas fa-bolt me-1 text-warning"></i> Filter Cepat</label>
        <div class="d-flex gap-1.5">
          <a href="?bulan=<?= date('m') ?>&tahun=<?= date('Y') ?><?= ($activeTab !== 'semua') ? '&tab='.$activeTab : '' ?>" class="btn btn-sm btn-outline-primary w-100 <?= ($filterBulan === date('m') && $filterTahun == date('Y')) ? 'active' : '' ?>">Bulan Ini</a>
          <a href="?bulan=semua&tahun=semua<?= ($activeTab !== 'semua') ? '&tab='.$activeTab : '' ?>" class="btn btn-sm btn-outline-secondary w-100 <?= ($filterBulan === 'semua' && $filterTahun === 'semua') ? 'active' : '' ?>">Semua Data</a>
        </div>
      </div>
    </form>
  </div>

  <!-- Tab Navigasi Pembayaran (4 TAB) -->
  <div class="d-flex justify-content-center mt-3 mb-4">
    <ul class="nav nav-pills gap-1.5 p-1 bg-white border rounded-3 shadow-sm d-inline-flex flex-wrap justify-content-center" id="pembayaranTabs" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'semua') ? 'active' : '' ?>" id="semua-tab" data-bs-toggle="pill" data-bs-target="#tabSemua" type="button" role="tab" aria-controls="tabSemua" aria-selected="<?= ($activeTab === 'semua') ? 'true' : 'false' ?>">
          <i class="fas fa-clock me-1.5"></i> Menunggu Konfirmasi <span class="badge bg-primary ms-1.5"><?= count($listSemuaFiltered) ?></span>
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'belum_lunas') ? 'active' : '' ?>" id="belum-lunas-tab" data-bs-toggle="pill" data-bs-target="#tabBelumLunas" type="button" role="tab" aria-controls="tabBelumLunas" aria-selected="<?= ($activeTab === 'belum_lunas') ? 'true' : 'false' ?>">
          <i class="fas fa-exclamation-circle me-1.5"></i> Belum Lunas <span class="badge bg-warning text-dark ms-1.5"><?= count($listBelumLunasFiltered) ?></span>
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'lunas') ? 'active' : '' ?>" id="lunas-tab" data-bs-toggle="pill" data-bs-target="#tabLunas" type="button" role="tab" aria-controls="tabLunas" aria-selected="<?= ($activeTab === 'lunas') ? 'true' : 'false' ?>">
          <i class="fas fa-check-circle me-1.5"></i> Lunas <span class="badge bg-success ms-1.5"><?= count($listLunasFiltered) ?></span>
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'ditolak') ? 'active' : '' ?>" id="ditolak-tab" data-bs-toggle="pill" data-bs-target="#tabDitolak" type="button" role="tab" aria-controls="tabDitolak" aria-selected="<?= ($activeTab === 'ditolak') ? 'true' : 'false' ?>">
          <i class="fas fa-times-circle me-1.5"></i> Ditolak <span class="badge bg-danger ms-1.5"><?= count($listDitolakFiltered) ?></span>
        </button>
      </li>
    </ul>
  </div>

  <!-- Tab Content -->
  <div class="tab-content" id="pembayaranTabsContent">

    <!-- TAB 1: MENUNGGU KONFIRMASI -->
    <div class="tab-pane fade <?= ($activeTab === 'semua') ? 'show active' : '' ?>" id="tabSemua" role="tabpanel" aria-labelledby="semua-tab">
      <?php if (!empty($listSemuaFiltered)): ?>
        <div class="d-flex flex-wrap justify-content-between align-items-center bg-white px-3 py-2 rounded-3 border mb-3 shadow-sm gap-2">
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-layer-group text-warning fs-6"></i>
                <div>
                    <span class="fw-bold text-dark small d-block" style="font-size: 0.80rem;">Sistem Antrean FIFO Pembayaran Aktif</span>
                    <span class="text-muted" style="font-size: 0.74rem;">Transaksi diurutkan dari terlama di atas. Antrean berikutnya otomatis terbuka setelah antrean di atasnya terverifikasi.</span>
                </div>
            </div>
            <span class="badge bg-light text-dark border small py-1 px-2.5 rounded-pill" style="font-size: 0.72rem;">
                <i class="fas fa-shield-alt text-success me-1"></i> Smart FIFO Lock Aktif
            </span>
        </div>

        <div class="row g-3" id="containerSemua">
          <?php 
          foreach ($listSemuaFiltered as $row): 
            $status = !empty($row['status']) ? $row['status'] : 'Menunggu konfirmasi';
            $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
            $isLocked = $row['is_locked'] ?? false;
            $blockingNo = $row['blocking_queue_no'] ?? 1;
          ?>
          <div class="col-lg-6 col-md-6 col-12 admin-pembayaran-card-item">
            <div class="admin-order-card <?= $isLocked ? 'card-locked' : '' ?>">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-2 pb-2 border-bottom">
                <div class="d-flex align-items-center gap-1.5 flex-wrap">
                  <?php if ($isLocked): ?>
                    <span class="badge bg-secondary px-2 py-0.5 rounded" style="font-size: 0.70rem;" title="Terkunci: Selesaikan Antrean #<?= $blockingNo ?> terlebih dahulu">
                      <i class="fas fa-lock text-danger me-1"></i>#<?= $row['queue_no']; ?> Terkunci
                    </span>
                  <?php else: ?>
                    <span class="badge bg-success px-2 py-0.5 rounded fw-bold" style="font-size: 0.70rem;">
                      <i class="fas fa-unlock me-1"></i>#<?= $row['queue_no']; ?> Prioritas
                    </span>
                  <?php endif; ?>
                  <span class="badge bg-dark font-monospace px-2 py-0.5 rounded" style="font-size: 0.74rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($no_tagihan) ?>
                  </span>
                  <?= statusLabel($status) ?>
                </div>
                <span class="text-muted" style="font-size: 0.72rem;">
                  <i class="far fa-calendar-alt me-1 text-secondary"></i><?= date('d M Y H:i', strtotime($row['tanggal_bayar'])) ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block" style="font-size: 0.82rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']) ?>
                  </span>
                  <small class="text-muted text-truncate d-block" style="font-size: 0.72rem;"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </div>
                <div class="d-flex align-items-center gap-1.5 flex-shrink-0">
                  <span class="badge bg-light text-dark border px-2 py-1" style="font-size: 0.72rem;">
                    <?= htmlspecialchars($row['metode']) ?>
                  </span>
                  <?php 
                  $buktiFiles = array_values(array_filter(array_map('trim', explode(',', $row['bukti_pembayaran'] ?? ''))));
                  if (!empty($buktiFiles)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($buktiFiles[0]) ?>" target="_blank" class="btn btn-outline-info btn-admin-action" title="Lihat Foto Bukti">
                      <i class="fas fa-image me-1"></i>Bukti
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border px-2 py-1" style="font-size: 0.70rem;">Tunai</span>
                  <?php endif; ?>
                </div>
              </div>

              <div class="bg-light p-2 rounded border mb-2.5 d-flex justify-content-between align-items-center" style="font-size: 0.76rem;">
                <span class="text-dark fw-semibold text-truncate me-2">
                  <i class="fas fa-cube text-secondary me-1"></i><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?>
                </span>
                <span class="text-muted small flex-shrink-0">Tagihan: <strong class="text-dark">Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></strong></span>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Jumlah Dibayar</small>
                  <span class="fw-bold text-success" style="font-size: 0.95rem;">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                </div>

                <div class="d-flex align-items-center gap-1.5">
                  <?php if ($isLocked): ?>
                    <button type="button" class="btn btn-secondary btn-admin-action" onclick="alertLocked(<?= $blockingNo ?>)" title="Terkunci">
                      <i class="fa fa-lock"></i>
                    </button>
                  <?php else: ?>
                    <button class="btn btn-warning btn-admin-action" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>" title="Edit Status">
                      <i class="fa fa-pen-to-square me-1"></i>Status
                    </button>
                  <?php endif; ?>

                  <button class="btn btn-outline-primary btn-admin-action" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id'] ?>" title="Lihat Detail">
                    <i class="fas fa-info-circle me-1"></i>Detail
                  </button>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border bg-white shadow-sm">
          <i class="fa fa-clock fs-2 text-muted mb-2"></i>
          <h6 class="fw-bold mb-1" style="color: #0e4430;">Tidak Ada Pembayaran Menunggu</h6>
          <p class="text-muted small mb-0">Seluruh antrean pembayaran telah terverifikasi.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- TAB 2: BELUM LUNAS -->
    <div class="tab-pane fade <?= ($activeTab === 'belum_lunas') ? 'show active' : '' ?>" id="tabBelumLunas" role="tabpanel" aria-labelledby="belum-lunas-tab">
      <?php if (!empty($listBelumLunasPaginated)): ?>
        <div class="d-flex flex-wrap justify-content-between align-items-center bg-white px-3 py-2 rounded-3 border mb-3 shadow-sm gap-2">
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-hourglass-half text-warning fs-6"></i>
                <div>
                    <span class="fw-bold text-dark small d-block" style="font-size: 0.80rem;">Sistem Antrean Pelunasan FIFO Aktif</span>
                    <span class="text-muted" style="font-size: 0.74rem;">Pelunasan diprioritaskan dari transaksi DP terlama di posisi paling atas (#1 Prioritas).</span>
                </div>
            </div>
            <span class="badge bg-light text-dark border small py-1 px-2.5 rounded-pill" style="font-size: 0.72rem;">
                <i class="fas fa-shield-alt text-success me-1"></i> FIFO Pelunasan Locked
            </span>
        </div>

        <div class="row g-3" id="containerBelumLunas">
          <?php 
          foreach ($listBelumLunasPaginated as $row): 
            $status = $row['status'];
            $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
            $isLockedBL = $row['is_locked'] ?? false;
            $blockingNoBL = $row['blocking_queue_no'] ?? 1;
          ?>
          <div class="col-lg-6 col-md-6 col-12 admin-pembayaran-card-item">
            <div class="admin-order-card <?= $isLockedBL ? 'card-locked' : '' ?>">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-2 pb-2 border-bottom">
                <div class="d-flex align-items-center gap-1.5 flex-wrap">
                  <?php if ($isLockedBL): ?>
                    <span class="badge bg-secondary px-2 py-0.5 rounded" style="font-size: 0.70rem;" title="Terkunci: Dahulukan pelunasan antrean #<?= $blockingNoBL ?>">
                      <i class="fas fa-lock text-danger me-1"></i>#<?= $row['queue_no']; ?> Terkunci
                    </span>
                  <?php else: ?>
                    <span class="badge bg-success px-2 py-0.5 rounded fw-bold" style="font-size: 0.70rem;">
                      <i class="fas fa-unlock me-1"></i>#<?= $row['queue_no']; ?> Prioritas Pelunasan
                    </span>
                  <?php endif; ?>
                  <span class="badge bg-dark font-monospace px-2 py-0.5 rounded" style="font-size: 0.74rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($no_tagihan) ?>
                  </span>
                  <?= statusLabel($status) ?>
                </div>
                <span class="text-muted" style="font-size: 0.72rem;">
                  <i class="far fa-calendar-alt me-1 text-secondary"></i><?= date('d M Y H:i', strtotime($row['tanggal_bayar'])) ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block" style="font-size: 0.82rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']) ?>
                  </span>
                  <small class="text-muted text-truncate d-block" style="font-size: 0.72rem;"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </div>
                <div class="d-flex align-items-center gap-1.5 flex-shrink-0">
                  <span class="badge bg-light text-dark border px-2 py-1" style="font-size: 0.72rem;">
                    <?= htmlspecialchars($row['metode']) ?>
                  </span>
                  <?php 
                  $buktiFiles = array_values(array_filter(array_map('trim', explode(',', $row['bukti_pembayaran'] ?? ''))));
                  if (!empty($buktiFiles)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($buktiFiles[0]) ?>" target="_blank" class="btn btn-outline-info btn-admin-action" title="Lihat Foto Bukti DP">
                      <i class="fas fa-image me-1"></i>Bukti DP
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border px-2 py-1" style="font-size: 0.70rem;">Tunai</span>
                  <?php endif; ?>
                </div>
              </div>

              <div class="bg-light p-2 rounded border mb-2.5 d-flex justify-content-between align-items-center" style="font-size: 0.76rem;">
                <span class="text-dark fw-semibold text-truncate me-2">
                  <i class="fas fa-cube text-secondary me-1"></i><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?>
                </span>
                <span class="text-muted small flex-shrink-0">Sisa: <strong class="text-danger">Rp<?= number_format(max(0, $row['total_tagihan'] - $row['jumlah_bayar']), 0, ',', '.') ?></strong></span>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">DP Masuk</small>
                  <span class="fw-bold text-warning text-dark" style="font-size: 0.95rem;">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                </div>

                <div class="d-flex align-items-center gap-1.5">
                  <?php if ($isLockedBL): ?>
                    <button type="button" class="btn btn-secondary btn-admin-action" onclick="alertLocked(<?= $blockingNoBL ?>)" title="Terkunci: Dahulukan pelunasan antrean terlama">
                      <i class="fa fa-lock"></i>
                    </button>
                  <?php else: ?>
                    <button class="btn btn-warning btn-admin-action" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>" title="Edit Status Pelunasan">
                      <i class="fa fa-pen-to-square me-1"></i>Status
                    </button>
                  <?php endif; ?>

                  <button class="btn btn-outline-primary btn-admin-action" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id'] ?>" title="Lihat Detail">
                    <i class="fas fa-info-circle me-1"></i>Detail
                  </button>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= renderPaginationBar($pageBelumLunas, $totalPagesBelumLunas, $totalItemsBelumLunas, count($listBelumLunasPaginated), 'page_belum_lunas') ?>

      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border bg-white shadow-sm">
          <i class="fa fa-exclamation-circle fs-2 text-warning mb-2"></i>
          <h6 class="fw-bold mb-1" style="color: #0e4430;">Tidak Ada Pembayaran Belum Lunas</h6>
          <p class="text-muted small mb-0">Tidak ada data transaksi pembayaran yang berstatus DP / Belum Lunas.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- TAB 3: LUNAS -->
    <div class="tab-pane fade <?= ($activeTab === 'lunas') ? 'show active' : '' ?>" id="tabLunas" role="tabpanel" aria-labelledby="lunas-tab">
      <?php if (!empty($listLunasPaginated)): ?>
        <div class="row g-3" id="containerLunas">
          <?php 
          foreach ($listLunasPaginated as $row): 
            $status = $row['status'];
            $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
          ?>
          <div class="col-lg-6 col-md-6 col-12 admin-pembayaran-card-item">
            <div class="admin-order-card">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-2 pb-2 border-bottom">
                <div class="d-flex align-items-center gap-1.5 flex-wrap">
                  <span class="badge bg-dark font-monospace px-2 py-0.5 rounded" style="font-size: 0.74rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($no_tagihan) ?>
                  </span>
                  <?= statusLabel($status) ?>
                </div>
                <span class="text-muted" style="font-size: 0.72rem;">
                  <i class="far fa-calendar-alt me-1 text-secondary"></i><?= date('d M Y H:i', strtotime($row['tanggal_bayar'])) ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block" style="font-size: 0.82rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']) ?>
                  </span>
                  <small class="text-muted text-truncate d-block" style="font-size: 0.72rem;"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </div>
                <div class="d-flex align-items-center gap-1.5 flex-shrink-0">
                  <span class="badge bg-light text-dark border px-2 py-1" style="font-size: 0.72rem;">
                    <?= htmlspecialchars($row['metode']) ?>
                  </span>
                  <?php 
                  $buktiFiles = array_values(array_filter(array_map('trim', explode(',', $row['bukti_pembayaran'] ?? ''))));
                  if (!empty($buktiFiles)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($buktiFiles[0]) ?>" target="_blank" class="btn btn-outline-info btn-admin-action" title="Lihat Foto Bukti">
                      <i class="fas fa-image me-1"></i>Bukti
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border px-2 py-1" style="font-size: 0.70rem;">Tunai</span>
                  <?php endif; ?>
                </div>
              </div>

              <div class="bg-light p-2 rounded border mb-2.5 d-flex justify-content-between align-items-center" style="font-size: 0.76rem;">
                <span class="text-dark fw-semibold text-truncate me-2">
                  <i class="fas fa-cube text-secondary me-1"></i><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?>
                </span>
                <span class="text-muted small flex-shrink-0">Total Tagihan: <strong class="text-dark">Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></strong></span>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Jumlah Dibayar</small>
                  <span class="fw-bold text-success" style="font-size: 0.95rem;">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                </div>

                <div class="d-flex align-items-center gap-1.5">
                  <button class="btn btn-secondary btn-admin-action" disabled title="Status Lunas Permanen">
                    <i class="fa fa-lock"></i>
                  </button>
                  <a href="../../cetak_invoice.php?id=<?= (int)$row['id']; ?>&from=admin" target="_blank" class="btn btn-outline-success btn-admin-action" title="Cetak Struk Invoice Resmi">
                    <i class="fas fa-file-invoice me-1"></i>Invoice
                  </a>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= renderPaginationBar($pageLunas, $totalPagesLunas, $totalItemsLunas, count($listLunasPaginated), 'page_lunas') ?>

      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border bg-white shadow-sm">
          <i class="fa fa-check-circle fs-2 text-success mb-2"></i>
          <h6 class="fw-bold mb-1" style="color: #0e4430;">Belum Ada Pembayaran Lunas</h6>
          <p class="text-muted small mb-0">Tidak ada data pembayaran lunas untuk periode yang dipilih.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- TAB 4: DITOLAK -->
    <div class="tab-pane fade <?= ($activeTab === 'ditolak') ? 'show active' : '' ?>" id="tabDitolak" role="tabpanel" aria-labelledby="ditolak-tab">
      <?php if (!empty($listDitolakPaginated)): ?>
        <div class="row g-3" id="containerDitolak">
          <?php 
          foreach ($listDitolakPaginated as $row): 
            $status = $row['status'];
            $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
          ?>
          <div class="col-lg-6 col-md-6 col-12 admin-pembayaran-card-item">
            <div class="admin-order-card">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-2 pb-2 border-bottom">
                <div class="d-flex align-items-center gap-1.5 flex-wrap">
                  <span class="badge bg-dark font-monospace px-2 py-0.5 rounded" style="font-size: 0.74rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($no_tagihan) ?>
                  </span>
                  <?= statusLabel($status) ?>
                  <span class="badge bg-danger px-2 py-0.5 rounded" style="font-size: 0.68rem;">
                    <i class="fas fa-undo-alt me-1"></i>DP Dikembalikan
                  </span>
                </div>
                <span class="text-muted" style="font-size: 0.72rem;">
                  <i class="far fa-calendar-alt me-1 text-secondary"></i><?= date('d M Y H:i', strtotime($row['tanggal_bayar'])) ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block" style="font-size: 0.82rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']) ?>
                  </span>
                  <small class="text-muted text-truncate d-block" style="font-size: 0.72rem;"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </div>
                <div class="d-flex align-items-center gap-1.5 flex-shrink-0">
                  <span class="badge bg-light text-dark border px-2 py-1" style="font-size: 0.72rem;">
                    <?= htmlspecialchars($row['metode']) ?>
                  </span>
                  <?php 
                  $buktiFiles = array_values(array_filter(array_map('trim', explode(',', $row['bukti_pembayaran'] ?? ''))));
                  if (!empty($buktiFiles)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($buktiFiles[0]) ?>" target="_blank" class="btn btn-outline-info btn-admin-action" title="Lihat Foto Bukti">
                      <i class="fas fa-image me-1"></i>Bukti
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border px-2 py-1" style="font-size: 0.70rem;">Tunai</span>
                  <?php endif; ?>
                </div>
              </div>

              <div class="bg-light p-2 rounded border mb-2.5 d-flex justify-content-between align-items-center" style="font-size: 0.76rem;">
                <span class="text-dark fw-semibold text-truncate me-2">
                  <i class="fas fa-cube text-secondary me-1"></i><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?>
                </span>
                <span class="text-muted small flex-shrink-0">Total Tagihan: <strong class="text-dark">Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></strong></span>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Uang Masuk DP (Refunded)</small>
                  <span class="fw-bold text-danger" style="font-size: 0.95rem;">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                </div>

                <div class="d-flex align-items-center gap-1.5">
                  <button class="btn btn-outline-primary btn-admin-action" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id'] ?>" title="Lihat Detail">
                    <i class="fas fa-info-circle me-1"></i>Detail
                  </button>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= renderPaginationBar($pageDitolak, $totalPagesDitolak, $totalItemsDitolak, count($listDitolakPaginated), 'page_ditolak') ?>

      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border bg-white shadow-sm">
          <i class="fa fa-ban fs-2 text-muted mb-2"></i>
          <h6 class="fw-bold mb-1" style="color: #0e4430;">Tidak Ada Pembayaran Ditolak</h6>
          <p class="text-muted small mb-0">Tidak ada riwayat pembayaran yang ditolak untuk periode yang dipilih.</p>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<!-- ==========================================
     MODALS EDIT & DETAIL (Seluruh Pembayaran)
=========================================== -->
<?php foreach ($allPayments as $row): 
    $statusCurrent = $row['status'] ?? 'Menunggu konfirmasi';
    if (strtolower(trim($statusCurrent)) === 'lunas') {
        continue;
    }
    $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
?>
<!-- Modal Edit Status -->
<div class="modal fade" id="modalEdit<?= $row['id'] ?>" tabindex="-1" aria-labelledby="modalEditLabel<?= $row['id'] ?>" aria-hidden="true">
    <div class="modal-dialog">
        <form action="aksi_pembayaran.php?aksi=edit" method="POST" class="modal-content bg-white shadow">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="modalEditLabel<?= $row['id'] ?>">
                    <i class="fa fa-edit me-1 text-warning"></i> Edit Status Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label text-muted small mb-1">No. Tagihan / Invoice:</label>
                    <div class="fw-bold text-dark"><?= htmlspecialchars($no_tagihan) ?></div>
                </div>
                <div class="mb-3">
                    <label class="form-label text-muted small mb-1">Penyewa & Produk:</label>
                    <div class="fw-semibold"><?= htmlspecialchars($row['nama']) ?> - <?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></div>
                </div>
                <div class="mb-3">
                    <label class="form-label text-muted small mb-1">Jumlah Bayar Terdaftar:</label>
                    <div class="text-success fw-bold">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?> (dari total Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?>)</div>
                </div>

                <!-- SELECT OPTION VALIDASI STATUS -->
                <div class="mb-3">
                    <label for="status<?= $row['id'] ?>" class="form-label fw-bold">Ubah Status Pembayaran:</label>
                    <select name="status" id="status<?= $row['id'] ?>" class="form-select" required>
                        <?php if (strcasecmp($statusCurrent, 'Belum lunas') === 0): ?>
                            <!-- Batasan Opsi jika status saat ini Belum Lunas -->
                            <option value="Belum lunas" selected hidden>Belum lunas (DP Saja)</option>
                            <option value="Lunas">Lunas (Pelunasan Selesai)</option>
                        <?php else: ?>
                            <!-- Opsi Normal untuk transaksi Menunggu Konfirmasi -->
                            <option value="Menunggu konfirmasi" <?= (strcasecmp($statusCurrent, 'Menunggu konfirmasi') === 0) ? 'selected' : '' ?>>Menunggu konfirmasi</option>
                            <option value="Belum lunas" <?= (strcasecmp($statusCurrent, 'Belum lunas') === 0) ? 'selected' : '' ?>>Belum lunas</option>
                            <option value="Lunas" <?= (strcasecmp($statusCurrent, 'Lunas') === 0) ? 'selected' : '' ?>>Lunas</option>
                            <option value="ditolak" <?= (strcasecmp($statusCurrent, 'ditolak') === 0) ? 'selected' : '' ?>>Ditolak</option>
                        <?php endif; ?>
                    </select>

                    <?php if (strcasecmp($statusCurrent, 'Belum lunas') === 0): ?>
                        <div class="alert alert-info p-2 small mt-2 border border-info">
                            <i class="fas fa-info-circle text-info me-1"></i>
                            <strong>Proses Pelunasan:</strong> Transaksi ini sudah dikonfirmasi DP-nya. Mengubah status ini akan memproses <strong>Pelunasan Sisa Tagihan</strong>.
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning p-2 small mt-2 border border-warning">
                            <i class="fas fa-exclamation-triangle text-warning me-1"></i>
                            <strong>Penting:</strong> Jika diubah ke <strong>Ditolak</strong>, pesanan otomatis dibatalkan dan uang pembayaran/DP sebesar <strong>Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></strong> dikembalikan (refund) kepada penyewa.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary fw-bold" name="edit">
                    <i class="fa fa-save me-1"></i> Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Detail Pembayaran -->
<div class="modal fade" id="modalDetail<?= $row['id'] ?>" tabindex="-1" aria-labelledby="modalDetailLabel<?= $row['id'] ?>" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content bg-white shadow">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="modalDetailLabel<?= $row['id'] ?>">
                    <i class="fas fa-receipt me-1 text-warning"></i> Detail Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-2">
                    <div class="col-6">
                        <small class="text-muted">No. Tagihan</small>
                        <div class="fw-bold text-dark"><?= htmlspecialchars($no_tagihan) ?></div>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">Tanggal Bayar</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['tanggal_bayar']) ?></div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-6">
                        <small class="text-muted">Nama Penyewa</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['nama']) ?></div>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">Produk Sewa</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-6">
                        <small class="text-muted">Metode Pembayaran</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['metode']) ?></div>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">Status</small>
                        <div><?= statusLabel($row['status']) ?></div>
                    </div>
                </div>

                <div class="card border-light shadow-sm mb-3">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Jumlah Bayar:</span>
                            <span class="fw-bold text-success">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Total Tagihan:</span>
                            <span>Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></span>
                        </div>
                        <div class="d-flex justify-content-between fw-bold text-danger pt-2 border-top">
                            <span>Sisa Tagihan:</span>
                            <span>Rp<?= number_format(max(0, $row['total_tagihan'] - $row['jumlah_bayar']), 0, ',', '.') ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Live Search
    const searchInput = document.getElementById('liveSearchPembayaran');
    if (searchInput) {
        searchInput.addEventListener('keyup', function () {
            let keyword = this.value.toLowerCase().trim();
            document.querySelectorAll('.admin-pembayaran-card-item').forEach(card => {
                let text = card.textContent.toLowerCase();
                card.style.display = text.includes(keyword) ? '' : 'none';
            });
        });
    }

    // Tab Sync ke URL
    const tabButtons = document.querySelectorAll('#pembayaranTabs button[data-bs-toggle="pill"]');
    tabButtons.forEach(btn => {
        btn.addEventListener('shown.bs.tab', function(e) {
            const target = e.target.getAttribute('data-bs-target');
            if (target) {
                let tabName = target.replace('#tab', '').toLowerCase();
                if (tabName === 'belumlunas') tabName = 'belum_lunas';
                const url = new URL(window.location);
                url.searchParams.set('tab', tabName);
                window.history.replaceState({}, '', url);
            }
        });
    });
});

function alertLocked(antreanNo) {
    Swal.fire({
        icon: 'warning',
        title: 'Antrean Terkunci (Prinsip FIFO)',
        html: 'Harap verifikasi dan selesaikan transaksi pada <strong>Antrean #' + antreanNo + '</strong> terlebih dahulu sebelum memproses antrean ini.',
        confirmButtonColor: '#0e4430',
        confirmButtonText: '<i class="fas fa-check me-1"></i> Mengerti'
    });
}
</script>

</body>
</html>