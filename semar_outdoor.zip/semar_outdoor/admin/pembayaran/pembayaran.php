<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';

// Tab Aktif (Default: semua, atau lunas, atau ditolak)
$activeTab = strtolower(trim($_GET['tab'] ?? 'semua'));
if (!in_array($activeTab, ['semua', 'lunas', 'ditolak'])) {
    $activeTab = 'semua';
}

/* =========================================================================
   [FIFO LOGIC] 1. QUERY ANTREAN VERIFIKASI PEMBAYARAN ADMIN (FIFO)
   - Pembayaran yang masuk diurutkan secara First-In, First-Out (tanggal_bayar ASC, id ASC)
   ========================================================================= */
$pembayaranQuery = mysqli_query($conn, "
    SELECT 
        pembayaran.*, 
        users.nama, 
        users.email, 
        COALESCE(
            NULLIF(GROUP_CONCAT(DISTINCT s.no_tagihan SEPARATOR ', '), ''),
            NULLIF(GROUP_CONCAT(DISTINCT sb.no_tagihan SEPARATOR ', '), ''),
            CONCAT('INV-', DATE_FORMAT(pembayaran.tanggal_bayar, '%Y%m%d'), '-', LPAD(pembayaran.id, 4, '0'))
        ) AS no_tagihan_formatted,
        COALESCE(
            NULLIF(GROUP_CONCAT(DISTINCT CONCAT(s.nama_produk, ' (x', s.qty, ')') SEPARATOR ', '), ''),
            NULLIF(GROUP_CONCAT(DISTINCT CONCAT(sb.nama_produk, ' (x', sb.qty, ')') SEPARATOR ', '), ''),
            'Item Sewa (Dibatalkan)'
        ) AS nama_produk_list,
        COALESCE(MIN(s.tanggal_buat), MIN(sb.dibatalkan_pada)) AS tanggal_buat
    FROM pembayaran 
    JOIN users ON pembayaran.id_users = users.id
    LEFT JOIN sewa s ON FIND_IN_SET(s.id, pembayaran.id_sewa)
    LEFT JOIN sewa_dibatalkan sb ON sb.id_users = pembayaran.id_users AND (sb.no_tagihan = s.no_tagihan OR sb.no_tagihan LIKE CONCAT('%-', LPAD(pembayaran.id_sewa, 4, '0')) OR sb.no_tagihan LIKE CONCAT('%-', LPAD(pembayaran.id_sewa, 3, '0')))
    GROUP BY pembayaran.id
    ORDER BY pembayaran.tanggal_bayar ASC, pembayaran.id ASC
");

// Klasifikasi data ke dalam 3 kelompok tab
$listSemua = [];   // Menunggu konfirmasi & Belum lunas
$listLunas = [];   // Lunas
$listDitolak = []; // Ditolak
$allPayments = [];

if ($pembayaranQuery && mysqli_num_rows($pembayaranQuery) > 0) {
    while ($row = mysqli_fetch_assoc($pembayaranQuery)) {
        if (!empty($row['no_tagihan_formatted'])) {
            $row['no_tagihan'] = $row['no_tagihan_formatted'];
        }
        if (!empty($row['nama_produk_list'])) {
            $row['nama_produk'] = $row['nama_produk_list'];
        }
        $allPayments[] = $row;
        $st = strtolower(trim($row['status'] ?? ''));
        if ($st === 'lunas') {
            $listLunas[] = $row;
        } elseif ($st === 'ditolak') {
            $listDitolak[] = $row;
        } else {
            // 'menunggu konfirmasi', 'belum lunas', atau default
            $listSemua[] = $row;
        }
    }
}

// Urutkan histori Lunas & Ditolak dari yang paling baru
usort($listLunas, function($a, $b) {
    return strtotime($b['tanggal_bayar']) <=> strtotime($a['tanggal_bayar']);
});
usort($listDitolak, function($a, $b) {
    return strtotime($b['tanggal_bayar']) <=> strtotime($a['tanggal_bayar']);
});

/* =========================================================================
   [FIFO LOGIC] 2. SMART FIFO & QUEUE LOCKING PADA ANTREAN PEMBAYARAN
   - Memastikan admin memverifikasi bukti pembayaran yang masuk lebih awal terlebih dahulu.
   - Jika antrean #N masih 'Menunggu konfirmasi', maka antrean #(N+1) ke atas akan TERKUNCI (Locked).
   - Mencegah inkonsistensi data dan kelalaian verifikasi bukti transfer user.
   ========================================================================= */
$queueCounter = 1;
$hasPendingConfirmationBefore = false;
$blockingQueueNo = 1;

foreach ($listSemua as &$item) {
    $item['queue_no'] = $queueCounter++;
    $st = strtolower(trim($item['status'] ?? ''));

    // [FIFO] Jika antrean sebelumnya masih 'Menunggu konfirmasi', kunci antrean ini
    if ($hasPendingConfirmationBefore) {
        $item['is_locked'] = true;
        $item['blocking_queue_no'] = $blockingQueueNo;
    } else {
        $item['is_locked'] = false;
        $item['blocking_queue_no'] = null;
    }

    // Jika item ini berstatus 'Menunggu konfirmasi', maka antrean selanjutnya harus menunggu item ini
    if ($st === 'menunggu konfirmasi' || empty($st)) {
        if (!$hasPendingConfirmationBefore) {
            $blockingQueueNo = $item['queue_no'];
        }
        $hasPendingConfirmationBefore = true;
    }
}
unset($item);

function statusLabel($status) {
    $st = strtolower(trim($status ?? ''));
    switch ($st) {
        case 'belum lunas':
            return '<span class="badge bg-warning text-dark">Belum lunas</span>';
        case 'lunas':
            return '<span class="badge bg-success">Lunas</span>';
        case 'ditolak':
            return '<span class="badge bg-danger">Ditolak</span>';
        default:
            return '<span class="badge bg-primary">Menunggu konfirmasi</span>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Data Pembayaran - Admin Semar Outdoor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="https://npmcdn.com/flatpickr/dist/themes/airbnb.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <style>
        body { background: #f8f9fa; }
        .flatpickr-day.flatpickr-disabled, 
        .flatpickr-day.flatpickr-disabled:hover,
        .flatpickr-day.prevMonthDay, 
        .flatpickr-day.nextMonthDay {
            color: #94a3b8 !important;
            background: #f1f5f9 !important;
            border-color: transparent !important;
            cursor: not-allowed !important;
            pointer-events: none !important;
            opacity: 0.4 !important;
            text-decoration: line-through !important;
        }
        .flatpickr-calendar {
            z-index: 99999 !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2) !important;
            border-radius: 12px !important;
        }
        .nav-pills .nav-link.active {
            background-color: rgba(0, 0, 0, 0.76);
            color: white;
            font-weight: 600;
        }
        .nav-pills .nav-link {
            color: #333;
            font-weight: 500;
        }
        table {
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(32, 27, 27, 0.05);
        }
        th, td {
            vertical-align: middle !important;
        }
        .img-thumb-bukti {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 6px;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .img-thumb-bukti:hover {
            transform: scale(1.15);
        }
        .sewa-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 12px;
            max-height: 200px;
            overflow-y: auto;
            padding: 4px;
        }
        .sewa-item-checkbox {
            cursor: pointer;
            padding: 8px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            margin-bottom: 6px;
            background: #fff;
            transition: all 0.2s;
        }
        .sewa-item-checkbox:hover {
            background: #f1f5f9;
            border-color: #cbd5e1;
        }
        .sewa-item-checkbox input[type="checkbox"]:checked + label {
            font-weight: bold;
            color: #0e4430;
        }
        .aksi-btn {
            display: flex;
            gap: 4px;
            justify-content: center;
        }
        #areaCetak table, #areaCetak th, #areaCetak td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        #areaCetak th {
            background-color: #f2f2f2;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        #areaCetak td, #areaCetak th {
            padding: 6px;
            font-size: 13px;
        }
        @media print {
            body > *:not(#areaCetak) {
                display: none !important;
            }
            #areaCetak {
                display: block;
                width: 100%;
            }
        }
    </style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="content-wrapper p-4" style="margin-left: 260px; min-height: 100vh;">
  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
      <h3 class="fw-bold mb-0">
        <i class="fas fa-cash-register me-2 text-primary"></i> Data Transaksi Pembayaran
      </h3>
      <p class="text-muted small mb-0">Kelola dan verifikasi bukti transfer pembayaran sewa alat secara berkala.</p>
    </div>
    
    <!-- Quick Search Top -->
    <div style="max-width: 320px; width: 100%;">
      <input type="text" id="liveSearchPembayaran" class="form-control"
             placeholder="Cari nama / no. tagihan / metode...">
    </div>
  </div>

  <!-- Flash Messages -->
  <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['success']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
  <?php endif; ?>

  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['error']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
  <?php endif; ?>

  <!-- Actions & Live Search -->
  <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-3">
    <div class="d-flex gap-2">
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambahPembayaran">
        <i class="fa fa-plus-circle me-1"></i> Tambah Pembayaran
      </button>
      <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalCetak" title="Cetak Laporan">
        <i class="fa fa-print me-1"></i> Cetak Laporan
      </button>
    </div>
  </div>

  <!-- Tab Navigasi Pembayaran -->
  <ul class="nav nav-pills mb-3 justify-content-center" id="pembayaranTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= ($activeTab === 'semua') ? 'active' : '' ?>" id="semua-tab" data-bs-toggle="pill" data-bs-target="#tabSemua" type="button" role="tab" aria-controls="tabSemua" aria-selected="<?= ($activeTab === 'semua') ? 'true' : 'false' ?>">
        <i class="fas fa-clock me-1"></i> Semua Pembayaran <span class="badge bg-warning text-dark ms-1"><?= count($listSemua) ?></span>
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= ($activeTab === 'lunas') ? 'active' : '' ?>" id="lunas-tab" data-bs-toggle="pill" data-bs-target="#tabLunas" type="button" role="tab" aria-controls="tabLunas" aria-selected="<?= ($activeTab === 'lunas') ? 'true' : 'false' ?>">
        <i class="fas fa-check-circle me-1"></i> Lunas <span class="badge bg-success ms-1"><?= count($listLunas) ?></span>
      </button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= ($activeTab === 'ditolak') ? 'active' : '' ?>" id="ditolak-tab" data-bs-toggle="pill" data-bs-target="#tabDitolak" type="button" role="tab" aria-controls="tabDitolak" aria-selected="<?= ($activeTab === 'ditolak') ? 'true' : 'false' ?>">
        <i class="fas fa-times-circle me-1"></i> Ditolak <span class="badge bg-danger ms-1"><?= count($listDitolak) ?></span>
      </button>
    </li>
  </ul>

  <!-- Tab Content -->
  <div class="tab-content" id="pembayaranTabsContent">

    <!-- ==========================================
         TAB 1: SEMUA PEMBAYARAN (Menunggu Konfirmasi / Belum Lunas)
    =========================================== -->
    <div class="tab-pane fade <?= ($activeTab === 'semua') ? 'show active' : '' ?>" id="tabSemua" role="tabpanel" aria-labelledby="semua-tab">
      <?php if (!empty($listSemua)): ?>
        <!-- Info Banner Smart FIFO -->
        <div class="d-flex flex-wrap justify-content-between align-items-center bg-white p-3 rounded-4 border mb-3 shadow-sm gap-2">
            <div class="d-flex align-items-center gap-2">
                <i class="fas fa-layer-group text-warning fs-5"></i>
                <div>
                    <span class="fw-bold text-dark small d-block">Sistem Antrean FIFO Pembayaran Aktif</span>
                    <span class="text-muted" style="font-size: 0.8rem;">Transaksi diurutkan berdasarkan waktu bayar terlama. Antrean berikutnya otomatis terbuka setelah antrean sebelumnya diverifikasi.</span>
                </div>
            </div>
            <span class="badge bg-light text-dark border small py-2 px-3 rounded-pill">
                <i class="fas fa-shield-alt text-success me-1"></i> Smart FIFO Lock Aktif
            </span>
        </div>

        <div class="table-responsive">
          <table class="table table-bordered table-hover bg-white align-middle" id="tabelSemua">
            <thead class="table-secondary text-center">
              <tr>
                <th style="width: 130px;">Antrean</th>
                <th>No. Tagihan</th>
                <th>Nama Penyewa</th>
                <th>Produk</th>
                <th>Metode</th>
                <th>Bukti</th>
                <th>Jumlah Bayar</th>
                <th>Total Tagihan</th>
                <th>Status</th>
                <th>Tanggal Bayar</th>
                <th style="width: 130px;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              foreach ($listSemua as $row): 
                $status = !empty($row['status']) ? $row['status'] : 'Menunggu konfirmasi';
                $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
                $isLocked = $row['is_locked'] ?? false;
                $blockingNo = $row['blocking_queue_no'] ?? 1;
              ?>
              <tr class="<?= $isLocked ? 'table-light opacity-75' : '' ?>">
                <td class="text-center">
                  <?php if ($isLocked): ?>
                    <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary py-1 px-2 rounded-pill small" title="Terkunci: Selesaikan Antrean #<?= $blockingNo ?> terlebih dahulu">
                      <i class="fas fa-lock text-danger me-1"></i>#<?= $row['queue_no']; ?> Terkunci
                    </span>
                  <?php else: ?>
                    <span class="badge bg-success bg-opacity-10 text-success border border-success py-1 px-2 rounded-pill small fw-bold">
                      <i class="fas fa-unlock me-1"></i>#<?= $row['queue_no']; ?> Prioritas
                    </span>
                  <?php endif; ?>
                </td>
                <td><span class="badge bg-dark"><?= htmlspecialchars($no_tagihan) ?></span></td>
                <td>
                  <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                  <small class="text-muted"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </td>
                <td><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['metode']) ?></span></td>
                <td class="text-center">
                  <?php 
                  $bukti = $row['bukti_pembayaran'] ?? '';
                  if ($bukti && file_exists('../../bukti_pembayaran/' . $bukti)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($bukti) ?>" target="_blank" title="Klik untuk memperbesar bukti">
                      <img src="../../bukti_pembayaran/<?= htmlspecialchars($bukti) ?>" alt="Bukti" class="img-thumb-bukti border">
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border">Tunai / Nihil</span>
                  <?php endif; ?>
                </td>
                <td class="text-success fw-bold">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></td>
                <td>Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></td>
                <td class="text-center"><?= statusLabel($status) ?></td>
                <td><small><?= htmlspecialchars($row['tanggal_bayar']) ?></small></td>
                <td class="text-center">
                  <div class="aksi-btn">
                    <?php if ($isLocked): ?>
                      <button type="button" class="btn btn-sm btn-secondary" onclick="alertLocked(<?= $blockingNo ?>)" title="Terkunci: Harap verifikasi Antrean #<?= $blockingNo ?> terlebih dahulu">
                        <i class="fa fa-lock"></i>
                      </button>
                    <?php else: ?>
                      <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>" title="Edit Status">
                        <i class="fa fa-pen-to-square"></i>
                      </button>
                    <?php endif; ?>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id'] ?>" title="Lihat Detail">
                      <i class="fas fa-info-circle"></i>
                    </button>
                    <?php if ($isLocked): ?>
                      <button class="btn btn-sm btn-outline-secondary" disabled title="Terkunci"><i class="fa fa-trash"></i></button>
                    <?php else: ?>
                      <form method="POST" action="aksi_pembayaran.php?aksi=hapus" onsubmit="return confirm('Hapus data transaksi pembayaran ini?')" style="display:inline;">
                        <input type="hidden" name="id" value="<?= (int)$row['id']; ?>">
                        <input type="hidden" name="tab" value="semua">
                        <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fa fa-trash"></i></button>
                      </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="alert alert-info text-center mt-3">
          <i class="fa fa-info-circle me-1"></i> Tidak ada data pembayaran yang sedang menunggu konfirmasi atau belum lunas.
        </div>
      <?php endif; ?>
    </div>

    <!-- ==========================================
         TAB 2: LUNAS
    =========================================== -->
    <div class="tab-pane fade <?= ($activeTab === 'lunas') ? 'show active' : '' ?>" id="tabLunas" role="tabpanel" aria-labelledby="lunas-tab">
      <?php if (!empty($listLunas)): ?>
        <div class="table-responsive">
          <table class="table table-bordered table-hover bg-white align-middle" id="tabelLunas">
            <thead class="table-secondary text-center">
              <tr>
                <th>No</th>
                <th>No. Tagihan</th>
                <th>Nama Penyewa</th>
                <th>Produk</th>
                <th>Metode</th>
                <th>Bukti</th>
                <th>Jumlah Bayar</th>
                <th>Total Tagihan</th>
                <th>Status</th>
                <th>Tanggal Bayar</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no = 1; 
              foreach ($listLunas as $row): 
                $status = $row['status'];
                $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
              ?>
              <tr>
                <td class="text-center fw-bold"><?= $no++; ?></td>
                <td><span class="badge bg-dark"><?= htmlspecialchars($no_tagihan) ?></span></td>
                <td>
                  <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                  <small class="text-muted"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </td>
                <td><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['metode']) ?></span></td>
                <td class="text-center">
                  <?php 
                  $bukti = $row['bukti_pembayaran'] ?? '';
                  if ($bukti && file_exists('../../bukti_pembayaran/' . $bukti)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($bukti) ?>" target="_blank" title="Klik untuk memperbesar bukti">
                      <img src="../../bukti_pembayaran/<?= htmlspecialchars($bukti) ?>" alt="Bukti" class="img-thumb-bukti border">
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border">Tunai / Nihil</span>
                  <?php endif; ?>
                </td>
                <td class="text-success fw-bold">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></td>
                <td>Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></td>
                <td class="text-center"><?= statusLabel($status) ?></td>
                <td><small><?= htmlspecialchars($row['tanggal_bayar']) ?></small></td>
                <td class="text-center">
                  <div class="aksi-btn">
                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>" title="Edit Status">
                      <i class="fa fa-pen-to-square"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id'] ?>" title="Lihat Detail">
                      <i class="fas fa-info-circle"></i>
                    </button>
                    <form method="POST" action="aksi_pembayaran.php?aksi=hapus" onsubmit="return confirm('Hapus data transaksi pembayaran ini?')" style="display:inline;">
                      <input type="hidden" name="id" value="<?= (int)$row['id']; ?>">
                      <input type="hidden" name="tab" value="lunas">
                      <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fa fa-trash"></i></button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="alert alert-info text-center mt-3">
          <i class="fa fa-info-circle me-1"></i> Belum ada data pembayaran dengan status Lunas.
        </div>
      <?php endif; ?>
    </div>

    <!-- ==========================================
         TAB 3: DITOLAK
    =========================================== -->
    <div class="tab-pane fade <?= ($activeTab === 'ditolak') ? 'show active' : '' ?>" id="tabDitolak" role="tabpanel" aria-labelledby="ditolak-tab">
      <?php if (!empty($listDitolak)): ?>
        <div class="table-responsive">
          <table class="table table-bordered table-hover bg-white align-middle" id="tabelDitolak">
            <thead class="table-secondary text-center">
              <tr>
                <th>No</th>
                <th>No. Tagihan</th>
                <th>Nama Penyewa</th>
                <th>Produk</th>
                <th>Metode</th>
                <th>Bukti</th>
                <th>Jumlah Bayar</th>
                <th>Total Tagihan</th>
                <th>Status</th>
                <th>Tanggal Bayar</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $no = 1; 
              foreach ($listDitolak as $row): 
                $status = $row['status'];
                $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
              ?>
              <tr>
                <td class="text-center fw-bold"><?= $no++; ?></td>
                <td><span class="badge bg-dark"><?= htmlspecialchars($no_tagihan) ?></span></td>
                <td>
                  <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                  <small class="text-muted"><?= htmlspecialchars($row['email'] ?? '') ?></small>
                </td>
                <td><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></td>
                <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($row['metode']) ?></span></td>
                <td class="text-center">
                  <?php 
                  $bukti = $row['bukti_pembayaran'] ?? '';
                  if ($bukti && file_exists('../../bukti_pembayaran/' . $bukti)): ?>
                    <a href="../../bukti_pembayaran/<?= htmlspecialchars($bukti) ?>" target="_blank" title="Klik untuk memperbesar bukti">
                      <img src="../../bukti_pembayaran/<?= htmlspecialchars($bukti) ?>" alt="Bukti" class="img-thumb-bukti border">
                    </a>
                  <?php else: ?>
                    <span class="badge bg-light text-muted border">Tunai / Nihil</span>
                  <?php endif; ?>
                </td>
                <td class="text-danger fw-bold">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></td>
                <td>Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></td>
                <td class="text-center"><?= statusLabel($status) ?></td>
                <td><small><?= htmlspecialchars($row['tanggal_bayar']) ?></small></td>
                <td class="text-center">
                  <div class="aksi-btn">
                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>" title="Edit Status">
                      <i class="fa fa-pen-to-square"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id'] ?>" title="Lihat Detail">
                      <i class="fas fa-info-circle"></i>
                    </button>
                    <form method="POST" action="aksi_pembayaran.php?aksi=hapus" onsubmit="return confirm('Hapus data transaksi pembayaran ini?')" style="display:inline;">
                      <input type="hidden" name="id" value="<?= (int)$row['id']; ?>">
                      <input type="hidden" name="tab" value="ditolak">
                      <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fa fa-trash"></i></button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="alert alert-info text-center mt-3">
          <i class="fa fa-info-circle me-1"></i> Tidak ada data pembayaran yang ditolak.
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<!-- ==========================================
     MODALS EDIT & DETAIL (Untuk seluruh pembayaran)
=========================================== -->
<?php foreach ($allPayments as $row): 
    $statusCurrent = $row['status'] ?? 'Menunggu konfirmasi';
    $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
?>
<!-- Modal Edit Status -->
<div class="modal fade" id="modalEdit<?= $row['id'] ?>" tabindex="-1" aria-labelledby="modalEditLabel<?= $row['id'] ?>" aria-hidden="true">
    <div class="modal-dialog">
        <form action="aksi_pembayaran.php?aksi=edit" method="POST" class="modal-content bg-white shadow">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="modalEditLabel<?= $row['id'] ?>">
                    <i class="fa fa-edit me-1 text-warning"></i> Edit Status Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label text-muted small mb-1">No. Tagihan / Invoice:</label>
                    <div class="fw-bold text-dark"><?= htmlspecialchars($no_tagihan) ?></div>
                </div>
                <div class="mb-3">
                    <label class="form-label text-muted small mb-1">Penyewa & Produk:</label>
                    <div class="fw-semibold"><?= htmlspecialchars($row['nama']) ?> - <?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></div>
                </div>
                <div class="mb-3">
                    <label class="form-label text-muted small mb-1">Jumlah Bayar:</label>
                    <div class="text-success fw-bold">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?> (dari total Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?>)</div>
                </div>
                <div class="mb-3">
                    <label for="status<?= $row['id'] ?>" class="form-label fw-bold">Ubah Status Pembayaran:</label>
                    <select name="status" id="status<?= $row['id'] ?>" class="form-select" required>
                        <option value="Menunggu konfirmasi" <?= (strcasecmp($statusCurrent, 'Menunggu konfirmasi') === 0) ? 'selected' : '' ?>>Menunggu konfirmasi</option>
                        <option value="Belum lunas" <?= (strcasecmp($statusCurrent, 'Belum lunas') === 0) ? 'selected' : '' ?>>Belum lunas</option>
                        <option value="Lunas" <?= (strcasecmp($statusCurrent, 'Lunas') === 0) ? 'selected' : '' ?>>Lunas</option>
                        <option value="ditolak" <?= (strcasecmp($statusCurrent, 'ditolak') === 0) ? 'selected' : '' ?>>Ditolak</option>
                    </select>
                    <small class="text-muted mt-1 d-block">
                        * Mengubah ke <strong>Lunas</strong> akan memindahkan data ke tab <em>Lunas</em>.<br>
                        * Mengubah ke <strong>Ditolak</strong> akan memindahkan data ke tab <em>Ditolak</em>.
                    </small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary fw-bold" name="edit">
                    <i class="fa fa-save me-1"></i> Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Detail Pembayaran -->
<div class="modal fade" id="modalDetail<?= $row['id'] ?>" tabindex="-1" aria-labelledby="modalDetailLabel<?= $row['id'] ?>" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content bg-white shadow">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="modalDetailLabel<?= $row['id'] ?>">
                    <i class="fas fa-receipt me-1 text-warning"></i> Detail Pembayaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-2">
                    <div class="col-6">
                        <small class="text-muted">No. Tagihan</small>
                        <div class="fw-bold text-dark"><?= htmlspecialchars($no_tagihan) ?></div>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">Tanggal Bayar</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['tanggal_bayar']) ?></div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-6">
                        <small class="text-muted">Nama Penyewa</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['nama']) ?></div>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">Produk Sewa</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['nama_produk'] ?? 'Sewa #' . $row['id_sewa']) ?></div>
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-6">
                        <small class="text-muted">Metode Pembayaran</small>
                        <div class="fw-semibold"><?= htmlspecialchars($row['metode']) ?></div>
                    </div>
                    <div class="col-6">
                        <small class="text-muted">Status</small>
                        <div><?= statusLabel($row['status']) ?></div>
                    </div>
                </div>

                <div class="mb-3">
                    <small class="text-muted">Bukti Pembayaran</small><br>
                    <?php if ($row['bukti_pembayaran'] && file_exists('../../bukti_pembayaran/' . $row['bukti_pembayaran'])): ?>
                        <a href="../../bukti_pembayaran/<?= htmlspecialchars($row['bukti_pembayaran']) ?>" target="_blank">
                            <img src="../../bukti_pembayaran/<?= htmlspecialchars($row['bukti_pembayaran']) ?>" class="img-thumbnail mt-1" style="max-width: 160px; max-height: 120px; object-fit: cover;">
                        </a>
                    <?php else: ?>
                        <div class="text-muted fst-italic">Pembayaran Tunai / Tidak ada file bukti</div>
                    <?php endif; ?>
                </div>

                <div class="card border-light shadow-sm">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Jumlah Bayar:</span>
                            <span class="fw-bold text-success">Rp<?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Total Tagihan:</span>
                            <span>Rp<?= number_format($row['total_tagihan'], 0, ',', '.') ?></span>
                        </div>
                        <div class="d-flex justify-content-between fw-bold text-danger pt-2 border-top">
                            <span>Sisa Tagihan:</span>
                            <span>Rp<?= number_format(max(0, $row['total_tagihan'] - $row['jumlah_bayar']), 0, ',', '.') ?></span>
                        </div>
                        <?php if ($row['jumlah_bayar'] > $row['total_tagihan']): ?>
                            <div class="text-muted mt-1 small">* Kelebihan bayar sebesar Rp<?= number_format($row['jumlah_bayar'] - $row['total_tagihan'], 0, ',', '.') ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- ==========================================
     MODAL TAMBAH PEMBAYARAN
=========================================== -->
<div class="modal fade" id="modalTambahPembayaran" tabindex="-1" aria-labelledby="modalTambahPembayaranLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    <form action="aksi_pembayaran.php?aksi=tambah" method="POST" class="modal-content bg-white shadow">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title" id="modalTambahPembayaranLabel">
                    <i class="fa fa-plus-circle me-1 text-warning"></i> Tambah Pembayaran Manual
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body">
                <!-- Pilih User -->
                <div class="mb-3">
                    <label for="id_users" class="form-label fw-semibold">Pilih Akun Pengguna <span class="text-danger">*</span></label>
                    <select name="id_users" id="id_users" class="form-select" required>
                        <option value="">-- Pilih Pengguna --</option>
                        <?php
                        $users = mysqli_query($conn, "SELECT id, nama, email FROM users ORDER BY nama ASC");
                        while ($user = mysqli_fetch_assoc($users)) {
                            echo '<option value="' . $user['id'] . '">' . htmlspecialchars($user['nama']) . ' (' . htmlspecialchars($user['email']) . ')</option>';
                        }
                        ?>
                    </select>
                </div>

                <!-- List Sewa Aktif User -->
                <div class="mb-3">
                    <label class="form-label fw-semibold">Pilih Item Sewa yang Dibayar <span class="text-danger">*</span></label>
                    <div id="list_sewa" class="sewa-grid border rounded p-2 bg-light">
                        <div class="text-muted small">Pilih pengguna terlebih dahulu untuk melihat daftar sewa aktif.</div>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <!-- Metode -->
                    <div class="col-md-6">
                        <label for="metode" class="form-label fw-semibold">Metode Pembayaran <span class="text-danger">*</span></label>
                        <select name="metode" id="metode" class="form-select" required>
                            <option value="">-- Pilih Metode --</option>
                            <option value="Tunai" selected>Tunai / Cash</option>
                            <option value="Transfer">Transfer Bank</option>
                            <option value="QRIS">QRIS</option>
                        </select>
                    </div>

                    <!-- Status -->
                    <div class="col-md-6">
                        <label for="status" class="form-label fw-semibold">Status Pembayaran <span class="text-danger">*</span></label>
                        <select name="status" id="status" class="form-select" required>
                            <option value="Lunas" selected>Lunas</option>
                            <option value="Belum lunas">Belum lunas</option>
                            <option value="Menunggu konfirmasi">Menunggu konfirmasi</option>
                            <option value="ditolak">Ditolak</option>
                        </select>
                    </div>

                    <!-- Total Tagihan -->
                    <div class="col-md-6">
                        <label for="total_tagihan" class="form-label fw-semibold">Total Tagihan Terpilih (Rp)</label>
                        <input type="number" name="total_tagihan" id="total_tagihan" class="form-control bg-light fw-bold" readonly required value="0">
                    </div>

                    <!-- Jumlah Bayar -->
                    <div class="col-md-6">
                        <label for="jumlah_bayar" class="form-label fw-semibold">Jumlah Bayar (Rp) <span class="text-danger">*</span></label>
                        <input type="number" name="jumlah_bayar" id="jumlah_bayar" class="form-control" min="10000" step="1000" required placeholder="Contoh: 10000, 15000, 20000, dst.">
                        <small class="text-muted" style="font-size: 0.75rem;"><i class="fas fa-info-circle text-primary me-1"></i> Minimal Rp 10.000 dan kelipatan Rp 1.000 (10.000, 11.000, 15.000, dst.).</small>
                    </div>

                    <!-- Tanggal Bayar -->
                    <div class="col-md-12">
                        <label for="tanggal_bayar" class="form-label fw-semibold">Tanggal & Waktu Bayar <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="text" name="tanggal_bayar" id="tanggal_bayar"
                                class="form-control bg-white"
                                placeholder="Pilih Tanggal & Waktu"
                                value="<?= date('Y-m-d H:i') ?>"
                                required>
                            <span class="input-group-text bg-light text-muted"><i class="fas fa-calendar-alt"></i></span>
                        </div>
                        <small class="text-muted" style="font-size: 0.75rem;"><i class="fas fa-ban text-danger me-1"></i> Hari sebelum hari ini dinonaktifkan / tidak dapat dipilih.</small>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" name="tambah" class="btn btn-primary fw-bold">
                    <i class="fa fa-save me-1"></i> Simpan Pembayaran
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ==========================================
     MODAL CETAK LAPORAN
=========================================== -->
<div class="modal fade" id="modalCetak" tabindex="-1" aria-labelledby="modalCetakLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content bg-white shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="modalCetakLabel">
          <i class="fa fa-print me-1 text-warning"></i> Cetak Seluruh Rekap Pembayaran
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <div id="areaCetak" class="p-3">
          <h4 class="text-center mb-1 fw-bold">Rekap Data Pembayaran - Semar Outdoor</h4>
          <p class="text-center text-muted mb-3">Dicetak pada: <?= date('d/m/Y H:i') ?> WIB</p>

          <table class="table table-sm table-bordered">
            <thead class="table-secondary text-center">
              <tr>
                <th>No</th>
                <th>No. Tagihan</th>
                <th>Nama Pengguna</th>
                <th>Nama Produk</th>
                <th>Metode</th>
                <th>Jumlah Bayar (Rp)</th>
                <th>Total Tagihan (Rp)</th>
                <th>Status</th>
                <th>Tanggal Bayar</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $queryCetak = mysqli_query($conn, "
                  SELECT p.*, u.nama AS nama_user, s.nama_produk, s.no_tagihan 
                  FROM pembayaran p
                  LEFT JOIN users u ON p.id_users = u.id
                  LEFT JOIN sewa s ON p.id_sewa = s.id
                  WHERE LOWER(TRIM(p.status)) IN ('lunas', 'belum lunas')
                  ORDER BY p.tanggal_bayar DESC
              ");
              $noCetak = 1;
              $totalCetakBayar = 0;
              $totalCetakTagihan = 0;
              while ($rowC = mysqli_fetch_assoc($queryCetak)) :
                $totalCetakBayar += (float)($rowC['jumlah_bayar'] ?? 0);
                $totalCetakTagihan += (float)($rowC['total_tagihan'] ?? 0);
                $no_tagihan_c = !empty($rowC['no_tagihan']) ? $rowC['no_tagihan'] : ('INV-' . date('Ymd', strtotime($rowC['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $rowC['id_sewa']));
              ?>
                <tr class="text-center">
                  <td><?= $noCetak++; ?></td>
                  <td><?= htmlspecialchars($no_tagihan_c) ?></td>
                  <td class="text-start"><?= htmlspecialchars($rowC['nama_user'] ?? '-') ?></td>
                  <td class="text-start"><?= htmlspecialchars($rowC['nama_produk'] ?? '-') ?></td>
                  <td><?= htmlspecialchars($rowC['metode'] ?? '-') ?></td>
                  <td>Rp <?= number_format($rowC['jumlah_bayar'] ?? 0, 0, ',', '.') ?></td>
                  <td>Rp <?= number_format($rowC['total_tagihan'] ?? 0, 0, ',', '.') ?></td>
                  <td>
                    <span class="badge <?= (strtolower(trim($rowC['status'] ?? '')) === 'lunas') ? 'bg-success' : 'bg-warning text-dark' ?>">
                      <?= htmlspecialchars($rowC['status'] ?? '-') ?>
                    </span>
                  </td>
                  <td><?= htmlspecialchars($rowC['tanggal_bayar'] ?? '-') ?></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
            <tfoot class="table-light fw-bold text-center">
              <tr>
                <td colspan="5" class="text-end">TOTAL PEMBAYARAN TERCATAT:</td>
                <td>Rp <?= number_format($totalCetakBayar, 0, ',', '.') ?></td>
                <td>Rp <?= number_format($totalCetakTagihan, 0, ',', '.') ?></td>
                <td colspan="2"></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="button" class="btn btn-danger fw-bold" onclick="cetakArea()" title="Print / Download PDF">
          <i class="fa fa-print me-1"></i> Cetak / Simpan PDF
        </button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/id.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Inisialisasi Flatpickr dengan pembatasan tanggal hari ini ke depan
    flatpickr("#tanggal_bayar", {
        enableTime: true,
        time_24hr: true,
        dateFormat: "Y-m-d H:i",
        defaultDate: "<?= date('Y-m-d H:i') ?>",
        minDate: "today",
        locale: "id",
        allowInput: false,
        disableMobile: "true"
    });

    const userSelect = document.getElementById('id_users');
    const totalTagihanInput = document.getElementById('total_tagihan');
    const listSewaContainer = document.getElementById('list_sewa');

    // 1. Ambil list sewa user via AJAX saat user dipilih
    userSelect.addEventListener('change', function () {
        let id_users = this.value;
        listSewaContainer.innerHTML = '';
        totalTagihanInput.value = 0;

        if (!id_users) {
            listSewaContainer.innerHTML = '<div class="text-muted small">Pilih pengguna terlebih dahulu untuk melihat daftar sewa aktif.</div>';
            return;
        }

        fetch('aksi_pembayaran.php?aksi=get_sewa&id_users=' + id_users)
            .then(res => res.json())
            .then(data => {
                if (data.length === 0) {
                    listSewaContainer.innerHTML = `<div class="text-muted small p-2">Tidak ada data sewa aktif untuk pengguna ini.</div>`;
                    return;
                }

                data.forEach(item => {
                    let sudahBayar = Number(item.sudah_bayar || 0);
                    let subtotal = Number(item.subtotal || 0);
                    let sisa = subtotal - sudahBayar;

                    // skip jika sudah lunas
                    if (sisa <= 0) return;

                    listSewaContainer.innerHTML += `
                    <label class="sewa-card mb-2 d-block">
                        <div class="d-flex align-items-start gap-2">
                            <input class="form-check-input sewa-checkbox mt-1"
                                type="checkbox"
                                name="id_sewa[]"
                                value="${item.id}"
                                data-total="${sisa}">
                            <div class="card-content flex-grow-1">
                                <strong>${item.nama_produk}</strong>
                                ${(item.nama_produk || '').toLowerCase().includes('gas') ? `
                                <small>Harga: Rp ${Number(item.total_harga).toLocaleString('id-ID')} x Qty: ${item.qty} (Gas tidak dikali durasi) + Ongkir: Rp ${Number(item.biaya_pengambilan).toLocaleString('id-ID')}</small>` : `
                                <small>Harga: Rp ${Number(item.total_harga).toLocaleString('id-ID')} x Qty: ${item.qty} x ${item.durasi} hari + Ongkir: Rp ${Number(item.biaya_pengambilan).toLocaleString('id-ID')}</small>`}
                                ${item.denda > 0 ? `<small class="text-danger fw-bold">+ Denda: Rp ${Number(item.denda).toLocaleString('id-ID')} (${item.hari_telat} hari telat)</small>` : ''}
                                <div class="d-flex justify-content-between mt-1 pt-1 border-top">
                                    <span class="text-muted small">Subtotal: Rp ${subtotal.toLocaleString('id-ID')}</span>
                                    <span class="text-danger fw-bold small">Sisa: Rp ${sisa.toLocaleString('id-ID')}</span>
                                </div>
                            </div>
                        </div>
                    </label>
                    `;
                });

                if (listSewaContainer.innerHTML === '') {
                    listSewaContainer.innerHTML = `<div class="text-success small p-2">Semua transaksi sewa pengguna ini telah lunas.</div>`;
                }
            })
            .catch(() => {
                listSewaContainer.innerHTML = `<div class="text-danger small p-2">Gagal memuat data sewa pengguna.</div>`;
            });
    });

    // 2. Hitung total tagihan terpilih
    document.addEventListener('change', function (e) {
        if (e.target.classList.contains('sewa-checkbox')) {
            let total = 0;
            document.querySelectorAll('.sewa-checkbox:checked').forEach(cb => {
                total += Number(cb.dataset.total || 0);
            });
            totalTagihanInput.value = total;
            const jumlahBayarInput = document.getElementById('jumlah_bayar');
            if (jumlahBayarInput && (!jumlahBayarInput.value || Number(jumlahBayarInput.value) === 0)) {
                jumlahBayarInput.value = total;
            }
        }
    });

    // 2.1 Validasi Tanggal Bayar (Tidak boleh sebelum hari ini)
    const formTambahPembayaran = document.querySelector('#modalTambahPembayaran form');
    const inputTglBayar = document.getElementById('tanggal_bayar');
    if (formTambahPembayaran && inputTglBayar) {
        inputTglBayar.addEventListener('change', function() {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const chosen = new Date(this.value);
            if (chosen < today) {
                alert('Tanggal pembayaran tidak boleh memilih hari kemarin/sebelumnya!');
                // Reset ke tanggal sekarang
                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');
                const hours = String(now.getHours()).padStart(2, '0');
                const mins = String(now.getMinutes()).padStart(2, '0');
                this.value = `${year}-${month}-${day}T${hours}:${mins}`;
            }
        });

        formTambahPembayaran.addEventListener('submit', function(e) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const chosen = new Date(inputTglBayar.value);
            if (chosen < today) {
                e.preventDefault();
                alert('Tanggal pembayaran tidak boleh memilih hari kemarin/sebelumnya!');
                inputTglBayar.focus();
                return false;
            }

            const inputJmlBayar = document.getElementById('jumlah_bayar');
            const jml = parseInt(inputJmlBayar.value) || 0;
            if (jml < 10000 || jml % 1000 !== 0) {
                e.preventDefault();
                alert('Jumlah pembayaran minimal Rp 10.000 dan merupakan kelipatan Rp 1.000 (contoh: 10.000, 15.000, 20.000, dst.)');
                inputJmlBayar.focus();
                return false;
            }
        });
    }

    // 3. Live search di seluruh tabel pada semua tab
    const searchInput = document.getElementById('liveSearchPembayaran');
    if (searchInput) {
        searchInput.addEventListener('keyup', function () {
            let keyword = this.value.toLowerCase().trim();
            let tables = [
                document.querySelectorAll('#tabelSemua tbody tr'),
                document.querySelectorAll('#tabelLunas tbody tr'),
                document.querySelectorAll('#tabelDitolak tbody tr')
            ];

            tables.forEach(rows => {
                rows.forEach(row => {
                    let text = row.textContent.toLowerCase();
                    let cells = row.querySelectorAll('td');

                    if (text.includes(keyword)) {
                        row.style.display = '';

                        cells.forEach((td, index) => {
                            // skip kolom aksi (terakhir) dan kolom bukti (index 5)
                            if (index === cells.length - 1 || index === 5) return;

                            if (!td.dataset.original) {
                                td.dataset.original = td.innerHTML;
                            }

                            if (keyword !== '') {
                                let regex = new RegExp(`(${keyword})`, 'gi');
                                td.innerHTML = td.dataset.original.replace(
                                    regex,
                                    `<span class="highlight">$1</span>`
                                );
                            } else {
                                td.innerHTML = td.dataset.original;
                            }
                        });
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        });
    }
});

// 4. Cetak area modal laporan
function cetakArea() {
    var areaCetak = document.getElementById('areaCetak').innerHTML;
    var w = window.open('', '', 'height=700,width=900');
    w.document.write('<html><head>');
    w.document.write('<title>Cetak Rekap Pembayaran</title>');
    w.document.write('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">');
    w.document.write('<style>body{ font-size:12px; padding:20px; } table{ width:100%; border-collapse:collapse; } th,td{ border:1px solid #000; padding:5px; }</style>');
    w.document.write('</head><body>');
    w.document.write(areaCetak);
    w.document.write('</body></html>');
    w.document.close();
    w.focus();
    setTimeout(function() {
        w.print();
        w.close();
    }, 500);
}

// 5. Sinkronkan tab aktif ke URL agar saat aksi / reload tetap di tab yang dipilih
document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('#pembayaranTabs button[data-bs-toggle="pill"]');
    tabButtons.forEach(btn => {
        btn.addEventListener('shown.bs.tab', function(e) {
            const target = e.target.getAttribute('data-bs-target');
            if (target) {
                let tabName = target.replace('#tab', '').toLowerCase();
                const url = new URL(window.location);
                url.searchParams.set('tab', tabName);
                window.history.replaceState({}, '', url);
            }
        });
    });
});

// 6. Notifikasi Antrean Terkunci (Prinsip FIFO)
function alertLocked(antreanNo) {
    Swal.fire({
        icon: 'warning',
        title: 'Antrean Terkunci (Prinsip FIFO)',
        html: 'Harap verifikasi dan selesaikan transaksi pada <strong>Antrean #' + antreanNo + '</strong> terlebih dahulu sebelum memproses antrean ini.',
        confirmButtonColor: '#0e4430',
        confirmButtonText: '<i class="fas fa-check me-1"></i> Mengerti'
    });
}
</script>

</body>
</html>
