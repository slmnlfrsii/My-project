<?php
session_start();
include '../../koneksi.php';
date_default_timezone_set('Asia/Jakarta');

$aksi = $_GET['aksi'] ?? '';

// ===================== GET SEWA USER (AJAX) =====================
if ($aksi === 'get_sewa') {

    header('Content-Type: application/json');

    $id_users = intval($_GET['id_users'] ?? 0);

    $query = mysqli_query($conn, "
        SELECT 
            s.id,
            s.nama_produk,
            s.qty,
            s.durasi,
            COALESCE(a.harga_per_hari, s.total_harga) AS total_harga,
            s.biaya_pengambilan,
            s.metode_pengambilan,
            s.tanggal_sewa,
            s.status,
            CASE 
                WHEN CURDATE() > DATE_ADD(s.tanggal_sewa, INTERVAL s.durasi DAY)
                THEN DATEDIFF(CURDATE(), DATE_ADD(s.tanggal_sewa, INTERVAL s.durasi DAY)) * 10000
                ELSE 0
            END AS denda
        FROM sewa s
        LEFT JOIN alat a ON s.id_alat = a.id
        WHERE s.id_users = '$id_users'
        AND s.status NOT IN ('selesai', 'Dibatalkan')
        ORDER BY s.id DESC
    ");

    $data = [];

    while ($row = mysqli_fetch_assoc($query)) {

        $harga = (float)$row['total_harga'];
        $qty = (int)$row['qty'];
        $durasi = (int)$row['durasi'];
        $ongkir = (float)$row['biaya_pengambilan'];

        // =========================
        // HITUNG DENDA (10.000 / hari, tidak berlaku untuk gas)
        // =========================
        $is_gas = (stripos($row['nama_produk'], 'gas') !== false);
        $denda = 0;
        $hari_telat = 0;

        if (!$is_gas && !empty($row['tanggal_sewa'])) {
            $tanggal_kembali = date('Y-m-d', strtotime($row['tanggal_sewa'] . ' + ' . $durasi . ' days'));
            $hari_ini = date('Y-m-d');
            $selisih_hari = floor((strtotime($hari_ini) - strtotime($tanggal_kembali)) / 86400);
            if ($selisih_hari > 0) {
                $hari_telat = (int)$selisih_hari;
                $denda = $hari_telat * 10000;
            }
        }

        // =========================
        // HITUNG TOTAL (Gas portable tidak dikali durasi)
        // =========================
        $harga_asli = ($harga * $qty * ($is_gas ? 1 : $durasi));
        $subtotal = $harga_asli + $ongkir + $denda;

        // =========================
        // SUDAH DIBAYAR (Gunakan FIND_IN_SET)
        // =========================
        $q_bayar = mysqli_query($conn, "
            SELECT SUM(jumlah_bayar) as total 
            FROM pembayaran 
            WHERE FIND_IN_SET('{$row['id']}', id_sewa)
            AND status IN ('Belum lunas','Lunas')
        ");

        $sudah_bayar = (float)(mysqli_fetch_assoc($q_bayar)['total'] ?? 0);

        // =========================
        // RETURN DATA
        // =========================
        $row['harga_asli'] = $harga_asli;
        $row['subtotal'] = $subtotal;
        $row['ongkir'] = $ongkir;
        $row['denda'] = $denda;
        $row['sudah_bayar'] = $sudah_bayar;
        $row['telat'] = $denda > 0;
        $row['hari_telat'] = $hari_telat;

        $data[] = $row;
    }

    echo json_encode($data);
    exit;
}

// ===================== TAMBAH PEMBAYARAN =====================
if ($aksi === 'tambah' && $_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_users = intval($_POST['id_users'] ?? 0);
    $id_sewa_array = $_POST['id_sewa'] ?? [];
    $metode = trim($_POST['metode'] ?? 'Transfer');
    $jumlah_bayar = (float)($_POST['jumlah_bayar'] ?? 0);
    $status = trim($_POST['status'] ?? 'Lunas');
    $raw_tgl = $_POST['tanggal_bayar'] ?? '';
    $timestamp = strtotime($raw_tgl);
    if (!$timestamp) {
        $timestamp = time();
    }
    $tanggal_bayar = date('Y-m-d H:i:s', $timestamp);

    // Validasi tanggal bayar tidak boleh sebelum hari ini
    $today_start = date('Y-m-d 00:00:00');
    if ($timestamp < strtotime($today_start)) {
        $_SESSION['error'] = "Tanggal pembayaran tidak boleh memilih hari sebelumnya (minimal hari ini).";
        header("Location: pembayaran.php");
        exit;
    }

    // Validasi jumlah bayar minimal Rp 10.000 dan kelipatan Rp 1.000
    if ($jumlah_bayar < 10000 || fmod($jumlah_bayar, 1000) != 0) {
        $_SESSION['error'] = "Jumlah pembayaran minimal adalah Rp 10.000 dan harus berupa kelipatan Rp 1.000 (contoh: 10.000, 15.000, 20.000, dst.).";
        header("Location: pembayaran.php");
        exit;
    }

    if (empty($id_sewa_array)) {
        $_SESSION['error'] = "Pilih minimal 1 sewa";
        header("Location: pembayaran.php");
        exit;
    }

    // upload bukti (optional)
    $bukti = '';
    if (!empty($_FILES['bukti_pembayaran']['name'])) {
        $ext = pathinfo($_FILES['bukti_pembayaran']['name'], PATHINFO_EXTENSION);
        $bukti = 'bukti_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['bukti_pembayaran']['tmp_name'], '../../bukti_pembayaran/' . $bukti);
    }

    // =========================
    // 🔥 LOGIKA DP & ALOKASI
    // =========================
    $sisa_bayar = $jumlah_bayar;

    $id_list = implode(",", array_map('intval', $id_sewa_array));

    $query = "
    SELECT s.*,
    COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat,
    (
        CASE 
            WHEN CURDATE() > DATE_ADD(s.tanggal_sewa, INTERVAL s.durasi DAY)
            THEN DATEDIFF(CURDATE(), DATE_ADD(s.tanggal_sewa, INTERVAL s.durasi DAY)) * 10000
            ELSE 0
        END
    ) AS denda
    FROM sewa s
    LEFT JOIN alat a ON s.id_alat = a.id
    WHERE s.id IN ($id_list)
    ORDER BY denda DESC, s.tanggal_sewa ASC
    ";

    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {

        if ($sisa_bayar <= 0) break;

        $id_sewa = (int)$row['id'];
        $harga_satuan = (float)$row['harga_satuan_alat'];

        $is_gas = (stripos($row['nama_produk'], 'gas') !== false);
        $subtotal = ($harga_satuan * $row['qty'] * ($is_gas ? 1 : $row['durasi'])) + $row['biaya_pengambilan'];
        $denda = (float)$row['denda'];

        $total_tagihan_fix = $subtotal + $denda;

        // total sudah dibayar (Gunakan FIND_IN_SET)
        $q_bayar = mysqli_query($conn, "
            SELECT SUM(jumlah_bayar) as total 
            FROM pembayaran 
            WHERE FIND_IN_SET('$id_sewa', id_sewa)
            AND status IN ('Lunas','Belum lunas')
        ");

        $sudah_bayar = (float)(mysqli_fetch_assoc($q_bayar)['total'] ?? 0);

        $sisa_tagihan = $total_tagihan_fix - $sudah_bayar;

        if ($sisa_tagihan <= 0) continue;

        // 🔥 alokasi pembayaran
        $bayar_ke_item = min($sisa_bayar, $sisa_tagihan);
        $admin_id = isset($_SESSION['id_admin']) ? (int)$_SESSION['id_admin'] : NULL;
        $tanggal_konfirmasi = in_array(strtolower($status), ['lunas', 'belum lunas']) ? date('Y-m-d H:i:s') : NULL;

        $stmt = $conn->prepare("
            INSERT INTO pembayaran 
            (id_users, id_admin, id_sewa, metode, jumlah_bayar, total_tagihan, bukti_pembayaran, status, tanggal_bayar, tanggal_konfirmasi)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $id_sewa_str = (string)$id_sewa;
        $stmt->bind_param("iisssdssss",
            $id_users,
            $admin_id,
            $id_sewa_str,
            $metode,
            $bayar_ke_item,
            $total_tagihan_fix,
            $bukti,
            $status,
            $tanggal_bayar,
            $tanggal_konfirmasi
        );

        $stmt->execute();
        $stmt->close();

        // Update status sewa jika pembayaran diterima (Lunas / Belum lunas)
        // Sistem otomatis menyortir: ada ongkir -> 'di antar', tanpa ongkir -> 'Siap di ambil'
        if (in_array(strtolower($status), ['lunas', 'belum lunas'])) {
            $biaya_ongkir = (float)($row['biaya_pengambilan'] ?? 0);
            $metode_pengambilan = strtolower($row['metode_pengambilan'] ?? '');
            $statusBaruSewa = ($biaya_ongkir > 0 || strpos($metode_pengambilan, 'cod') !== false || strpos($metode_pengambilan, 'antar') !== false) 
                ? 'di antar' 
                : 'Siap di ambil';

            mysqli_query($conn, "
                UPDATE sewa 
                SET status = '$statusBaruSewa'
                WHERE id = $id_sewa AND status = 'Menunggu pembayaran'
            ");
        }

            // =========================
            // ❌ DITOLAK SAAT TAMBAH PEMBAYARAN
            // =========================
            if (strtolower($status) === 'ditolak') {
                $statusFix = 'Ditolak';
                $noTagihan = !empty($row['no_tagihan']) 
                    ? $row['no_tagihan'] 
                    : ('INV-' . date('Ymd', strtotime($row['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $id_sewa));

                // Update status sewa menjadi 'Ditolak' (dihapus)
                mysqli_query($conn, "DELETE sewa SET status = 'Ditolak' WHERE id = $id_sewa");

                // Salin ke tabel sewa_dibatalkan dengan status 'Ditolak'
                $insertBatal = $conn->prepare("INSERT INTO sewa_dibatalkan 
                    (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                
                if ($insertBatal) {
                    $insertBatal->bind_param(
                        "issiidsssss",
                        $row['id_users'],
                        $noTagihan,
                        $row['nama_produk'],
                        $row['qty'],
                        $row['durasi'],
                        $row['total_harga'],
                        $row['biaya_pengambilan'],
                        $row['metode_pengambilan'],
                        $row['gambar'],
                        $row['tanggal_sewa'],
                        $statusFix
                    );
                    $insertBatal->execute();
                    $insertBatal->close();
                }
            }

            $sisa_bayar -= $bayar_ke_item;
        }

        $stLower = strtolower(trim($status));
        $redirectTab = ($stLower === 'ditolak') ? 'ditolak' : (($stLower === 'lunas') ? 'lunas' : 'semua');

        if ($stLower === 'ditolak') {
            $_SESSION['success'] = "Pembayaran ditolak. Pesanan sewa telah dibatalkan dan uang DP sebesar Rp " . number_format($jumlah_bayar, 0, ',', '.') . " dikembalikan kepada penyewa.";
        } else {
            $_SESSION['success'] = "Pembayaran berhasil ditambahkan.";
        }
        header("Location: pembayaran.php?tab=" . $redirectTab);
        exit;
    }


    // ===================== EDIT STATUS =====================
    if ($aksi === 'edit' && $_SERVER['REQUEST_METHOD'] === 'POST') {

        try {

            $id = $_POST['id'] ?? null;
            $status = $_POST['status'] ?? null;

            if (!$id || !$status) {
                throw new Exception("Data tidak lengkap");
            }

            // Validasi: Status Lunas bersifat permanen dan tidak dapat diubah kembali
            $checkLunas = mysqli_query($conn, "SELECT status FROM pembayaran WHERE id = " . intval($id));
            if ($checkLunas && mysqli_num_rows($checkLunas) > 0) {
                $cur = mysqli_fetch_assoc($checkLunas);
                if (strtolower(trim($cur['status'])) === 'lunas') {
                    throw new Exception("Transaksi yang sudah berstatus 'Lunas' bersifat permanen dan tidak dapat diubah kembali.");
                }
            }

            // update status pembayaran & rekam admin yang mengonfirmasi
            $admin_id = isset($_SESSION['id_admin']) ? (int)$_SESSION['id_admin'] : NULL;
            if (strtolower($status) === 'lunas') {
                $stmt = $conn->prepare("UPDATE pembayaran SET status=?, jumlah_bayar=total_tagihan, id_admin=?, tanggal_konfirmasi=NOW() WHERE id=?");
                if (!$stmt) {
                    throw new Exception("Prepare update gagal: " . $conn->error);
                }
                $stmt->bind_param("sii", $status, $admin_id, $id);
            } elseif (strtolower($status) === 'belum lunas') {
                $stmt = $conn->prepare("UPDATE pembayaran SET status=?, id_admin=?, tanggal_konfirmasi=NOW() WHERE id=?");
                if (!$stmt) {
                    throw new Exception("Prepare update gagal: " . $conn->error);
                }
                $stmt->bind_param("sii", $status, $admin_id, $id);
            } else {
                $stmt = $conn->prepare("UPDATE pembayaran SET status=? WHERE id=?");
                if (!$stmt) {
                    throw new Exception("Prepare update gagal: " . $conn->error);
                }
                $stmt->bind_param("si", $status, $id);
            }

            if (!$stmt->execute()) {
                throw new Exception("Gagal update status pembayaran");
            }

            // ambil data pembayaran
            $res = mysqli_query($conn, "SELECT * FROM pembayaran WHERE id = $id");
            if (!$res || mysqli_num_rows($res) == 0) {
                throw new Exception("Data pembayaran tidak ditemukan");
            }

            $get = mysqli_fetch_assoc($res);

            if (empty($get['id_sewa'])) {
                throw new Exception("ID sewa kosong");
            }

            // Ambil semua ID sewa baik dari kolom id_sewa maupun no_tagihan yang sama
            $id_sewa_list = array_map('intval', explode(',', $get['id_sewa']));

            $first_id = $id_sewa_list[0] ?? 0;
            if ($first_id > 0) {
                $qTag = mysqli_query($conn, "SELECT no_tagihan, id_users FROM sewa WHERE id = $first_id");
                if ($rTag = mysqli_fetch_assoc($qTag)) {
                    $noTag = $rTag['no_tagihan'];
                    $uId = $rTag['id_users'];
                    if (!empty($noTag)) {
                        $qSame = mysqli_query($conn, "SELECT id FROM sewa WHERE id_users = $uId AND no_tagihan = '$noTag'");
                        if ($qSame && mysqli_num_rows($qSame) > 0) {
                            while ($rowSame = mysqli_fetch_assoc($qSame)) {
                                $id_sewa_list[] = (int)$rowSame['id'];
                            }
                        }
                    }
                }
            }
            $id_sewa_list = array_values(array_unique(array_filter($id_sewa_list)));

            foreach ($id_sewa_list as $id_sewa) {
                if ($id_sewa <= 0) continue;

                // ambil data sewa
                $sewa_q = mysqli_query($conn, "SELECT * FROM sewa WHERE id = $id_sewa");
                if (!$sewa_q || mysqli_num_rows($sewa_q) == 0) continue;

                $sewa = mysqli_fetch_assoc($sewa_q);

                $is_gas = (stripos($sewa['nama_produk'], 'gas') !== false);
                $subtotal = ($sewa['total_harga'] * $sewa['qty'] * ($is_gas ? 1 : $sewa['durasi'])) + $sewa['biaya_pengambilan'];

                // hitung denda
                $tanggal_kembali = date('Y-m-d', strtotime($sewa['tanggal_sewa'] . ' + ' . $sewa['durasi'] . ' days'));
                $hari_ini = date('Y-m-d');
                $denda = 0;

                if ($hari_ini > $tanggal_kembali) {
                    $selisih = (strtotime($hari_ini) - strtotime($tanggal_kembali)) / 86400;
                    $denda = $selisih * 10000;
                }

                $total_tagihan = $subtotal + $denda;

                // =========================
                // ❌ DITOLAK -> UPDATE STATUS SEWA JADI 'Ditolak' & SALIN KE sewa_dibatalkan (TIDAK DIHAPUS)
                // =========================
                if (strtolower($status) === 'ditolak') {
                    $statusFix = 'Ditolak';
                    $noTagihan = !empty($sewa['no_tagihan']) 
                        ? $sewa['no_tagihan'] 
                        : ('INV-' . date('Ymd', strtotime($sewa['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $id_sewa));

                    // Kembalikan stok jika alat sedang dalam status aktif disewa
                    $statusRow = strtolower(trim($sewa['status']));
                    $activeStatuses = ['siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung'];
                    if (in_array($statusRow, $activeStatuses) && !empty($sewa['id_alat'])) {
                        $qtySewa = (int)$sewa['qty'];
                        $idAlat = (int)$sewa['id_alat'];
                        $conn->query("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + $qtySewa) WHERE id = $idAlat");
                    }

                    // Update status sewa menjadi 'Ditolak' (TIDAK DIHAPUS DARI DATABASE)
                    mysqli_query($conn, "UPDATE sewa SET status = 'Ditolak' WHERE id = $id_sewa");

                    // Salin ke tabel sewa_dibatalkan dengan status 'Ditolak'
                    $insertBatal = $conn->prepare("INSERT INTO sewa_dibatalkan 
                        (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                    
                    if ($insertBatal) {
                        $insertBatal->bind_param(
                            "issiidsssss",
                            $sewa['id_users'],
                            $noTagihan,
                            $sewa['nama_produk'],
                            $sewa['qty'],
                            $sewa['durasi'],
                            $sewa['total_harga'],
                            $sewa['biaya_pengambilan'],
                            $sewa['metode_pengambilan'],
                            $sewa['gambar'],
                            $sewa['tanggal_sewa'],
                            $statusFix
                        );
                        $insertBatal->execute();
                        $insertBatal->close();
                    }
                }

                // =========================
                // ✅ DITERIMA (Lunas / Belum lunas)
                // Sistem otomatis menyortir: ada ongkir -> 'di antar', tanpa ongkir -> 'Siap di ambil'
                // =========================
                if (in_array(strtolower($status), ['lunas', 'belum lunas'])) {
                    $biaya_ongkir = (float)($sewa['biaya_pengambilan'] ?? 0);
                    $metode = strtolower($sewa['metode_pengambilan'] ?? '');
                    $is_consumable = (stripos($sewa['nama_produk'], 'gas') !== false);
                    $statusBaruSewa = ($biaya_ongkir > 0 || strpos($metode, 'cod') !== false || strpos($metode, 'antar') !== false) 
                        ? 'di antar' 
                        : 'Siap di ambil';

                    mysqli_query($conn, "
                        UPDATE sewa 
                        SET status = '$statusBaruSewa'
                        WHERE id = $id_sewa AND status IN ('Menunggu pembayaran', 'Menunggu konfirmasi', 'Belum lunas')
                    ");
                }

                // =========================
                // ⏳ MENUNGGU KONFIRMASI
                // =========================
                if (strtolower($status) === 'menunggu konfirmasi') {
                    mysqli_query($conn, "
                        UPDATE sewa 
                        SET status = 'Menunggu pembayaran'
                        WHERE id = $id_sewa AND status IN ('Siap di ambil', 'siap di ambil', 'di antar', 'diantar')
                    ");
                }
            }

            $stLower = strtolower(trim($status));
            $redirectTab = ($stLower === 'ditolak') ? 'ditolak' : (($stLower === 'lunas') ? 'lunas' : 'semua');

            if ($stLower === 'ditolak') {
                $jmlBayar = (float)($get['jumlah_bayar'] ?? 0);
                $_SESSION['success'] = "Status pembayaran ditolak. Pesanan sewa telah dibatalkan dan uang DP/pembayaran yang masuk sebesar Rp " . number_format($jmlBayar, 0, ',', '.') . " dikembalikan kepada penyewa.";
            } else {
                $_SESSION['success'] = "Status pembayaran berhasil diupdate.";
            }
            header("Location: pembayaran.php?tab=" . $redirectTab);
            exit;

        } catch (Throwable $e) {
            $_SESSION['error'] = "Error: " . $e->getMessage();
            $stLower = isset($status) ? strtolower(trim($status)) : 'semua';
            $redirectTab = ($stLower === 'ditolak') ? 'ditolak' : (($stLower === 'lunas') ? 'lunas' : 'semua');
            header("Location: pembayaran.php?tab=" . $redirectTab);
            exit;
        }
}

// ===================== HAPUS PEMBAYARAN =====================
if ($aksi === 'hapus' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    $tab = $_POST['tab'] ?? $_GET['tab'] ?? 'semua';
    if ($id > 0) {
        $cek = mysqli_query($conn, "SELECT bukti_pembayaran FROM pembayaran WHERE id = $id");
        if ($cek && mysqli_num_rows($cek) > 0) {
            $b = mysqli_fetch_assoc($cek)['bukti_pembayaran'];
            if (!empty($b) && file_exists('../../bukti_pembayaran/' . $b)) {
                @unlink('../../bukti_pembayaran/' . $b);
            }
        }
        mysqli_query($conn, "DELETE FROM pembayaran WHERE id = $id");
        $_SESSION['success'] = "Data pembayaran berhasil dihapus.";
    } else {
        $_SESSION['error'] = "ID pembayaran tidak valid.";
    }
    header("Location: pembayaran.php?tab=" . urlencode($tab));
    exit;
}


// ===================== FALLBACK =====================
$_SESSION['error'] = "Aksi tidak valid";
header("Location: pembayaran.php");
exit;