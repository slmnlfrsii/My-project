<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

// Query hanya pembayaran yang berstatus Lunas dan Belum Lunas (DP)
$query = mysqli_query($conn, "SELECT p.*, u.nama AS nama_user, s.nama_produk, s.no_tagihan 
                              FROM pembayaran p 
                              LEFT JOIN users u ON p.id_users = u.id
                              LEFT JOIN sewa s ON p.id_sewa = s.id
                              WHERE LOWER(TRIM(p.status)) IN ('lunas', 'belum lunas')
                              ORDER BY p.tanggal_bayar DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Rekap Pembayaran - Semar Outdoor</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-size: 13px;
            color: #212529;
        }
        .header-laporan {
            border-bottom: 2px solid #333;
            padding-bottom: 12px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            border: 1px solid #333 !important;
            padding: 7px 8px;
        }
        table th {
            background-color: #f2f2f2 !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        @media print {
            .no-print { display: none !important; }
            body { padding: 0; }
            .container { max-width: 100% !important; width: 100% !important; padding: 0 !important; }
        }
    </style>
</head>
<body class="bg-white">
<div class="container mt-4 mb-4">
    <!-- Header Laporan -->
    <div class="header-laporan text-center">
        <h3 class="fw-bold mb-1">SEMAR OUTDOOR</h3>
        <p class="mb-1 text-muted">Layanan Rental Peralatan Camping & Outdoor Terpercaya</p>
        <h5 class="fw-bold mt-3 mb-1 text-uppercase">Laporan Rekap Pembayaran (Lunas & Uang Muka / DP)</h5>
        <small class="text-muted">Dicetak pada: <?= date('d F Y, H:i') ?> WIB</small>
    </div>

    <!-- Toolbar Aksi -->
    <div class="d-flex justify-content-between align-items-center mb-3 no-print">
        <a href="pembayaran.php" class="btn btn-secondary btn-sm">
            <i class="fa fa-arrow-left me-1"></i> Kembali ke Kasir
        </a>
        <button class="btn btn-danger btn-sm fw-bold px-3" onclick="window.print()">
            <i class="fa fa-print me-1"></i> Cetak / Simpan PDF
        </button>
    </div>

    <!-- Tabel Data -->
    <table class="table table-bordered align-middle">
        <thead class="text-center">
            <tr>
                <th style="width: 40px;">No</th>
                <th style="width: 130px;">No. Tagihan</th>
                <th>Nama Pelanggan</th>
                <th>Alat Disewa</th>
                <th style="width: 100px;">Metode</th>
                <th style="width: 120px;">Jumlah Bayar</th>
                <th style="width: 120px;">Total Tagihan</th>
                <th style="width: 90px;">Status</th>
                <th style="width: 130px;">Tanggal Bayar</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $no = 1;
        $totalBayar = 0;
        $totalTagihan = 0;
        if ($query && mysqli_num_rows($query) > 0):
            while ($row = mysqli_fetch_assoc($query)) {
                $totalBayar += (float)($row['jumlah_bayar'] ?? 0);
                $totalTagihan += (float)($row['total_tagihan'] ?? 0);
                $no_tagihan = !empty($row['no_tagihan']) ? $row['no_tagihan'] : ('INV-' . date('Ymd', strtotime($row['tanggal_bayar'] ?? 'now')) . '-' . sprintf('%04d', $row['id_sewa']));
                $isLunas = (strtolower(trim($row['status'] ?? '')) === 'lunas');
        ?>
            <tr>
                <td class="text-center"><?= $no++ ?></td>
                <td class="text-center font-monospace fw-bold"><?= htmlspecialchars($no_tagihan) ?></td>
                <td><?= htmlspecialchars($row['nama_user'] ?? '-') ?></td>
                <td><?= htmlspecialchars($row['nama_produk'] ?? '-') ?></td>
                <td class="text-center"><?= htmlspecialchars($row['metode'] ?? '-') ?></td>
                <td class="text-end">Rp <?= number_format($row['jumlah_bayar'] ?? 0, 0, ',', '.') ?></td>
                <td class="text-end">Rp <?= number_format($row['total_tagihan'] ?? 0, 0, ',', '.') ?></td>
                <td class="text-center fw-bold <?= $isLunas ? 'text-success' : 'text-warning' ?>">
                    <?= htmlspecialchars($row['status'] ?? '-') ?>
                </td>
                <td class="text-center"><?= htmlspecialchars($row['tanggal_bayar'] ?? '-') ?></td>
            </tr>
        <?php
            }
        else:
        ?>
            <tr>
                <td colspan="9" class="text-center py-4 text-muted">Tidak ada data pembayaran dengan status Lunas atau Belum Lunas.</td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot class="fw-bold">
            <tr class="table-light">
                <td colspan="5" class="text-end text-uppercase">Total Rekapitulasi:</td>
                <td class="text-end">Rp <?= number_format($totalBayar, 0, ',', '.') ?></td>
                <td class="text-end">Rp <?= number_format($totalTagihan, 0, ',', '.') ?></td>
                <td colspan="2" class="text-center text-muted"><?= ($no - 1) ?> Transaksi</td>
            </tr>
        </tfoot>
    </table>

    <!-- Tanda Tangan Laporan -->
    <div class="row mt-5 pt-3 no-print-page">
        <div class="col-6"></div>
        <div class="col-6 text-center">
            <p class="mb-5">Semarang, <?= date('d F Y') ?><br>Petugas Kasir & Admin,</p>
            <p class="fw-bold text-decoration-underline mb-0">Semar Outdoor Management</p>
        </div>
    </div>
</div>

<script>
    window.addEventListener('DOMContentLoaded', () => {
        // Otomatis fokus jika ingin cetak langsung
    });
</script>
</body>
</html>
