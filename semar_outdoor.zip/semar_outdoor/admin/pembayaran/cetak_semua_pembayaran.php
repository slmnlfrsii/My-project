<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

// Load Logo Base64 agar selalu tampil sempurna di print popup / PDF
$logoFile = __DIR__ . '/../../assets/images/logo.png';
$logoBase64 = '';
if (file_exists($logoFile)) {
    $logoBase64 = 'data:image/png;base64,' . base64_encode(file_get_contents($logoFile));
}

$filterBulan = isset($_GET['bulan']) ? trim($_GET['bulan']) : date('m');
$filterTahun = isset($_GET['tahun']) ? trim($_GET['tahun']) : (string)date('Y');

$namaBulanIndo = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

if ($filterBulan !== 'semua' && $filterTahun !== 'semua') {
    $labelPeriode = "Periode: " . ($namaBulanIndo[(int)$filterBulan] ?? $filterBulan) . " " . $filterTahun;
} elseif ($filterBulan !== 'semua') {
    $labelPeriode = "Periode: Bulan " . ($namaBulanIndo[(int)$filterBulan] ?? $filterBulan) . " (Semua Tahun)";
} elseif ($filterTahun !== 'semua') {
    $labelPeriode = "Periode: Tahun " . $filterTahun . " (Semua Bulan)";
} else {
    $labelPeriode = "Periode: Semua Data Transaksi";
}

$where = ["LOWER(TRIM(p.status)) IN ('lunas', 'belum lunas')"];
if ($filterBulan !== 'semua') {
    $where[] = "MONTH(p.tanggal_bayar) = " . (int)$filterBulan;
}
if ($filterTahun !== 'semua') {
    $where[] = "YEAR(p.tanggal_bayar) = " . (int)$filterTahun;
}
$whereSql = implode(' AND ', $where);

// Query data pembayaran berstatus Lunas dan Belum Lunas (DP) dengan filter periode
$query = mysqli_query($conn, "
    SELECT p.*, u.nama AS nama_user, 
           COALESCE(
               NULLIF(GROUP_CONCAT(DISTINCT s.no_tagihan SEPARATOR ', '), ''),
               NULLIF(GROUP_CONCAT(DISTINCT sb.no_tagihan SEPARATOR ', '), ''),
               CONCAT('INV-', DATE_FORMAT(p.tanggal_bayar, '%Y%m%d'), '-', LPAD(p.id, 4, '0'))
           ) AS no_tagihan,
           COALESCE(
               NULLIF(GROUP_CONCAT(DISTINCT CONCAT(s.nama_produk, ' (x', s.qty, ')') SEPARATOR ', '), ''),
               NULLIF(GROUP_CONCAT(DISTINCT CONCAT(sb.nama_produk, ' (x', sb.qty, ')') SEPARATOR ', '), ''),
               'Item Sewa'
           ) AS nama_produk
    FROM pembayaran p 
    LEFT JOIN users u ON p.id_users = u.id
    LEFT JOIN sewa s ON FIND_IN_SET(s.id, p.id_sewa)
    LEFT JOIN sewa_dibatalkan sb ON sb.id_users = p.id_users AND (sb.no_tagihan = s.no_tagihan OR sb.no_tagihan LIKE CONCAT('%-', LPAD(p.id_sewa, 4, '0')) OR sb.no_tagihan LIKE CONCAT('%-', LPAD(p.id_sewa, 3, '0')))
    WHERE $whereSql
    GROUP BY p.id
    ORDER BY p.tanggal_bayar DESC
");

// Pre-calculate data summary
$dataPembayaran = [];
$totalBayar = 0;
$totalTagihan = 0;
$countLunas = 0;
$countBelumLunas = 0;

if ($query && mysqli_num_rows($query) > 0) {
    while ($row = mysqli_fetch_assoc($query)) {
        $totalBayar += (float)($row['jumlah_bayar'] ?? 0);
        $totalTagihan += (float)($row['total_tagihan'] ?? 0);
        $st = strtolower(trim($row['status'] ?? ''));
        if ($st === 'lunas') {
            $countLunas++;
        } else {
            $countBelumLunas++;
        }
        $dataPembayaran[] = $row;
    }
}
$sisaTagihan = max(0, $totalTagihan - $totalBayar);
$totalTransaksi = count($dataPembayaran);

function formatTanggalIndo($datetime) {
    if (empty($datetime) || $datetime === '-') return '-';
    $ts = strtotime($datetime);
    if (!$ts) return $datetime;
    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    $hari = [
        'Sunday' => 'Minggu', 'Monday' => 'Senin', 'Tuesday' => 'Selasa',
        'Wednesday' => 'Rabu', 'Thursday' => 'Kamis', 'Friday' => 'Jumat', 'Saturday' => 'Sabtu'
    ];
    $namaHari = $hari[date('l', $ts)] ?? '';
    $tgl = date('d', $ts);
    $bln = $bulan[(int)date('m', $ts)] ?? '';
    $thn = date('Y', $ts);
    $jam = date('H:i', $ts);
    return "$namaHari, $tgl $bln $thn | $jam WIB";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Rekapitulasi Pembayaran - Semar Outdoor</title>
    <!-- Fonts & Bootstrap 5 -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style id="pageOrientationStyle">
        @page {
            size: A4 landscape;
            margin: 8mm;
        }
    </style>

<style>
    :root {
        --brand-green: #0e4430;
        --brand-green-dark: #09281c;
        --text-dark: #0f172a;
        --text-muted: #64748b;
        --border-color: #cbd5e1;
    }

    * {
        box-sizing: border-box;
    }

    body {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10.5px;
        color: var(--text-dark);
        background-color: #f1f5f9;
        margin: 0;
        padding: 0;
        transition: all 0.25s ease;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }

    /* Printable Paper Container */
    .page-container {
        margin: 15px auto 25px auto;
        background: #ffffff;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.07);
        border: 1px solid #e2e8f0;
        transition: max-width 0.25s ease, padding 0.25s ease;
        box-sizing: border-box;
    }

    /* Landscape Mode */
    body.orientation-landscape .page-container {
        max-width: 1040px;
        padding: 22px 24px;
    }
    body.orientation-landscape .summary-grid {
        grid-template-columns: repeat(4, 1fr);
    }

    /* Portrait Mode */
    body.orientation-portrait .page-container {
        max-width: 780px;
        padding: 18px 20px;
    }
    body.orientation-portrait .summary-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    body.orientation-portrait .table-laporan {
        font-size: 8.5px;
    }
    body.orientation-portrait .table-laporan th {
        font-size: 8px;
        padding: 5px 3px !important;
    }
    body.orientation-portrait .table-laporan td {
        padding: 4px 4px !important;
    }

    /* Toolbar Top Action Bar */
    .no-print-toolbar {
        max-width: 1120px;
        margin: 20px auto 0 auto;
        padding: 10px 18px;
        background: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
        border: 1px solid #e2e8f0;
        transition: max-width 0.25s ease;
    }
    body.orientation-portrait .no-print-toolbar {
        max-width: 820px;
    }

    .btn-orientation-group .btn {
        font-weight: 600;
        font-size: 11px;
        padding: 4px 10px;
    }
    .btn-orientation-group .btn.active {
        background-color: var(--brand-green) !important;
        color: #ffffff !important;
        border-color: var(--brand-green) !important;
        box-shadow: inset 0 2px 4px rgba(0,0,0,0.18) !important;
    }

    /* Multi-item List */
    .items-cell-list {
        display: flex;
        flex-direction: column;
        gap: 2.5px;
    }

    .item-cell-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 4px;
        font-size: 9.5px;
        line-height: 1.3;
        padding: 1.5px 0;
        border-bottom: 1px dashed #e2e8f0;
    }

    .item-cell-row:last-child {
        border-bottom: none;
    }

    .item-cell-row .item-dot {
        color: var(--brand-green);
        font-weight: bold;
        font-size: 11px;
        line-height: 1;
        margin-right: 2px;
    }

    .item-cell-row .item-name {
        flex-grow: 1;
        color: #1e293b;
        font-weight: 500;
    }

    .item-cell-single {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 4px;
        font-size: 9.5px;
        font-weight: 500;
    }

    .item-qty-badge {
        background-color: #f1f5f9;
        color: #0f172a;
        border: 1px solid #cbd5e1;
        border-radius: 3px;
        padding: 0px 4px;
        font-size: 8.5px;
        font-weight: 700;
        font-family: 'JetBrains Mono', Consolas, monospace;
        white-space: nowrap;
        flex-shrink: 0;
    }

    /* Kop Laporan Resmi */
    .kop-laporan {
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 2.5px solid var(--brand-green);
        padding-bottom: 14px;
        margin-bottom: 16px;
        position: relative;
    }

    .kop-laporan::after {
        content: "";
        position: absolute;
        bottom: -5px;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--brand-green);
    }

    .kop-brand-wrapper {
        display: flex;
        align-items: center;
        gap: 16px;
    }

    .kop-logo {
        width: 78px;
        height: 78px;
        object-fit: contain;
        flex-shrink: 0;
        background: #ffffff;
        border-radius: 50%;
        padding: 2px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border: 1px solid #e2e8f0;
    }

    .kop-brand-title {
        font-size: 20px;
        font-weight: 800;
        color: var(--brand-green);
        letter-spacing: 0.8px;
        margin: 0 0 2px 0;
        text-transform: uppercase;
    }

    .kop-brand-sub {
        font-size: 11px;
        font-weight: 600;
        color: #334155;
        margin: 0 0 3px 0;
    }

    .kop-brand-desc {
        font-size: 9.5px;
        color: var(--text-muted);
        margin: 0;
        line-height: 1.4;
    }

    .kop-meta {
        text-align: right;
        border-left: 2px solid #e2e8f0;
        padding-left: 18px;
        flex-shrink: 0;
    }

    .doc-badge {
        display: inline-block;
        background: var(--brand-green);
        color: #ffffff;
        font-size: 9.5px;
        font-weight: 700;
        padding: 3px 12px;
        border-radius: 20px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .doc-print-time {
        font-size: 9.5px;
        color: var(--text-muted);
        margin-top: 4px;
        line-height: 1.3;
    }

    /* Judul Laporan */
    .laporan-title-box {
        text-align: center;
        margin-bottom: 16px;
    }

    .laporan-title-box h4 {
        font-size: 15px;
        font-weight: 800;
        color: #0f172a;
        letter-spacing: 0.6px;
        margin: 0 0 3px 0;
        text-transform: uppercase;
    }

    .laporan-title-box p {
        font-size: 10.5px;
        color: var(--text-muted);
        margin: 0;
    }

    /* Summary KPI Cards */
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 10px;
        margin-bottom: 18px;
    }

    .summary-card {
        background: #f8fafc;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        padding: 8px 12px;
        text-align: center;
    }

    .summary-card .label {
        font-size: 9px;
        color: var(--text-muted);
        font-weight: 600;
        text-transform: uppercase;
        margin-bottom: 2px;
    }

    .summary-card .value {
        font-size: 13px;
        font-weight: 800;
        color: var(--text-dark);
    }

    .summary-card.success .value {
        color: #047857;
    }

    .summary-card.warning .value {
        color: #b45309;
    }

    /* Tabel Laporan Presisi */
    .table-laporan-wrapper {
        width: 100%;
        margin-bottom: 20px;
    }

    .table-laporan {
        width: 100% !important;
        table-layout: fixed;
        border-collapse: collapse !important;
        font-size: 10px;
        margin: 0;
    }

    .table-laporan th {
        background-color: var(--brand-green) !important;
        color: #ffffff !important;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 9px;
        letter-spacing: 0.3px;
        padding: 8px 6px !important;
        border: 1px solid var(--brand-green-dark) !important;
        text-align: center;
        vertical-align: middle;
    }

    .table-laporan td {
        padding: 6px 8px !important;
        border: 1px solid var(--border-color) !important;
        vertical-align: middle;
        color: #1e293b;
        word-wrap: break-word;
    }

    .table-laporan tbody tr:nth-child(even) td {
        background-color: #f8fafc !important;
    }

    .table-laporan tfoot td {
        background-color: #f1f5f9 !important;
        font-weight: 700;
        border-top: 2px solid var(--brand-green) !important;
        border-bottom: 2px solid var(--brand-green) !important;
        padding: 8px 8px !important;
    }

    .tagihan-code {
        font-family: 'JetBrains Mono', Consolas, monospace;
        font-weight: 700;
        font-size: 8.5px;
        white-space: nowrap;
        color: #0f172a;
    }

    /* PENGATURAN STATUS HANYA TEKS TANPA BACKGROUND */
    span.badge-lunas,
    .badge-lunas {
        background: none !important;
        color: #15803d !important;
        border: none !important;
        padding: 0 !important;
        font-weight: 800 !important;
        font-size: 9.5px !important;
        display: inline-block !important;
        white-space: nowrap !important;
    }

    span.badge-belum,
    .badge-belum {
        background: none !important;
        color: #d97706 !important;
        border: none !important;
        padding: 0 !important;
        font-weight: 800 !important;
        font-size: 9.5px !important;
        display: inline-block !important;
        white-space: nowrap !important;
    }

    .badge-metode {
        background-color: #f1f5f9 !important;
        color: #334155 !important;
        border: 1px solid #cbd5e1;
        padding: 1.5px 5px;
        border-radius: 3px;
        font-weight: 600;
        font-size: 8.5px;
        display: inline-block;
        white-space: nowrap;
    }

    /* Lembar Tanda Tangan */
    .ttd-wrapper {
        display: flex;
        justify-content: flex-end;
        margin-top: 24px;
        page-break-inside: avoid;
    }

    .ttd-box {
        text-align: center;
        width: 250px;
    }

    .ttd-box .ttd-date {
        font-size: 10px;
        color: #334155;
        margin-bottom: 2px;
    }

    .ttd-box .ttd-role {
        font-size: 10px;
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 50px;
    }

    .ttd-box .ttd-name {
        font-size: 10.5px;
        font-weight: 700;
        text-decoration: underline;
        color: #0f172a;
        margin-bottom: 1px;
    }

    .ttd-box .ttd-instansi {
        font-size: 8.5px;
        color: var(--text-muted);
    }

    /* PERBAIKAN UTAMA: PRINT MEDIA RULES */
    @media print {
        .no-print, .no-print-toolbar {
            display: none !important;
        }
        html, body {
            background: #ffffff !important;
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            height: auto !important;
            min-height: 100% !important;
            overflow: visible !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        .page-container {
            max-width: 100% !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
        }
        .table-laporan-wrapper {
            width: 100% !important;
            overflow: visible !important;
            margin-bottom: 10px !important;
        }
        .table-laporan {
            width: 100% !important;
            table-layout: fixed !important;
            border-collapse: collapse !important;
        }
        .table-laporan tr {
            page-break-inside: avoid;
        }
        .table-laporan thead {
            display: table-header-group;
        }
        .table-laporan tfoot {
            display: table-footer-group;
        }
    }
</style>

</head>
<body class="orientation-landscape">

<!-- Toolbar Navigasi Screen -->
<div class="no-print-toolbar no-print">
    <div class="d-flex align-items-center gap-2 flex-wrap">
        <a href="pembayaran.php?bulan=<?= urlencode($filterBulan) ?>&tahun=<?= urlencode($filterTahun) ?>" class="btn btn-outline-secondary btn-sm fw-bold">
            <i class="fa fa-arrow-left me-1"></i> Kembali
        </a>
        <span class="badge bg-light text-dark border py-2 px-3" style="font-size: 15px;">
            <i class="fas fa-file-invoice text-success me-1.5" style="font-size: 16px;"></i> 
            <strong style="font-size: 16px;"><?= $totalTransaksi ?></strong> Data | 
            <span class="text-primary" style="font-size: 15px; font-weight: 600;"><?= htmlspecialchars($labelPeriode) ?></span>
        </span>
        <form method="GET" class="d-flex align-items-center gap-1.5 m-0">
            <select name="bulan" class="form-select form-select-sm" style="width: 130px;" onchange="this.form.submit()">
                <option value="semua" <?= ($filterBulan === 'semua') ? 'selected' : '' ?>>Semua Bulan</option>
                <?php foreach ($namaBulanIndo as $numBln => $txtBln): ?>
                    <option value="<?= $numBln ?>" <?= ($filterBulan == $numBln) ? 'selected' : '' ?>><?= $txtBln ?></option>
                <?php endforeach; ?>
            </select>
            <select name="tahun" class="form-select form-select-sm" style="width: 110px;" onchange="this.form.submit()">
                <option value="semua" <?= ($filterTahun === 'semua') ? 'selected' : '' ?>>Semua Thn</option>
                <?php 
                $currY = (int)date('Y');
                for ($y = $currY; $y >= 2024; $y--): ?>
                    <option value="<?= $y ?>" <?= ($filterTahun == $y) ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
        </form>
        
        <div class="btn-group btn-group-sm btn-orientation-group" role="group" aria-label="Pilihan Orientasi">
            <button type="button" class="btn btn-outline-success active" id="btnLandscape" onclick="setOrientation('landscape')">
                <i class="fas fa-arrows-alt-h me-1"></i> Landscape
            </button>
            <button type="button" class="btn btn-outline-success" id="btnPortrait" onclick="setOrientation('portrait')">
                <i class="fas fa-arrows-alt-v me-1"></i> Portrait
            </button>
        </div>
    </div>

    <div>
        <button class="btn btn-danger btn-sm fw-bold px-3 shadow-sm" onclick="window.print()">
            <i class="fa fa-print me-1"></i> Cetak / Simpan PDF
        </button>
    </div>
</div>

<!-- Lembar Cetak Laporan -->
<div class="page-container">
    <!-- Kop Laporan Resmi -->
    <div class="kop-laporan">
        <div class="kop-brand-wrapper">
            <?php if (!empty($logoBase64)): ?>
                <img src="<?= $logoBase64 ?>" alt="Logo Semar Outdoor" class="kop-logo">
            <?php endif; ?>
            <div>
                <h1 class="kop-brand-title">SEMAR OUTDOOR EQUIPMENT</h1>
                <p class="kop-brand-sub">Rental & Persewaan Perlengkapan Camping, Pendakian, & Alat Petualangan Outdoor</p>
                <p class="kop-brand-desc">
                    Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466<br>
                    <span>Email: semaroutdoor@gmail.com</span> &bull; <span>Instagram: @semaroutdoor</span> &bull; <span>Buka: 08.00 - 21.00 WIB</span>
                </p>
            </div>
        </div>
        <div class="kop-meta">
            <span class="doc-badge">Dokumen Resmi</span>
            <div class="doc-print-time">
                <strong>Dicetak pada:</strong><br>
                <?= formatTanggalIndo(date('Y-m-d H:i:s')) ?>
            </div>
        </div>
    </div>

    <!-- Judul & Periode Laporan -->
    <div class="laporan-title-box">
        <h4>LAPORAN REKAPITULASI PEMBAYARAN</h4>
        <p>Klasifikasi Data: Pembayaran Berstatus <strong>LUNAS</strong> dan <strong>BELUM LUNAS (Uang Muka / DP)</strong> &bull; <strong style="color: #0e4430; font-size: 11px;"><?= htmlspecialchars($labelPeriode) ?></strong></p>
    </div>

    <!-- Summary Box -->
    <div class="summary-grid">
        <div class="summary-card">
            <div class="label">Total Transaksi</div>
            <div class="value"><?= $totalTransaksi ?> Transaksi</div>
        </div>
        <div class="summary-card success">
            <div class="label">Total Dana Masuk (Bayar)</div>
            <div class="value">Rp <?= number_format($totalBayar, 0, ',', '.') ?></div>
        </div>
        <div class="summary-card">
            <div class="label">Total Nilai Tagihan</div>
            <div class="value">Rp <?= number_format($totalTagihan, 0, ',', '.') ?></div>
        </div>
        <div class="summary-card <?= ($sisaTagihan > 0) ? 'warning' : 'success' ?>">
            <div class="label">Sisa Belum Terbayar</div>
            <div class="value">Rp <?= number_format($sisaTagihan, 0, ',', '.') ?></div>
        </div>
    </div>

    <!-- Tabel Data Rekap Presisi -->
    <div class="table-laporan-wrapper">
        <table class="table-laporan">
            <colgroup>
                <col style="width: 3.5%;">  <!-- No -->
                <col style="width: 12.5%;"> <!-- No. Tagihan -->
                <col style="width: 11%;">   <!-- Nama Pengguna -->
                <col style="width: 15%;">   <!-- Alat Disewa -->
                <col style="width: 10%;">    <!-- Metode -->
                <col style="width: 11%;">   <!-- Jumlah Bayar -->
                <col style="width: 11%;">   <!-- Total Tagihan -->
                <col style="width: 9%;">    <!-- Status -->
                <col style="width: 11%;">   <!-- Tanggal Bayar -->
            </colgroup>
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Tagihan</th>
                    <th style="text-align: center;">Nama Pengguna</th>
                    <th style="text-align: center;">Alat Disewa</th>
                    <th>Metode</th>
                    <th style="text-align: center;">Jumlah Bayar</th>
                    <th style="text-align: center;">Total Tagihan</th>
                    <th>Status</th>
                    <th>Tanggal Bayar</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!empty($dataPembayaran)): 
                $no = 1;
                foreach ($dataPembayaran as $row):
                    $isLunas = (strtolower(trim($row['status'] ?? '')) === 'lunas');
                    $tglDate = !empty($row['tanggal_bayar']) ? date('d/m/Y', strtotime($row['tanggal_bayar'])) : '-';
                    $tglTime = !empty($row['tanggal_bayar']) ? date('H:i', strtotime($row['tanggal_bayar'])) . ' WIB' : '';
                    $rawNama = trim($row['nama_produk'] ?? '');
            ?>
                <tr>
                    <td class="text-center fw-bold"><?= $no++ ?></td>
                    <td class="text-center"><span class="tagihan-code"><?= htmlspecialchars($row['no_tagihan'] ?? '-') ?></span></td>
                    <td style="font-weight: 600; word-wrap: break-word;"><?= htmlspecialchars($row['nama_user'] ?? '-') ?></td>
                    <td style="word-wrap: break-word;">
                        <?php
                        if (!empty($rawNama) && $rawNama !== '-') {
                            $itemsList = array_map('trim', explode(', ', $rawNama));
                            if (count($itemsList) > 1) {
                                echo '<div class="items-cell-list">';
                                foreach ($itemsList as $singleItem) {
                                    if (empty($singleItem)) continue;
                                    if (preg_match('/^(.*?)\s*\(x(\d+)\)$/i', $singleItem, $match)) {
                                        $itemName = $match[1];
                                        $itemQty  = $match[2];
                                        echo '<div class="item-cell-row">';
                                        echo '  <span class="item-dot">&bull;</span> ';
                                        echo '  <span class="item-name">' . htmlspecialchars($itemName) . '</span> ';
                                        echo '  <span class="item-qty-badge">x' . $itemQty . '</span>';
                                        echo '</div>';
                                    } else {
                                        echo '<div class="item-cell-row">';
                                        echo '  <span class="item-dot">&bull;</span> ';
                                        echo '  <span class="item-name">' . htmlspecialchars($singleItem) . '</span>';
                                        echo '</div>';
                                    }
                                }
                                echo '</div>';
                            } else {
                                $singleItem = $itemsList[0];
                                if (preg_match('/^(.*?)\s*\(x(\d+)\)$/i', $singleItem, $match)) {
                                    $itemName = $match[1];
                                    $itemQty  = $match[2];
                                    echo '<div class="item-cell-single">';
                                    echo '  <span class="item-name">' . htmlspecialchars($itemName) . '</span> ';
                                    echo '  <span class="item-qty-badge">x' . $itemQty . '</span>';
                                    echo '</div>';
                                } else {
                                    echo '<span class="item-name">' . htmlspecialchars($singleItem) . '</span>';
                                }
                            }
                        } else {
                            echo '<span class="text-muted">-</span>';
                        }
                        ?>
                    </td>
                    <td class="text-center">
                        <span class="badge-metode"><?= htmlspecialchars($row['metode'] ?? '-') ?></span>
                    </td>
                    <td class="text-end fw-bold text-success" style="white-space: nowrap;">
                        Rp <?= number_format($row['jumlah_bayar'] ?? 0, 0, ',', '.') ?>
                    </td>
                    <td class="text-end fw-semibold" style="white-space: nowrap;">
                        Rp <?= number_format($row['total_tagihan'] ?? 0, 0, ',', '.') ?>
                    </td>
                    <td class="text-center">
                        <span class="<?= $isLunas ? 'badge-lunas' : 'badge-belum' ?>">
                            <?= htmlspecialchars(ucwords(strtolower(trim($row['status'] ?? '-')))) ?>
                        </span>
                    </td>
                    <td class="text-center" style="padding: 4px 2px !important;">
                        <div style="font-weight: 700; color: #0f172a; line-height: 1.25; font-size: 8.5px;"><?= $tglDate ?></div>
                        <?php if (!empty($tglTime)): ?>
                            <div style="font-size: 7.5px; color: #64748b; line-height: 1.25;"><?= $tglTime ?></div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php 
                endforeach; 
            else: 
            ?>
                <tr>
                    <td colspan="9" class="text-center py-4 text-muted">
                        <i class="fa fa-info-circle me-1"></i> Tidak ada data pembayaran dengan status Lunas atau Belum Lunas.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5" class="text-end text-uppercase fw-bold" style="letter-spacing: 0.4px;">TOTAL REKAPITULASI:</td>
                    <td class="text-end text-success fw-bold" style="white-space: nowrap;">
                        Rp <?= number_format($totalBayar, 0, ',', '.') ?>
                    </td>
                    <td class="text-end fw-bold" style="white-space: nowrap;">
                        Rp <?= number_format($totalTagihan, 0, ',', '.') ?>
                    </td>
                    <td colspan="2" class="text-center text-muted fw-bold">
                        <?= $totalTransaksi ?> Transaksi
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Tanda Tangan & Pengesahan -->
    <div class="ttd-wrapper">
        <div class="ttd-box">
            <div class="ttd-date">Tasikmalaya, <?= date('d F Y') ?></div>
            <div class="ttd-role">Petugas Kasir & Administrasi,</div>
            <div class="ttd-name">( Semar Outdoor Management )</div>
            <div class="ttd-instansi">Unit Pengelola Keuangan</div>
        </div>
    </div>
</div>

<script>
function setOrientation(orientation) {
    const styleTag = document.getElementById('pageOrientationStyle');
    const btnL = document.getElementById('btnLandscape');
    const btnP = document.getElementById('btnPortrait');
    
    if (orientation === 'portrait') {
        styleTag.innerHTML = '@page { size: A4 portrait; margin: 8mm; }';
        document.body.classList.remove('orientation-landscape');
        document.body.classList.add('orientation-portrait');
        btnP.classList.add('active');
        btnL.classList.remove('active');
    } else {
        styleTag.innerHTML = '@page { size: A4 landscape; margin: 8mm; }';
        document.body.classList.remove('orientation-portrait');
        document.body.classList.add('orientation-landscape');
        btnL.classList.add('active');
        btnP.classList.remove('active');
    }
}
</script>
</body>
</html>