<?php
session_start();
include '../../koneksi.php'; 
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

// 1. Filter Tahun
$year = isset($_GET['tahun']) ? (int)$_GET['tahun'] : (int)date('Y');

// 2. Total Uang Masuk Tahun Terpilih
$queryUang = "SELECT SUM(jumlah_bayar) AS total_uang 
              FROM pembayaran 
              WHERE LOWER(TRIM(status)) IN ('lunas', 'belum lunas')
              AND YEAR(tanggal_bayar) = $year";
$resultUang = mysqli_query($conn, $queryUang);
$rowUang = mysqli_fetch_assoc($resultUang);
$totalUang = (float)($rowUang['total_uang'] ?? 0);

// 3. Data Keuangan Bulanan (Lunas, DP, & Total) + Jumlah Transaksi
$monthlyLunas = array_fill(1, 12, 0);
$monthlyDP = array_fill(1, 12, 0);
$monthlyTotal = array_fill(1, 12, 0);
$monthlyTrx = array_fill(1, 12, 0);

$queryBulanan = "SELECT 
                    MONTH(tanggal_bayar) AS bulan, 
                    SUM(CASE WHEN LOWER(TRIM(status)) = 'lunas' THEN jumlah_bayar ELSE 0 END) AS total_lunas,
                    SUM(CASE WHEN LOWER(TRIM(status)) = 'belum lunas' THEN jumlah_bayar ELSE 0 END) AS total_dp,
                    SUM(jumlah_bayar) AS total_gabungan,
                    COUNT(id) AS total_transaksi
                 FROM pembayaran 
                 WHERE LOWER(TRIM(status)) IN ('lunas', 'belum lunas')
                 AND YEAR(tanggal_bayar) = $year
                 GROUP BY MONTH(tanggal_bayar)";
$resultBulanan = mysqli_query($conn, $queryBulanan);
if ($resultBulanan) {
    while ($row = mysqli_fetch_assoc($resultBulanan)) {
        $bln = (int)$row['bulan'];
        $monthlyLunas[$bln] = (float)$row['total_lunas'];
        $monthlyDP[$bln] = (float)$row['total_dp'];
        $monthlyTotal[$bln] = (float)$row['total_gabungan'];
        $monthlyTrx[$bln] = (int)$row['total_transaksi'];
    }
}

// 4. Hitung Statistik Ringkasan Bulanan
$maxBulanVal = 0;
$maxBulanIdx = 1;
$sumBulan = 0;
$activeMonths = 0;
$totalLunasTahun = array_sum($monthlyLunas);
$totalDPTahun = array_sum($monthlyDP);
$totalTransaksiTahun = array_sum($monthlyTrx);
$namaBulanIndo = [1=>'Januari', 2=>'Februari', 3=>'Maret', 4=>'April', 5=>'Mei', 6=>'Juni', 7=>'Juli', 8=>'Agustus', 9=>'September', 10=>'Oktober', 11=>'November', 12=>'Desember'];

foreach ($monthlyTotal as $m => $v) {
    if ($v > $maxBulanVal) {
        $maxBulanVal = $v;
        $maxBulanIdx = $m;
    }
    if ($v > 0) {
        $sumBulan += $v;
        $activeMonths++;
    }
}
$avgBulan = ($activeMonths > 0) ? ($sumBulan / $activeMonths) : 0;

// 5. Daftar Tahun untuk Dropdown Filter (Multi-Tahun: Database + Rentang 5 Tahun)
$currentYear = (int)date('Y');
$years = [];

// Rentang tahun (4 tahun ke belakang hingga 1 tahun ke depan)
for ($y = $currentYear - 4; $y <= $currentYear + 1; $y++) {
    $years[] = $y;
}

// Ambil tahun dari database pembayaran & sewa jika ada
$qYears = mysqli_query($conn, "
    SELECT DISTINCT YEAR(tanggal_bayar) AS tahun 
    FROM pembayaran 
    WHERE tanggal_bayar IS NOT NULL AND YEAR(tanggal_bayar) > 2000
    UNION
    SELECT DISTINCT YEAR(tanggal_buat) AS tahun
    FROM sewa
    WHERE tanggal_buat IS NOT NULL AND YEAR(tanggal_buat) > 2000
");
if ($qYears) {
    while ($y = mysqli_fetch_assoc($qYears)) {
        if (!empty($y['tahun'])) $years[] = (int)$y['tahun'];
    }
}
$years = array_unique($years);
rsort($years);

// 6. Distribusi Status Transaksi Sewa
$qStatusCount = mysqli_query($conn, "
    SELECT 
        COUNT(id) AS total_sewa_semua,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'menunggu pembayaran' THEN 1 ELSE 0 END) AS status_menunggu_bayar,
        SUM(CASE WHEN LOWER(TRIM(status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar') THEN 1 ELSE 0 END) AS status_siap_antar,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'berlangsung' THEN 1 ELSE 0 END) AS status_berlangsung,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'selesai' THEN 1 ELSE 0 END) AS status_selesai,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'dibatalkan' THEN 1 ELSE 0 END) AS status_dibatalkan
    FROM sewa
");
$rowStatus = mysqli_fetch_assoc($qStatusCount) ?: [];
$totalSewaSemua = (int)($rowStatus['total_sewa_semua'] ?? 0);
$cntMenungguBayar = (int)($rowStatus['status_menunggu_bayar'] ?? 0);
$cntSiapAntar = (int)($rowStatus['status_siap_antar'] ?? 0);
$cntBerlangsung = (int)($rowStatus['status_berlangsung'] ?? 0);
$cntSelesai = (int)($rowStatus['status_selesai'] ?? 0);
$cntDibatalkan = (int)($rowStatus['status_dibatalkan'] ?? 0);
$totalSewaAktif = $cntSiapAntar + $cntBerlangsung;

// 7. Total Pengguna
$queryUser = "SELECT COUNT(id) AS total_user FROM users";
$resultUser = mysqli_query($conn, $queryUser);
$totalUser = (int)(mysqli_fetch_assoc($resultUser)['total_user'] ?? 0);

// 8. Total Alat & Stok
$qAlat = mysqli_query($conn, "
    SELECT 
        COUNT(id) AS total_jenis_alat,
        SUM(stok_awal) AS total_unit_stok,
        SUM(sisa_stok) AS total_unit_tersedia
    FROM alat
");
$rowAlat = mysqli_fetch_assoc($qAlat) ?: [];
$totalJenisAlat = (int)($rowAlat['total_jenis_alat'] ?? 0);
$totalUnitStok = (int)($rowAlat['total_unit_stok'] ?? 0);
$totalUnitTersedia = (int)($rowAlat['total_unit_tersedia'] ?? 0);
$unitTerpakai = max(0, $totalUnitStok - $totalUnitTersedia);
$persenStokTersedia = ($totalUnitStok > 0) ? round(($totalUnitTersedia / $totalUnitStok) * 100) : 0;

// 9. Top 5 Produk Paling Sering Disewa
$queryTopProduk = "
    SELECT 
        a.id,
        a.nama,
        a.gambar,
        a.stok_awal,
        a.sisa_stok,
        a.harga_per_hari,
        COALESCE(SUM(s.qty), 0) AS total_disewa
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat AND LOWER(TRIM(s.status)) != 'dibatalkan'
    GROUP BY a.id
    ORDER BY total_disewa DESC, a.id ASC
    LIMIT 5
";
$resultTopProduk = mysqli_query($conn, $queryTopProduk);

// 10. Transaksi Terbaru yang Butuh Tindakan
$qRecentOrders = mysqli_query($conn, "
    SELECT s.*, u.nama AS nama_user
    FROM sewa s
    JOIN users u ON s.id_users = u.id
    WHERE LOWER(TRIM(s.status)) IN ('menunggu pembayaran', 'siap di ambil', 'di antar')
    ORDER BY s.tanggal_buat DESC, s.id DESC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard Admin - Semar Outdoor</title>
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  
  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    body {
      background-color: var(--bg-body);
      font-family: 'Plus Jakarta Sans', sans-serif;
      color: var(--text-main);
      min-height: 100vh;
      overflow-x: hidden;
    }

    /* Welcome Banner */
    .welcome-banner {
      background: linear-gradient(135deg, #12282a 0%, #162d2f 50%, #0e4430 100%);
      border-radius: 16px;
      color: #ffffff;
      padding: 26px 30px;
      box-shadow: 0 10px 25px rgba(18, 40, 42, 0.15);
      position: relative;
      overflow: hidden;
      margin-bottom: 25px;
    }

    .welcome-banner::after {
      content: "";
      position: absolute;
      top: -50px;
      right: -50px;
      width: 200px;
      height: 200px;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.15) 0%, transparent 70%);
      border-radius: 50%;
      pointer-events: none;
    }

    .welcome-title {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.6rem;
      font-weight: 800;
      letter-spacing: -0.3px;
      margin-bottom: 5px;
    }

    .welcome-subtitle {
      color: #cbd5e1;
      font-size: 0.9rem;
      margin: 0;
    }

    /* KPI Summary Cards */
    .kpi-card {
      background: #ffffff;
      border-radius: 16px;
      padding: 22px 20px;
      border: 1px solid rgba(0, 0, 0, 0.05);
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);
      transition: all 0.25s ease;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .kpi-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
      border-color: rgba(194, 120, 3, 0.3);
    }

    .kpi-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
    }

    .kpi-label {
      font-size: 0.82rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--text-muted);
      margin: 0;
    }

    .kpi-icon-wrap {
      width: 46px;
      height: 46px;
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.35rem;
    }

    .kpi-icon-wrap.green {
      background: rgba(14, 68, 48, 0.1);
      color: #0e4430;
    }

    .kpi-icon-wrap.gold {
      background: rgba(194, 120, 3, 0.1);
      color: #c27803;
    }

    .kpi-icon-wrap.blue {
      background: rgba(37, 99, 235, 0.1);
      color: #2563eb;
    }

    .kpi-icon-wrap.purple {
      background: rgba(124, 58, 237, 0.1);
      color: #7c3aed;
    }

    .kpi-value {
      font-size: 1.55rem;
      font-weight: 800;
      color: var(--brand-dark);
      margin-bottom: 4px;
      line-height: 1.2;
    }

    .kpi-footer {
      font-size: 0.78rem;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 5px;
    }

    /* Content Cards */
    .dashboard-card {
      background: #ffffff;
      border-radius: 16px;
      border: 1px solid rgba(0, 0, 0, 0.05);
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);
      padding: 24px;
      height: 100%;
    }

    .card-head-title {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 20px;
      padding-bottom: 12px;
      border-bottom: 1px solid #f1f5f9;
    }

    .card-head-title h5 {
      font-size: 1.05rem;
      font-weight: 700;
      color: var(--brand-dark);
      margin: 0;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* Quick Action Shortcuts */
    .quick-action-btn {
      display: flex;
      align-items: center;
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 14px 16px;
      text-decoration: none;
      color: var(--brand-dark);
      font-weight: 600;
      font-size: 0.9rem;
      transition: all 0.2s ease;
      height: 100%;
    }

    .quick-action-btn:hover {
      background: #ffffff;
      border-color: var(--brand-gold);
      color: var(--brand-gold);
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.06);
    }

    .quick-action-icon {
      width: 38px;
      height: 38px;
      border-radius: 10px;
      background: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
      flex-shrink: 0;
    }

    /* Top Product Items */
    .top-product-item {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 12px 0;
      border-bottom: 1px solid #f1f5f9;
    }

    .top-product-item:last-child {
      border-bottom: none;
      padding-bottom: 0;
    }

    .top-product-thumb {
      width: 48px;
      height: 44px;
      border-radius: 8px;
      object-fit: cover;
      border: 1px solid #e2e8f0;
      flex-shrink: 0;
    }

    .top-product-info {
      flex: 1;
      min-width: 0;
    }

    .top-product-name {
      font-weight: 700;
      font-size: 0.92rem;
      color: var(--brand-dark);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 3px;
    }

    .top-product-progress {
      height: 6px;
      border-radius: 10px;
      background: #f1f5f9;
      margin-top: 4px;
    }

    .recent-order-pill {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 11px 14px;
      background: #f8fafc;
      border-radius: 10px;
      margin-bottom: 10px;
      border: 1px solid #edf2f7;
      transition: background 0.2s;
    }

    .recent-order-pill:hover {
      background: #f1f5f9;
    }

    /* Chart Type Switcher & Mini Stats */
    .chart-type-pill {
      background: #f1f5f9;
      border-radius: 50px;
      padding: 3px;
      display: inline-flex;
      gap: 3px;
    }

    .btn-chart-type {
      border: none;
      background: transparent;
      padding: 5px 12px;
      font-size: 0.78rem;
      font-weight: 700;
      color: var(--text-muted);
      border-radius: 50px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-chart-type.active {
      background: #ffffff;
      color: var(--brand-dark);
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
    }

    .chart-mini-stat {
      background: #f8fafc;
      border: 1px solid #f1f5f9;
      border-radius: 12px;
      padding: 10px 14px;
      transition: all 0.2s ease;
    }

    .chart-mini-stat:hover {
      background: #ffffff;
      border-color: #e2e8f0;
    }
  </style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
  <!-- 1. Welcome Header Banner -->
  <div class="welcome-banner d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
    <div>
      <div class="d-inline-flex align-items-center gap-2 px-3 py-1 rounded-pill bg-white bg-opacity-10 text-warning small fw-bold mb-2">
        <i class="fas fa-calendar-day"></i> <?= date('l, d F Y') ?>
      </div>
      <h1 class="welcome-title">Selamat Datang di Panel Admin Semar Outdoor!</h1>
      <p class="welcome-subtitle">Pantau performa persewaan, kelola stok alat, dan verifikasi pembayaran pelanggan secara real-time.</p>
    </div>

    <div class="d-flex align-items-center gap-3">
      <a href="../riwayat/riwayat.php" class="btn btn-warning btn-sm fw-bold px-3 py-2 text-dark shadow-sm">
        <i class="fas fa-clipboard-list me-1"></i> Antrian Sewa (<?= $totalSewaAktif ?>)
      </a>
      <a href="../pembayaran/pembayaran.php" class="btn btn-outline-light btn-sm fw-bold px-3 py-2">
        <i class="fas fa-money-bill-wave me-1"></i> Pembayaran
      </a>
    </div>
  </div>

  <!-- 2. Ringkasan 4 Kartu KPI Utama -->
  <div class="row g-3 mb-4">
    <!-- KPI 1: Pendapatan -->
    <div class="col-xl-3 col-md-6">
      <div class="kpi-card">
        <div>
          <div class="kpi-header">
            <span class="kpi-label">Uang Masuk (<?= $year ?>)</span>
            <div class="kpi-icon-wrap green">
              <i class="fas fa-wallet"></i>
            </div>
          </div>
          <div class="kpi-value text-success">
            Rp<?= number_format($totalUang, 0, ',', '.') ?>
          </div>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-check-circle text-success"></i>
          <span>Total transaksi terbayar (Lunas / DP)</span>
        </div>
      </div>
    </div>

    <!-- KPI 2: Transaksi Sewa Aktif -->
    <div class="col-xl-3 col-md-6">
      <div class="kpi-card">
        <div>
          <div class="kpi-header">
            <span class="kpi-label">Sewa Berjalan</span>
            <div class="kpi-icon-wrap gold">
              <i class="fas fa-calendar-check"></i>
            </div>
          </div>
          <div class="kpi-value text-warning">
            <?= $totalSewaAktif ?> <span class="fs-6 fw-normal text-muted">Pesanan</span>
          </div>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-clock text-warning"></i>
          <span><?= $cntSiapAntar ?> Siap/Antar &bull; <?= $cntBerlangsung ?> Berlangsung</span>
        </div>
      </div>
    </div>

    <!-- KPI 3: Unit Stok Alat -->
    <div class="col-xl-3 col-md-6">
      <div class="kpi-card">
        <div>
          <div class="kpi-header">
            <span class="kpi-label">Kapasitas Stok Alat</span>
            <div class="kpi-icon-wrap blue">
              <i class="fas fa-campground"></i>
            </div>
          </div>
          <div class="kpi-value text-primary">
            <?= $totalUnitTersedia ?> <span class="fs-6 fw-normal text-muted">/ <?= $totalUnitStok ?> Unit</span>
          </div>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-box-open text-primary"></i>
          <span><?= $persenStokTersedia ?>% Unit siap disewa (<?= $totalJenisAlat ?> Variasi)</span>
        </div>
      </div>
    </div>

    <!-- KPI 4: Total Pelanggan -->
    <div class="col-xl-3 col-md-6">
      <div class="kpi-card">
        <div>
          <div class="kpi-header">
            <span class="kpi-label">Total Pelanggan</span>
            <div class="kpi-icon-wrap purple">
              <i class="fas fa-users"></i>
            </div>
          </div>
          <div class="kpi-value text-dark">
            <?= $totalUser ?> <span class="fs-6 fw-normal text-muted">Akun</span>
          </div>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-user-check text-secondary"></i>
          <span>Akun penyewa terdaftar di sistem</span>
        </div>
      </div>
    </div>
  </div>

  <!-- 3. Pintasan Tindakan Cepat (Quick Shortcuts) -->
  <div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
      <a href="../alat/list_alat.php" class="quick-action-btn">
        <div class="quick-action-icon text-success">
          <i class="fas fa-plus-circle"></i>
        </div>
        <div>
          <div>Kelola Alat</div>
          <small class="text-muted fw-normal">Tambah / Edit Stok</small>
        </div>
      </a>
    </div>
    <div class="col-6 col-md-3">
      <a href="../pembayaran/pembayaran.php" class="quick-action-btn">
        <div class="quick-action-icon text-warning">
          <i class="fas fa-receipt"></i>
        </div>
        <div>
          <div>Verifikasi Bayar</div>
          <small class="text-muted fw-normal"><?= $cntMenungguBayar ?> Menunggu</small>
        </div>
      </a>
    </div>
    <div class="col-6 col-md-3">
      <a href="../riwayat/riwayat.php" class="quick-action-btn">
        <div class="quick-action-icon text-primary">
          <i class="fas fa-tasks"></i>
        </div>
        <div>
          <div>Antrian Sewa</div>
          <small class="text-muted fw-normal">Proses FIFO</small>
        </div>
      </a>
    </div>
    <div class="col-6 col-md-3">
      <a href="../pengembalian/pengembalian.php" class="quick-action-btn">
        <div class="quick-action-icon text-danger">
          <i class="fas fa-undo-alt"></i>
        </div>
        <div>
          <div>Pengembalian</div>
          <small class="text-muted fw-normal"><?= $cntSelesai ?> Selesai</small>
        </div>
      </a>
    </div>
  </div>

  <!-- 4. Bagian Grafik Laporan & Distribusi Status -->
  <div class="row g-4 mb-4">
    <!-- Grafik Pendapatan & Transaksi Bulanan -->
    <div class="col-lg-8">
      <div class="dashboard-card">
        <div class="card-head-title flex-wrap gap-2">
          <div>
            <h5><i class="fas fa-chart-line text-success me-1"></i> Arus Kas & Volume Transaksi</h5>
            <small class="text-muted">Grafik kombinasi pendapatan (Rupiah) dan frekuensi transaksi sewa tahun <?= $year ?>.</small>
          </div>

          <div class="d-flex align-items-center gap-2">
            <!-- Mode Switcher -->
            <div class="chart-type-pill">
              <button type="button" class="btn-chart-type active" id="btnTypeBar" onclick="setChartType('combo')">
                <i class="fas fa-chart-column me-1"></i> Kombinasi
              </button>
              <button type="button" class="btn-chart-type" id="btnTypeLine" onclick="setChartType('area')">
                <i class="fas fa-chart-area me-1"></i> Area
              </button>
            </div>

            <!-- Year Filter -->
            <form method="GET" class="d-flex align-items-center gap-1 m-0">
              <select name="tahun" class="form-select form-select-sm w-auto fw-bold text-dark border-secondary bg-light" onchange="this.form.submit()">
                <?php foreach ($years as $thn): ?>
                  <option value="<?= $thn ?>" <?= ($year == $thn) ? 'selected' : '' ?>>
                    Tahun <?= $thn ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </form>
          </div>
        </div>

        <!-- 4 Highlight Pills -->
        <div class="row g-2 mb-3">
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.7rem; font-weight: 700;">PELUNASAN</span>
              <strong class="text-success" style="font-size: 0.9rem;">Rp<?= number_format($totalLunasTahun, 0, ',', '.') ?></strong>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.7rem; font-weight: 700;">UANG MUKA (DP)</span>
              <strong class="text-warning" style="font-size: 0.9rem;">Rp<?= number_format($totalDPTahun, 0, ',', '.') ?></strong>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.7rem; font-weight: 700;">TOTAL TRANSAKSI</span>
              <strong class="text-primary" style="font-size: 0.9rem;"><?= $totalTransaksiTahun ?> Trx</strong>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.7rem; font-weight: 700;">TOTAL OMSET</span>
              <strong class="text-dark" style="font-size: 0.9rem;">Rp<?= number_format($totalUang, 0, ',', '.') ?></strong>
            </div>
          </div>
        </div>

        <div style="height: 300px; position: relative;">
          <canvas id="monthlyChart"></canvas>
        </div>

        <div class="row g-2 mt-3 pt-3 border-top text-center text-sm-start small text-muted">
          <div class="col-sm-6">
            <span><i class="fas fa-trophy text-warning me-1"></i> Puncak Omset (<?= $namaBulanIndo[$maxBulanIdx] ?? '-' ?>): <strong class="text-success">Rp<?= number_format($maxBulanVal, 0, ',', '.') ?></strong></span>
          </div>
          <div class="col-sm-6 text-sm-end">
            <span><i class="fas fa-calculator text-primary me-1"></i> Rata-Rata Bulanan: <strong class="text-dark">Rp<?= number_format($avgBulan, 0, ',', '.') ?></strong></span>
          </div>
        </div>
      </div>
    </div>

    <!-- Ringkasan Status Sewa (Doughnut Chart & Status Cards) -->
    <div class="col-lg-4">
      <div class="dashboard-card">
        <div class="card-head-title">
          <h5><i class="fas fa-chart-pie text-warning me-1"></i> Status Persewaan</h5>
          <span class="badge bg-light text-dark border"><?= $totalSewaSemua ?> Total</span>
        </div>

        <div style="height: 200px; position: relative; margin-bottom: 15px;">
          <canvas id="statusChart"></canvas>
        </div>

        <div class="d-flex flex-column gap-2 small">
          <div class="d-flex justify-content-between align-items-center p-2 rounded bg-light border">
            <span><i class="fas fa-circle text-primary me-2"></i>Menunggu Pembayaran</span>
            <strong class="badge bg-primary rounded-pill"><?= $cntMenungguBayar ?></strong>
          </div>
          <div class="d-flex justify-content-between align-items-center p-2 rounded bg-light border">
            <span><i class="fas fa-circle text-warning me-2"></i>Siap Diambil / Antar</span>
            <strong class="badge bg-warning text-dark rounded-pill"><?= $cntSiapAntar ?></strong>
          </div>
          <div class="d-flex justify-content-between align-items-center p-2 rounded bg-light border">
            <span><i class="fas fa-circle text-success me-2"></i>Berlangsung (Disewa)</span>
            <strong class="badge bg-success rounded-pill"><?= $cntBerlangsung ?></strong>
          </div>
          <div class="d-flex justify-content-between align-items-center p-2 rounded bg-light border">
            <span><i class="fas fa-circle text-secondary me-2"></i>Selesai / Kembali</span>
            <strong class="badge bg-secondary rounded-pill"><?= $cntSelesai ?></strong>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 5. Bagian Bawah: Top Produk & Pesanan Menunggu Tindakan -->
  <div class="row g-4">
    <!-- Top 5 Produk Populer -->
    <div class="col-lg-7">
      <div class="dashboard-card">
        <div class="card-head-title">
          <h5><i class="fas fa-fire text-danger me-1"></i> 5 Peralatan Paling Sering Disewa</h5>
          <a href="../alat/list_alat.php" class="btn btn-link btn-sm text-decoration-none p-0 fw-bold">Semua Alat &rarr;</a>
        </div>

        <div class="d-flex flex-column gap-2">
          <?php 
          $rank = 1;
          if ($resultTopProduk && mysqli_num_rows($resultTopProduk) > 0): 
            while ($tp = mysqli_fetch_assoc($resultTopProduk)): 
              $totalDisewa = (int)$tp['total_disewa'];
              $stokAwal = (int)$tp['stok_awal'] > 0 ? (int)$tp['stok_awal'] : 1;
              $persenDisewa = min(100, round(($totalDisewa / max(1, $totalDisewa + (int)$tp['sisa_stok'])) * 100));
              $imgAlat = !empty($tp['gambar']) ? '../uploads/alat/' . $tp['gambar'] : '../../assets/images/tenda.jpg';
          ?>
            <div class="top-product-item">
              <span class="badge bg-dark rounded-circle px-2 py-1 small"><?= $rank++ ?></span>
              <img src="<?= htmlspecialchars($imgAlat) ?>" alt="produk" class="top-product-thumb">
              <div class="top-product-info">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="top-product-name"><?= htmlspecialchars($tp['nama']) ?></div>
                  <span class="badge bg-light text-dark border small fw-bold"><?= $totalDisewa ?>x disewa</span>
                </div>
                <div class="d-flex justify-content-between align-items-center text-muted small">
                  <span>Rp<?= number_format($tp['harga_per_hari'], 0, ',', '.') ?>/hari</span>
                  <span>Sisa: <strong class="<?= $tp['sisa_stok'] > 0 ? 'text-success' : 'text-danger' ?>"><?= $tp['sisa_stok'] ?> unit</strong></span>
                </div>
                <div class="progress top-product-progress">
                  <div class="progress-bar bg-success" style="width: <?= $persenDisewa ?>%;"></div>
                </div>
              </div>
            </div>
          <?php 
            endwhile; 
          else: 
          ?>
            <p class="text-muted text-center my-3">Belum ada data penyewaan alat.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Pesanan Terbaru Butuh Tindakan -->
    <div class="col-lg-5">
      <div class="dashboard-card">
        <div class="card-head-title">
          <h5><i class="fas fa-bell text-warning me-1"></i> Pesanan Butuh Diproses</h5>
          <a href="../riwayat/riwayat.php" class="btn btn-link btn-sm text-decoration-none p-0 fw-bold">Kelola Antrian &rarr;</a>
        </div>

        <?php if ($qRecentOrders && mysqli_num_rows($qRecentOrders) > 0): ?>
          <div class="d-flex flex-column gap-2">
            <?php while ($ord = mysqli_fetch_assoc($qRecentOrders)): 
              $st = strtolower(trim($ord['status']));
              $badgeClass = 'bg-primary';
              if (in_array($st, ['siap di ambil', 'siap diambil', 'di antar', 'diantar'])) {
                  $badgeClass = 'bg-warning text-dark';
              }
              $noTagihan = !empty($ord['no_tagihan']) ? $ord['no_tagihan'] : ('INV-' . sprintf('%04d', $ord['id']));
            ?>
              <div class="recent-order-pill">
                <div>
                  <div class="fw-bold text-dark small"><?= htmlspecialchars($ord['nama_user']) ?></div>
                  <div class="text-muted" style="font-size: 0.76rem;">
                    <span class="badge bg-dark" style="font-size: 0.7rem;"><?= htmlspecialchars($noTagihan) ?></span> &bull; <?= htmlspecialchars($ord['nama_produk']) ?> (x<?= (int)$ord['qty'] ?>)
                  </div>
                </div>
                <div>
                  <span class="badge <?= $badgeClass ?> small"><?= htmlspecialchars($ord['status']) ?></span>
                </div>
              </div>
            <?php endwhile; ?>
          </div>
        <?php else: ?>
          <div class="text-center text-muted py-4">
            <i class="fas fa-check-circle fs-3 text-success mb-2 d-block"></i>
            <small>Semua pesanan saat ini telah diproses dengan rapi!</small>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // 1. Data Arus Kas & Volume Transaksi Bulanan
  const lunasData = <?= json_encode(array_values($monthlyLunas)) ?>;
  const dpData = <?= json_encode(array_values($monthlyDP)) ?>;
  const trxData = <?= json_encode(array_values($monthlyTrx)) ?>;
  const labelsMonth = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

  const ctxMonthly = document.getElementById('monthlyChart').getContext('2d');
  
  // Gradien untuk Mode Area
  const gradLunas = ctxMonthly.createLinearGradient(0, 0, 0, 300);
  gradLunas.addColorStop(0, 'rgba(14, 68, 48, 0.45)');
  gradLunas.addColorStop(1, 'rgba(14, 68, 48, 0.01)');

  const gradDP = ctxMonthly.createLinearGradient(0, 0, 0, 300);
  gradDP.addColorStop(0, 'rgba(245, 158, 11, 0.4)');
  gradDP.addColorStop(1, 'rgba(245, 158, 11, 0.01)');

  let monthlyChartInstance = new Chart(ctxMonthly, {
    type: 'bar',
    data: {
      labels: labelsMonth,
      datasets: [
        {
          type: 'bar',
          label: 'Pelunasan (Rp)',
          data: lunasData,
          backgroundColor: '#0e4430',
          borderColor: '#0e4430',
          borderWidth: 1,
          borderRadius: 6,
          yAxisID: 'y',
          order: 2
        },
        {
          type: 'bar',
          label: 'Uang Muka (DP)',
          data: dpData,
          backgroundColor: '#f59e0b',
          borderColor: '#d97706',
          borderWidth: 1,
          borderRadius: 6,
          yAxisID: 'y',
          order: 2
        },
        {
          type: 'line',
          label: 'Volume Transaksi',
          data: trxData,
          borderColor: '#2563eb',
          backgroundColor: '#2563eb',
          borderWidth: 3,
          tension: 0.35,
          pointRadius: 5,
          pointBackgroundColor: '#2563eb',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointHoverRadius: 7,
          yAxisID: 'y1',
          order: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false
      },
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            usePointStyle: true,
            boxWidth: 8,
            font: { size: 11, weight: '600' },
            color: '#334155'
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              if (context.dataset.yAxisID === 'y') {
                return ' ' + context.dataset.label + ': Rp ' + Number(context.raw).toLocaleString('id-ID');
              } else {
                return ' ' + context.dataset.label + ': ' + context.raw + ' Transaksi';
              }
            },
            footer: function(tooltipItems) {
              let revSum = 0;
              let trxCount = 0;
              tooltipItems.forEach(function(item) {
                if (item.dataset.yAxisID === 'y') {
                  revSum += Number(item.raw);
                } else {
                  trxCount = item.raw;
                }
              });
              return '💰 Total Omset: Rp ' + revSum.toLocaleString('id-ID') + ' (' + trxCount + ' Trx)';
            }
          }
        }
      },
      scales: {
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          beginAtZero: true,
          title: {
            display: true,
            text: 'Nominal (Rp)',
            color: '#0e4430',
            font: { size: 11, weight: '700' }
          },
          ticks: {
            callback: function(val) {
              return 'Rp ' + (val >= 1000000 ? (val / 1000000) + ' Jt' : (val >= 1000 ? (val / 1000) + ' Rb' : val));
            },
            color: '#64748b',
            font: { size: 10 }
          },
          grid: { color: '#f1f5f9' }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          beginAtZero: true,
          grid: { drawOnChartArea: false },
          title: {
            display: true,
            text: 'Jumlah Transaksi',
            color: '#2563eb',
            font: { size: 11, weight: '700' }
          },
          ticks: {
            precision: 0,
            callback: function(val) {
              return val + ' Trx';
            },
            color: '#2563eb',
            font: { size: 10, weight: '700' }
          }
        },
        x: {
          ticks: { color: '#64748b', font: { size: 11 } },
          grid: { display: false }
        }
      }
    }
  });

  function setChartType(type) {
    document.getElementById('btnTypeBar').classList.toggle('active', type === 'combo');
    document.getElementById('btnTypeLine').classList.toggle('active', type === 'area');

    if (type === 'combo') {
      monthlyChartInstance.data.datasets[0].type = 'bar';
      monthlyChartInstance.data.datasets[0].fill = false;
      monthlyChartInstance.data.datasets[0].backgroundColor = '#0e4430';
      monthlyChartInstance.data.datasets[0].borderColor = '#0e4430';
      monthlyChartInstance.data.datasets[0].borderRadius = 6;

      monthlyChartInstance.data.datasets[1].type = 'bar';
      monthlyChartInstance.data.datasets[1].fill = false;
      monthlyChartInstance.data.datasets[1].backgroundColor = '#f59e0b';
      monthlyChartInstance.data.datasets[1].borderColor = '#d97706';
      monthlyChartInstance.data.datasets[1].borderRadius = 6;

      monthlyChartInstance.data.datasets[2].hidden = false;
    } else {
      monthlyChartInstance.data.datasets[0].type = 'line';
      monthlyChartInstance.data.datasets[0].fill = true;
      monthlyChartInstance.data.datasets[0].backgroundColor = gradLunas;
      monthlyChartInstance.data.datasets[0].borderColor = '#0e4430';
      monthlyChartInstance.data.datasets[0].tension = 0.38;
      monthlyChartInstance.data.datasets[0].pointRadius = 4;
      monthlyChartInstance.data.datasets[0].pointBackgroundColor = '#0e4430';

      monthlyChartInstance.data.datasets[1].type = 'line';
      monthlyChartInstance.data.datasets[1].fill = true;
      monthlyChartInstance.data.datasets[1].backgroundColor = gradDP;
      monthlyChartInstance.data.datasets[1].borderColor = '#f59e0b';
      monthlyChartInstance.data.datasets[1].tension = 0.38;
      monthlyChartInstance.data.datasets[1].pointRadius = 4;
      monthlyChartInstance.data.datasets[1].pointBackgroundColor = '#f59e0b';

      monthlyChartInstance.data.datasets[2].hidden = false;
    }
    monthlyChartInstance.update();
  }

  // 2. Doughnut Chart Status Sewa
  const ctxStatus = document.getElementById('statusChart').getContext('2d');
  new Chart(ctxStatus, {
    type: 'doughnut',
    data: {
      labels: ['Menunggu Bayar', 'Siap/Antar', 'Berlangsung', 'Selesai', 'Dibatalkan'],
      datasets: [{
        data: [
          <?= $cntMenungguBayar ?>, 
          <?= $cntSiapAntar ?>, 
          <?= $cntBerlangsung ?>, 
          <?= $cntSelesai ?>, 
          <?= $cntDibatalkan ?>
        ],
        backgroundColor: [
          '#2563eb', // Menunggu
          '#f59e0b', // Siap/Antar
          '#10b981', // Berlangsung
          '#64748b', // Selesai
          '#ef4444'  // Dibatalkan
        ],
        borderWidth: 2,
        borderColor: '#ffffff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '72%',
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function(context) {
              return ' ' + context.label + ': ' + context.raw + ' Pesanan';
            }
          }
        }
      }
    }
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('status') === 'success') {
      Swal.fire({
        icon: 'success',
        title: 'Login Berhasil',
        text: 'Selamat datang kembali di Dashboard Semar Outdoor!',
        confirmButtonColor: '#0e4430'
      });
    }
  });
</script>
</body>
</html>
