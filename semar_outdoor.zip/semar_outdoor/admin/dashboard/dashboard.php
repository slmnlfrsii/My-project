<?php
session_start();
include '../../koneksi.php'; 
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

// Konfigurasi Nama Hari & Bulan dalam Bahasa Indonesia
$hariIndo = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu'
];
$bulanIndoSingkat = [
    1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'Mei', 6 => 'Jun',
    7 => 'Jul', 8 => 'Agu', 9 => 'Sep', 10 => 'Okt', 11 => 'Nov', 12 => 'Des'
];
$bulanIndoPanjang = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 5 => 'Mei', 6 => 'Juni',
    7 => 'Juli', 8 => 'Agustus', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

$namaHariIni = $hariIndo[date('l')] ?? date('l');
$namaBulanIni = $bulanIndoPanjang[(int)date('n')] ?? date('F');
$tanggalHariIni = $namaHariIni . ', ' . date('d') . ' ' . $namaBulanIni . ' ' . date('Y');

function formatTanggalIndo($tanggalStr) {
    global $bulanIndoSingkat;
    if (empty($tanggalStr)) return '-';
    $ts = strtotime($tanggalStr);
    if (!$ts) return '-';
    $tgl = date('d', $ts);
    $bln = $bulanIndoSingkat[(int)date('n', $ts)] ?? date('M', $ts);
    $thn = date('Y', $ts);
    return "$tgl $bln $thn";
}

// 1. Filter Tahun
$year = isset($_GET['tahun']) ? (int)$_GET['tahun'] : (int)date('Y');

// 2. Total Uang Masuk Tahun Terpilih
$queryUang = "SELECT SUM(jumlah_bayar) AS total_uang 
              FROM pembayaran 
              WHERE LOWER(TRIM(status)) IN ('lunas', 'belum lunas')
              AND YEAR(tanggal_bayar) = $year";
$resultUang = mysqli_query($conn, $queryUang);
$rowUang = mysqli_fetch_assoc($resultUang);
$totalUang = (float)($rowUang['total_uang'] ?? 0);

// 3. Data Keuangan Bulanan (Lunas, DP, & Total) + Jumlah Transaksi
$monthlyLunas = array_fill(1, 12, 0);
$monthlyDP = array_fill(1, 12, 0);
$monthlyTotal = array_fill(1, 12, 0);
$monthlyTrx = array_fill(1, 12, 0);

$queryBulanan = "SELECT 
                    MONTH(tanggal_bayar) AS bulan, 
                    SUM(CASE WHEN LOWER(TRIM(status)) = 'lunas' THEN jumlah_bayar ELSE 0 END) AS total_lunas,
                    SUM(CASE WHEN LOWER(TRIM(status)) = 'belum lunas' THEN jumlah_bayar ELSE 0 END) AS total_dp,
                    SUM(jumlah_bayar) AS total_gabungan,
                    COUNT(id) AS total_transaksi
                 FROM pembayaran 
                 WHERE LOWER(TRIM(status)) IN ('lunas', 'belum lunas')
                 AND YEAR(tanggal_bayar) = $year
                 GROUP BY MONTH(tanggal_bayar)";
$resultBulanan = mysqli_query($conn, $queryBulanan);
if ($resultBulanan) {
    while ($row = mysqli_fetch_assoc($resultBulanan)) {
        $bln = (int)$row['bulan'];
        $monthlyLunas[$bln] = (float)$row['total_lunas'];
        $monthlyDP[$bln] = (float)$row['total_dp'];
        $monthlyTotal[$bln] = (float)$row['total_gabungan'];
        $monthlyTrx[$bln] = (int)$row['total_transaksi'];
    }
}

// 4. Hitung Statistik Ringkasan Bulanan
$maxBulanVal = 0;
$maxBulanIdx = 1;
$sumBulan = 0;
$activeMonths = 0;
$totalLunasTahun = array_sum($monthlyLunas);
$totalDPTahun = array_sum($monthlyDP);
$totalTransaksiTahun = array_sum($monthlyTrx);

foreach ($monthlyTotal as $m => $v) {
    if ($v > $maxBulanVal) {
        $maxBulanVal = $v;
        $maxBulanIdx = $m;
    }
    if ($v > 0) {
        $sumBulan += $v;
        $activeMonths++;
    }
}
$avgBulan = ($activeMonths > 0) ? ($sumBulan / $activeMonths) : 0;

// 5. Daftar Tahun untuk Dropdown Filter (Multi-Tahun: Database + Rentang 5 Tahun)
$currentYear = (int)date('Y');
$years = [];

for ($y = $currentYear - 4; $y <= $currentYear + 1; $y++) {
    $years[] = $y;
}

$qYears = mysqli_query($conn, "
    SELECT DISTINCT YEAR(tanggal_bayar) AS tahun 
    FROM pembayaran 
    WHERE tanggal_bayar IS NOT NULL AND YEAR(tanggal_bayar) > 2000
    UNION
    SELECT DISTINCT YEAR(tanggal_buat) AS tahun
    FROM sewa
    WHERE tanggal_buat IS NOT NULL AND YEAR(tanggal_buat) > 2000
");
if ($qYears) {
    while ($y = mysqli_fetch_assoc($qYears)) {
        if (!empty($y['tahun'])) $years[] = (int)$y['tahun'];
    }
}
$years = array_unique($years);
rsort($years);

// 6. Distribusi Status Transaksi Sewa
$qStatusCount = mysqli_query($conn, "
    SELECT 
        COUNT(id) AS total_sewa_semua,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'menunggu pembayaran' THEN 1 ELSE 0 END) AS status_menunggu_bayar,
        SUM(CASE WHEN LOWER(TRIM(status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar') THEN 1 ELSE 0 END) AS status_siap_antar,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'berlangsung' THEN 1 ELSE 0 END) AS status_berlangsung,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'selesai' THEN 1 ELSE 0 END) AS status_selesai,
        SUM(CASE WHEN LOWER(TRIM(status)) = 'dibatalkan' THEN 1 ELSE 0 END) AS status_dibatalkan
    FROM sewa
");
$rowStatus = mysqli_fetch_assoc($qStatusCount) ?: [];
$totalSewaSemua = (int)($rowStatus['total_sewa_semua'] ?? 0);
$cntMenungguBayar = (int)($rowStatus['status_menunggu_bayar'] ?? 0);
$cntSiapAntar = (int)($rowStatus['status_siap_antar'] ?? 0);
$cntBerlangsung = (int)($rowStatus['status_berlangsung'] ?? 0);
$cntSelesai = (int)($rowStatus['status_selesai'] ?? 0);
$cntDibatalkan = (int)($rowStatus['status_dibatalkan'] ?? 0);
$totalSewaAktif = $cntSiapAntar + $cntBerlangsung;

// 7. Total Pengguna
$queryUser = "SELECT COUNT(id) AS total_user FROM users";
$resultUser = mysqli_query($conn, $queryUser);
$totalUser = (int)(mysqli_fetch_assoc($resultUser)['total_user'] ?? 0);

// 8. Total Alat & Stok
$qAlat = mysqli_query($conn, "
    SELECT 
        COUNT(id) AS total_jenis_alat,
        SUM(stok_awal) AS total_unit_stok,
        SUM(sisa_stok) AS total_unit_tersedia
    FROM alat
");
$rowAlat = mysqli_fetch_assoc($qAlat) ?: [];
$totalJenisAlat = (int)($rowAlat['total_jenis_alat'] ?? 0);
$totalUnitStok = (int)($rowAlat['total_unit_stok'] ?? 0);
$totalUnitTersedia = (int)($rowAlat['total_unit_tersedia'] ?? 0);
$unitTerpakai = max(0, $totalUnitStok - $totalUnitTersedia);
$persenStokTersedia = ($totalUnitStok > 0) ? round(($totalUnitTersedia / $totalUnitStok) * 100) : 0;

// 9. Top 5 Produk Paling Sering Disewa
$queryTopProduk = "
    SELECT 
        a.id,
        a.nama,
        a.gambar,
        a.stok_awal,
        a.sisa_stok,
        a.harga_per_hari,
        COALESCE(SUM(s.qty), 0) AS total_disewa
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat AND LOWER(TRIM(s.status)) != 'dibatalkan'
    GROUP BY a.id
    ORDER BY total_disewa DESC, a.id ASC
    LIMIT 5
";
$resultTopProduk = mysqli_query($conn, $queryTopProduk);

// 10. Transaksi Persewaan Terbaru (5 Transaksi Terkini)
$qRecentOrders = mysqli_query($conn, "
    SELECT s.*, u.nama AS nama_user
    FROM sewa s
    JOIN users u ON s.id_users = u.id
    ORDER BY s.id DESC
    LIMIT 5
");

// 11. Data Agenda Operasional Hari Ini & Peringatan
$todayDate = date('Y-m-d');
$qKonfirmasiBayar = mysqli_query($conn, "SELECT COUNT(id) AS total FROM pembayaran WHERE LOWER(TRIM(status)) = 'menunggu konfirmasi'");
$cntKonfirmasiBayar = (int)(mysqli_fetch_assoc($qKonfirmasiBayar)['total'] ?? 0);

$qStokKritis = mysqli_query($conn, "SELECT COUNT(id) AS total FROM alat WHERE sisa_stok <= 2");
$cntStokKritis = (int)(mysqli_fetch_assoc($qStokKritis)['total'] ?? 0);

$qOmsetHariIni = mysqli_query($conn, "
    SELECT COALESCE(SUM(jumlah_bayar), 0) AS omset, COUNT(id) AS total_trx 
    FROM pembayaran 
    WHERE DATE(tanggal_bayar) = '$todayDate' AND LOWER(TRIM(status)) IN ('lunas', 'belum lunas')
");
$rowOmsetHariIni = mysqli_fetch_assoc($qOmsetHariIni) ?: [];
$omsetHariIni = (float)($rowOmsetHariIni['omset'] ?? 0);
$trxHariIni = (int)($rowOmsetHariIni['total_trx'] ?? 0);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Dashboard Admin - Semar Outdoor</title>
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  
  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    body {
      background-color: var(--bg-body);
      font-family: 'Plus Jakarta Sans', sans-serif;
      color: var(--text-main);
      font-size: 0.84rem;
      min-height: 100vh;
      overflow-x: hidden;
    }

    /* Banner Sambutan (Elegan & Rapi) */
    .welcome-banner {
      background: linear-gradient(135deg, #12282a 0%, #162d2f 50%, #0e4430 100%);
      border-radius: 12px;
      color: #ffffff;
      padding: 20px 18px;
      box-shadow: 0 4px 16px rgba(18, 40, 42, 0.12);
      position: relative;
      overflow: hidden;
      margin-bottom: 22px;
    }

    .welcome-banner::after {
      content: "";
      position: absolute;
      top: -40px;
      right: -40px;
      width: 140px;
      height: 140px;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.15) 0%, transparent 70%);
      border-radius: 50%;
      pointer-events: none;
    }

    .welcome-title {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.15rem;
      font-weight: 700;
      letter-spacing: -0.2px;
      margin-bottom: 2px;
    }

    .welcome-subtitle {
      color: #cbd5e1;
      font-size: 0.78rem;
      margin: 0;
      line-height: 1.35;
    }

    /* Kartu Ringkasan KPI (Gaya Bersih & Minimalis) */
    .kpi-card {
      background: #ffffff;
      border-radius: 10px;
      padding: 12px 14px;
      border: 1px solid #e2e8f0;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
      transition: all 0.2s ease;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .kpi-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
      border-color: #cbd5e1;
    }

    .kpi-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 6px;
    }

    .kpi-label {
      font-size: 0.68rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      color: var(--text-muted);
      margin: 0;
    }

    .kpi-icon-wrap {
      width: 32px;
      height: 32px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.92rem;
    }

    .kpi-icon-wrap.green { background: rgba(14, 68, 48, 0.1); color: #0e4430; }
    .kpi-icon-wrap.gold { background: rgba(194, 120, 3, 0.1); color: #c27803; }
    .kpi-icon-wrap.blue { background: rgba(37, 99, 235, 0.1); color: #2563eb; }
    .kpi-icon-wrap.purple { background: rgba(124, 58, 237, 0.1); color: #7c3aed; }

    .kpi-value {
      font-size: 1.20rem;
      font-weight: 800;
      color: var(--brand-dark);
      margin-bottom: 2px;
      line-height: 1.2;
    }

    .kpi-footer {
      font-size: 0.68rem;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 4px;
      margin-top: 3px;
    }

    /* Kartu Konten Utama */
    .dashboard-card {
      background: #ffffff;
      border-radius: 10px;
      border: 1px solid #e2e8f0;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
      padding: 14px 16px;
      height: 100%;
    }

    .card-head-title {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 12px;
      padding-bottom: 6px;
      border-bottom: 1px solid #f1f5f9;
    }

    .card-head-title h5 {
      font-size: 0.86rem;
      font-weight: 700;
      color: var(--brand-dark);
      margin: 0;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    /* Titik Indikator Status */
    .status-indicator {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      display: inline-block;
    }

    /* Pengubah Tipe Grafik & Ringkasan Mini */
    .chart-type-pill {
      background: #f1f5f9;
      border-radius: 50px;
      padding: 2px;
      display: inline-flex;
      gap: 2px;
    }

    .btn-chart-type {
      border: none;
      background: transparent;
      padding: 3px 8px;
      font-size: 0.70rem;
      font-weight: 700;
      color: var(--text-muted);
      border-radius: 50px;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-chart-type.active {
      background: #ffffff;
      color: var(--brand-dark);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
    }

    .chart-mini-stat {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 5px 8px;
      transition: all 0.2s ease;
    }

    .chart-mini-stat:hover {
      background: #ffffff;
      border-color: #cbd5e1;
    }

    .hover-task-item {
      transition: all 0.2s ease;
    }

    .hover-task-item:hover {
      background-color: #ffffff !important;
      border-color: #cbd5e1 !important;
      transform: translateX(3px);
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }
  </style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
  <!-- 1. Banner Sambutan Atas -->
  <div class="welcome-banner d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3 mb-5">
    <div>
      <h1 class="welcome-title">Selamat Datang di Panel Admin Semar Outdoor!</h1>
      <p class="welcome-subtitle">Pantau performa persewaan, kelola stok alat rental, dan verifikasi pembayaran pelanggan secara real-time.</p>
    </div>

    <div class="d-flex align-items-center gap-2 flex-shrink-0">
      <div class="d-inline-flex align-items-center px-3 py-2.5 rounded-pill bg-white bg-opacity-10 text-warning fw-semibold border border-white border-opacity-10 shadow-sm" style="font-size: 0.90rem;">
        <i class="fas fa-calendar-alt me-2"></i>
        <span><?= $tanggalHariIni ?></span>
      </div>
    </div>
  </div>

  <!-- 2. Ringkasan 4 Kartu KPI Utama -->
  <div class="row g-2.5 mb-4">
    <!-- KPI 1: Pendapatan -->
    <div class="col-xl-3 col-sm-6">
      <div class="kpi-card">
        <div class="kpi-header">
          <span class="kpi-label">Total Pendapatan / Omset (<?= $year ?>)</span>
          <div class="kpi-icon-wrap green">
            <i class="fas fa-wallet"></i>
          </div>
        </div>
        <div class="kpi-value text-success">
          Rp<?= number_format($totalUang, 0, ',', '.') ?>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-check-circle text-success"></i>
          <span>Total transaksi terbayar (Lunas / DP)</span>
        </div>
      </div>
    </div>

    <!-- KPI 2: Sewa Sedang Berjalan -->
    <div class="col-xl-3 col-sm-6">
      <div class="kpi-card">
        <div class="kpi-header">
          <span class="kpi-label">Sewa Sedang Berjalan</span>
          <div class="kpi-icon-wrap gold">
            <i class="fas fa-calendar-check"></i>
          </div>
        </div>
        <div class="kpi-value text-warning">
          <?= $totalSewaAktif ?> <span class="fw-normal text-muted" style="font-size: 0.75rem;">Pesanan Aktif</span>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-clock text-warning"></i>
          <span><?= $cntSiapAntar ?> Siap Ambil / Antar &bull; <?= $cntBerlangsung ?> Sedang Disewa</span>
        </div>
      </div>
    </div>

    <!-- KPI 3: Kapasitas Stok Alat Rental -->
    <div class="col-xl-3 col-sm-6">
      <div class="kpi-card">
        <div class="kpi-header">
          <span class="kpi-label">Ketersediaan Stok Alat Rental</span>
          <div class="kpi-icon-wrap blue">
            <i class="fas fa-campground"></i>
          </div>
        </div>
        <div class="kpi-value text-primary">
          <?= $totalUnitTersedia ?> <span class="fw-normal text-muted" style="font-size: 0.75rem;">/ <?= $totalUnitStok ?> Unit</span>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-box-open text-primary"></i>
          <span><?= $persenStokTersedia ?>% Unit siap sewa (<?= $totalJenisAlat ?> Jenis Alat)</span>
        </div>
      </div>
    </div>

    <!-- KPI 4: Total Pelanggan -->
    <div class="col-xl-3 col-sm-6">
      <div class="kpi-card">
        <div class="kpi-header">
          <span class="kpi-label">Total Pelanggan Terdaftar</span>
          <div class="kpi-icon-wrap purple">
            <i class="fas fa-users"></i>
          </div>
        </div>
        <div class="kpi-value text-dark">
          <?= $totalUser ?> <span class="fw-normal text-muted" style="font-size: 0.75rem;">Akun Penyewa</span>
        </div>
        <div class="kpi-footer">
          <i class="fas fa-user-check text-secondary"></i>
          <span>Pelanggan terdaftar di sistem</span>
        </div>
      </div>
    </div>
  </div>

  <!-- 3. Bagian Grafik Laporan Arus Kas & Status Persewaan -->
  <div class="row g-3 mb-3">
    <!-- Grafik Pendapatan & Transaksi Bulanan -->
    <div class="col-lg-8">
      <div class="dashboard-card">
        <div class="card-head-title flex-wrap gap-2">
          <div>
            <h5><i class="fas fa-chart-line text-success me-1"></i> Arus Kas & Volume Transaksi</h5>
            <small class="text-muted" style="font-size: 0.72rem;">Grafik performa pendapatan persewaan dan jumlah transaksi tahun <?= $year ?>.</small>
          </div>

          <div class="d-flex align-items-center gap-2">
            <!-- Pilihan Mode Grafik -->
            <div class="chart-type-pill">
              <button type="button" class="btn-chart-type active" id="btnTypeBar" onclick="setChartType('combo')">
                <i class="fas fa-chart-column me-1"></i> Diagram Batang
              </button>
              <button type="button" class="btn-chart-type" id="btnTypeLine" onclick="setChartType('area')">
                <i class="fas fa-chart-area me-1"></i> Diagram Area
              </button>
            </div>

            <!-- Filter Tahun -->
            <form method="GET" class="d-flex align-items-center m-0 ms-1">
              <select name="tahun" class="form-select form-select-sm fw-bold text-dark border-secondary-subtle bg-white shadow-sm" style="font-size: 0.76rem; width: auto; min-width: 135px; padding: 5px 36px 5px 12px; cursor: pointer; border-radius: 6px;" onchange="this.form.submit()">
                <?php foreach ($years as $thn): ?>
                  <option value="<?= $thn ?>" <?= ($year == $thn) ? 'selected' : '' ?>>
                    Tahun <?= $thn ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </form>
          </div>
        </div>

        <!-- 4 Highlight Statistik Mini -->
        <div class="row g-1.5 mb-2.5">
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.65rem; font-weight: 700;">PELUNASAN</span>
              <strong class="text-success" style="font-size: 0.80rem;">Rp<?= number_format($totalLunasTahun, 0, ',', '.') ?></strong>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.65rem; font-weight: 700;">UANG MUKA (DP)</span>
              <strong class="text-warning" style="font-size: 0.80rem;">Rp<?= number_format($totalDPTahun, 0, ',', '.') ?></strong>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.65rem; font-weight: 700;">TOTAL TRANSAKSI</span>
              <strong class="text-primary" style="font-size: 0.80rem;"><?= $totalTransaksiTahun ?> Pesanan</strong>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="chart-mini-stat text-center">
              <span class="text-muted d-block" style="font-size: 0.65rem; font-weight: 700;">TOTAL OMSET</span>
              <strong class="text-dark" style="font-size: 0.80rem;">Rp<?= number_format($totalUang, 0, ',', '.') ?></strong>
            </div>
          </div>
        </div>

        <div style="height: 220px; position: relative;">
          <canvas id="monthlyChart"></canvas>
        </div>

        <div class="row g-2 mt-2 pt-2 border-top text-center text-sm-start text-muted" style="font-size: 0.72rem;">
          <div class="col-sm-6">
            <span><i class="fas fa-trophy text-warning me-1"></i> Puncak Omset (<?= $namaBulanPanjang = $bulanIndoPanjang[$maxBulanIdx] ?? '-' ?>): <strong class="text-success">Rp<?= number_format($maxBulanVal, 0, ',', '.') ?></strong></span>
          </div>
          <div class="col-sm-6 text-sm-end">
            <span><i class="fas fa-calculator text-primary me-1"></i> Rata-Rata Bulanan: <strong class="text-dark">Rp<?= number_format($avgBulan, 0, ',', '.') ?></strong></span>
          </div>
        </div>
      </div>
    </div>

    <!-- Agenda & Antrean Tugas Operasional -->
    <div class="col-lg-4">
      <div class="dashboard-card d-flex flex-column justify-content-between">
        <div>
          <div class="card-head-title mb-2">
            <h5><i class="fas fa-clipboard-check text-warning me-1"></i> Agenda & Tugas Operasional</h5>
            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25" style="font-size: 0.66rem;">
              <i class="fas fa-circle text-success me-1" style="font-size: 0.45rem;"></i> Real-Time
            </span>
          </div>

          <div class="d-flex flex-column gap-1.5 mb-2.5" style="font-size: 0.74rem;">
            <!-- Tugas 1: Verifikasi Pembayaran Masuk -->
            <a href="../pembayaran/pembayaran.php" class="d-flex justify-content-between align-items-center p-2 rounded bg-light border text-decoration-none hover-task-item">
              <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle d-flex align-items-center justify-content-center bg-warning bg-opacity-15 text-warning" style="width: 28px; height: 28px; font-size: 0.75rem;">
                  <i class="fas fa-receipt"></i>
                </div>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 0.76rem;">Verifikasi Pembayaran</div>
                  <div class="text-muted" style="font-size: 0.67rem;">Konfirmasi bukti transfer penyewa</div>
                </div>
              </div>
              <div>
                <span class="badge <?= $cntKonfirmasiBayar > 0 ? 'bg-warning text-dark' : 'bg-secondary bg-opacity-25 text-secondary' ?> rounded-pill px-2" style="font-size: 0.65rem;">
                  <?= $cntKonfirmasiBayar ?> Antrean
                </span>
              </div>
            </a>

            <!-- Tugas 2: Penyerahan Alat (Siap Ambil / Antar) -->
            <a href="../sewa/sewa.php" class="d-flex justify-content-between align-items-center p-2 rounded bg-light border text-decoration-none hover-task-item">
              <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle d-flex align-items-center justify-content-center bg-primary bg-opacity-15 text-primary" style="width: 28px; height: 28px; font-size: 0.75rem;">
                  <i class="fas fa-truck-ramp-box"></i>
                </div>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 0.76rem;">Siap Diambil / Diantar</div>
                  <div class="text-muted" style="font-size: 0.67rem;">Unit siap diserahkan ke pelanggan</div>
                </div>
              </div>
              <div>
                <span class="badge <?= $cntSiapAntar > 0 ? 'bg-primary' : 'bg-secondary bg-opacity-25 text-secondary' ?> rounded-pill px-2" style="font-size: 0.65rem;">
                  <?= $cntSiapAntar ?> Pesanan
                </span>
              </div>
            </a>

            <!-- Tugas 3: Pengembalian Unit Sedang Disewa -->
            <a href="../pengembalian/pengembalian.php" class="d-flex justify-content-between align-items-center p-2 rounded bg-light border text-decoration-none hover-task-item">
              <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle d-flex align-items-center justify-content-center bg-success bg-opacity-15 text-success" style="width: 28px; height: 28px; font-size: 0.75rem;">
                  <i class="fas fa-undo-alt"></i>
                </div>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 0.76rem;">Jadwal Pengembalian Unit</div>
                  <div class="text-muted" style="font-size: 0.67rem;">Unit sedang aktif disewa di lapangan</div>
                </div>
              </div>
              <div>
                <span class="badge <?= $cntBerlangsung > 0 ? 'bg-success' : 'bg-secondary bg-opacity-25 text-secondary' ?> rounded-pill px-2" style="font-size: 0.65rem;">
                  <?= $cntBerlangsung ?> Disewa
                </span>
              </div>
            </a>

            <!-- Tugas 4: Peringatan Stok Menipis -->
            <a href="../alat/list_alat.php" class="d-flex justify-content-between align-items-center p-2 rounded bg-light border text-decoration-none hover-task-item">
              <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle d-flex align-items-center justify-content-center bg-danger bg-opacity-15 text-danger" style="width: 28px; height: 28px; font-size: 0.75rem;">
                  <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                  <div class="fw-bold text-dark" style="font-size: 0.76rem;">Peringatan Stok Menipis</div>
                  <div class="text-muted" style="font-size: 0.67rem;">Alat dengan sisa stok &le; 2 unit</div>
                </div>
              </div>
              <div>
                <span class="badge <?= $cntStokKritis > 0 ? 'bg-danger' : 'bg-secondary bg-opacity-25 text-secondary' ?> rounded-pill px-2" style="font-size: 0.65rem;">
                  <?= $cntStokKritis ?> Alat
                </span>
              </div>
            </a>
          </div>
        </div>

        <!-- Ringkasan Arus Kas Masuk Hari Ini -->
        <div class="p-2.5 rounded bg-light border" style="font-size: 0.74rem;">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <span class="fw-bold text-dark"><i class="fas fa-cash-register text-success me-1"></i> Arus Kas Masuk Hari Ini</span>
            <strong class="text-success" style="font-size: 0.82rem;">Rp<?= number_format($omsetHariIni, 0, ',', '.') ?></strong>
          </div>
          <div class="d-flex justify-content-between text-muted mt-1" style="font-size: 0.68rem;">
            <span>Transaksi Hari Ini: <strong class="text-dark"><?= $trxHariIni ?> Transaksi</strong></span>
            <span>Unit di Lapangan: <strong class="text-primary"><?= $unitTerpakai ?> Unit</strong></span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 4. Bagian Bawah: Top 5 Alat Terlaris & 5 Riwayat Persewaan Terbaru -->
  <div class="row g-3">
    <!-- 5 Alat Paling Sering Disewa -->
    <div class="col-lg-6">
      <div class="dashboard-card">
        <div class="card-head-title">
          <h5><i class="fas fa-fire text-danger me-1"></i> 5 Alat Paling Sering Disewa</h5>
          <a href="../alat/list_alat.php" class="btn btn-link btn-sm text-decoration-none p-0 fw-bold" style="font-size: 0.74rem;">Kelola Semua Alat &rarr;</a>
        </div>

        <div class="d-flex flex-column gap-1.5">
          <?php 
          $rank = 1;
          if ($resultTopProduk && mysqli_num_rows($resultTopProduk) > 0): 
            while ($tp = mysqli_fetch_assoc($resultTopProduk)): 
              $totalDisewa = (int)$tp['total_disewa'];
              $imgAlat = !empty($tp['gambar']) ? '../uploads/alat/' . $tp['gambar'] : '../../assets/images/tenda.jpg';
          ?>
            <div class="d-flex align-items-center justify-content-between p-2 rounded bg-light border">
              <div class="d-flex align-items-center gap-2.5">
                <span class="badge bg-dark rounded-circle" style="width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 0.65rem;"><?= $rank++ ?></span>
                <img src="<?= htmlspecialchars($imgAlat) ?>" alt="produk" style="width: 32px; height: 32px; border-radius: 6px; object-fit: cover;" class="border">
                <div>
                  <div class="fw-bold text-dark" style="font-size: 0.78rem;"><?= htmlspecialchars($tp['nama']) ?></div>
                  <div class="text-muted" style="font-size: 0.70rem;">Harga: Rp<?= number_format($tp['harga_per_hari'], 0, ',', '.') ?> / hari</div>
                </div>
              </div>
              <div class="text-end">
                <span class="badge bg-success bg-opacity-15 text-success border border-success border-opacity-25 fw-bold" style="font-size: 0.70rem;"><?= $totalDisewa ?>x Disewa</span>
                <div class="text-muted" style="font-size: 0.68rem;">Tersedia: <strong class="<?= $tp['sisa_stok'] > 0 ? 'text-success' : 'text-danger' ?>"><?= $tp['sisa_stok'] ?> unit</strong></div>
              </div>
            </div>
          <?php 
            endwhile; 
          else: 
          ?>
            <p class="text-muted text-center my-3 small">Belum ada data penyewaan alat.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- 5 Riwayat Persewaan Terbaru -->
    <div class="col-lg-6">
      <div class="dashboard-card">
        <div class="card-head-title">
          <h5><i class="fas fa-clock text-primary me-1"></i> 5 Riwayat Persewaan Terbaru</h5>
          <a href="../riwayat/riwayat.php" class="btn btn-link btn-sm text-decoration-none p-0 fw-bold" style="font-size: 0.74rem;">Lihat Semua Riwayat &rarr;</a>
        </div>

        <?php if ($qRecentOrders && mysqli_num_rows($qRecentOrders) > 0): ?>
          <div class="d-flex flex-column gap-1.5">
            <?php while ($ord = mysqli_fetch_assoc($qRecentOrders)): 
              $st = strtolower(trim($ord['status']));
              $badgeClass = 'bg-primary';
              $displayStatus = 'Menunggu Pembayaran';

              if (in_array($st, ['siap di ambil', 'siap diambil', 'di antar', 'diantar'])) {
                  $badgeClass = 'bg-warning text-dark';
                  $displayStatus = 'Siap Diambil / Diantar';
              } elseif ($st == 'berlangsung') {
                  $badgeClass = 'bg-success';
                  $displayStatus = 'Sedang Disewa';
              } elseif ($st == 'selesai') {
                  $badgeClass = 'bg-secondary';
                  $displayStatus = 'Selesai / Kembali';
              } elseif ($st == 'dibatalkan') {
                  $badgeClass = 'bg-danger';
                  $displayStatus = 'Dibatalkan';
              }
              $noTagihan = !empty($ord['no_tagihan']) ? $ord['no_tagihan'] : ('INV-' . sprintf('%04d', $ord['id']));
              $tglSewaIndo = formatTanggalIndo($ord['tanggal_sewa']);
            ?>
              <div class="d-flex align-items-center justify-content-between p-2 rounded bg-light border">
                <div>
                  <div class="fw-bold text-dark" style="font-size: 0.78rem;">
                    <?= htmlspecialchars($ord['nama_user']) ?>
                    <span class="badge bg-white text-secondary border ms-1 py-0.5 px-1.5 fw-medium" style="font-size: 0.58rem; letter-spacing: 0.2px;">#<?= htmlspecialchars($noTagihan) ?></span>
                  </div>
                  <div class="text-muted" style="font-size: 0.70rem;">
                    <?= htmlspecialchars($ord['nama_produk']) ?> &bull; <?= $ord['durasi'] ?> Hari Sewa (Tanggal: <?= $tglSewaIndo ?>)
                  </div>
                </div>
                <div>
                  <span class="badge <?= $badgeClass ?>" style="font-size: 0.67rem;"><?= htmlspecialchars($displayStatus) ?></span>
                </div>
              </div>
            <?php endwhile; ?>
          </div>
        <?php else: ?>
          <div class="text-center text-muted py-3">
            <i class="fas fa-check-circle fs-4 text-success mb-1.5 d-block"></i>
            <small style="font-size: 0.75rem;">Belum ada riwayat transaksi persewaan.</small>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // 1. Data Arus Kas & Volume Transaksi Bulanan
  const lunasData = <?= json_encode(array_values($monthlyLunas)) ?>;
  const dpData = <?= json_encode(array_values($monthlyDP)) ?>;
  const trxData = <?= json_encode(array_values($monthlyTrx)) ?>;
  const labelsMonth = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

  const ctxMonthly = document.getElementById('monthlyChart').getContext('2d');
  
  // Gradien untuk Mode Area
  const gradLunas = ctxMonthly.createLinearGradient(0, 0, 0, 300);
  gradLunas.addColorStop(0, 'rgba(14, 68, 48, 0.45)');
  gradLunas.addColorStop(1, 'rgba(14, 68, 48, 0.01)');

  const gradDP = ctxMonthly.createLinearGradient(0, 0, 0, 300);
  gradDP.addColorStop(0, 'rgba(245, 158, 11, 0.4)');
  gradDP.addColorStop(1, 'rgba(245, 158, 11, 0.01)');

  let monthlyChartInstance = new Chart(ctxMonthly, {
    type: 'bar',
    data: {
      labels: labelsMonth,
      datasets: [
        {
          type: 'bar',
          label: 'Pelunasan (Rp)',
          data: lunasData,
          backgroundColor: '#0e4430',
          borderColor: '#0e4430',
          borderWidth: 1,
          borderRadius: 6,
          yAxisID: 'y',
          order: 2
        },
        {
          type: 'bar',
          label: 'Uang Muka (DP)',
          data: dpData,
          backgroundColor: '#f59e0b',
          borderColor: '#d97706',
          borderWidth: 1,
          borderRadius: 6,
          yAxisID: 'y',
          order: 2
        },
        {
          type: 'line',
          label: 'Jumlah Transaksi',
          data: trxData,
          borderColor: '#2563eb',
          backgroundColor: '#2563eb',
          borderWidth: 3,
          tension: 0.35,
          pointRadius: 5,
          pointBackgroundColor: '#2563eb',
          pointBorderColor: '#ffffff',
          pointBorderWidth: 2,
          pointHoverRadius: 7,
          yAxisID: 'y1',
          order: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: { usePointStyle: true, boxWidth: 8, font: { size: 11, weight: '600' }, color: '#334155' }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return context.dataset.yAxisID === 'y' 
                ? ' ' + context.dataset.label + ': Rp ' + Number(context.raw).toLocaleString('id-ID') 
                : ' ' + context.dataset.label + ': ' + context.raw + ' Transaksi';
            },
            footer: function(tooltipItems) {
              let revSum = 0;
              let trxCount = 0;
              tooltipItems.forEach(function(item) {
                if (item.dataset.yAxisID === 'y') {
                  revSum += Number(item.raw);
                } else {
                  trxCount = item.raw;
                }
              });
              return '💰 Total Omset: Rp ' + revSum.toLocaleString('id-ID') + ' (' + trxCount + ' Transaksi)';
            }
          }
        }
      },
      scales: {
        y: { 
          type: 'linear', 
          display: true, 
          position: 'left', 
          beginAtZero: true, 
          title: {
            display: true,
            text: 'Nominal (Rp)',
            color: '#0e4430',
            font: { size: 11, weight: '700' }
          },
          grid: { color: '#f1f5f9' }, 
          ticks: { 
            callback: function(val) {
              return 'Rp ' + (val >= 1000000 ? (val / 1000000) + ' Jt' : (val >= 1000 ? (val / 1000) + ' Rb' : val));
            },
            color: '#64748b', 
            font: { size: 10 } 
          } 
        },
        y1: { 
          type: 'linear', 
          display: true, 
          position: 'right', 
          beginAtZero: true, 
          grid: { drawOnChartArea: false }, 
          title: {
            display: true,
            text: 'Jumlah Transaksi',
            color: '#2563eb',
            font: { size: 11, weight: '700' }
          },
          ticks: { 
            precision: 0, 
            callback: function(val) {
              return val + ' Trx';
            },
            color: '#2563eb', 
            font: { size: 10, weight: '700' } 
          } 
        },
        x: { ticks: { color: '#64748b', font: { size: 11 } }, grid: { display: false } }
      }
    }
  });

  function setChartType(type) {
    document.getElementById('btnTypeBar').classList.toggle('active', type === 'combo');
    document.getElementById('btnTypeLine').classList.toggle('active', type === 'area');

    if (type === 'combo') {
      monthlyChartInstance.data.datasets[0].type = 'bar';
      monthlyChartInstance.data.datasets[0].backgroundColor = '#0e4430';
      monthlyChartInstance.data.datasets[1].type = 'bar';
      monthlyChartInstance.data.datasets[1].backgroundColor = '#f59e0b';
    } else {
      monthlyChartInstance.data.datasets[0].type = 'line';
      monthlyChartInstance.data.datasets[0].fill = true;
      monthlyChartInstance.data.datasets[0].backgroundColor = gradLunas;
      monthlyChartInstance.data.datasets[1].type = 'line';
      monthlyChartInstance.data.datasets[1].fill = true;
      monthlyChartInstance.data.datasets[1].backgroundColor = gradDP;
    }
    monthlyChartInstance.update();
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('status') === 'success') {
      Swal.fire({
        icon: 'success',
        title: 'Login Berhasil',
        text: 'Selamat datang kembali di Dashboard Semar Outdoor!',
        confirmButtonColor: '#0e4430'
      });
    }
  });
</script>
</body>
</html>
