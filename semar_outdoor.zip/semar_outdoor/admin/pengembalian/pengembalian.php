<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

/* =========================================================================
   [FIFO / INVOICE GROUPING] QUERY & PENGELOMPOKAN DATA PENGEMBALIAN PER INVOICE
   ========================================================================= */
$sewaSelesaiQuery = $conn->query("
  SELECT sewa.*, users.nama, users.email, 
         COALESCE(alat.harga_per_hari, sewa.total_harga) AS harga_satuan_alat,
         alat.harga_per_hari AS harga_per_hari_alat
  FROM sewa 
  JOIN users ON sewa.id_users = users.id 
  LEFT JOIN alat ON sewa.id_alat = alat.id
  WHERE status = 'selesai'
  ORDER BY COALESCE(sewa.tanggal_dikembalikan, sewa.tanggal_buat) DESC, sewa.id DESC
");

$groupedSelesai = [];
if ($sewaSelesaiQuery && $sewaSelesaiQuery->num_rows > 0) {
    while ($r = $sewaSelesaiQuery->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)($r['harga_per_hari_alat'] ?? $r['harga_satuan_alat'] ?? $r['total_harga']);
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['harga_satuan_val'] = $harga_satuan;
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $r['gambar_path'] = !empty($r['gambar']) ? "../uploads/alat/" . $r['gambar'] : "../../assets/images/no-image.png";
        $groupedSelesai[$noTag][] = $r;
    }
}

$sewaSelesaiList = [];
foreach ($groupedSelesai as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $product_names = [];
    $item_ids = [];

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $product_names[] = $it['nama_produk'] . ' (x' . $it['qty'] . ')';
        $item_ids[] = (int)$it['id'];
    }

    $tgl_kembali = !empty($primary['tanggal_dikembalikan']) ? date('d M Y, H:i', strtotime($primary['tanggal_dikembalikan'])) : '-';

    $sewaSelesaiList[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'item_ids' => $item_ids,
        'id_users' => $primary['id_users'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => $primary['status'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'tanggal_buat' => $primary['tanggal_buat'],
        'tanggal_dikembalikan' => $tgl_kembali,
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'items_count' => count($items),
        'nama_produk_list' => implode(', ', $product_names),
        'items' => $items
    ];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Pengembalian Alat - Admin Semar Outdoor</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body { background: #f8f9fa; }
    .badge-status {
      text-transform: capitalize;
      font-size: 0.85rem;
      padding: 0.35em 0.6em;
    }
    table {
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(32, 27, 27, 0.05);
    }
    th, td {
      vertical-align: middle !important;
    }
    .img-thumb {
      width: 45px;
      height: 40px;
      object-fit: cover;
      border-radius: 6px;
    }
    .aksi-btn {
      display: flex;
      gap: 5px;
      align-items: center;
      justify-content: center;
      flex-wrap: nowrap;
      white-space: nowrap;
    }
    .modal-section-title {
      font-size: 0.85rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #495057;
      border-bottom: 2px solid #e9ecef;
      padding-bottom: 5px;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
<?php include '../sidebar.php'; ?>

<div class="main-content">
  <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-3">
    <div>
      <h3 class="fw-bold mb-0"><i class="fas fa-undo-alt me-2 text-success"></i>Data Pengembalian Alat</h3>
      <p class="text-muted small mb-0">Daftar transaksi penyewaan yang telah selesai dan dikembalikan ke toko.</p>
    </div>

    <div style="max-width: 320px; width: 100%;">
      <input type="text" id="liveSearchPengembalian" class="form-control"
             placeholder="Cari nama / no. tagihan / alat...">
    </div>
  </div>

  <?php if (!empty($_SESSION['flash_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <?php if (count($sewaSelesaiList) > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered table-hover bg-white align-middle" id="tabelPengembalian">
        <thead class="table-secondary text-center">
          <tr>
            <th style="width: 50px;">No</th>
            <th style="width: 150px;">No. Tagihan</th>
            <th>Penyewa</th>
            <th>Alat Disewa</th>
            <th style="width: 130px;">Total Biaya</th>
            <th style="width: 170px;">Status & Pengembalian</th>
            <th style="width: 130px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php 
          $no = 1; 
          foreach ($sewaSelesaiList as $row): 
          ?>
          <tr>
            <td class="text-center fw-bold"><?= $no++; ?></td>
            <td><span class="badge bg-dark"><?= htmlspecialchars($row['no_tagihan']); ?></span></td>
            <td>
              <strong><?= htmlspecialchars($row['nama']); ?></strong><br>
              <small class="text-muted"><?= htmlspecialchars($row['email']); ?></small>
            </td>
            <td>
              <div class="d-flex flex-column gap-2">
                <?php foreach ($row['items'] as $itemAlat): ?>
                  <div class="d-flex align-items-center gap-2">
                    <img src="<?= htmlspecialchars($itemAlat['gambar_path']); ?>" alt="alat" class="img-thumb border flex-shrink-0">
                    <div>
                      <div class="fw-semibold text-dark small"><?= htmlspecialchars($itemAlat['nama_produk']); ?></div>
                      <small class="text-muted"><span class="badge bg-light text-dark border">x<?= (int)$itemAlat['qty']; ?></span> &bull; Rp<?= number_format($itemAlat['harga_satuan_val'], 0, ',', '.'); ?>/hari</small>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </td>
            <td>
              <div class="fw-bold text-success">
                Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?>
              </div>
              <small class="text-muted d-block"><?= $row['total_qty']; ?> unit &bull; <?= $row['durasi']; ?> hari</small>
            </td>
            <td>
              <span class="badge bg-success badge-status"><i class="fas fa-check-circle me-1"></i><?= htmlspecialchars($row['status']); ?></span>
              <div class="small text-muted mt-1">
                <i class="fas fa-clock me-1 text-secondary"></i><?= htmlspecialchars($row['tanggal_dikembalikan']); ?>
              </div>
            </td>
            <td class="text-center">
              <div class="aksi-btn">
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editStatusModal" 
                        data-id="<?= (int)$row['primary_id']; ?>" data-status="<?= htmlspecialchars($row['status']); ?>" title="Edit Status">
                  <i class="fa fa-edit"></i>
                </button>
                <button 
                  class="btn btn-sm btn-outline-primary lihat-detail-btn" 
                  data-bs-toggle="modal" 
                  data-bs-target="#detailModal"
                  data-invoice='<?= json_encode($row, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'
                  title="Lihat Detail Transaksi"
                >
                  <i class="fas fa-info-circle"></i>
                </button>
                <form method="POST" action="aksi_pengembalian.php" onsubmit="return confirm('Hapus seluruh data invoice pengembalian ini?')" style="display:inline;">
                  <input type="hidden" name="id" value="<?= (int)$row['primary_id']; ?>">
                  <input type="hidden" name="tabel" value="sewa">
                  <button class="btn btn-sm btn-danger" type="submit" name="hapus" title="Hapus Data"><i class="fa fa-trash"></i></button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-info text-center mt-3">
      <i class="fas fa-info-circle me-1"></i> Belum ada data penyewaan yang berstatus selesai dikembalikan.
    </div>
  <?php endif; ?>
</div>

<!-- Modal Edit Status -->
<div class="modal fade" id="editStatusModal" tabindex="-1" aria-labelledby="editStatusLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="aksi_pengembalian.php" method="POST" id="editStatusForm" class="modal-content bg-white shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="editStatusLabel">
          <i class="fa fa-edit me-1 text-warning"></i> Edit Status Penyewaan
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="sewaId" />
        <div class="mb-3">
          <label for="status" class="form-label fw-semibold">Status Transaksi <span class="text-danger">*</span></label>
          <select name="status" id="status" class="form-select" required>
            <option value="selesai">Selesai (Sudah Dikembalikan)</option>
            <option value="berlangsung">Berlangsung</option>
            <option value="siap di ambil">Siap di ambil</option>
            <option value="di antar">Di antar</option>
            <option value="menunggu pembayaran">Menunggu Pembayaran</option>
          </select>
          <small class="text-muted mt-1 d-block">
            * Mengubah status dari <em>Selesai</em> ke status aktif akan mengurangi kembali sisa stok alat.
          </small>
        </div>
      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
        <button type="submit" name="update_status" class="btn btn-primary btn-sm fw-bold">
          <i class="fa fa-save me-1"></i> Update Status
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Detail Pengembalian -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="detailModalLabel">
          <i class="fas fa-receipt me-2 text-warning"></i> Detail & Rincian Pengembalian
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-4" id="detailModalBody">
        <!-- Konten modal diisi via JS -->
      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
  // Edit Status Modal handler
  const editStatusModal = document.getElementById('editStatusModal');
  if (editStatusModal) {
    editStatusModal.addEventListener('show.bs.modal', event => {
      const button = event.relatedTarget;
      const id = button.getAttribute('data-id');
      const status = button.getAttribute('data-status');

      document.getElementById('sewaId').value = id;
      document.getElementById('status').value = status.toLowerCase();
    });
  }

  // Detail Modal handler (Multi-item Support)
  document.querySelectorAll('.lihat-detail-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const inv = JSON.parse(this.getAttribute('data-invoice'));

      let itemsHtml = '';
      inv.items.forEach(it => {
        const hg = parseFloat(it.harga_satuan_val) || 0;
        const sub = parseFloat(it.subtotal_item) || 0;
        itemsHtml += `
          <tr>
            <td class="text-center">
              <img src="${it.gambar_path}" alt="alat" style="width: 38px; height: 38px; object-fit: cover; border-radius: 4px;" class="border" />
            </td>
            <td><strong>${it.nama_produk}</strong></td>
            <td class="text-center fw-bold">${it.qty}</td>
            <td class="text-end">Rp${hg.toLocaleString('id-ID')}</td>
            <td class="text-end fw-bold text-success">Rp${sub.toLocaleString('id-ID')}</td>
          </tr>
        `;
      });

      const html = `
        <div class="row g-3 mb-3 p-3 bg-light rounded-3 border">
          <div class="col-sm-6">
            <span class="text-muted d-block small">Nomor Tagihan:</span>
            <strong class="text-primary fs-6">${inv.no_tagihan}</strong>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Status Pengembalian:</span>
            <span class="badge bg-success">Selesai Dikembalikan</span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Penyewa:</span>
            <strong>${inv.nama}</strong> <span class="text-muted">(${inv.email})</span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Tanggal Pengembalian:</span>
            <strong class="text-success"><i class="fas fa-clock me-1"></i>${inv.tanggal_dikembalikan}</strong>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Tanggal Mulai Sewa:</span>
            <strong>${inv.tanggal_sewa}</strong> (Durasi: ${inv.durasi} hari)
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Metode Pengambilan:</span>
            <strong class="text-dark">${inv.metode_pengambilan}</strong>
          </div>
        </div>

        <div class="modal-section-title mb-2 fw-bold text-dark">
          <i class="fas fa-boxes me-1 text-primary"></i> Daftar Alat dalam Tagihan Ini (${inv.items_count} item):
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-bordered table-hover align-middle mb-0 small">
            <thead class="table-light text-center">
              <tr>
                <th style="width: 50px;">Foto</th>
                <th>Nama Alat</th>
                <th style="width: 60px;">Qty</th>
                <th style="width: 100px;">Harga Satuan</th>
                <th style="width: 110px;">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>
        </div>

        <div class="bg-light p-3 rounded-3 border">
          <div class="d-flex justify-content-between mb-1 small text-muted">
            <span>Biaya Pengambilan / Ongkir:</span>
            <span>Rp${parseFloat(inv.total_ongkir).toLocaleString('id-ID')}</span>
          </div>
          <hr class="my-2">
          <div class="d-flex justify-content-between align-items-center">
            <span class="fw-bold fs-6 text-dark">Total Biaya Transaksi:</span>
            <span class="fw-bold text-success fs-5">Rp${parseFloat(inv.total_biaya).toLocaleString('id-ID')}</span>
          </div>
        </div>
      `;

      document.getElementById('detailModalBody').innerHTML = html;
    });
  });

  // Live search
  const liveSearch = document.getElementById('liveSearchPengembalian');
  if (liveSearch) {
    liveSearch.addEventListener('keyup', function () {
      let keyword = this.value.toLowerCase().trim();
      let rows = document.querySelectorAll('#tabelPengembalian tbody tr');

      rows.forEach(row => {
        let rowText = row.textContent.toLowerCase();
        if (rowText.includes(keyword)) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });
  }
</script>
</body>
</html>
