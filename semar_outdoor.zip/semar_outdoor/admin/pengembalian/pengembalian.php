<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

/* =========================================================================
   [FIFO / INVOICE GROUPING] QUERY & PENGELOMPOKAN DATA PENGEMBALIAN PER INVOICE
   ========================================================================= */
$sewaSelesaiQuery = $conn->query("
  SELECT sewa.*, users.nama, users.email, users.no_hp, users.alamat,
         COALESCE(alat.harga_per_hari, sewa.total_harga) AS harga_satuan_alat,
         alat.harga_per_hari AS harga_per_hari_alat
  FROM sewa 
  JOIN users ON sewa.id_users = users.id 
  LEFT JOIN alat ON sewa.id_alat = alat.id
  WHERE status = 'selesai'
  ORDER BY COALESCE(sewa.tanggal_dikembalikan, sewa.tanggal_buat) DESC, sewa.id DESC
");

$groupedSelesai = [];
if ($sewaSelesaiQuery && $sewaSelesaiQuery->num_rows > 0) {
    while ($r = $sewaSelesaiQuery->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)($r['harga_per_hari_alat'] ?? $r['harga_satuan_alat'] ?? $r['total_harga']);
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['harga_satuan_val'] = $harga_satuan;
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $r['gambar_path'] = !empty($r['gambar']) ? "../uploads/alat/" . $r['gambar'] : "../../assets/images/no-image.png";
        $groupedSelesai[$noTag][] = $r;
    }
}

$sewaSelesaiList = [];
foreach ($groupedSelesai as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $product_names = [];
    $item_ids = [];

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $product_names[] = $it['nama_produk'] . ' (x' . $it['qty'] . ')';
        $item_ids[] = (int)$it['id'];
    }

    $tgl_kembali_raw = $primary['tanggal_dikembalikan'] ?? '';
    $tgl_kembali = !empty($tgl_kembali_raw) ? date('d M Y, H:i', strtotime($tgl_kembali_raw)) : '-';

    $sewaSelesaiList[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'item_ids' => $item_ids,
        'id_users' => $primary['id_users'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'no_hp' => $primary['no_hp'] ?? '-',
        'alamat' => $primary['alamat'] ?? '-',
        'status' => $primary['status'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'tanggal_buat' => $primary['tanggal_buat'],
        'tanggal_dikembalikan_raw' => $tgl_kembali_raw,
        'tanggal_dikembalikan' => $tgl_kembali,
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'items_count' => count($items),
        'nama_produk_list' => implode(', ', $product_names),
        'items' => $items
    ];
}

/* =========================================================================
   [FILTER PERIODE BULAN & TAHUN]
   ========================================================================= */
$filterBulan = isset($_GET['bulan']) ? trim($_GET['bulan']) : date('m');
$filterTahun = isset($_GET['tahun']) ? trim($_GET['tahun']) : (string)date('Y');

$filterPengembalianByPeriod = function($list, $bulan, $tahun) {
    if ($bulan === 'semua' && $tahun === 'semua') {
        return $list;
    }
    return array_values(array_filter($list, function($row) use ($bulan, $tahun) {
        $tgl = !empty($row['tanggal_dikembalikan_raw']) ? $row['tanggal_dikembalikan_raw'] : (!empty($row['tanggal_dikembalikan']) && $row['tanggal_dikembalikan'] !== '-' ? $row['tanggal_dikembalikan'] : ($row['tanggal_buat'] ?? ''));
        if (empty($tgl)) return true;
        $rowBln = (int)date('n', strtotime($tgl));
        $rowThn = (int)date('Y', strtotime($tgl));
        if ($bulan !== 'semua' && $rowBln !== (int)$bulan) {
            return false;
        }
        if ($tahun !== 'semua' && $rowThn !== (int)$tahun) {
            return false;
        }
        return true;
    }));
};

$sewaSelesaiFiltered = $filterPengembalianByPeriod($sewaSelesaiList, $filterBulan, $filterTahun);

// Daftar tahun dinamis dari database
$yearsList = [];
$currY = (int)date('Y');
for ($y = $currY; $y >= $currY - 2; $y--) {
    $yearsList[] = $y;
}
$qY = mysqli_query($conn, "SELECT DISTINCT YEAR(tanggal_dikembalikan) AS y FROM sewa WHERE tanggal_dikembalikan IS NOT NULL AND YEAR(tanggal_dikembalikan) > 2000 UNION SELECT DISTINCT YEAR(tanggal_buat) AS y FROM sewa WHERE tanggal_buat IS NOT NULL AND YEAR(tanggal_buat) > 2000");
if ($qY) {
    while ($yr = mysqli_fetch_assoc($qY)) {
        if (!empty($yr['y'])) $yearsList[] = (int)$yr['y'];
    }
}
$yearsList = array_values(array_unique($yearsList));
rsort($yearsList);

// Paginasi - 12 data per halaman
$itemsPerPage = 12;
$pagePengembalian = max(1, (int)($_GET['page'] ?? 1));
$totalItemsPengembalian = count($sewaSelesaiFiltered);
$totalPagesPengembalian = max(1, ceil($totalItemsPengembalian / $itemsPerPage));
$pagePengembalian = min($pagePengembalian, $totalPagesPengembalian);
$offsetPengembalian = ($pagePengembalian - 1) * $itemsPerPage;
$sewaSelesaiPaginated = array_slice($sewaSelesaiFiltered, $offsetPengembalian, $itemsPerPage);

function renderPaginationBar($currentPage, $totalPages, $totalItems, $itemsCount, $pageParam = 'page') {
    if ($totalPages <= 1) return '';
    ob_start(); ?>
    <nav aria-label="Navigasi Halaman" class="d-flex flex-column align-items-center mt-4 mb-2">
      <ul class="pagination pagination-sm mb-1 shadow-sm rounded-pill overflow-hidden">
        <li class="page-item <?= ($currentPage <= 1) ? 'disabled' : '' ?>">
          <a class="page-link px-3" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $currentPage - 1])) ?>">
            <i class="fas fa-chevron-left me-1"></i> Sebelumnya
          </a>
        </li>
        <?php
        $startPage = max(1, $currentPage - 2);
        $endPage = min($totalPages, $currentPage + 2);
        if ($startPage > 1) {
            echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, [$pageParam => 1])) . '">1</a></li>';
            if ($startPage > 2) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
        for ($p = $startPage; $p <= $endPage; $p++): ?>
          <li class="page-item <?= ($p == $currentPage) ? 'active' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $p])) ?>"><?= $p ?></a>
          </li>
        <?php endfor;
        if ($endPage < $totalPages) {
            if ($endPage < $totalPages - 1) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, [$pageParam => $totalPages])) . '">' . $totalPages . '</a></li>';
        }
        ?>
        <li class="page-item <?= ($currentPage >= $totalPages) ? 'disabled' : '' ?>">
          <a class="page-link px-3" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $currentPage + 1])) ?>">
            Berikutnya <i class="fas fa-chevron-right ms-1"></i>
          </a>
        </li>
      </ul>
      <div class="text-muted small mt-1" style="font-size: 0.73rem;">
        Menampilkan <strong><?= $itemsCount ?></strong> dari total <strong><?= $totalItems ?></strong> transaksi (Halaman <?= $currentPage ?> dari <?= $totalPages ?>)
      </div>
    </nav>
    <?php
    return ob_get_clean();
}

// Fungsi Helper untuk Render Tabel Barang 2 Bagian (Kolom Sejajar)
function renderCardItemsTable($items) {
    $total = count($items);
    if ($total <= 1) {
        // Jika hanya 1 barang, tampilkan 1 tabel standar
        ob_start(); ?>
        <div class="table-responsive border rounded mb-2 overflow-hidden">
          <table class="table table-bordered table-striped table-card-items mb-0">
            <thead>
              <tr>
                <th>Nama Alat</th>
                <th class="text-center" style="width: 65px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($items as $it): ?>
                <tr>
                  <td class="text-dark fw-semibold text-truncate"><?= htmlspecialchars($it['nama_produk']); ?></td>
                  <td class="text-center">
                    <span class="badge bg-white text-dark border px-1.5" style="font-size: 0.68rem; line-height: 1.1;">
                      x<?= (int)$it['qty']; ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php
        return ob_get_clean();
    }

    // Jika barang banyak (> 1), bagi data menjadi 2 bagian (kiri & kanan)
    $half = ceil($total / 2);
    $leftItems = array_slice($items, 0, $half);
    $rightItems = array_slice($items, $half);

    ob_start(); ?>
    <div class="border rounded mb-2 overflow-hidden bg-white">
      <div class="row g-0">
        <!-- Bagian Kiri -->
        <div class="col-6 border-end">
          <table class="table table-bordered table-striped table-card-items mb-0 border-0">
            <thead>
              <tr>
                <th class="border-0 border-bottom">Nama Alat</th>
                <th class="text-center border-0 border-bottom" style="width: 65px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($leftItems as $it): ?>
                <tr>
                  <td class="text-dark fw-semibold text-truncate border-0 border-bottom"><?= htmlspecialchars($it['nama_produk']); ?></td>
                  <td class="text-center border-0 border-bottom">
                    <span class="badge bg-white text-dark border px-1.5" style="font-size: 0.68rem; line-height: 1.1;">
                      x<?= (int)$it['qty']; ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Bagian Kanan -->
        <div class="col-6">
          <table class="table table-bordered table-striped table-card-items mb-0 border-0">
            <thead>
              <tr>
                <th class="border-0 border-bottom">Nama Alat</th>
                <th class="text-center border-0 border-bottom" style="width: 65px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($rightItems as $it): ?>
                <tr>
                  <td class="text-dark fw-semibold text-truncate border-0 border-bottom"><?= htmlspecialchars($it['nama_produk']); ?></td>
                  <td class="text-center border-0 border-bottom">
                    <span class="badge bg-white text-dark border px-1.5" style="font-size: 0.68rem; line-height: 1.1;">
                      x<?= (int)$it['qty']; ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Pengembalian Alat - Admin Semar Outdoor</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body { background: #f8f9fa; }
    .admin-order-card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 14px 16px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.04);
      height: 100%;
      display: flex;
      flex-direction: column;
      transition: all 0.2s ease;
    }
    .admin-order-card:hover {
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
      border-color: #cbd5e1;
    }
    .badge-status {
      text-transform: capitalize;
      font-size: 0.70rem;
      padding: 0.25em 0.5em;
      font-weight: 600;
    }
    .img-thumb {
      width: 26px;
      height: 26px;
      object-fit: cover;
      border-radius: 4px;
    }
    .aksi-btn {
      display: flex;
      gap: 3px;
      align-items: center;
      justify-content: center;
      flex-wrap: nowrap;
      white-space: nowrap;
    }
    .modal-section-title {
      font-size: 0.82rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      color: #495057;
      border-bottom: 2px solid #e9ecef;
      padding-bottom: 4px;
      margin-bottom: 8px;
    }
    /* Style Tabel Ringkas Alat 2 Bagian Dalam Card */
    .table-card-items {
      font-size: 0.72rem;
      margin-bottom: 0;
      table-layout: fixed;
      width: 100%;
    }
    .table-card-items th {
      background-color: #f1f5f9;
      color: #334155;
      font-weight: 600;
      padding: 4px 6px;
    }
    .table-card-items td {
      padding: 4px 6px;
      vertical-align: middle;
      background-color: #ffffff;
    }
  </style>
</head>
<body>
<?php include '../sidebar.php'; ?>

<div class="main-content">
  <!-- Standard Page Header Bar -->
  <div class="admin-page-header">
    <div>
      <div class="admin-header-title">
        <i class="fas fa-undo-alt me-2 text-success"></i>Data Pengembalian Alat
      </div>
      <div class="admin-header-chips">
        <span class="badge bg-success px-2.5 py-1 rounded-pill">
          <i class="fas fa-check-circle me-1"></i> <?= count($sewaSelesaiFiltered) ?> Transaksi Selesai Dikembalikan
        </span>
      </div>
    </div>

    <!-- Search Bar -->
    <div class="admin-header-actions">
      <div style="width: 240px;">
        <input type="text" id="liveSearchPengembalian" class="form-control search-input-admin"
               placeholder="Cari pengembalian...">
      </div>
    </div>
  </div>

  <?php if (!empty($_SESSION['flash_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show mb-3" role="alert">
      <i class="fas fa-check-circle me-2"></i> <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
      <i class="fas fa-exclamation-triangle me-2"></i> <?= $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Filter Periode Bulan & Tahun -->
  <div class="card p-3 mb-4 border-0 shadow-sm rounded-3 bg-white">
    <form method="GET" class="row g-2 align-items-center">
      <div class="col-md-4 col-6">
        <label class="form-label text-muted small mb-1 fw-bold"><i class="fas fa-calendar-alt me-1 text-primary"></i> Filter Bulan</label>
        <select name="bulan" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="semua" <?= ($filterBulan === 'semua') ? 'selected' : '' ?>>Semua Bulan</option>
          <?php
          $namaBulan = [
            '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
            '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
            '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
          ];
          foreach ($namaBulan as $blnNum => $blnTxt): ?>
            <option value="<?= $blnNum ?>" <?= ($filterBulan === $blnNum) ? 'selected' : '' ?>><?= $blnTxt ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 col-6">
        <label class="form-label text-muted small mb-1 fw-bold"><i class="fas fa-calendar me-1 text-primary"></i> Filter Tahun</label>
        <select name="tahun" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="semua" <?= ($filterTahun === 'semua') ? 'selected' : '' ?>>Semua Tahun</option>
          <?php foreach ($yearsList as $y): ?>
            <option value="<?= $y ?>" <?= ($filterTahun == $y) ? 'selected' : '' ?>><?= $y ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4 col-12">
        <label class="form-label text-muted small mb-1 fw-bold"><i class="fas fa-bolt me-1 text-warning"></i> Filter Cepat</label>
        <div class="d-flex gap-1.5">
          <a href="?bulan=<?= date('m') ?>&tahun=<?= date('Y') ?>" class="btn btn-sm btn-outline-primary w-100 <?= ($filterBulan === date('m') && $filterTahun == date('Y')) ? 'active' : '' ?>">Bulan Ini</a>
          <a href="?bulan=semua&tahun=semua" class="btn btn-sm btn-outline-secondary w-100 <?= ($filterBulan === 'semua' && $filterTahun === 'semua') ? 'active' : '' ?>">Semua Data</a>
        </div>
      </div>
    </form>
  </div>

  <?php if (count($sewaSelesaiPaginated) > 0): ?>
    <div class="row g-3" id="containerPengembalian">
      <?php foreach ($sewaSelesaiPaginated as $row): ?>
      <div class="col-lg-6 col-md-6 col-12 admin-pengembalian-card-item">
        <div class="admin-order-card">
          <!-- Header Baris Atas: No Tagihan, Status Selesai, Tanggal Dikembalikan -->
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-1 mb-2 pb-1.5 border-bottom">
            <div class="d-flex align-items-center gap-1.5 flex-wrap">
              <span class="badge bg-dark font-monospace px-2 py-0.5 rounded" style="font-size: 0.74rem;">
                <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($row['no_tagihan']); ?>
              </span>
              <span class="badge bg-success px-2 py-0.5 rounded" style="font-size: 0.70rem;">
                <i class="fas fa-check-circle me-1"></i><?= htmlspecialchars($row['status']); ?>
              </span>
            </div>
            <span class="text-muted" style="font-size: 0.72rem;">
              <i class="fas fa-undo-alt text-success me-1"></i>Dikembalikan: <strong><?= htmlspecialchars($row['tanggal_dikembalikan'] ?? '-'); ?></strong>
            </span>
          </div>

          <!-- Info Penyewa -->
          <div class="d-flex justify-content-between align-items-center mb-1.5">
            <div class="text-truncate me-2">
              <span class="fw-bold text-dark" style="font-size: 0.82rem;">
                <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']); ?>
              </span>
              <small class="text-muted d-block text-truncate" style="font-size: 0.72rem;"><?= htmlspecialchars($row['email']); ?></small>
            </div>
            <span class="badge bg-light text-dark border px-2 py-0.5 flex-shrink-0" style="font-size: 0.70rem;">
              <?= htmlspecialchars($row['metode_pengambilan']); ?>
            </span>
          </div>

          <!-- Tabel Barang 2 Bagian / Sejajar -->
          <?= renderCardItemsTable($row['items']); ?>

          <!-- Meta Unit & Durasi -->
          <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 0.72rem;">
            <span>Total: <strong><?= $row['total_qty']; ?> unit</strong> &bull; <strong><?= $row['durasi']; ?> hari</strong></span>
            <span>Tgl Sewa: <strong><?= htmlspecialchars($row['tanggal_sewa']); ?></strong></span>
          </div>

          <!-- Footer: Total Biaya & Aksi -->
          <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
            <div>
              <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Total Biaya Transaksi</small>
              <span class="fw-bold text-success" style="font-size: 0.92rem;">Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?></span>
            </div>

            <div class="d-flex align-items-center gap-1">
              <button 
                class="btn btn-sm btn-outline-primary lihat-detail-btn" 
                data-bs-toggle="modal" 
                data-bs-target="#detailModal"
                data-invoice='<?= json_encode($row, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'
                title="Lihat Detail Data Penyewa & Pengembalian"
              >
                <i class="fas fa-info-circle me-1"></i>Detail
              </button>
            </div>
          </div>

        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?= renderPaginationBar($pagePengembalian, $totalPagesPengembalian, $totalItemsPengembalian, count($sewaSelesaiPaginated), 'page') ?>

  <?php else: ?>
    <div class="card p-4 text-center rounded-3 border-0 shadow-sm">
      <i class="fas fa-info-circle fs-2 text-muted mb-2"></i>
      <h6 class="fw-bold mb-1">Belum Ada Pengembalian Selesai</h6>
      <p class="text-muted small mb-0">Tidak ada data pengembalian alat untuk periode yang dipilih.</p>
    </div>
  <?php endif; ?>
</div>

<!-- Modal Detail Pengembalian -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="detailModalLabel">
          <i class="fas fa-receipt me-2 text-warning"></i> Detail Informasi Penyewa & Pengembalian
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-4" id="detailModalBody">
        <!-- Konten modal diisi via JS -->
      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
  // Detail Modal handler (Multi-item & Full Tenant Information Support)
  document.querySelectorAll('.lihat-detail-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const inv = JSON.parse(this.getAttribute('data-invoice'));

      let itemsHtml = '';
      inv.items.forEach(it => {
        const hg = parseFloat(it.harga_satuan_val) || 0;
        const sub = parseFloat(it.subtotal_item) || 0;
        itemsHtml += `
          <tr>
            <td class="text-center">
              <img src="${it.gambar_path}" alt="alat" style="width: 38px; height: 38px; object-fit: cover; border-radius: 4px;" class="border" />
            </td>
            <td><strong>${it.nama_produk}</strong></td>
            <td class="text-center fw-bold">${it.qty}</td>
            <td class="text-end">Rp${hg.toLocaleString('id-ID')}</td>
            <td class="text-end fw-bold text-success">Rp${sub.toLocaleString('id-ID')}</td>
          </tr>
        `;
      });

      const html = `
        <div class="row g-3 mb-3 p-3 bg-light rounded-3 border">
          <div class="col-sm-6">
            <span class="text-muted d-block small">Nomor Tagihan / Invoice:</span>
            <strong class="text-primary fs-6">${inv.no_tagihan}</strong>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Status Pengembalian:</span>
            <span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Selesai Dikembalikan</span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Nama Penyewa:</span>
            <strong class="text-dark">${inv.nama}</strong>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Email Penyewa:</span>
            <span class="text-dark">${inv.email || '-'}</span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">No. HP / WhatsApp:</span>
            <strong class="text-success"><i class="fab fa-whatsapp me-1"></i>${inv.no_hp || '-'}</strong>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Alamat Pengiriman / Penyewa:</span>
            <span class="text-dark">${inv.alamat || '-'}</span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Tanggal Mulai Sewa:</span>
            <strong>${inv.tanggal_sewa}</strong> (Durasi: ${inv.durasi} hari)
          </div>
          <div class="col-sm-6">
            <span class="text-muted d-block small">Waktu Dikembalikan:</span>
            <strong class="text-success"><i class="fas fa-clock me-1"></i>${inv.tanggal_dikembalikan}</strong>
          </div>
          <div class="col-sm-12">
            <span class="text-muted d-block small">Metode Pengambilan:</span>
            <strong class="text-dark">${inv.metode_pengambilan}</strong>
          </div>
        </div>

        <div class="modal-section-title mb-2 fw-bold text-dark">
          <i class="fas fa-boxes me-1 text-primary"></i> Rincian Alat yang Telah Dikembalikan (${inv.items_count} item):
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-bordered table-hover align-middle mb-0 small">
            <thead class="table-light text-center">
              <tr>
                <th style="width: 50px;">Foto</th>
                <th>Nama Alat</th>
                <th style="width: 65px;">Jumlah</th>
                <th style="width: 100px;">Harga Satuan</th>
                <th style="width: 110px;">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>
        </div>

        <div class="bg-light p-3 rounded-3 border">
          <div class="d-flex justify-content-between mb-1 small text-muted">
            <span>Biaya Pengantaran / Ongkir:</span>
            <span>Rp${parseFloat(inv.total_ongkir).toLocaleString('id-ID')}</span>
          </div>
          <hr class="my-2">
          <div class="d-flex justify-content-between align-items-center">
            <span class="fw-bold fs-6 text-dark">Total Biaya Transaksi:</span>
            <span class="fw-bold text-success fs-5">Rp${parseFloat(inv.total_biaya).toLocaleString('id-ID')}</span>
          </div>
        </div>
      `;

      document.getElementById('detailModalBody').innerHTML = html;
    });
  });

  // Live search
  const liveSearch = document.getElementById('liveSearchPengembalian');
  if (liveSearch) {
    liveSearch.addEventListener('keyup', function () {
      let keyword = this.value.toLowerCase().trim();
      document.querySelectorAll('.admin-pengembalian-card-item').forEach(card => {
        let text = card.textContent.toLowerCase();
        card.style.display = text.includes(keyword) ? '' : 'none';
      });
    });
  }
</script>
</body>
</html>