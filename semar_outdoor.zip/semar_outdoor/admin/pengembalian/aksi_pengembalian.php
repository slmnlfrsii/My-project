<?php
session_start();
include '../../koneksi.php';
include '../cek_login.php';
date_default_timezone_set('Asia/Jakarta');

if (isset($_POST['update_status'])) {

    $id = (int) $_POST['id'];
    $status_baru = $_POST['status'];
    $statusNew = strtolower(trim($status_baru));

    $conn->begin_transaction();

    try {
        // Ambil data utama
        $get = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
        $get->bind_param("i", $id);
        $get->execute();
        $data = $get->get_result()->fetch_assoc();
        $get->close();

        if (!$data) {
            throw new Exception("Data transaksi tidak ditemukan!");
        }

        $allItemIds = [$id];
        $noTagihanBatch = $data['no_tagihan'] ?? '';
        $idUsersBatch = (int)$data['id_users'];

        if (!empty($noTagihanBatch)) {
            $qBatch = mysqli_query($conn, "SELECT id FROM sewa WHERE id_users = $idUsersBatch AND no_tagihan = '$noTagihanBatch'");
            if ($qBatch && mysqli_num_rows($qBatch) > 0) {
                while ($bRow = mysqli_fetch_assoc($qBatch)) {
                    $allItemIds[] = (int)$bRow['id'];
                }
            }
        }
        $allItemIds = array_values(array_unique(array_filter($allItemIds)));

        $activeStatuses = ['siap di ambil', 'di antar', 'diantar', 'berlangsung'];
        $becomingActive = in_array($statusNew, $activeStatuses);

        foreach ($allItemIds as $item_id) {
            $getItem = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
            $getItem->bind_param("i", $item_id);
            $getItem->execute();
            $itemData = $getItem->get_result()->fetch_assoc();
            $getItem->close();

            if (!$itemData) continue;

            $statusItemCurrent = strtolower(trim($itemData['status']));
            $wasActive = in_array($statusItemCurrent, $activeStatuses);

            // 1. Berpindah ke status aktif (stok berkurang)
            if (!$wasActive && $becomingActive && !empty($itemData['id_alat'])) {
                $getAlat = $conn->prepare("SELECT sisa_stok, nama FROM alat WHERE id = ?");
                $getAlat->bind_param("i", $itemData['id_alat']);
                $getAlat->execute();
                $curAlat = $getAlat->get_result()->fetch_assoc();
                $getAlat->close();

                if ($curAlat && $curAlat['sisa_stok'] < (int)$itemData['qty']) {
                    throw new Exception("Stok tidak cukup untuk {$curAlat['nama']} (Sisa: {$curAlat['sisa_stok']}, butuh: {$itemData['qty']})");
                }

                $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = GREATEST(0, sisa_stok - ?) WHERE id = ?");
                $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                $updateStok->execute();
                $updateStok->close();
            }

            // 2. Berpindah dari status aktif ke non-aktif/selesai (stok dikembalikan)
            if ($wasActive && !$becomingActive && !empty($itemData['id_alat'])) {
                $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
                $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                $updateStok->execute();
                $updateStok->close();
            }

            // Update status item
            if ($statusNew === 'selesai') {
                $update = $conn->prepare("UPDATE sewa SET status = 'selesai', tanggal_dikembalikan = NOW() WHERE id = ?");
                $update->bind_param("i", $item_id);
                $update->execute();
                $update->close();
            } else {
                $update = $conn->prepare("UPDATE sewa SET status = ? WHERE id = ?");
                $update->bind_param("si", $status_baru, $item_id);
                $update->execute();
                $update->close();
            }
        }

        $conn->commit();
        $_SESSION['flash_success'] = "Status seluruh item dalam invoice berhasil diperbarui!";

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['flash_error'] = $e->getMessage();
    }

    header("Location: pengembalian.php");
    exit;
}


// =========================
// HAPUS DATA INVOICE
// =========================
if (isset($_POST['hapus'])) {

    $id = (int) $_POST['id'];

    $conn->begin_transaction();

    try {
        $get = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
        $get->bind_param("i", $id);
        $get->execute();
        $data = $get->get_result()->fetch_assoc();
        $get->close();

        if ($data) {
            $allItemIds = [$id];
            $noTagihanBatch = $data['no_tagihan'] ?? '';
            $idUsersBatch = (int)$data['id_users'];

            if (!empty($noTagihanBatch)) {
                $qBatch = mysqli_query($conn, "SELECT id FROM sewa WHERE id_users = $idUsersBatch AND no_tagihan = '$noTagihanBatch'");
                if ($qBatch && mysqli_num_rows($qBatch) > 0) {
                    while ($bRow = mysqli_fetch_assoc($qBatch)) {
                        $allItemIds[] = (int)$bRow['id'];
                    }
                }
            }
            $allItemIds = array_values(array_unique(array_filter($allItemIds)));

            $activeStatuses = ['siap di ambil', 'di antar', 'diantar', 'berlangsung'];

            foreach ($allItemIds as $delId) {
                $getItem = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
                $getItem->bind_param("i", $delId);
                $getItem->execute();
                $itemData = $getItem->get_result()->fetch_assoc();
                $getItem->close();

                if (!$itemData) continue;

                if (in_array(strtolower(trim($itemData['status'])), $activeStatuses) && !empty($itemData['id_alat'])) {
                    $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
                    $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                    $updateStok->execute();
                    $updateStok->close();
                }

                $delStmt = $conn->prepare("DELETE FROM sewa WHERE id = ?");
                $delStmt->bind_param("i", $delId);
                $delStmt->execute();
                $delStmt->close();
            }
        }

        $conn->commit();
        $_SESSION['flash_success'] = "Data seluruh item dalam invoice berhasil dihapus!";

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['flash_error'] = "Gagal menghapus data: " . $e->getMessage();
    }

    header("Location: pengembalian.php");
    exit;
}
?>