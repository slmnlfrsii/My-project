<?php
session_start();

// Hapus semua session
$_SESSION = [];
session_destroy();

// Redirect ke halaman login dengan notifikasi logout sukses
header("Location: index.php?logout=success");
exit;
