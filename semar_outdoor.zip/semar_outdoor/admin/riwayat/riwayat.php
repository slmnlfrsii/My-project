<?php
session_start();
require_once "../../koneksi.php";
include '../cek_login.php';

// Tab Aktif (Default: sewa_masuk, berlangsung, atau dibatalkan)
$tabInput = isset($_GET['tab']) ? strtolower(trim($_GET['tab'])) : 'sewa_masuk';
$allowedTabs = ['sewa_masuk', 'berlangsung', 'dibatalkan'];
$activeTab = in_array($tabInput, $allowedTabs) ? $tabInput : 'sewa_masuk';

/* =========================================================================
   [FIFO LOGIC] 1. QUERY SEWA BERLANGSUNG DIURUTKAN SECARA FIFO
   ========================================================================= */
$sewaBerlangsungQuery = $conn->query("
    SELECT sewa.*, users.nama, users.email, 
           COALESCE(alat.harga_per_hari, sewa.total_harga) AS harga_satuan_alat,
           alat.harga_per_hari AS harga_per_hari_alat
    FROM sewa 
    JOIN users ON sewa.id_users = users.id 
    LEFT JOIN alat ON sewa.id_alat = alat.id
    WHERE sewa.status NOT IN ('selesai', 'Dibatalkan', 'dibatalkan')
    ORDER BY COALESCE(sewa.tanggal_buat, '1970-01-01 00:00:00') ASC, sewa.id ASC
");
$sewaSelesai = $conn->query("
    SELECT sewa.*, users.nama, users.email, 
           COALESCE(alat.harga_per_hari, sewa.total_harga) AS harga_satuan_alat,
           alat.harga_per_hari AS harga_per_hari_alat
    FROM sewa 
    JOIN users ON sewa.id_users = users.id 
    LEFT JOIN alat ON sewa.id_alat = alat.id
    WHERE status = 'selesai'
    ORDER BY sewa.tanggal_dikembalikan DESC, sewa.id DESC
");
$sewaDibatalkan = $conn->query("
    SELECT sewa_dibatalkan.*, users.nama, users.email, 
           COALESCE(alat.harga_per_hari, sewa_dibatalkan.total_harga) AS harga_satuan_alat,
           alat.harga_per_hari AS harga_per_hari_alat
    FROM sewa_dibatalkan 
    JOIN users ON sewa_dibatalkan.id_users = users.id
    LEFT JOIN alat ON sewa_dibatalkan.nama_produk = alat.nama
    ORDER BY sewa_dibatalkan.dibatalkan_pada DESC, sewa_dibatalkan.id DESC
");

// Pre-process dan grouping data sewa per Nomor Invoice
$groupedBerlangsung = [];

if ($sewaBerlangsungQuery && $sewaBerlangsungQuery->num_rows > 0) {
    while ($r = $sewaBerlangsungQuery->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        
        $harga_satuan = (float)($r['harga_per_hari_alat'] ?? $r['harga_satuan_alat'] ?? $r['total_harga']);
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['harga_satuan_val'] = $harga_satuan;
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $r['gambar_path'] = !empty($r['gambar']) ? "../uploads/alat/" . $r['gambar'] : "../../assets/images/no-image.png";

        $groupedBerlangsung[$noTag][] = $r;
    }
}

/* =========================================================================
   [FIFO LOGIC & PENGELOMPOKAN TAB INDEPENDEN]
   ========================================================================= */
$masukStatuses = ['siap di ambil', 'siap diambil', 'di antar', 'diantar', 'menunggu pembayaran'];

$sewaMasukRaw = [];
$sewaBerlangsungRaw = [];

foreach ($groupedBerlangsung as $noTag => $items) {
    $primary = $items[0];
    $statusClean = strtolower(trim($primary['status']));

    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $product_names = [];
    $item_ids = [];

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $product_names[] = $it['nama_produk'] . ' (x' . $it['qty'] . ')';
        $item_ids[] = (int)$it['id'];
    }

    $cardData = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'item_ids' => $item_ids,
        'id_users' => $primary['id_users'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => $primary['status'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'tanggal_buat' => $primary['tanggal_buat'],
        'tanggal_dikembalikan' => $primary['tanggal_dikembalikan'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'nama_produk_list' => implode(', ', $product_names),
        'items' => $items,
    ];

    if (in_array($statusClean, $masukStatuses)) {
        $sewaMasukRaw[] = $cardData;
    } else {
        $sewaBerlangsungRaw[] = $cardData;
    }
}

// Processing FIFO khusus TAB SEWA MASUK
$sewaMasukList = [];
$hasActiveProcessMasuk = false;
$blockingQueueNoMasuk = 1;

foreach ($sewaMasukRaw as $idx => $card) {
    $st = strtolower(trim($card['status']));
    $qNo = $idx + 1;
    $card['queue_no'] = $qNo;

    if ($st === 'menunggu pembayaran') {
        $card['is_locked'] = true;
        $card['blocking_queue_no'] = $blockingQueueNoMasuk;
    } else {
        if (!$hasActiveProcessMasuk) {
            $card['is_locked'] = false;
            $hasActiveProcessMasuk = true;
            $blockingQueueNoMasuk = $qNo;
        } else {
            $card['is_locked'] = true;
            $card['blocking_queue_no'] = $blockingQueueNoMasuk;
        }
    }
    $sewaMasukList[] = $card;
}

// Processing FIFO khusus TAB BERLANGSUNG
$sewaBerlangsungList = [];
$hasActiveProcessBerlangsung = false;
$blockingQueueNoBerlangsung = 1;

foreach ($sewaBerlangsungRaw as $idx => $card) {
    $qNo = $idx + 1;
    $card['queue_no'] = $qNo;

    if (!$hasActiveProcessBerlangsung) {
        $card['is_locked'] = false;
        $hasActiveProcessBerlangsung = true;
        $blockingQueueNoBerlangsung = $qNo;
    } else {
        $card['is_locked'] = true;
        $card['blocking_queue_no'] = $blockingQueueNoBerlangsung;
    }
    $sewaBerlangsungList[] = $card;
}

// Grouping Sewa Dibatalkan
$sewaDibatalkanList = [];
$groupedDibatalkan = [];
if ($sewaDibatalkan && $sewaDibatalkan->num_rows > 0) {
    while ($r = $sewaDibatalkan->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['dibatalkan_pada'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)($r['harga_per_hari_alat'] ?? $r['harga_satuan_alat'] ?? $r['total_harga']);
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['harga_satuan_val'] = $harga_satuan;
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $r['gambar_path'] = !empty($r['gambar']) ? "../uploads/alat/" . $r['gambar'] : "../../assets/images/no-image.png";
        $groupedDibatalkan[$noTag][] = $r;
    }
}
foreach ($groupedDibatalkan as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $product_names = [];
    $item_ids = [];
    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $product_names[] = $it['nama_produk'] . ' (x' . $it['qty'] . ')';
        $item_ids[] = (int)$it['id'];
    }

    $rawStatus = strtolower(trim($primary['status'] ?? ''));
    $isDitolakBayar = ($rawStatus === 'ditolak');
    if (!$isDitolakBayar && !empty($item_ids)) {
        $uId = (int)$primary['id_users'];
        $findClauses = [];
        foreach ($item_ids as $itmId) {
            $findClauses[] = "FIND_IN_SET('" . (int)$itmId . "', id_sewa)";
        }
        $whereMatch = implode(' OR ', $findClauses);
        $qCheckDitolak = $conn->query("SELECT id FROM pembayaran WHERE id_users = $uId AND LOWER(TRIM(status)) = 'ditolak' AND ($whereMatch) LIMIT 1");
        if ($qCheckDitolak && $qCheckDitolak->num_rows > 0) {
            $isDitolakBayar = true;
        }
    }

    $is_auto_batal = (strpos($rawStatus, 'otomatis') !== false);

    if ($isDitolakBayar) {
        $statusDisplay = 'Ditolak';
    } elseif ($is_auto_batal) {
        $statusDisplay = 'Batal Otomatis';
    } else {
        $statusDisplay = 'Dibatalkan User';
    }

    $sewaDibatalkanList[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'item_ids' => $item_ids,
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => $statusDisplay,
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'dibatalkan_pada' => $primary['dibatalkan_pada'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'nama_produk_list' => implode(', ', $product_names),
        'items' => $items,
        'is_ditolak' => $isDitolakBayar,
        'is_auto_batal' => $is_auto_batal
    ];
}

/* =========================================================================
   [FILTER PERIODE BULAN & TAHUN]
   ========================================================================= */
$filterBulan = isset($_GET['bulan']) ? trim($_GET['bulan']) : date('m');
$filterTahun = isset($_GET['tahun']) ? trim($_GET['tahun']) : (string)date('Y');

$filterRiwayatByPeriod = function($list, $bulan, $tahun) {
    if ($bulan === 'semua' && $tahun === 'semua') {
        return $list;
    }
    return array_values(array_filter($list, function($row) use ($bulan, $tahun) {
        $tgl = !empty($row['tanggal_buat']) ? $row['tanggal_buat'] : (!empty($row['tanggal_sewa']) ? $row['tanggal_sewa'] : ($row['dibatalkan_pada'] ?? ''));
        if (empty($tgl)) return true;
        $rowBln = (int)date('n', strtotime($tgl));
        $rowThn = (int)date('Y', strtotime($tgl));
        if ($bulan !== 'semua' && $rowBln !== (int)$bulan) {
            return false;
        }
        if ($tahun !== 'semua' && $rowThn !== (int)$tahun) {
            return false;
        }
        return true;
    }));
};

$sewaMasukFiltered = $filterRiwayatByPeriod($sewaMasukList, $filterBulan, $filterTahun);
$sewaBerlangsungFiltered = $filterRiwayatByPeriod($sewaBerlangsungList, $filterBulan, $filterTahun);
$sewaDibatalkanFiltered = $filterRiwayatByPeriod($sewaDibatalkanList, $filterBulan, $filterTahun);

// Daftar tahun dinamis
$yearsList = [];
$currY = (int)date('Y');
for ($y = $currY; $y >= $currY - 2; $y--) {
    $yearsList[] = $y;
}
$qY = mysqli_query($conn, "SELECT DISTINCT YEAR(tanggal_buat) AS y FROM sewa WHERE tanggal_buat IS NOT NULL AND YEAR(tanggal_buat) > 2000 UNION SELECT DISTINCT YEAR(tanggal_sewa) AS y FROM sewa WHERE tanggal_sewa IS NOT NULL AND YEAR(tanggal_sewa) > 2000 UNION SELECT DISTINCT YEAR(dibatalkan_pada) AS y FROM sewa_dibatalkan WHERE dibatalkan_pada IS NOT NULL AND YEAR(dibatalkan_pada) > 2000");
if ($qY) {
    while ($yr = mysqli_fetch_assoc($qY)) {
        if (!empty($yr['y'])) $yearsList[] = (int)$yr['y'];
    }
}
$yearsList = array_values(array_unique($yearsList));
rsort($yearsList);

// Paginasi Setup (12 items per page)
$itemsPerPage = 12;

$pageMasuk = max(1, (int)($_GET['page_masuk'] ?? ($_GET['page'] ?? 1)));
$totalItemsMasuk = count($sewaMasukFiltered);
$totalPagesMasuk = max(1, ceil($totalItemsMasuk / $itemsPerPage));
$pageMasuk = min($pageMasuk, $totalPagesMasuk);
$offsetMasuk = ($pageMasuk - 1) * $itemsPerPage;
$sewaMasukPaginated = array_slice($sewaMasukFiltered, $offsetMasuk, $itemsPerPage);

$pageBerlangsung = max(1, (int)($_GET['page_berlangsung'] ?? 1));
$totalItemsBerlangsung = count($sewaBerlangsungFiltered);
$totalPagesBerlangsung = max(1, ceil($totalItemsBerlangsung / $itemsPerPage));
$pageBerlangsung = min($pageBerlangsung, $totalPagesBerlangsung);
$offsetBerlangsung = ($pageBerlangsung - 1) * $itemsPerPage;
$sewaBerlangsungPaginated = array_slice($sewaBerlangsungFiltered, $offsetBerlangsung, $itemsPerPage);

$pageDibatalkan = max(1, (int)($_GET['page_dibatalkan'] ?? 1));
$totalItemsDibatalkan = count($sewaDibatalkanFiltered);
$totalPagesDibatalkan = max(1, ceil($totalItemsDibatalkan / $itemsPerPage));
$pageDibatalkan = min($pageDibatalkan, $totalPagesDibatalkan);
$offsetDibatalkan = ($pageDibatalkan - 1) * $itemsPerPage;
$sewaDibatalkanPaginated = array_slice($sewaDibatalkanFiltered, $offsetDibatalkan, $itemsPerPage);

function renderPaginationBar($currentPage, $totalPages, $totalItems, $itemsCount, $pageParam = 'page') {
    if ($totalPages <= 1) return '';
    ob_start(); ?>
    <nav aria-label="Navigasi Halaman" class="d-flex flex-column align-items-center mt-4 mb-2">
      <ul class="pagination pagination-sm mb-1 shadow-sm rounded-pill overflow-hidden">
        <li class="page-item <?= ($currentPage <= 1) ? 'disabled' : '' ?>">
          <a class="page-link px-2 px-md-3" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $currentPage - 1])) ?>">
            <i class="fas fa-chevron-left me-1"></i> <span class="d-none d-sm-inline">Sebelumnya</span>
          </a>
        </li>
        <?php
        $startPage = max(1, $currentPage - 1);
        $endPage = min($totalPages, $currentPage + 1);
        if ($startPage > 1) {
            echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, [$pageParam => 1])) . '">1</a></li>';
            if ($startPage > 2) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
        for ($p = $startPage; $p <= $endPage; $p++): ?>
          <li class="page-item <?= ($p == $currentPage) ? 'active' : '' ?>">
            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $p])) ?>"><?= $p ?></a>
          </li>
        <?php endfor;
        if ($endPage < $totalPages) {
            if ($endPage < $totalPages - 1) echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            echo '<li class="page-item"><a class="page-link" href="?' . http_build_query(array_merge($_GET, [$pageParam => $totalPages])) . '">' . $totalPages . '</a></li>';
        }
        ?>
        <li class="page-item <?= ($currentPage >= $totalPages) ? 'disabled' : '' ?>">
          <a class="page-link px-2 px-md-3" href="?<?= http_build_query(array_merge($_GET, [$pageParam => $currentPage + 1])) ?>">
            <span class="d-none d-sm-inline">Berikutnya</span> <i class="fas fa-chevron-right ms-1"></i>
          </a>
        </li>
      </ul>
      <div class="text-muted small mt-1 text-center" style="font-size: 0.73rem;">
        Menampilkan <strong><?= $itemsCount ?></strong> dari <strong><?= $totalItems ?></strong> data
      </div>
    </nav>
    <?php
    return ob_get_clean();
}

// Fungsi Helper Render Tabel Barang (2 Kolom Sejajar Konsisten di Desktop & Android)
function renderCardItemsTable($items) {
    $total = count($items);
    if ($total <= 1) {
        ob_start(); ?>
        <div class="table-responsive border rounded mb-2 overflow-hidden">
          <table class="table table-bordered table-striped table-card-items mb-0">
            <thead>
              <tr>
                <th>Nama Alat</th>
                <th class="text-center" style="width: 65px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($items as $it): ?>
                <tr>
                  <td class="text-dark fw-semibold text-truncate"><?= htmlspecialchars($it['nama_produk']); ?></td>
                  <td class="text-center">
                    <span class="badge bg-white text-dark border px-1.5" style="font-size: 0.68rem; line-height: 1.1;">
                      x<?= (int)$it['qty']; ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php
        return ob_get_clean();
    }

    $half = ceil($total / 2);
    $leftItems = array_slice($items, 0, $half);
    $rightItems = array_slice($items, $half);

    ob_start(); ?>
    <div class="border rounded mb-2 overflow-hidden bg-white">
      <div class="row g-0">
        <!-- Bagian Kiri (Selalu 50% Lebar) -->
        <div class="col-6 border-end">
          <table class="table table-bordered table-striped table-card-items mb-0 border-0">
            <thead>
              <tr>
                <th class="border-0 border-bottom">Nama Alat</th>
                <th class="text-center border-0 border-bottom" style="width: 65px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($leftItems as $it): ?>
                <tr>
                  <td class="text-dark fw-semibold text-truncate border-0 border-bottom"><?= htmlspecialchars($it['nama_produk']); ?></td>
                  <td class="text-center border-0 border-bottom">
                    <span class="badge bg-white text-dark border px-1.5" style="font-size: 0.68rem; line-height: 1.1;">
                      x<?= (int)$it['qty']; ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <!-- Bagian Kanan (Selalu 50% Lebar) -->
        <div class="col-6">
          <table class="table table-bordered table-striped table-card-items mb-0 border-0">
            <thead>
              <tr>
                <th class="border-0 border-bottom">Nama Alat</th>
                <th class="text-center border-0 border-bottom" style="width: 65px;">Jumlah</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($rightItems as $it): ?>
                <tr>
                  <td class="text-dark fw-semibold text-truncate border-0 border-bottom"><?= htmlspecialchars($it['nama_produk']); ?></td>
                  <td class="text-center border-0 border-bottom">
                    <span class="badge bg-white text-dark border px-1.5" style="font-size: 0.68rem; line-height: 1.1;">
                      x<?= (int)$it['qty']; ?>
                    </span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Riwayat Penyewaan - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body { background: #f8f9fa; }
    
    .admin-page-header {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      margin-bottom: 15px;
    }
    .admin-header-actions {
      width: 100%;
    }
    @media (min-width: 576px) {
      .admin-header-actions {
        width: auto;
      }
    }

    .admin-order-card {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 12px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
      height: 100%;
      display: flex;
      flex-direction: column;
      transition: all 0.2s ease;
    }
    .card-locked {
      background: #f8fafc;
      border-color: #cbd5e1;
    }

    .nav-pills-wrapper {
      width: 100%;
      overflow-x: auto;
      white-space: nowrap;
      -webkit-overflow-scrolling: touch;
      padding-bottom: 4px;
    }
    .nav-pills-wrapper::-webkit-scrollbar {
      display: none;
    }
    .nav-pills {
      flex-wrap: nowrap !important;
    }
    .nav-pills .nav-link {
      color: #334155;
      font-weight: 500;
      font-size: 0.82rem;
      padding: 8px 14px;
      border-radius: 20px;
    }
    .nav-pills .nav-link.active {
      background-color: #0e4430;
      color: white;
      font-weight: 600;
    }

    .table-card-items {
      font-size: 0.72rem;
      margin-bottom: 0;
      table-layout: fixed;
      width: 100%;
    }
    .table-card-items th {
      background-color: #f1f5f9;
      color: #334155;
      font-weight: 600;
      padding: 4px 6px;
    }
    .table-card-items td {
      padding: 4px 6px;
      vertical-align: middle;
      background-color: #ffffff;
    }

    .cursor-pointer { cursor: pointer; }

    @media (max-width: 576px) {
      .main-content {
        padding: 12px 8px !important;
      }
      .admin-order-card {
        padding: 10px;
      }
      .card-header-responsive {
        flex-direction: column;
        align-items: flex-start !important;
        gap: 6px;
      }
      .card-footer-responsive {
        flex-direction: column;
        align-items: stretch !important;
        gap: 8px;
      }
      .card-footer-responsive .btn {
        width: 100%;
      }
      .modal-dialog {
        margin: 8px;
      }
    }
  </style>
</head>
<body>

<?php include "../sidebar.php"; ?>

<div class="main-content">
  <!-- Header Bar -->
  <div class="admin-page-header">
    <div>
      <div class="admin-header-title h5 mb-0 fw-bold">
        <i class="fas fa-history me-2 text-warning"></i>Riwayat Penyewaan & Transaksi
      </div>
    </div>

    <!-- Search Bar -->
    <div class="admin-header-actions">
      <div class="w-100" style="max-width: 320px;">
        <input type="text" id="liveSearchSewa" class="form-control form-control-sm search-input-admin rounded-pill px-3"
               placeholder="Cari transaksi sewa...">
      </div>
    </div>
  </div>

  <div class="alert alert-info py-2 px-3 mb-3 d-flex align-items-center" style="font-size: 0.78rem;">
    <i class="fas fa-info-circle me-2 text-primary fs-6 flex-shrink-0"></i>
    <div>
      <strong>Alur Antrian FIFO:</strong>
      <span class="d-block text-muted" style="font-size: 0.73rem;">
        Transaksi diproses berurutan per tab. Selesaikan transaksi teratas terlebih dahulu untuk membuka kunci edit antrean berikutnya.
      </span>
    </div>
  </div>

  <?php if (!empty($_SESSION['flash_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show mb-3 py-2 small" role="alert">
      <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
      <button type="button" class="btn-close py-2" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-3 py-2 small" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
      <button type="button" class="btn-close py-2" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Filter Periode Bulan & Tahun -->
  <div class="card p-2.5 p-md-3 mb-3 border-0 shadow-sm rounded-3 bg-white">
    <form method="GET" class="row g-2 align-items-center">
      <?php if (!empty($activeTab) && $activeTab !== 'sewa_masuk'): ?>
        <input type="hidden" name="tab" value="<?= htmlspecialchars($activeTab) ?>">
      <?php endif; ?>

      <div class="col-6 col-md-4">
        <label class="form-label text-muted small mb-1 fw-bold" style="font-size:0.75rem;"><i class="fas fa-calendar-alt me-1 text-primary"></i> Bulan</label>
        <select name="bulan" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="semua" <?= ($filterBulan === 'semua') ? 'selected' : '' ?>>Semua Bulan</option>
          <?php
          $namaBulan = [
            '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
            '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
            '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
          ];
          foreach ($namaBulan as $blnNum => $blnTxt): ?>
            <option value="<?= $blnNum ?>" <?= ($filterBulan === $blnNum) ? 'selected' : '' ?>><?= $blnTxt ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-6 col-md-4">
        <label class="form-label text-muted small mb-1 fw-bold" style="font-size:0.75rem;"><i class="fas fa-calendar me-1 text-primary"></i> Tahun</label>
        <select name="tahun" class="form-select form-select-sm" onchange="this.form.submit()">
          <option value="semua" <?= ($filterTahun === 'semua') ? 'selected' : '' ?>>Semua Tahun</option>
          <?php foreach ($yearsList as $y): ?>
            <option value="<?= $y ?>" <?= ($filterTahun == $y) ? 'selected' : '' ?>><?= $y ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-12 col-md-4">
        <label class="form-label text-muted small mb-1 fw-bold" style="font-size:0.75rem;"><i class="fas fa-bolt me-1 text-warning"></i> Cepat</label>
        <div class="d-flex gap-1.5">
          <a href="?bulan=<?= date('m') ?>&tahun=<?= date('Y') ?><?= ($activeTab !== 'sewa_masuk') ? '&tab='.$activeTab : '' ?>" class="btn btn-sm btn-outline-primary w-100 <?= ($filterBulan === date('m') && $filterTahun == date('Y')) ? 'active' : '' ?>">Bulan Ini</a>
          <a href="?bulan=semua&tahun=semua<?= ($activeTab !== 'sewa_masuk') ? '&tab='.$activeTab : '' ?>" class="btn btn-sm btn-outline-secondary w-100 <?= ($filterBulan === 'semua' && $filterTahun === 'semua') ? 'active' : '' ?>">Semua Data</a>
        </div>
      </div>
    </form>
  </div>

  <!-- Nav Pills Tabs Responsif -->
  <div class="nav-pills-wrapper mb-3">
    <ul class="nav nav-pills justify-content-start justify-content-md-center gap-2" id="riwayatTabs" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'sewa_masuk') ? 'active' : '' ?>" id="sewa_masuk-tab" data-bs-toggle="pill" data-bs-target="#sewa_masuk" type="button" role="tab">
          <i class="fas fa-inbox me-2"></i>Sewa Masuk (<?= count($sewaMasukFiltered) ?>)
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'berlangsung') ? 'active' : '' ?>" id="berlangsung-tab" data-bs-toggle="pill" data-bs-target="#berlangsung" type="button" role="tab">
          <i class="fas fa-clock me-2"></i>Berlangsung (<?= count($sewaBerlangsungFiltered) ?>)
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($activeTab === 'dibatalkan') ? 'active' : '' ?>" id="dibatalkan-tab" data-bs-toggle="pill" data-bs-target="#dibatalkan" type="button" role="tab">
          <i class="fas fa-times-circle me-2"></i>Dibatalkan (<?= count($sewaDibatalkanFiltered) ?>)
        </button>
      </li>
    </ul>
  </div>
    
  <div class="tab-content">

    <!-- Tab 1: Sewa Masuk -->
    <div class="tab-pane fade <?= ($activeTab === 'sewa_masuk') ? 'show active' : '' ?>" id="sewa_masuk" role="tabpanel">
      <?php if (!empty($sewaMasukPaginated)): ?>
        <div class="row g-2 g-md-3" id="containerSewaMasuk">
          <?php foreach($sewaMasukPaginated as $row):
            $statusColors = [
              'menunggu pembayaran' => 'danger',
              'siap di ambil' => 'warning',
              'siap diambil' => 'warning',
              'diantar' => 'warning',
              'di antar' => 'warning',
            ];
            $statusCleanRow = strtolower(trim($row['status']));
            $color = $statusColors[$statusCleanRow] ?? 'warning';
            $isMenungguBayar = ($statusCleanRow === 'menunggu pembayaran');
            $isLocked = $row['is_locked'] ?? false;
          ?>
          <div class="col-lg-6 col-12 admin-card-item">
            <div class="admin-order-card <?= ($isMenungguBayar || $isLocked) ? 'card-locked' : '' ?>">
              <div class="d-flex justify-content-between align-items-center gap-1 mb-2 pb-1.5 border-bottom card-header-responsive">
                <div class="d-flex align-items-center gap-1 flex-wrap">
                  <span class="badge bg-secondary px-1.5 py-0.5 rounded font-monospace" style="font-size: 0.68rem;">
                    #<?= (int)$row['queue_no']; ?>
                  </span>
                  <span class="badge bg-dark font-monospace px-1.5 py-0.5 rounded" style="font-size: 0.70rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($row['no_tagihan']); ?>
                  </span>
                  <span class="badge bg-<?= $color; ?> px-1.5 py-0.5 rounded text-capitalize" style="font-size: 0.68rem;">
                    <?= htmlspecialchars($row['status']); ?>
                  </span>
                </div>
                <span class="text-muted ms-auto ms-sm-0" style="font-size: 0.70rem;">
                  <i class="far fa-calendar-alt me-1"></i><?= date('d M Y', strtotime($row['tanggal_sewa'])); ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-1.5">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block text-truncate" style="font-size: 0.80rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']); ?>
                  </span>
                  <small class="text-muted d-block text-truncate" style="font-size: 0.70rem;"><?= htmlspecialchars($row['email']); ?></small>
                </div>
                <span class="badge bg-light text-dark border px-2 py-0.5 flex-shrink-0" style="font-size: 0.68rem;">
                  <?= htmlspecialchars($row['metode_pengambilan']); ?>
                </span>
              </div>

              <!-- Tabel Barang 2 Kolom Sejajar -->
              <?= renderCardItemsTable($row['items']); ?>

              <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 0.70rem;">
                <span>Total: <strong><?= (int)$row['total_qty']; ?> unit</strong> &bull; <strong><?= (int)$row['durasi']; ?> hari</strong></span>
                <?php if ($isMenungguBayar): ?>
                  <span class="text-danger fw-bold"><i class="fa fa-clock me-1"></i>Belum Bayar</span>
                <?php elseif ($isLocked): ?>
                  <span class="text-secondary" title="Menunggu antrian #<?= (int)$row['blocking_queue_no']; ?>"><i class="fa fa-lock me-1"></i>Terkunci Antrian #<?= (int)$row['blocking_queue_no']; ?></span>
                <?php endif; ?>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto card-footer-responsive">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.65rem;">Total Biaya</small>
                  <span class="fw-bold text-success" style="font-size: 0.90rem;">Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?></span>
                </div>

                <div class="d-flex align-items-center gap-1 w-100 w-sm-auto justify-content-end">
                  <?php if ($isMenungguBayar): ?>
                    <button class="btn btn-sm btn-secondary opacity-75 flex-fill flex-sm-grow-0" disabled title="Terkunci: Belum Bayar">
                      <i class="fa fa-lock me-1"></i>Status
                    </button>
                  <?php elseif ($isLocked): ?>
                    <button class="btn btn-sm btn-secondary flex-fill flex-sm-grow-0" disabled title="Terkunci Antrian #<?= (int)$row['blocking_queue_no']; ?>">
                      <i class="fa fa-lock me-1"></i>Status
                    </button>
                  <?php else: ?>
                    <button class="btn btn-sm btn-warning flex-fill flex-sm-grow-0" data-bs-toggle="modal" data-bs-target="#editStatusModal" 
                      data-id="<?= (int)$row['primary_id']; ?>" 
                      data-status="<?= htmlspecialchars($row['status']); ?>" 
                      data-notagihan="<?= htmlspecialchars($row['no_tagihan']); ?>">
                      <i class="fa fa-edit me-1"></i>Status
                    </button>
                  <?php endif; ?>

                  <button 
                    class="btn btn-sm btn-outline-primary lihat-detail-btn flex-fill flex-sm-grow-0" 
                    data-bs-toggle="modal" 
                    data-bs-target="#detailModal"
                    data-invoice='<?= htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>'
                  ><i class="fas fa-info-circle me-1"></i>Detail</button>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= renderPaginationBar($pageMasuk, $totalPagesMasuk, $totalItemsMasuk, count($sewaMasukPaginated), 'page_masuk') ?>

      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border-0 shadow-sm">
          <i class="fas fa-inbox fs-2 text-muted mb-2"></i>
          <h6 class="fw-bold mb-1">Belum Ada Sewa Masuk</h6>
          <p class="text-muted small mb-0">Tidak ada transaksi yang menunggu tindakan untuk periode ini.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- Tab 2: Sewa Berlangsung -->
    <div class="tab-pane fade <?= ($activeTab === 'berlangsung') ? 'show active' : '' ?>" id="berlangsung" role="tabpanel">
      <?php if (!empty($sewaBerlangsungPaginated)): ?>
        <div class="row g-2 g-md-3" id="containerBerlangsung">
          <?php foreach($sewaBerlangsungPaginated as $row):
            $statusCleanRow = strtolower(trim($row['status']));
            $color = ($statusCleanRow === 'selesai') ? 'success' : 'primary';
            $isLocked = $row['is_locked'] ?? false;
          ?>
          <div class="col-lg-6 col-12 admin-card-item">
            <div class="admin-order-card <?= ($isLocked) ? 'card-locked' : '' ?>">
              <div class="d-flex justify-content-between align-items-center gap-1 mb-2 pb-1.5 border-bottom card-header-responsive">
                <div class="d-flex align-items-center gap-1 flex-wrap">
                  <span class="badge bg-secondary px-1.5 py-0.5 rounded font-monospace" style="font-size: 0.68rem;">
                    #<?= (int)$row['queue_no']; ?>
                  </span>
                  <span class="badge bg-dark font-monospace px-1.5 py-0.5 rounded" style="font-size: 0.70rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($row['no_tagihan']); ?>
                  </span>
                  <span class="badge bg-<?= $color; ?> px-1.5 py-0.5 rounded text-capitalize" style="font-size: 0.68rem;">
                    <?= htmlspecialchars($row['status']); ?>
                  </span>
                </div>
                <span class="text-muted ms-auto ms-sm-0" style="font-size: 0.70rem;">
                  <i class="far fa-calendar-alt me-1"></i><?= date('d M Y', strtotime($row['tanggal_sewa'])); ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-1.5">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block text-truncate" style="font-size: 0.80rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']); ?>
                  </span>
                  <small class="text-muted d-block text-truncate" style="font-size: 0.70rem;"><?= htmlspecialchars($row['email']); ?></small>
                </div>
                <span class="badge bg-light text-dark border px-2 py-0.5 flex-shrink-0" style="font-size: 0.68rem;">
                  <?= htmlspecialchars($row['metode_pengambilan']); ?>
                </span>
              </div>

              <?= renderCardItemsTable($row['items']); ?>

              <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 0.70rem;">
                <span>Total: <strong><?= (int)$row['total_qty']; ?> unit</strong> &bull; <strong><?= (int)$row['durasi']; ?> hari</strong></span>
                <?php if ($isLocked): ?>
                  <span class="text-secondary" title="Menunggu antrian #<?= (int)$row['blocking_queue_no']; ?>"><i class="fa fa-lock me-1"></i>Terkunci Antrian #<?= (int)$row['blocking_queue_no']; ?></span>
                <?php endif; ?>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto card-footer-responsive">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.65rem;">Total Biaya</small>
                  <span class="fw-bold text-success" style="font-size: 0.90rem;">Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?></span>
                </div>

                <div class="d-flex align-items-center gap-1 w-100 w-sm-auto justify-content-end">
                  <?php if ($isLocked): ?>
                    <button class="btn btn-sm btn-secondary flex-fill flex-sm-grow-0" disabled title="Terkunci Antrian #<?= (int)$row['blocking_queue_no']; ?>">
                      <i class="fa fa-lock me-1"></i>Status
                    </button>
                  <?php else: ?>
                    <button class="btn btn-sm btn-warning flex-fill flex-sm-grow-0" data-bs-toggle="modal" data-bs-target="#editStatusModal" 
                      data-id="<?= (int)$row['primary_id']; ?>" 
                      data-status="<?= htmlspecialchars($row['status']); ?>" 
                      data-notagihan="<?= htmlspecialchars($row['no_tagihan']); ?>">
                      <i class="fa fa-edit me-1"></i>Status
                    </button>
                  <?php endif; ?>

                  <button 
                    class="btn btn-sm btn-outline-primary lihat-detail-btn flex-fill flex-sm-grow-0" 
                    data-bs-toggle="modal" 
                    data-bs-target="#detailModal"
                    data-invoice='<?= htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>'
                  ><i class="fas fa-info-circle me-1"></i>Detail</button>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= renderPaginationBar($pageBerlangsung, $totalPagesBerlangsung, $totalItemsBerlangsung, count($sewaBerlangsungPaginated), 'page_berlangsung') ?>

      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border-0 shadow-sm">
          <i class="fas fa-box-open fs-2 text-muted mb-2"></i>
          <h6 class="fw-bold mb-1">Belum Ada Sewa Berlangsung</h6>
          <p class="text-muted small mb-0">Tidak ada pesanan aktif untuk periode yang dipilih.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- Tab 3: Dibatalkan -->
    <div class="tab-pane fade <?= ($activeTab === 'dibatalkan') ? 'show active' : '' ?>" id="dibatalkan" role="tabpanel">
      <?php if (!empty($sewaDibatalkanPaginated)): ?>
        <div class="row g-2 g-md-3" id="containerDibatalkan">
          <?php foreach($sewaDibatalkanPaginated as $row): ?>
          <div class="col-lg-6 col-12 admin-card-item">
            <div class="admin-order-card">
              <div class="d-flex justify-content-between align-items-center gap-1 mb-2 pb-1.5 border-bottom card-header-responsive">
                <div class="d-flex align-items-center gap-1 flex-wrap">
                  <span class="badge bg-dark font-monospace px-1.5 py-0.5 rounded" style="font-size: 0.70rem;">
                    <i class="fas fa-receipt me-1"></i><?= htmlspecialchars($row['no_tagihan']); ?>
                  </span>
                  <?php if ($row['status'] === 'Ditolak'): ?>
                    <span class="badge bg-danger px-1.5 py-0.5 rounded" style="font-size: 0.68rem;">Ditolak</span>
                    <?php if (!empty($row['is_ditolak'])): ?>
                      <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-1.5 py-0.5 rounded" style="font-size: 0.65rem;">
                        <i class="fas fa-undo-alt me-1"></i>DP Kembalikan
                      </span>
                    <?php endif; ?>
                  <?php elseif ($row['status'] === 'Batal Otomatis'): ?>
                    <span class="badge bg-danger px-1.5 py-0.5 rounded" style="font-size: 0.68rem;">
                      <i class="fas fa-clock me-1"></i>Batal Otomatis
                    </span>
                  <?php else: ?>
                    <span class="badge bg-secondary px-1.5 py-0.5 rounded" style="font-size: 0.68rem;">
                      <i class="fas fa-user-times me-1"></i>Dibatalkan User
                    </span>
                  <?php endif; ?>
                </div>
                <span class="text-muted ms-auto ms-sm-0" style="font-size: 0.70rem;">
                  <i class="fas fa-times-circle text-danger me-1"></i><?= htmlspecialchars($row['dibatalkan_pada'] ?? '-'); ?>
                </span>
              </div>

              <div class="d-flex justify-content-between align-items-center mb-1.5">
                <div class="text-truncate me-2">
                  <span class="fw-bold text-dark d-block text-truncate" style="font-size: 0.80rem;">
                    <i class="fas fa-user-circle me-1 text-primary"></i><?= htmlspecialchars($row['nama']); ?>
                  </span>
                  <small class="text-muted d-block text-truncate" style="font-size: 0.70rem;"><?= htmlspecialchars($row['email']); ?></small>
                </div>
                <span class="badge bg-light text-dark border px-2 py-0.5 flex-shrink-0" style="font-size: 0.68rem;">
                  <?= htmlspecialchars($row['metode_pengambilan']); ?>
                </span>
              </div>

              <?= renderCardItemsTable($row['items']); ?>

              <div class="d-flex justify-content-between text-muted mb-2" style="font-size: 0.70rem;">
                <span>Total: <strong><?= (int)$row['total_qty']; ?> unit</strong> &bull; <strong><?= (int)$row['durasi']; ?> hari</strong></span>
                <span class="text-danger small"><?= htmlspecialchars($row['status']); ?></span>
              </div>

              <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto card-footer-responsive">
                <div>
                  <small class="text-muted d-block" style="font-size: 0.65rem;">Nominal Pemesanan</small>
                  <span class="fw-bold text-secondary" style="font-size: 0.90rem;">Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?></span>
                </div>

                <div class="d-flex align-items-center gap-1 w-100 w-sm-auto justify-content-end">
                  <button 
                    class="btn btn-sm btn-outline-primary lihat-detail-dibatalkan flex-fill flex-sm-grow-0" 
                    data-bs-toggle="modal" 
                    data-bs-target="#modalDibatalkan"
                    data-invoice='<?= htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>'
                  ><i class="fas fa-info-circle me-1"></i>Detail</button>
                </div>
              </div>

            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <?= renderPaginationBar($pageDibatalkan, $totalPagesDibatalkan, $totalItemsDibatalkan, count($sewaDibatalkanPaginated), 'page_dibatalkan') ?>

      <?php else: ?>
        <div class="card p-4 text-center rounded-3 border-0 shadow-sm">
          <i class="fas fa-ban fs-2 text-muted mb-2"></i>
          <h6 class="fw-bold mb-1">Belum Ada Sewa Dibatalkan</h6>
          <p class="text-muted small mb-0">Tidak ada riwayat pembatalan untuk periode yang dipilih.</p>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<!-- Modal Edit Status (Radio Cards) -->
<div class="modal fade" id="editStatusModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <form action="aksi_riwayat.php" method="POST" id="editStatusForm" class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
      <div class="modal-header bg-dark text-white py-3 px-4 border-0">
        <h6 class="modal-title fw-bold mb-0 d-flex align-items-center gap-2">
          <i class="fas fa-sliders-h text-warning fs-5"></i> Update Status Penyewaan
        </h6>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>

      <div class="modal-body p-4 bg-light">
        <input type="hidden" name="id" id="sewaId" />
        
        <div class="card border-0 shadow-sm rounded-3 mb-3">
          <div class="card-body p-3 bg-white rounded-3">
            <div class="row align-items-center g-2">
              <div class="col-6 border-end">
                <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.65rem;">No. Invoice</small>
                <span class="fw-bold text-primary font-monospace fs-6" id="editNoTagihanText">-</span>
              </div>
              <div class="col-6 ps-3">
                <small class="text-muted d-block text-uppercase fw-bold" style="font-size: 0.65rem;">Status Saat Ini</small>
                <div>
                  <span class="badge bg-secondary px-2 py-1" id="editStatusSaatIniBadge">-</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <label class="form-label fw-bold small text-dark mb-2">Pilih Tindakan Status Baru:</label>
        <div id="statusOptionsContainer" class="d-flex flex-column gap-2">
          <!-- Render Opsi Radio via JS -->
        </div>

        <div class="alert alert-warning border-0 shadow-sm small mb-0 mt-3 p-2.5 d-flex align-items-center gap-2 rounded-3" style="font-size:0.75rem;">
          <i class="fas fa-shield-alt text-warning fs-6 flex-shrink-0"></i>
          <div>Perubahan status ini tunduk pada aturan <strong>Antrean FIFO</strong> per transaksi.</div>
        </div>
      </div>

      <div class="modal-footer bg-white border-top py-2.5 px-4 justify-content-end gap-2">
        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3 fw-semibold" data-bs-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-sm btn-primary rounded-pill px-4 fw-bold shadow-sm">
          <i class="fas fa-check-circle me-1"></i> Konfirmasi & Simpan
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Detail Penyewaan -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-dark text-white py-2.5">
        <h6 class="modal-title fw-bold">
          <i class="fas fa-receipt me-2 text-warning"></i> Detail Rincian Transaksi
        </h6>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-3 p-md-4">
        <div class="row g-2 mb-3 p-2.5 bg-light rounded-3 border small">
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Nomor Invoice:</small>
            <span class="badge bg-dark font-monospace" id="detailNoTagihan"></span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Status Penyewaan:</small>
            <span class="badge" id="detailStatusBadge"></span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Nama Penyewa:</small>
            <strong id="detailPenyewa" class="text-dark"></strong>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Email Penyewa:</small>
            <span id="detailEmail" class="text-muted text-truncate d-block"></span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Mulai Sewa:</small>
            <strong id="detailTanggalSewa"></strong>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Durasi Sewa:</small>
            <span><strong id="detailDurasi"></strong> hari</span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Metode:</small>
            <strong id="detailMetode" class="text-primary"></strong>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Checkout:</small>
            <span id="detailTanggalBuat"></span>
          </div>
        </div>

        <div class="fw-bold mb-2 small text-uppercase text-secondary">
          <i class="fas fa-boxes me-1 text-primary"></i> Daftar Alat Disewa
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-bordered table-hover align-middle mb-0" style="font-size: 0.78rem;">
            <thead class="table-secondary text-center">
              <tr>
                <th style="width: 45px;">Foto</th>
                <th>Produk</th>
                <th style="width: 50px;">Qty</th>
                <th style="width: 90px;">Harga</th>
                <th style="width: 100px;">Subtotal</th>
              </tr>
            </thead>
            <tbody id="detailItemsTableBody"></tbody>
          </table>
        </div>

        <div class="bg-light p-2.5 rounded-3 border">
          <div class="d-flex justify-content-between mb-1 small">
            <span>Biaya Ongkir:</span>
            <span class="fw-semibold" id="detailBiayaPengambilan">Rp 0</span>
          </div>
          <div class="d-flex justify-content-between pt-1.5 border-top fw-bold text-success fs-6">
            <span>Total Tagihan:</span>
            <span id="detailSubtotal">Rp 0</span>
          </div>
        </div>

      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm rounded-pill px-3" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Detail Sewa Dibatalkan -->
<div class="modal fade" id="modalDibatalkan" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-danger text-white py-2.5">
        <h6 class="modal-title fw-bold">
          <i class="fas fa-ban me-2"></i> Detail Sewa Dibatalkan
        </h6>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-3 p-md-4">
        <div class="row g-2 mb-3 p-2.5 bg-light rounded-3 border small">
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Nomor Invoice:</small>
            <span class="badge bg-dark font-monospace" id="noTagihanDibatalkan"></span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Status:</small>
            <span class="badge bg-danger">Dibatalkan</span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Nama Penyewa:</small>
            <strong id="penyewaDibatalkan" class="text-dark"></strong>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Email Penyewa:</small>
            <span id="emailDibatalkan" class="text-muted text-truncate d-block"></span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Tanggal Mulai:</small>
            <strong id="tanggalSewaDibatalkan"></strong>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Dibatalkan Pada:</small>
            <span id="dibatalkanPada" class="text-danger fw-semibold"></span>
          </div>
          <div class="col-6 col-sm-6">
            <small class="text-muted d-block">Metode:</small>
            <strong id="metodeDibatalkan" class="text-primary"></strong>
          </div>
        </div>

        <div class="fw-bold mb-2 small text-uppercase text-secondary">
          <i class="fas fa-boxes me-1 text-danger"></i> Daftar Alat Dibatalkan
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-bordered table-hover align-middle mb-0" style="font-size: 0.78rem;">
            <thead class="table-secondary text-center">
              <tr>
                <th style="width: 45px;">Foto</th>
                <th>Produk</th>
                <th style="width: 50px;">Qty</th>
                <th style="width: 90px;">Harga</th>
                <th style="width: 100px;">Subtotal</th>
              </tr>
            </thead>
            <tbody id="itemsDibatalkanTableBody"></tbody>
          </table>
        </div>

        <div class="bg-light p-2.5 rounded-3 border">
          <div class="d-flex justify-content-between mb-1 small">
            <span>Biaya Ongkir:</span>
            <span class="fw-semibold" id="biayapengambilanDibatalkan">Rp 0</span>
          </div>
          <div class="d-flex justify-content-between pt-1.5 border-top fw-bold text-danger fs-6">
            <span>Total Nilai:</span>
            <span id="subtotalDibatalkan">Rp 0</span>
          </div>
        </div>

      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm rounded-pill px-3" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Live Search
document.getElementById('liveSearchSewa').addEventListener('keyup', function () {
    let keyword = this.value.toLowerCase().trim();
    document.querySelectorAll('.admin-card-item').forEach(card => {
        let text = card.textContent.toLowerCase();
        card.style.display = text.includes(keyword) ? '' : 'none';
    });
});

// Edit Status Modal Handler (Radio Action Cards)
const editStatusModal = document.getElementById('editStatusModal');
if (editStatusModal) {
  editStatusModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    const id = button.getAttribute('data-id');
    const statusRaw = button.getAttribute('data-status') || '';
    const status = statusRaw.toLowerCase().trim();
    const notagihan = button.getAttribute('data-notagihan') || '-';

    document.getElementById('sewaId').value = id;
    
    const noTagElem = document.getElementById('editNoTagihanText');
    if (noTagElem) noTagElem.textContent = notagihan;

    const badgeElem = document.getElementById('editStatusSaatIniBadge');
    if (badgeElem) {
      badgeElem.textContent = statusRaw;
      if (status === 'berlangsung') {
        badgeElem.className = 'badge bg-primary px-2.5 py-1';
      } else if (['siap di ambil', 'siap diambil', 'di antar', 'diantar'].includes(status)) {
        badgeElem.className = 'badge bg-warning text-dark px-2.5 py-1';
      } else {
        badgeElem.className = 'badge bg-secondary px-2.5 py-1';
      }
    }

    const optionsContainer = document.getElementById('statusOptionsContainer');
    if (optionsContainer) {
      optionsContainer.innerHTML = '';

      // JIKA DIPANGGIL DARI TAB SEWA MASUK: HANYA TAMPIL OPSI BERLANGSUNG
      if (status !== 'berlangsung') {
        optionsContainer.innerHTML = `
          <label class="card border-2 border-primary bg-white p-3 rounded-3 shadow-sm cursor-pointer position-relative">
            <div class="d-flex align-items-center justify-content-between">
              <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle bg-primary bg-opacity-10 p-2.5 text-primary d-flex align-items-center justify-content-center" style="width: 42px; height: 42px;">
                  <i class="fas fa-box-open fs-5"></i>
                </div>
                <div>
                  <h6 class="fw-bold text-dark mb-0">Ubah ke Berlangsung</h6>
                  <small class="text-muted" style="font-size: 0.73rem;">Alat telah diambil atau diserahkan ke pelanggan</small>
                </div>
              </div>
              <input type="radio" name="status" value="berlangsung" class="form-check-input fs-5 text-primary" checked required />
            </div>
          </label>
        `;
      } 
      // JIKA DIPANGGIL DARI TAB BERLANGSUNG: HANYA TAMPIL OPSI SELESAI
      else {
        optionsContainer.innerHTML = `
          <label class="card border-2 border-success bg-white p-3 rounded-3 shadow-sm cursor-pointer position-relative">
            <div class="d-flex align-items-center justify-content-between">
              <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle bg-success bg-opacity-10 p-2.5 text-success d-flex align-items-center justify-content-center" style="width: 42px; height: 42px;">
                  <i class="fas fa-check-double fs-5"></i>
                </div>
                <div>
                  <h6 class="fw-bold text-dark mb-0">Ubah ke Selesai</h6>
                  <small class="text-muted" style="font-size: 0.73rem;">Alat sudah dikembalikan & stok kembali terisi</small>
                </div>
              </div>
              <input type="radio" name="status" value="selesai" class="form-check-input fs-5 text-success" checked required />
            </div>
          </label>
        `;
      }
    }
  });
}

// Detail Modal Handler (Sewa Masuk & Berlangsung)
document.querySelectorAll('.lihat-detail-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    try {
      const inv = JSON.parse(this.getAttribute('data-invoice'));
      document.getElementById('detailNoTagihan').textContent = inv.no_tagihan || '-';
      document.getElementById('detailPenyewa').textContent = inv.nama || '-';
      document.getElementById('detailEmail').textContent = inv.email || '-';
      document.getElementById('detailDurasi').textContent = inv.durasi || '1';
      document.getElementById('detailTanggalSewa').textContent = inv.tanggal_sewa || '-';
      document.getElementById('detailTanggalBuat').textContent = inv.tanggal_buat || '-';
      document.getElementById('detailMetode').textContent = inv.metode_pengambilan || '-';
      document.getElementById('detailBiayaPengambilan').textContent = 'Rp ' + Number(inv.total_ongkir || 0).toLocaleString('id-ID');
      document.getElementById('detailSubtotal').textContent = 'Rp ' + Number(inv.total_biaya || 0).toLocaleString('id-ID');

      const badge = document.getElementById('detailStatusBadge');
      if (badge) {
        badge.textContent = inv.status || '-';
        const stLower = (inv.status || '').toLowerCase().trim();
        const colors = {
          'menunggu pembayaran': 'bg-danger',
          'berlangsung': 'bg-primary',
          'siap di ambil': 'bg-warning text-dark',
          'siap diambil': 'bg-warning text-dark',
          'di antar': 'bg-warning text-dark',
          'diantar': 'bg-warning text-dark',
          'selesai': 'bg-success',
          'dibatalkan': 'bg-danger'
        };
        badge.className = 'badge ' + (colors[stLower] || 'bg-primary');
      }

      const tbody = document.getElementById('detailItemsTableBody');
      tbody.innerHTML = '';
      if (inv.items && inv.items.length > 0) {
        inv.items.forEach(it => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td class="text-center">
              <img src="${it.gambar_path}" alt="alat" style="width: 32px; height: 32px; object-fit: cover; border-radius: 4px;" class="border">
            </td>
            <td>
              <strong class="text-dark d-block text-truncate" style="max-width: 120px;">${it.nama_produk}</strong>
            </td>
            <td class="text-center fw-bold">${it.qty}</td>
            <td class="text-end">Rp ${Number(it.harga_satuan_val || it.total_harga || 0).toLocaleString('id-ID')}</td>
            <td class="text-end fw-bold text-success">Rp ${Number(it.subtotal_item || 0).toLocaleString('id-ID')}</td>
          `;
          tbody.appendChild(tr);
        });
      }
    } catch(e) {
      console.error(e);
    }
  });
});

// Detail Modal Handler (Sewa Dibatalkan)
document.querySelectorAll('.lihat-detail-dibatalkan').forEach(btn => {
  btn.addEventListener('click', function () {
    try {
      const inv = JSON.parse(this.getAttribute('data-invoice'));
      document.getElementById('noTagihanDibatalkan').textContent = inv.no_tagihan || '-';
      document.getElementById('penyewaDibatalkan').textContent = inv.nama || '-';
      document.getElementById('emailDibatalkan').textContent = inv.email || '-';
      document.getElementById('tanggalSewaDibatalkan').textContent = inv.tanggal_sewa || '-';
      document.getElementById('dibatalkanPada').textContent = inv.dibatalkan_pada || '-';
      document.getElementById('metodeDibatalkan').textContent = inv.metode_pengambilan || '-';
      document.getElementById('biayapengambilanDibatalkan').textContent = 'Rp ' + Number(inv.total_ongkir || 0).toLocaleString('id-ID');
      document.getElementById('subtotalDibatalkan').textContent = 'Rp ' + Number(inv.total_biaya || 0).toLocaleString('id-ID');

      const tbody = document.getElementById('itemsDibatalkanTableBody');
      tbody.innerHTML = '';
      if (inv.items && inv.items.length > 0) {
        inv.items.forEach(it => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td class="text-center">
              <img src="${it.gambar_path}" alt="alat" style="width: 32px; height: 32px; object-fit: cover; border-radius: 4px;" class="border">
            </td>
            <td>
              <strong class="text-dark d-block text-truncate" style="max-width: 120px;">${it.nama_produk}</strong>
            </td>
            <td class="text-center fw-bold">${it.qty}</td>
            <td class="text-end">Rp ${Number(it.harga_satuan_val || it.total_harga || 0).toLocaleString('id-ID')}</td>
            <td class="text-end fw-bold text-danger">Rp ${Number(it.subtotal_item || 0).toLocaleString('id-ID')}</td>
          `;
          tbody.appendChild(tr);
        });
      }
    } catch(e) {
      console.error(e);
    }
  });
});

// Sinkronkan Tab ke URL Query Parameter
document.addEventListener('DOMContentLoaded', function() {
  const tabButtons = document.querySelectorAll('#riwayatTabs button[data-bs-toggle="pill"]');
  tabButtons.forEach(btn => {
    btn.addEventListener('shown.bs.tab', function(e) {
      const target = e.target.getAttribute('data-bs-target');
      if (target) {
        const tabName = target.replace('#', '');
        const url = new URL(window.location);
        url.searchParams.set('tab', tabName);
        window.history.replaceState({}, '', url);
      }
    });
  });
});
</script>

</body>
</html>