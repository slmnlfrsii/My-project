<?php
session_start();
require_once "../../koneksi.php";
include '../cek_login.php';

// Tab Aktif (Default: berlangsung, atau dibatalkan)
$activeTab = (isset($_GET['tab']) && strtolower(trim($_GET['tab'])) === 'dibatalkan') ? 'dibatalkan' : 'berlangsung';

// Query data sewa sesuai urutan antrian (tanggal_buat ASC, id ASC)
/* =========================================================================
   [FIFO LOGIC] 1. QUERY SEWA BERLANGSUNG DIURUTKAN SECARA FIFO
   - Data sewa aktif diurutkan berdasarkan antrean pemesanan terlama (tanggal_buat ASC, id ASC)
   ========================================================================= */
$sewaBerlangsungQuery = $conn->query("
    SELECT sewa.*, users.nama, users.email, 
           COALESCE(alat.harga_per_hari, sewa.total_harga) AS harga_satuan_alat,
           alat.harga_per_hari AS harga_per_hari_alat
    FROM sewa 
    JOIN users ON sewa.id_users = users.id 
    LEFT JOIN alat ON sewa.id_alat = alat.id
    WHERE sewa.status NOT IN ('selesai', 'Dibatalkan', 'dibatalkan')
    ORDER BY COALESCE(sewa.tanggal_buat, '1970-01-01 00:00:00') ASC, sewa.id ASC
");
$sewaSelesai = $conn->query("
    SELECT sewa.*, users.nama, users.email, 
           COALESCE(alat.harga_per_hari, sewa.total_harga) AS harga_satuan_alat,
           alat.harga_per_hari AS harga_per_hari_alat
    FROM sewa 
    JOIN users ON sewa.id_users = users.id 
    LEFT JOIN alat ON sewa.id_alat = alat.id
    WHERE status = 'selesai'
    ORDER BY sewa.tanggal_dikembalikan DESC, sewa.id DESC
");
$sewaDibatalkan = $conn->query("
    SELECT sewa_dibatalkan.*, users.nama, users.email, 
           COALESCE(alat.harga_per_hari, sewa_dibatalkan.total_harga) AS harga_satuan_alat,
           alat.harga_per_hari AS harga_per_hari_alat
    FROM sewa_dibatalkan 
    JOIN users ON sewa_dibatalkan.id_users = users.id
    LEFT JOIN alat ON sewa_dibatalkan.nama_produk = alat.nama
    ORDER BY sewa_dibatalkan.dibatalkan_pada DESC, sewa_dibatalkan.id DESC
");

// Pre-process dan grouping data sewa per Nomor Invoice
$sewaBerlangsungList = [];
$groupedBerlangsung = [];

if ($sewaBerlangsungQuery && $sewaBerlangsungQuery->num_rows > 0) {
    while ($r = $sewaBerlangsungQuery->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        
        $harga_satuan = (float)($r['harga_per_hari_alat'] ?? $r['harga_satuan_alat'] ?? $r['total_harga']);
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['harga_satuan_val'] = $harga_satuan;
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $r['gambar_path'] = !empty($r['gambar']) ? "../uploads/alat/" . $r['gambar'] : "../../assets/images/no-image.png";

        $groupedBerlangsung[$noTag][] = $r;
    }
}

/* =========================================================================
   [FIFO LOGIC] 2. SMART FIFO LOCKING PADA RIWAYAT PENYEWAAN ADMIN
   - Antrean pesanan sebelum status 'Siap di ambil' / 'Di antar' harus diproses berurutan
   ========================================================================= */
$previousIsPending = false;
$clearedStatuses = ['siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung', 'selesai'];
$queueCounter = 1;

foreach ($groupedBerlangsung as $noTag => $items) {
    $primary = $items[0];
    $statusClean = strtolower(trim($primary['status']));
    
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $product_names = [];
    $item_ids = [];

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $product_names[] = $it['nama_produk'] . ' (x' . $it['qty'] . ')';
        $item_ids[] = (int)$it['id'];
    }

    $is_locked = ($previousIsPending && !in_array($statusClean, $clearedStatuses));
    if (!in_array($statusClean, $clearedStatuses)) {
        $previousIsPending = true;
    }

    $sewaBerlangsungList[] = [
        'queue_no' => $queueCounter++,
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'item_ids' => $item_ids,
        'id_users' => $primary['id_users'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => $primary['status'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'tanggal_buat' => $primary['tanggal_buat'],
        'tanggal_dikembalikan' => $primary['tanggal_dikembalikan'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'nama_produk_list' => implode(', ', $product_names),
        'items' => $items,
        'is_locked' => $is_locked
    ];
}

// Grouping Sewa Dibatalkan
$sewaDibatalkanList = [];
$groupedDibatalkan = [];
if ($sewaDibatalkan && $sewaDibatalkan->num_rows > 0) {
    while ($r = $sewaDibatalkan->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['dibatalkan_pada'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)($r['harga_per_hari_alat'] ?? $r['harga_satuan_alat'] ?? $r['total_harga']);
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['harga_satuan_val'] = $harga_satuan;
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $r['gambar_path'] = !empty($r['gambar']) ? "../uploads/alat/" . $r['gambar'] : "../../assets/images/no-image.png";
        $groupedDibatalkan[$noTag][] = $r;
    }
}
foreach ($groupedDibatalkan as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;
    $product_names = [];
    $item_ids = [];
    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
        $product_names[] = $it['nama_produk'] . ' (x' . $it['qty'] . ')';
        $item_ids[] = (int)$it['id'];
    }
    $sewaDibatalkanList[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'item_ids' => $item_ids,
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => $primary['status'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'dibatalkan_pada' => $primary['dibatalkan_pada'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'nama_produk_list' => implode(', ', $product_names),
        'items' => $items
    ];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Riwayat Penyewaan - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <link rel="stylesheet" href="https://npmcdn.com/flatpickr/dist/themes/airbnb.css">
  <style>
    body { background: #f8f9fa; }
    .flatpickr-day.flatpickr-disabled, 
    .flatpickr-day.flatpickr-disabled:hover,
    .flatpickr-day.prevMonthDay, 
    .flatpickr-day.nextMonthDay {
        color: #94a3b8 !important;
        background: #f1f5f9 !important;
        border-color: transparent !important;
        cursor: not-allowed !important;
        pointer-events: none !important;
        opacity: 0.4 !important;
        text-decoration: line-through !important;
    }
    .flatpickr-calendar {
        z-index: 99999 !important;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2) !important;
        border-radius: 12px !important;
    }
    .card-sewa {
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      background: #fff;
      margin-bottom: 1.5rem;
    }
    .badge-status {
      text-transform: capitalize;
      font-size: 0.85rem;
      padding: 0.35em 0.6em;
    }
    .nav-pills .nav-link.active {
      background-color:rgba(0, 0, 0, 0.76);
      color: white;
      font-weight: 600;
    }
    table {
      background: black;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(32, 27, 27, 0.05);
    }
    th, td {
      vertical-align: middle !important;
    }
    .img-thumb {
      width: 60px;
      height: 45px;
      object-fit: cover;
      border-radius: 5px;
    }
    .aksi-btn {
      display: flex;
      gap: 5px;
      align-items: center;
      justify-content: center;
      flex-wrap: nowrap;
      white-space: nowrap;
    }
    .modal-section-title {
      font-size: 0.95rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #495057;
      border-bottom: 2px solid #e9ecef;
      padding-bottom: 6px;
      margin-bottom: 12px;
    }
    .alat-card-modal {
      border: 2px solid #e2e8f0;
      border-radius: 10px;
      padding: 10px;
      background: #fff;
      transition: all 0.2s ease;
      cursor: pointer;
      height: 100%;
    }
    .alat-card-modal:hover {
      border-color: #3b82f6;
      box-shadow: 0 4px 12px rgba(59, 130, 246, 0.12);
    }
    .alat-card-modal.active-card {
      border-color: #0d6efd;
      background-color: #f0f7ff;
    }
    .alat-card-modal.disabled-card {
      opacity: 0.55;
      cursor: not-allowed;
      background: #f8fafc;
    }
    .alat-thumb-modal {
      width: 65px;
      height: 65px;
      object-fit: cover;
      border-radius: 8px;
    }
    .summary-box-modal {
      background: #f8fafc;
      border: 1.5px solid #cbd5e1;
      border-radius: 10px;
      padding: 14px;
    }
  </style>
</head>
<body>

<?php include "../sidebar.php"; ?>

<div class="main-content">
  <h3 class="mb-3 fw-bold"><i class="fas fa-history me-2"></i>Riwayat Penyewaan</h3>

  <div class="alert alert-info py-2 mb-3 d-flex align-items-center">
    <i class="fas fa-stream fa-2x me-3 text-primary"></i>
    <div>
      <strong>Sistem Antrian FIFO (First-In, First-Out):</strong>
      <div class="small">Pesanan diproses berurutan berdasarkan waktu checkout. Tombol edit status pesanan berikutnya akan terbuka setelah pesanan pada antrian sebelumnya telah diproses (Siap di ambil / Di antar / Berlangsung).</div>
    </div>
  </div>

  <?php if (!empty($_SESSION['flash_success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['flash_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-3">
    <!-- Tombol trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambahSewaUser">
      <i class="fas fa-plus me-1"></i> Tambah Sewa
    </button>
    <div style="max-width: 320px; width: 100%;">
      <input type="text" id="liveSearchSewa" class="form-control"
             placeholder="Cari nama / alat / status...">
    </div>
  </div>
  <ul class="nav nav-pills mb-3 justify-content-center" id="riwayatTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= ($activeTab === 'berlangsung') ? 'active' : '' ?>" id="berlangsung-tab" data-bs-toggle="pill" data-bs-target="#berlangsung" type="button" role="tab" aria-controls="berlangsung" aria-selected="<?= ($activeTab === 'berlangsung') ? 'true' : 'false' ?>">Sewa Berlangsung</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link <?= ($activeTab === 'dibatalkan') ? 'active' : '' ?>" id="dibatalkan-tab" data-bs-toggle="pill" data-bs-target="#dibatalkan" type="button" role="tab" aria-controls="dibatalkan" aria-selected="<?= ($activeTab === 'dibatalkan') ? 'true' : 'false' ?>">Dibatalkan</button>
    </li>

  </ul>

  <div class="tab-content">

    <!-- Sewa Berlangsung -->
    <div class="tab-pane fade <?= ($activeTab === 'berlangsung') ? 'show active' : '' ?>" id="berlangsung" role="tabpanel" aria-labelledby="berlangsung-tab">
      <?php if (!empty($sewaBerlangsungList)): ?>
        <div class="table-responsive">
        <table class="table table-bordered table-hover bg-white align-middle" id="tabelBerlangsung">
          <thead class="table-secondary text-center">
            <tr>
              <th style="width: 70px;">Antrian</th>
              <th style="width: 160px;">No. Tagihan</th>
              <th>Penyewa</th>
              <th>Alat Disewa</th>
              <th style="width: 150px;">Total Biaya</th>
              <th style="width: 150px;">Status</th>
              <th style="width: 140px;">Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach($sewaBerlangsungList as $row):
            $statusColors = [
              'menunggu pembayaran' => 'danger',
              'berlangsung' => 'primary',
              'siap di ambil' => 'warning',
              'siap diambil' => 'warning',
              'diantar' => 'warning',
              'di antar' => 'warning',
              'dibatalkan' => 'danger',
              'selesai' => 'success',
            ];
            $color = $statusColors[strtolower(trim($row['status']))] ?? 'warning';
          ?>
          <tr>
            <td class="text-center fw-bold">
              <span class="badge bg-secondary fs-6">#<?= (int)$row['queue_no']; ?></span>
            </td>
            <td><span class="badge bg-dark"><?= htmlspecialchars($row['no_tagihan']); ?></span></td>
            <td>
              <strong><?= htmlspecialchars($row['nama']); ?></strong><br>
              <small class="text-muted"><?= htmlspecialchars($row['email']); ?></small>
            </td>
            <td>
              <div class="d-flex flex-column gap-2">
                <?php foreach($row['items'] as $item): ?>
                  <div class="d-flex align-items-center gap-2">
                    <img src="<?= htmlspecialchars($item['gambar_path']); ?>" alt="alat" class="img-thumb border flex-shrink-0" style="width: 36px; height: 36px; object-fit: cover; border-radius: 6px;">
                    <div>
                      <div class="fw-semibold text-dark small"><?= htmlspecialchars($item['nama_produk']); ?></div>
                      <small class="text-muted"><span class="badge bg-light text-dark border">x<?= (int)$item['qty']; ?></span> &bull; Rp<?= number_format($item['subtotal_item'], 0, ',', '.'); ?></small>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            </td>
            <td class="fw-bold text-success">
              Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?>
              <br><small class="text-muted fw-normal"><?= (int)$row['total_qty']; ?> Unit &bull; <?= (int)$row['durasi']; ?> Hari</small>
            </td>
            <td>
              <span class="badge bg-<?= $color; ?> badge-status"><?= htmlspecialchars($row['status']); ?></span>
              <?php if ($row['is_locked']): ?>
                <br><small class="badge bg-secondary text-white mt-1" title="Menunggu antrian sebelumnya diproses"><i class="fa fa-lock me-1"></i>Antrian Terkunci</small>
              <?php endif; ?>
            </td>
            <td class="text-center">
              <div class="aksi-btn">
                <?php if (!$row['is_locked']): ?>
                  <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editStatusModal" 
                    data-id="<?= (int)$row['primary_id']; ?>" data-status="<?= htmlspecialchars($row['status']); ?>" data-notagihan="<?= htmlspecialchars($row['no_tagihan']); ?>" title="Edit Status Seluruh Item">
                    <i class="fa fa-edit"></i>
                  </button>
                <?php else: ?>
                  <button class="btn btn-sm btn-secondary" disabled title="Terkunci: Menunggu antrian sebelumnya diproses (Siap di ambil / Di antar / Berlangsung)">
                    <i class="fa fa-lock"></i>
                  </button>
                <?php endif; ?>
                <button 
                  class="btn btn-sm btn-outline-primary lihat-detail-btn" 
                  data-bs-toggle="modal" 
                  data-bs-target="#detailModal"
                  data-invoice='<?= htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>'
                  title="Lihat Detail Transaksi"
                ><i class="fas fa-info-circle"></i></button>
                <form method="POST" action="aksi_riwayat.php" onsubmit="return confirm('Hapus seluruh item dalam invoice ini?')" style="display:inline;">
                  <input type="hidden" name="id" value="<?= (int)$row['primary_id']; ?>">
                  <input type="hidden" name="tabel" value="sewa">
                  <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fa fa-trash"></i></button>
                </form>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        </table>
        </div>
      <?php else: ?>
        <p class="text-center text-muted mt-3">Belum ada data sewa berlangsung.</p>
      <?php endif; ?>
    </div>

    <!-- Dibatalkan -->
    <div class="tab-pane fade <?= ($activeTab === 'dibatalkan') ? 'show active' : '' ?>" id="dibatalkan" role="tabpanel" aria-labelledby="dibatalkan-tab">
      <?php if (!empty($sewaDibatalkanList)): ?>
        <div class="table-responsive">
          <table class="table table-bordered table-hover bg-white align-middle" id="tabelDibatalkan">
            <thead class="table-secondary text-center">
              <tr>
                <th style="width: 60px;">No</th>
                <th style="width: 160px;">No. Tagihan</th>
                <th>Penyewa</th>
                <th>Alat Disewa</th>
                <th style="width: 150px;">Total Biaya</th>
                <th style="width: 130px;">Status</th>
                <th style="width: 110px;">Aksi</th>
              </tr>
            </thead>
            <tbody>
            <?php $no=1; foreach($sewaDibatalkanList as $row): ?>
              <tr>
                <td class="text-center fw-bold"><?= $no++; ?></td>
                <td><span class="badge bg-dark"><?= htmlspecialchars($row['no_tagihan']); ?></span></td>
                <td>
                  <strong><?= htmlspecialchars($row['nama']); ?></strong><br>
                  <small class="text-muted"><?= htmlspecialchars($row['email']); ?></small>
                </td>
                <td>
                  <div class="d-flex flex-column gap-2">
                    <?php foreach($row['items'] as $item): ?>
                      <div class="d-flex align-items-center gap-2">
                        <img src="<?= htmlspecialchars($item['gambar_path']); ?>" alt="alat" class="img-thumb border flex-shrink-0" style="width: 36px; height: 36px; object-fit: cover; border-radius: 6px;">
                        <div>
                          <div class="fw-semibold text-dark small"><?= htmlspecialchars($item['nama_produk']); ?></div>
                          <small class="text-muted"><span class="badge bg-light text-dark border">x<?= (int)$item['qty']; ?></span> &bull; Rp<?= number_format($item['subtotal_item'], 0, ',', '.'); ?></small>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </td>
                <td class="fw-bold text-secondary">
                  Rp<?= number_format($row['total_biaya'], 0, ',', '.'); ?>
                  <br><small class="text-muted fw-normal"><?= (int)$row['total_qty']; ?> Unit &bull; <?= (int)$row['durasi']; ?> Hari</small>
                </td>
                <td><span class="badge bg-danger badge-status"><?= htmlspecialchars($row['status']); ?></span></td>
                <td class="text-center">
                  <div class="aksi-btn">
                    <button 
                      class="btn btn-sm btn-outline-primary lihat-detail-dibatalkan" 
                      data-bs-toggle="modal" 
                      data-bs-target="#modalDibatalkan"
                      data-invoice='<?= htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8'); ?>'
                      title="Lihat Detail Transaksi"
                    >
                      <i class="fas fa-info-circle"></i>
                    </button>
                    <form method="POST" action="aksi_riwayat.php" onsubmit="return confirm('Hapus data ini?')" style="display:inline;">
                      <input type="hidden" name="id" value="<?= (int)$row['primary_id']; ?>">
                      <input type="hidden" name="tabel" value="sewa_dibatalkan">
                      <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fa fa-trash"></i></button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="text-center text-muted mt-3">Belum ada data sewa dibatalkan.</p>
      <?php endif; ?>
    </div>


  </div>
</div>
<!-- Modal Tambah User + Sewa (Redesigned UI) -->
<div class="modal fade" id="modalTambahSewaUser" tabindex="-1" aria-labelledby="modalTambahSewaUserLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <form action="aksi_riwayat.php" method="POST" id="formTambahSewaModal" class="modal-content border-0 shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="modalTambahSewaUserLabel">
          <i class="fas fa-cart-plus me-2 text-warning"></i> Tambah Transaksi Sewa Baru
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-4">
          
          <!-- Bagian 1: Data Penyewa & Waktu Sewa -->
          <div class="modal-section-title">
            <i class="fas fa-user-circle me-1 text-primary"></i> 1. Informasi Penyewa & Jadwal
          </div>
          
          <div class="row g-3 mb-4">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Pilih Pelanggan / User <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text bg-light"><i class="fas fa-user"></i></span>
                <select name="id_users" class="form-select" required id="modalSelectUser">
                  <option value="">-- Pilih Akun User --</option>
                  <?php
                  $users = mysqli_query($conn, "SELECT * FROM users ORDER BY nama ASC");
                  while ($u = mysqli_fetch_assoc($users)) {
                    echo "<option value='{$u['id']}'>{$u['nama']} ({$u['email']})</option>";
                  }
                  ?>
                </select>
              </div>
            </div>

            <div class="col-md-3 col-sm-6">
              <label class="form-label fw-semibold">Tanggal Sewa <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text bg-light text-muted"><i class="fas fa-calendar-alt"></i></span>
                <input type="text" name="tanggal_sewa" id="modalTanggalSewa" class="form-control bg-white" value="<?= date('Y-m-d') ?>" placeholder="Pilih Tanggal" required>
              </div>
            </div>

            <div class="col-md-3 col-sm-6">
              <label class="form-label fw-semibold">Durasi Sewa (Hari) <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text bg-light"><i class="fas fa-clock"></i></span>
                <input type="number" name="durasi" id="modalDurasi" class="form-control" value="1" min="1" required>
              </div>
            </div>

            <div class="col-md-6">
              <label class="form-label fw-semibold">Metode Pengambilan <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-group-text bg-light"><i class="fas fa-truck"></i></span>
                <select name="metode_pengambilan" class="form-select" id="metodePengambilan" required>
                  <option value="Ambil Ke toko">Ambil Ke Toko (Rp 0)</option>
                  <option value="Diantar">Diantar / COD (+Rp 10.000)</option>
                </select>
              </div>
            </div>

            <div class="col-md-6" id="ongkirGroup" style="display:none;">
              <label class="form-label fw-semibold">Biaya Ongkir (Rp)</label>
              <div class="input-group">
                <span class="input-group-text bg-light">Rp</span>
                <input type="number" name="biaya_pengambilan" id="ongkirInput" class="form-control" value="0" min="0" step="1000">
              </div>
            </div>
          </div>

          <!-- Bagian 2: Pilih Alat Outdoor -->
          <div class="d-flex justify-content-between align-items-center mb-2">
            <div class="modal-section-title mb-0 border-0 pb-0">
              <i class="fas fa-campground me-1 text-success"></i> 2. Pilih Alat yang Disewa
            </div>
            <div class="d-flex gap-2">
              <input type="text" id="searchAlatModal" class="form-control form-control-sm" style="width: 220px;" placeholder="🔍 Cari nama alat...">
              <button type="button" class="btn btn-sm btn-outline-secondary" id="btnSelectAllModal">
                <i class="fas fa-check-square me-1"></i> Pilih Semua
              </button>
            </div>
          </div>
          <hr class="mt-1 mb-3">

          <div class="row g-3" id="alatGridModal" style="max-height: 380px; overflow-y: auto; padding: 4px;">
            <?php
            $alat_modal_q = mysqli_query($conn, "SELECT * FROM alat ORDER BY nama ASC");
            while ($a = mysqli_fetch_assoc($alat_modal_q)):
              $is_gas_a = (stripos($a['nama'], 'gas') !== false);
              $stok_awal_a = isset($a['stok_awal']) ? (int)$a['stok_awal'] : 0;
              $sisa_stok_a = isset($a['sisa_stok']) ? (int)$a['sisa_stok'] : 0;
              $is_out_of_stock = ($sisa_stok_a <= 0);
              $gambar_path = !empty($a['gambar']) ? "../uploads/alat/" . $a['gambar'] : "../../assets/images/no-image.png";
            ?>
              <div class="col-md-6 col-lg-4 alat-item-col" data-nama="<?= strtolower(htmlspecialchars($a['nama'])) ?>">
                <div class="alat-card-modal d-flex flex-column justify-content-between <?= $is_out_of_stock ? 'disabled-card' : '' ?>" id="card-alat-<?= $a['id'] ?>" data-id="<?= $a['id'] ?>">
                  
                  <div class="d-flex align-items-start gap-2 mb-2">
                    <input class="form-check-input alat-checkbox mt-1"
                           type="checkbox"
                           name="alat[]"
                           value="<?= $a['id']; ?>"
                           id="chk-alat-<?= $a['id']; ?>"
                           data-id="<?= $a['id']; ?>"
                           data-harga="<?= (int)$a['harga_per_hari']; ?>"
                           data-is-gas="<?= $is_gas_a ? '1' : '0'; ?>"
                           <?= $is_out_of_stock ? 'disabled' : ''; ?>>
                    
                    <img src="<?= htmlspecialchars($gambar_path); ?>" alt="<?= htmlspecialchars($a['nama']); ?>" class="alat-thumb-modal border">
                    
                    <div class="flex-grow-1">
                      <label class="form-check-label fw-bold text-dark d-block mb-1" for="chk-alat-<?= $a['id']; ?>">
                        <?= htmlspecialchars($a['nama']); ?>
                      </label>
                      <div class="text-success fw-semibold small">
                        Rp <?= number_format($a['harga_per_hari'], 0, ',', '.'); ?> / hari
                      </div>
                      <?php if ($is_gas_a): ?>
                        <span class="badge bg-info text-dark" style="font-size: 0.7rem;"><i class="fas fa-fire me-1"></i>Gas (Harga x Qty)</span>
                      <?php endif; ?>
                    </div>
                  </div>

                  <div class="d-flex justify-content-between align-items-center border-top pt-2 mt-1">
                    <div>
                      <?php if ($is_out_of_stock): ?>
                        <span class="badge bg-danger">Stok Habis (0)</span>
                      <?php else: ?>
                        <span class="badge bg-light text-dark border">
                          Sisa: <strong class="text-primary"><?= $sisa_stok_a ?></strong> / <?= $stok_awal_a ?>
                        </span>
                      <?php endif; ?>
                    </div>

                    <div class="d-flex align-items-center gap-1" style="width: 110px;">
                      <span class="small text-muted">Qty:</span>
                      <input type="number"
                             name="qty[<?= $a['id']; ?>]"
                             id="qty-alat-<?= $a['id']; ?>"
                             class="form-control form-control-sm text-center qty-modal-input"
                             min="1"
                             max="<?= $sisa_stok_a; ?>"
                             value="1"
                             data-id="<?= $a['id']; ?>"
                             disabled>
                    </div>
                  </div>

                </div>
              </div>
            <?php endwhile; ?>
          </div>

          <!-- Bagian 3: Ringkasan Estimasi Biaya -->
          <div class="summary-box-modal mt-4">
            <div class="row align-items-center">
              <div class="col-md-7">
                <div class="fw-bold mb-1"><i class="fas fa-calculator me-1 text-primary"></i> Estimasi Total Transaksi:</div>
                <div class="small text-muted" id="summaryBreakdownText">Pilih setidaknya 1 alat untuk melihat rincian biaya.</div>
              </div>
              <div class="col-md-5 text-md-end mt-2 mt-md-0">
                <div class="small text-muted">Total Estimasi Tagihan:</div>
                <h4 class="text-success fw-bold mb-0" id="totalEstimasiModalText">Rp 0</h4>
              </div>
            </div>
          </div>

        </div>
        <div class="modal-footer bg-white border-top shadow-sm py-3 px-4 d-flex justify-content-between align-items-center">
          <div class="text-muted small">
            <i class="fas fa-info-circle me-1 text-primary"></i> Pastikan alat dan data penyewa sudah sesuai sebelum menyimpan.
          </div>
          <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-danger px-3 fw-semibold" data-bs-dismiss="modal">
              <i class="fas fa-times me-1"></i> Batal
            </button>
            <button type="submit" name="tambah_user_sewa" id="btnSubmitModalSewa" class="btn btn-success px-4 fw-bold">
              <i class="fas fa-save me-1"></i> Simpan Transaksi Sewa
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>


<!-- Modal Edit Status -->
<div class="modal fade" id="editStatusModal" tabindex="-1" aria-labelledby="editStatusLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="aksi_riwayat.php" method="POST" id="editStatusForm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editStatusLabel">Edit Status Penyewaan</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="sewaId" />
          <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select name="status" id="status" class="form-select" required>
              <option value="selesai">Selesai</option>
              <option value="berlangsung">Berlangsung</option>
              <option value="siap di ambil">Siap di ambil</option>
              <option value="di antar">Di antar</option>
              <option value="menunggu pembayaran">Menunggu Pembayaran</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
        </div>
      </div>
    </form>
  </div>
</div>
<!-- Modal Detail -->
<!-- Modal Detail Penyewaan (Multi-item Invoice Support) -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title" id="detailModalLabel">
          <i class="fas fa-receipt me-2 text-warning"></i> Detail & Rincian Transaksi Invoice
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-4">
        <!-- Info Header Invoice -->
        <div class="row g-3 mb-3 p-3 bg-light rounded-3 border">
          <div class="col-sm-6">
            <small class="text-muted d-block">Nomor Tagihan / Invoice:</small>
            <span class="badge bg-dark fs-6" id="detailNoTagihan"></span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Status Penyewaan:</small>
            <span class="badge" id="detailStatusBadge"></span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Nama Penyewa:</small>
            <strong id="detailPenyewa" class="text-dark"></strong>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Email Penyewa:</small>
            <span id="detailEmail" class="text-muted"></span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Tanggal Mulai Sewa:</small>
            <strong id="detailTanggalSewa"></strong>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Durasi Sewa:</small>
            <span><strong id="detailDurasi"></strong> hari</span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Metode Pengambilan:</small>
            <strong id="detailMetode" class="text-primary"></strong>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Tanggal Checkout:</small>
            <span id="detailTanggalBuat"></span>
          </div>
        </div>

        <!-- Tabel Daftar Barang Dalam Invoice -->
        <div class="modal-section-title mb-2">
          <i class="fas fa-boxes me-1 text-primary"></i> Daftar Alat yang Disewa
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-bordered table-hover align-middle mb-0">
            <thead class="table-secondary text-center small">
              <tr>
                <th style="width: 55px;">Foto</th>
                <th>Nama Produk</th>
                <th style="width: 70px;">Qty</th>
                <th style="width: 120px;">Harga Satuan</th>
                <th style="width: 130px;">Subtotal</th>
              </tr>
            </thead>
            <tbody id="detailItemsTableBody">
              <!-- Rendered via JavaScript -->
            </tbody>
          </table>
        </div>

        <!-- Rincian Biaya -->
        <div class="bg-light p-3 rounded-3 border">
          <div class="d-flex justify-content-between mb-2 small">
            <span>Biaya Pengambilan / Ongkir:</span>
            <span class="fw-semibold" id="detailBiayaPengambilan">Rp 0</span>
          </div>
          <div class="d-flex justify-content-between pt-2 border-top fw-bold text-success fs-5">
            <span>Total Tagihan Invoice:</span>
            <span id="detailSubtotal">Rp 0</span>
          </div>
        </div>

      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Detail Sewa Dibatalkan -->
<div class="modal fade" id="modalDibatalkan" tabindex="-1" aria-labelledby="modalDibatalkanLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="modalDibatalkanLabel">
          <i class="fas fa-ban me-2"></i> Detail Sewa Dibatalkan
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
      </div>
      <div class="modal-body p-4">
        <!-- Info Header Invoice -->
        <div class="row g-3 mb-3 p-3 bg-light rounded-3 border">
          <div class="col-sm-6">
            <small class="text-muted d-block">Nomor Tagihan / Invoice:</small>
            <span class="badge bg-dark fs-6" id="noTagihanDibatalkan"></span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Status:</small>
            <span class="badge bg-danger">Dibatalkan</span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Nama Penyewa:</small>
            <strong id="penyewaDibatalkan" class="text-dark"></strong>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Email Penyewa:</small>
            <span id="emailDibatalkan" class="text-muted"></span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Tanggal Mulai Sewa:</small>
            <strong id="tanggalSewaDibatalkan"></strong>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Tanggal Dibatalkan:</small>
            <span id="dibatalkanPada" class="text-danger fw-semibold"></span>
          </div>
          <div class="col-sm-6">
            <small class="text-muted d-block">Metode Pengambilan:</small>
            <strong id="metodeDibatalkan" class="text-primary"></strong>
          </div>
        </div>

        <!-- Tabel Daftar Barang Dalam Invoice -->
        <div class="modal-section-title mb-2">
          <i class="fas fa-boxes me-1 text-danger"></i> Daftar Alat yang Dibatalkan
        </div>
        <div class="table-responsive mb-3">
          <table class="table table-bordered table-hover align-middle mb-0">
            <thead class="table-secondary text-center small">
              <tr>
                <th style="width: 55px;">Foto</th>
                <th>Nama Produk</th>
                <th style="width: 70px;">Qty</th>
                <th style="width: 120px;">Harga Satuan</th>
                <th style="width: 130px;">Subtotal</th>
              </tr>
            </thead>
            <tbody id="itemsDibatalkanTableBody">
              <!-- Rendered via JavaScript -->
            </tbody>
          </table>
        </div>

        <!-- Rincian Biaya -->
        <div class="bg-light p-3 rounded-3 border">
          <div class="d-flex justify-content-between mb-2 small">
            <span>Biaya Pengambilan / Ongkir:</span>
            <span class="fw-semibold" id="biayapengambilanDibatalkan">Rp 0</span>
          </div>
          <div class="d-flex justify-content-between pt-2 border-top fw-bold text-danger fs-5">
            <span>Total Nilai Transaksi:</span>
            <span id="subtotalDibatalkan">Rp 0</span>
          </div>
        </div>

      </div>
      <div class="modal-footer bg-light py-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://npmcdn.com/flatpickr/dist/l10n/id.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  flatpickr("#modalTanggalSewa", {
      dateFormat: "Y-m-d",
      defaultDate: "<?= date('Y-m-d') ?>",
      minDate: "today",
      locale: "id",
      allowInput: false,
      disableMobile: true
  });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const modalDurasi = document.getElementById('modalDurasi');
  const metode = document.getElementById('metodePengambilan');
  const ongkirGroup = document.getElementById('ongkirGroup');
  const ongkirInput = document.getElementById('ongkirInput');
  const searchAlatModal = document.getElementById('searchAlatModal');
  const btnSelectAllModal = document.getElementById('btnSelectAllModal');
  const totalEstimasiText = document.getElementById('totalEstimasiModalText');
  const summaryBreakdownText = document.getElementById('summaryBreakdownText');
  const formTambahSewaModal = document.getElementById('formTambahSewaModal');

  // 1. Fungsi Hitung Estimasi Total
  function hitungEstimasiModal() {
    const durasi = parseInt(modalDurasi.value) || 1;
    let ongkir = 0;
    if (metode.value !== 'Ambil Ke toko') {
      ongkir = parseInt(ongkirInput.value) || 10000;
    }

    let totalSubtotalAlat = 0;
    let totalItemCount = 0;
    let itemsDetail = [];

    document.querySelectorAll('.alat-checkbox:checked').forEach(cb => {
      const id = cb.dataset.id;
      const harga = parseInt(cb.dataset.harga) || 0;
      const isGas = cb.dataset.isGas === '1';
      const qtyInput = document.getElementById('qty-alat-' + id);
      const qty = parseInt(qtyInput ? qtyInput.value : 1) || 1;
      
      const multDurasi = isGas ? 1 : durasi;
      const subtotal = harga * qty * multDurasi;

      totalSubtotalAlat += subtotal;
      totalItemCount += qty;
    });

    const grandTotal = totalSubtotalAlat + (totalItemCount > 0 ? ongkir : 0);

    totalEstimasiText.textContent = 'Rp ' + grandTotal.toLocaleString('id-ID');

    if (totalItemCount > 0) {
      summaryBreakdownText.innerHTML = `<strong>${totalItemCount} item</strong> dipilih | Subtotal Alat: <strong>Rp ${totalSubtotalAlat.toLocaleString('id-ID')}</strong> | Ongkir: <strong>Rp ${ongkir.toLocaleString('id-ID')}</strong> (Durasi: ${durasi} hari)`;
    } else {
      summaryBreakdownText.textContent = 'Pilih setidaknya 1 alat untuk melihat rincian biaya.';
    }
  }

  // 2. Event Checkbox & Qty
  document.querySelectorAll('.alat-checkbox').forEach(cb => {
    cb.addEventListener('change', function () {
      const id = this.dataset.id;
      const card = document.getElementById('card-alat-' + id);
      const qtyInput = document.getElementById('qty-alat-' + id);

      if (this.checked) {
        if (card) card.classList.add('active-card');
        if (qtyInput) {
          qtyInput.disabled = false;
          if (!qtyInput.value || parseInt(qtyInput.value) < 1) qtyInput.value = 1;
        }
      } else {
        if (card) card.classList.remove('active-card');
        if (qtyInput) {
          qtyInput.disabled = true;
          qtyInput.value = 1;
        }
      }
      hitungEstimasiModal();
    });
  });

  // 3. Click pada card untuk toggle checkbox
  document.querySelectorAll('.alat-card-modal').forEach(card => {
    card.addEventListener('click', function (e) {
      if (this.classList.contains('disabled-card')) return;
      // Jangan toggle jika user mengklik input qty atau label/checkbox langsung
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'LABEL') return;

      const id = this.dataset.id;
      const cb = document.getElementById('chk-alat-' + id);
      if (cb && !cb.disabled) {
        cb.checked = !cb.checked;
        cb.dispatchEvent(new Event('change'));
      }
    });
  });

  // 4. Input Qty change
  document.querySelectorAll('.qty-modal-input').forEach(input => {
    input.addEventListener('input', function () {
      const max = parseInt(this.max) || 9999;
      let val = parseInt(this.value) || 1;
      if (val > max) this.value = max;
      if (val < 1) this.value = 1;
      hitungEstimasiModal();
    });
  });

  // 5. Select All toggle
  let isAllSelected = false;
  btnSelectAllModal.addEventListener('click', function () {
    isAllSelected = !isAllSelected;
    document.querySelectorAll('.alat-checkbox:not(:disabled)').forEach(cb => {
      cb.checked = isAllSelected;
      cb.dispatchEvent(new Event('change'));
    });
    this.innerHTML = isAllSelected ? '<i class="fas fa-times-square me-1"></i> Batal Semua' : '<i class="fas fa-check-square me-1"></i> Pilih Semua';
  });

  // 6. Search filter alat modal
  searchAlatModal.addEventListener('keyup', function () {
    const keyword = this.value.toLowerCase();
    document.querySelectorAll('.alat-item-col').forEach(item => {
      const nama = item.dataset.nama || '';
      item.style.display = nama.includes(keyword) ? '' : 'none';
    });
  });

  // 7. Durasi & Metode change
  modalDurasi.addEventListener('input', hitungEstimasiModal);

  function updateOngkirModal() {
    if (metode.value === 'Ambil Ke toko') {
      ongkirGroup.style.display = 'none';
      ongkirInput.value = 0;
      ongkirInput.disabled = true;
    } else {
      ongkirGroup.style.display = 'block';
      ongkirInput.disabled = false;
      if (parseInt(ongkirInput.value) <= 0) ongkirInput.value = 10000;
    }
    hitungEstimasiModal();
  }

  metode.addEventListener('change', updateOngkirModal);
  ongkirInput.addEventListener('input', hitungEstimasiModal);

  // 8. Form submit validation
  formTambahSewaModal.addEventListener('submit', function (e) {
    const selectedAlat = document.querySelectorAll('.alat-checkbox:checked');
    const userSelect = document.getElementById('modalSelectUser');

    if (!userSelect.value) {
      e.preventDefault();
      alert('Silakan pilih akun pelanggan / user terlebih dahulu!');
      userSelect.focus();
      return false;
    }

    if (selectedAlat.length === 0) {
      e.preventDefault();
      alert('Silakan pilih minimal 1 alat yang akan disewa!');
      return false;
    }
  });

  updateOngkirModal();
});
</script>
<script>
document.getElementById('liveSearchSewa').addEventListener('keyup', function () {
    let keyword = this.value.toLowerCase().trim();

    let tables = [
        document.querySelectorAll('#tabelBerlangsung tbody tr'),
        document.querySelectorAll('#tabelDibatalkan tbody tr')
    ];

    tables.forEach(rows => {
        rows.forEach(row => {
            let text = row.textContent.toLowerCase();
            if (text.includes(keyword)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
});
</script>

<script>
  const editStatusModal = document.getElementById('editStatusModal');
  editStatusModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    const id = button.getAttribute('data-id');
    const status = button.getAttribute('data-status');

    document.getElementById('sewaId').value = id;
    document.getElementById('status').value = status.toLowerCase();
  });
</script>
<script>
  // Detail Modal Handler (Sewa Berlangsung)
  document.querySelectorAll('.lihat-detail-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      try {
        const inv = JSON.parse(this.getAttribute('data-invoice'));
        document.getElementById('detailNoTagihan').textContent = inv.no_tagihan || '-';
        document.getElementById('detailPenyewa').textContent = inv.nama || '-';
        document.getElementById('detailEmail').textContent = inv.email || '-';
        document.getElementById('detailDurasi').textContent = inv.durasi || '1';
        document.getElementById('detailTanggalSewa').textContent = inv.tanggal_sewa || '-';
        document.getElementById('detailTanggalBuat').textContent = inv.tanggal_buat || '-';
        document.getElementById('detailMetode').textContent = inv.metode_pengambilan || '-';
        document.getElementById('detailBiayaPengambilan').textContent = 'Rp ' + Number(inv.total_ongkir || 0).toLocaleString('id-ID');
        document.getElementById('detailSubtotal').textContent = 'Rp ' + Number(inv.total_biaya || 0).toLocaleString('id-ID');

        const badge = document.getElementById('detailStatusBadge');
        if (badge) {
          badge.textContent = inv.status || '-';
          const stLower = (inv.status || '').toLowerCase().trim();
          const colors = {
            'menunggu pembayaran': 'bg-danger',
            'berlangsung': 'bg-primary',
            'siap di ambil': 'bg-warning text-dark',
            'siap diambil': 'bg-warning text-dark',
            'di antar': 'bg-warning text-dark',
            'diantar': 'bg-warning text-dark',
            'selesai': 'bg-success',
            'dibatalkan': 'bg-danger'
          };
          badge.className = 'badge ' + (colors[stLower] || 'bg-primary');
        }

        // Render items table
        const tbody = document.getElementById('detailItemsTableBody');
        tbody.innerHTML = '';
        if (inv.items && inv.items.length > 0) {
          inv.items.forEach(it => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
              <td class="text-center">
                <img src="${it.gambar_path}" alt="alat" style="width: 40px; height: 40px; object-fit: cover; border-radius: 6px;" class="border">
              </td>
              <td>
                <strong class="text-dark">${it.nama_produk}</strong>
              </td>
              <td class="text-center fw-bold">${it.qty}</td>
              <td class="text-end">Rp ${Number(it.harga_satuan_val || it.total_harga || 0).toLocaleString('id-ID')}</td>
              <td class="text-end fw-bold text-success">Rp ${Number(it.subtotal_item || 0).toLocaleString('id-ID')}</td>
            `;
            tbody.appendChild(tr);
          });
        }
      } catch(e) {
        console.error(e);
      }
    });
  });

  // Detail Modal Handler (Sewa Dibatalkan)
  document.querySelectorAll('.lihat-detail-dibatalkan').forEach(btn => {
    btn.addEventListener('click', function () {
      try {
        const inv = JSON.parse(this.getAttribute('data-invoice'));
        document.getElementById('noTagihanDibatalkan').textContent = inv.no_tagihan || '-';
        document.getElementById('penyewaDibatalkan').textContent = inv.nama || '-';
        document.getElementById('emailDibatalkan').textContent = inv.email || '-';
        document.getElementById('tanggalSewaDibatalkan').textContent = inv.tanggal_sewa || '-';
        document.getElementById('dibatalkanPada').textContent = inv.dibatalkan_pada || '-';
        document.getElementById('metodeDibatalkan').textContent = inv.metode_pengambilan || '-';
        document.getElementById('biayapengambilanDibatalkan').textContent = 'Rp ' + Number(inv.total_ongkir || 0).toLocaleString('id-ID');
        document.getElementById('subtotalDibatalkan').textContent = 'Rp ' + Number(inv.total_biaya || 0).toLocaleString('id-ID');

        const tbody = document.getElementById('itemsDibatalkanTableBody');
        tbody.innerHTML = '';
        if (inv.items && inv.items.length > 0) {
          inv.items.forEach(it => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
              <td class="text-center">
                <img src="${it.gambar_path}" alt="alat" style="width: 40px; height: 40px; object-fit: cover; border-radius: 6px;" class="border">
              </td>
              <td>
                <strong class="text-dark">${it.nama_produk}</strong>
              </td>
              <td class="text-center fw-bold">${it.qty}</td>
              <td class="text-end">Rp ${Number(it.harga_satuan_val || it.total_harga || 0).toLocaleString('id-ID')}</td>
              <td class="text-end fw-bold text-danger">Rp ${Number(it.subtotal_item || 0).toLocaleString('id-ID')}</td>
            `;
            tbody.appendChild(tr);
          });
        }
      } catch(e) {
        console.error(e);
      }
    });
  });
</script>

<script>
  // Sinkronkan tab aktif ke URL agar saat refresh / aksi tetap di tab yang sama
  document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('#riwayatTabs button[data-bs-toggle="pill"]');
    tabButtons.forEach(btn => {
      btn.addEventListener('shown.bs.tab', function(e) {
        const target = e.target.getAttribute('data-bs-target');
        if (target) {
          const tabName = target.replace('#', '');
          const url = new URL(window.location);
          url.searchParams.set('tab', tabName);
          window.history.replaceState({}, '', url);
        }
      });
    });
  });
</script>

</body>
</html>
