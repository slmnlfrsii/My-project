<?php
session_start();
require_once "../../koneksi.php";
date_default_timezone_set('Asia/Jakarta');

/* ===============================
   1. TAMBAH SEWA (ADMIN)
================================= */
if (isset($_POST['tambah_user_sewa'])) {

    $id_users = $_POST['id_users'];
    $alatList = $_POST['alat'] ?? [];
    $qtyList  = $_POST['qty'] ?? [];

    $tanggal_sewa = $_POST['tanggal_sewa'];
    $metode_pengambilan = $_POST['metode_pengambilan'];

    $durasi = max(1, (int)$_POST['durasi']);

    $biaya_pengambilan = ($metode_pengambilan === 'Ambil Ke toko')
        ? 0
        : max(10000, (int)$_POST['biaya_pengambilan']);

    $tanggal_buat = date('Y-m-d H:i:s');
    $status = 'Menunggu pembayaran';

    $conn->begin_transaction();

    try {
        // Generate 1 Nomor Invoice (no_tagihan) unik
        $q_max = mysqli_query($conn, "SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM sewa");
        $next_id = mysqli_fetch_assoc($q_max)['next_id'] ?? 1;
        $batch_no_tagihan = 'INV-' . date('Ymd') . '-' . sprintf('%04d', $next_id);

        foreach ($alatList as $id_alat) {
            $qty = isset($qtyList[$id_alat]) ? (int)$qtyList[$id_alat] : 1;
            $qty = max(1, $qty);

            // Ambil data alat
            $getAlat = $conn->prepare("SELECT nama, harga_per_hari, gambar, sisa_stok FROM alat WHERE id = ?");
            $getAlat->bind_param("i", $id_alat);
            $getAlat->execute();
            $alatData = $getAlat->get_result()->fetch_assoc();
            $getAlat->close();

            if (!$alatData) continue;

            // Cek sisa stok
            if ($alatData['sisa_stok'] < $qty) {
                throw new Exception("Sisa stok tidak cukup untuk {$alatData['nama']}");
            }

            // Insert sewa
            $insert = $conn->prepare("INSERT INTO sewa (
                id_users, id_alat, no_tagihan, nama_produk, total_harga, gambar, qty, tanggal_sewa, durasi,
                metode_pengambilan, biaya_pengambilan, tanggal_buat, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $insert->bind_param(
                "iissdsisisdss",
                $id_users,
                $id_alat,
                $batch_no_tagihan,
                $alatData['nama'],
                $alatData['harga_per_hari'],
                $alatData['gambar'],
                $qty,
                $tanggal_sewa,
                $durasi,
                $metode_pengambilan,
                $biaya_pengambilan,
                $tanggal_buat,
                $status
            );

            $insert->execute();
            $insert->close();
        }

        $conn->commit();
        echo "<script>alert('Berhasil menambahkan sewa.'); window.location='riwayat.php';</script>";

    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>alert('Gagal: {$e->getMessage()}'); window.location='riwayat.php';</script>";
    }
}


/* ===============================
   2. UPDATE STATUS
================================= */
if (isset($_POST['id']) && isset($_POST['status'])) {

    $id = (int)$_POST['id'];
    $statusInput = $_POST['status'];
    $statusNew = strtolower(trim($statusInput));

    $conn->begin_transaction();

    try {
        // Ambil data sewa utama
        $select = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
        $select->bind_param("i", $id);
        $select->execute();
        $data = $select->get_result()->fetch_assoc();
        $select->close();

        if (!$data) {
            throw new Exception("Data transaksi tidak ditemukan.");
        }

        // CARI SEMUA ITEM DENGAN INVOICE YANG SAMA (Prepared Statement Safe)
        $allItemIds = [$id];
        $noTagihanBatch = $data['no_tagihan'] ?? '';
        $idUsersBatch = (int)$data['id_users'];

        if (!empty($noTagihanBatch)) {
            $qBatch = $conn->prepare("SELECT id FROM sewa WHERE id_users = ? AND no_tagihan = ?");
            $qBatch->bind_param("is", $idUsersBatch, $noTagihanBatch);
            $qBatch->execute();
            $resBatch = $qBatch->get_result();
            while ($bRow = $resBatch->fetch_assoc()) {
                $allItemIds[] = (int)$bRow['id'];
            }
            $qBatch->close();
        }
        $allItemIds = array_values(array_unique(array_filter($allItemIds)));

        $statusCurrent = strtolower(trim($data['status']));

        // Validasi: Pembayaran belum masuk
        if ($statusCurrent === 'menunggu pembayaran') {
            throw new Exception("Pesanan masih berstatus 'Menunggu pembayaran'. Verifikasi pembayaran terlebih dahulu.");
        }

        // Validasi aksi edit status
        if (!in_array($statusNew, ['berlangsung', 'selesai'])) {
            throw new Exception("Status hanya dapat diubah menjadi 'Berlangsung' atau 'Selesai'.");
        }

        // VALIDASI STRICT FIFO PER-KATEGORI TAB
        $clearedStatuses = ['selesai', 'dibatalkan'];

        if (!in_array($statusCurrent, $clearedStatuses)) {
            $tanggal_buat = !empty($data['tanggal_buat']) ? $data['tanggal_buat'] : '1970-01-01 00:00:00';
            $minIdInBatch = min($allItemIds);

            // Tentukan status mana saja yang perlu divalidasi antreannya sesuai tab
            $fifoFilterStatuses = ($statusNew === 'berlangsung') 
                ? "LOWER(TRIM(status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar')" 
                : "LOWER(TRIM(status)) = 'berlangsung'";

            // Bind dynamic array IDs aman dari SQL Injection
            $inClause = implode(',', array_map('intval', $allItemIds));

            $queryAntrian = "
                SELECT id, nama_produk, no_tagihan 
                FROM sewa 
                WHERE id NOT IN ($inClause) 
                AND $fifoFilterStatuses
                AND (
                    COALESCE(tanggal_buat, '1970-01-01 00:00:00') < ? 
                    OR (COALESCE(tanggal_buat, '1970-01-01 00:00:00') = ? AND id < ?)
                )
                ORDER BY COALESCE(tanggal_buat, '1970-01-01 00:00:00') ASC, id ASC 
                LIMIT 1
            ";

            $cekAntrian = $conn->prepare($queryAntrian);
            $cekAntrian->bind_param("ssi", $tanggal_buat, $tanggal_buat, $minIdInBatch);
            $cekAntrian->execute();
            $antrianSebelumnya = $cekAntrian->get_result()->fetch_assoc();
            $cekAntrian->close();

            if ($antrianSebelumnya) {
                $namaProdukSebelumnya = !empty($antrianSebelumnya['no_tagihan']) ? $antrianSebelumnya['no_tagihan'] : $antrianSebelumnya['nama_produk'];
                throw new Exception("Tidak dapat memproses transaksi! Antrean sebelumnya ({$namaProdukSebelumnya}) belum diselesaikan.");
            }
        }

        // PROSES PERUBAHAN STATUS & STOK UNTUK SELURUH ITEM INVOICE
        foreach ($allItemIds as $item_id) {
            $getSewaItem = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
            $getSewaItem->bind_param("i", $item_id);
            $getSewaItem->execute();
            $itemData = $getSewaItem->get_result()->fetch_assoc();
            $getSewaItem->close();

            if (!$itemData) continue;

            $statusItemCurrent = strtolower(trim($itemData['status']));
            $activeStatuses = ['siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung'];
            
            $wasActive = in_array($statusItemCurrent, $activeStatuses);
            $becomingActive = in_array($statusNew, $activeStatuses);

            // 1. Kurangi stok HANYA jika berpindah dari Non-Aktif -> Aktif
            if (!$wasActive && $becomingActive) {
                $getAlat = $conn->prepare("SELECT sisa_stok, nama FROM alat WHERE id = ?");
                $getAlat->bind_param("i", $itemData['id_alat']);
                $getAlat->execute();
                $curAlat = $getAlat->get_result()->fetch_assoc();
                $getAlat->close();

                if ($curAlat && $curAlat['sisa_stok'] < (int)$itemData['qty']) {
                    throw new Exception("Stok tidak cukup untuk {$curAlat['nama']} (Sisa stok: {$curAlat['sisa_stok']}, dibutuhkan: {$itemData['qty']})");
                }

                $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = GREATEST(0, sisa_stok - ?) WHERE id = ?");
                $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                $updateStok->execute();
                $updateStok->close();
            }

            // 2. Kembalikan stok jika berpindah dari Status Aktif -> Selesai/Dibatalkan
            if ($wasActive && !$becomingActive) {
                $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
                $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                $updateStok->execute();
                $updateStok->close();
            }

            // 3. Update status transaksi di database
            if ($statusNew === 'selesai') {
                $update = $conn->prepare("UPDATE sewa SET status = 'selesai', tanggal_dikembalikan = NOW() WHERE id = ?");
                $update->bind_param("i", $item_id);
                $update->execute();
                $update->close();
            } elseif ($statusNew === 'dibatalkan') {
                $statusFix = 'Dibatalkan';
                $noTagihan = !empty($itemData['no_tagihan']) ? $itemData['no_tagihan'] : ('INV-' . date('Ymd', strtotime($itemData['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $item_id));

                $insert = $conn->prepare("INSERT INTO sewa_dibatalkan 
                    (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

                $insert->bind_param(
                    "issiiidssss",
                    $itemData['id_users'],
                    $noTagihan,
                    $itemData['nama_produk'],
                    $itemData['qty'],
                    $itemData['durasi'],
                    $itemData['total_harga'],
                    $itemData['biaya_pengambilan'],
                    $itemData['metode_pengambilan'],
                    $itemData['gambar'],
                    $itemData['tanggal_sewa'],
                    $statusFix
                );
                $insert->execute();
                $insert->close();

                $delete = $conn->prepare("DELETE FROM sewa WHERE id = ?");
                $delete->bind_param("i", $item_id);
                $delete->execute();
                $delete->close();
            } else {
                $update = $conn->prepare("UPDATE sewa SET status = ? WHERE id = ?");
                $update->bind_param("si", $statusInput, $item_id);
                $update->execute();
                $update->close();
            }
        }

        $conn->commit();
        $_SESSION['flash_success'] = "Status transaksi berhasil diperbarui.";

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['flash_error'] = $e->getMessage();
    }

    $redirectTab = ($statusNew === 'selesai') ? 'berlangsung' : 'sewa_masuk';
    header("Location: riwayat.php?tab=" . $redirectTab);
    exit();
}


/* ===============================
   3. HAPUS DATA + KEMBALIKAN STOK
================================= */
if (isset($_POST['id']) && isset($_POST['tabel'])) {

    $id = (int)$_POST['id'];
    $tabel = $_POST['tabel'];
    $redirectTab = ($tabel === 'sewa_dibatalkan') ? 'dibatalkan' : 'berlangsung';

    $conn->begin_transaction();

    try {
        if ($tabel === 'sewa') {
            $get = $conn->prepare("SELECT id, no_tagihan, id_users, id_alat, qty, status FROM sewa WHERE id = ?");
            $get->bind_param("i", $id);
            $get->execute();
            $data = $get->get_result()->fetch_assoc();
            $get->close();

            if ($data) {
                $allItemsToDelete = [$data];
                $noTag = $data['no_tagihan'] ?? '';
                $uId = (int)$data['id_users'];

                if (!empty($noTag)) {
                    $qOther = $conn->prepare("SELECT id, no_tagihan, id_users, id_alat, qty, status FROM sewa WHERE id_users = ? AND no_tagihan = ?");
                    $qOther->bind_param("is", $uId, $noTag);
                    $qOther->execute();
                    $resOther = $qOther->get_result();
                    $allItemsToDelete = [];
                    while ($oRow = $resOther->fetch_assoc()) {
                        $allItemsToDelete[] = $oRow;
                    }
                    $qOther->close();
                }

                $activeStatuses = ['siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung'];

                foreach ($allItemsToDelete as $delItem) {
                    $statusRow = strtolower(trim($delItem['status']));
                    
                    if (in_array($statusRow, $activeStatuses) && !empty($delItem['id_alat'])) {
                        $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
                        $updateStok->bind_param("ii", $delItem['qty'], $delItem['id_alat']);
                        $updateStok->execute();
                        $updateStok->close();
                    }

                    $stmtDel = $conn->prepare("DELETE FROM sewa WHERE id = ?");
                    $stmtDel->bind_param("i", $delItem['id']);
                    $stmtDel->execute();
                    $stmtDel->close();
                }
            }
        }

        if ($tabel === 'sewa_dibatalkan') {
            $getD = $conn->prepare("SELECT id, no_tagihan, id_users FROM sewa_dibatalkan WHERE id = ?");
            $getD->bind_param("i", $id);
            $getD->execute();
            $dataD = $getD->get_result()->fetch_assoc();
            $getD->close();

            if ($dataD && !empty($dataD['no_tagihan'])) {
                $noTagD = $dataD['no_tagihan'];
                $uIdD = (int)$dataD['id_users'];
                $stmtD = $conn->prepare("DELETE FROM sewa_dibatalkan WHERE id_users = ? AND no_tagihan = ?");
                $stmtD->bind_param("is", $uIdD, $noTagD);
                $stmtD->execute();
                $stmtD->close();
            } else {
                $stmtD = $conn->prepare("DELETE FROM sewa_dibatalkan WHERE id = ?");
                $stmtD->bind_param("i", $id);
                $stmtD->execute();
                $stmtD->close();
            }
        }

        $conn->commit();
        $_SESSION['flash_success'] = "Data berhasil dihapus.";

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['flash_error'] = "Gagal menghapus data: " . $e->getMessage();
    }

    header("Location: riwayat.php?tab=" . $redirectTab);
    exit();
}
?>