<?php
session_start();
require_once "../../koneksi.php";
date_default_timezone_set('Asia/Jakarta');
/* ===============================
   TAMBAH SEWA (ADMIN)
================================= */
if (isset($_POST['tambah_user_sewa'])) {

    $id_users = $_POST['id_users'];
    $alatList = $_POST['alat'] ?? [];
    $qtyList  = $_POST['qty'] ?? [];

    $tanggal_sewa = $_POST['tanggal_sewa'];
    $metode_pengambilan = $_POST['metode_pengambilan'];

    $durasi = max(1, (int)$_POST['durasi']);

    $biaya_pengambilan = ($metode_pengambilan === 'Ambil Ke toko')
        ? 0
        : max(10000, (int)$_POST['biaya_pengambilan']);

    $tanggal_buat = date('Y-m-d H:i:s');
    $status = 'Menunggu pembayaran';

    $conn->begin_transaction();

    try {

        // Generate 1 Nomor Invoice (no_tagihan) yang sama untuk seluruh item dalam transaksi ini
        $q_max = mysqli_query($conn, "SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM sewa");
        $next_id = mysqli_fetch_assoc($q_max)['next_id'] ?? 1;
        $batch_no_tagihan = 'INV-' . date('Ymd') . '-' . sprintf('%04d', $next_id);

        foreach ($alatList as $id_alat) {

            $qty = isset($qtyList[$id_alat]) ? (int)$qtyList[$id_alat] : 1;
            $qty = max(1, $qty);

            // ambil data alat
            $getAlat = $conn->prepare("SELECT nama, harga_per_hari, gambar, sisa_stok FROM alat WHERE id = ?");
            $getAlat->bind_param("i", $id_alat);
            $getAlat->execute();
            $alatData = $getAlat->get_result()->fetch_assoc();

            if (!$alatData) continue;

            // cek sisa stok
            if ($alatData['sisa_stok'] < $qty) {
                throw new Exception("Sisa stok tidak cukup untuk {$alatData['nama']}");
            }

            // insert sewa
            $insert = $conn->prepare("INSERT INTO sewa (
                id_users, id_alat, no_tagihan, nama_produk, total_harga, gambar, qty, tanggal_sewa, durasi,
                metode_pengambilan, biaya_pengambilan, tanggal_buat, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $insert->bind_param(
                "iissdsisisdss",
                $id_users,
                $id_alat,
                $batch_no_tagihan,
                $alatData['nama'],
                $alatData['harga_per_hari'],
                $alatData['gambar'],
                $qty,
                $tanggal_sewa,
                $durasi,
                $metode_pengambilan,
                $biaya_pengambilan,
                $tanggal_buat,
                $status
            );

            $insert->execute();
        }

        $conn->commit();

        echo "<script>alert('Berhasil menambahkan sewa.'); window.location='riwayat.php';</script>";

    } catch (Exception $e) {
        $conn->rollback();
        echo "<script>alert('Gagal: {$e->getMessage()}'); window.location='riwayat.php';</script>";
    }
}


/* ===============================
   UPDATE STATUS
================================= */
if (isset($_POST['id']) && isset($_POST['status'])) {

    $id = (int)$_POST['id'];
    $statusInput = $_POST['status'];
    $statusNew = strtolower(trim($statusInput));

    // 🔐 TRANSAKSI
    $conn->begin_transaction();

    try {
        // Ambil data sewa utama
        $select = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
        $select->bind_param("i", $id);
        $select->execute();
        $data = $select->get_result()->fetch_assoc();
        $select->close();

        if (!$data) {
            throw new Exception("Data tidak ditemukan");
        }

        // ==========================================
        // CARI SEMUA ITEM DENGAN INVOICE YANG SAMA
        // ==========================================
        $allItemIds = [$id];
        $noTagihanBatch = $data['no_tagihan'] ?? '';
        $idUsersBatch = (int)$data['id_users'];

        if (!empty($noTagihanBatch)) {
            $qBatch = mysqli_query($conn, "SELECT id FROM sewa WHERE id_users = $idUsersBatch AND no_tagihan = '$noTagihanBatch'");
            if ($qBatch && mysqli_num_rows($qBatch) > 0) {
                while ($bRow = mysqli_fetch_assoc($qBatch)) {
                    $allItemIds[] = (int)$bRow['id'];
                }
            }
        }
        $allItemIds = array_values(array_unique(array_filter($allItemIds)));

        /* =========================================================================
           [FIFO LOGIC] VALIDASI STRICT FIFO PADA PERUBAHAN STATUS OLEH ADMIN
           - Admin dilarang mengubah status pesanan berikutnya jika antrean pesanan
             yang masuk lebih awal belum diproses ke status 'Siap di ambil' / 'Di antar'.
           ========================================================================= */
        $statusCurrent = strtolower(trim($data['status']));
        $clearedStatuses = ['siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung', 'selesai'];

        if (!in_array($statusCurrent, $clearedStatuses)) {
            $tanggal_buat = !empty($data['tanggal_buat']) ? $data['tanggal_buat'] : '1970-01-01 00:00:00';
            $idsListStr = implode(',', $allItemIds);

            $cekAntrian = $conn->prepare("
                SELECT id, nama_produk, tanggal_buat 
                FROM sewa 
                WHERE id NOT IN ($idsListStr) 
                AND LOWER(TRIM(status)) NOT IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar', 'berlangsung', 'selesai')
                AND (
                    COALESCE(tanggal_buat, '1970-01-01 00:00:00') < ? 
                    OR (COALESCE(tanggal_buat, '1970-01-01 00:00:00') = ? AND id < ?)
                )
                ORDER BY COALESCE(tanggal_buat, '1970-01-01 00:00:00') ASC, id ASC 
                LIMIT 1
            ");
            $cekAntrian->bind_param("sss", $tanggal_buat, $tanggal_buat, $id);
            $cekAntrian->execute();
            $antrianSebelumnya = $cekAntrian->get_result()->fetch_assoc();
            $cekAntrian->close();

            if ($antrianSebelumnya) {
                throw new Exception("Tidak dapat mengubah status karena antrian pesanan sebelumnya ({$antrianSebelumnya['nama_produk']}) belum diproses.");
            }
        }

        // ==========================================
        // PROSES PERUBAHAN STATUS UNTUK SELURUH ITEM INVOICE
        // ==========================================
        foreach ($allItemIds as $item_id) {
            $getSewaItem = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
            $getSewaItem->bind_param("i", $item_id);
            $getSewaItem->execute();
            $itemData = $getSewaItem->get_result()->fetch_assoc();
            $getSewaItem->close();

            if (!$itemData) continue;

            $statusItemCurrent = strtolower(trim($itemData['status']));
            $activeStatuses = ['siap di ambil', 'di antar', 'diantar', 'berlangsung'];
            $wasActive = in_array($statusItemCurrent, $activeStatuses);
            $becomingActive = in_array($statusNew, $activeStatuses);

            // 1. Berpindah ke status aktif (stok berkurang)
            if (!$wasActive && $becomingActive) {
                $getAlat = $conn->prepare("SELECT sisa_stok, nama FROM alat WHERE id = ?");
                $getAlat->bind_param("i", $itemData['id_alat']);
                $getAlat->execute();
                $curAlat = $getAlat->get_result()->fetch_assoc();
                $getAlat->close();

                if ($curAlat && $curAlat['sisa_stok'] < (int)$itemData['qty']) {
                    throw new Exception("Stok tidak cukup untuk {$curAlat['nama']} (Sisa stok: {$curAlat['sisa_stok']}, dibutuhkan: {$itemData['qty']})");
                }

                $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = GREATEST(0, sisa_stok - ?) WHERE id = ?");
                $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                $updateStok->execute();
                $updateStok->close();
            }

            // 2. Berpindah dari status aktif ke non-aktif/selesai/dibatalkan (stok dikembalikan)
            if ($wasActive && !$becomingActive) {
                $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
                $updateStok->bind_param("ii", $itemData['qty'], $itemData['id_alat']);
                $updateStok->execute();
                $updateStok->close();
            }

            /* ===== SELESAI ===== */
            if ($statusNew === 'selesai') {
                $update = $conn->prepare("UPDATE sewa SET status = 'selesai', tanggal_dikembalikan = NOW() WHERE id = ?");
                $update->bind_param("i", $item_id);
                $update->execute();
                $update->close();
            }
            /* ===== DIBATALKAN ===== */
            elseif ($statusNew === 'dibatalkan') {
                $statusFix = 'Dibatalkan';
                $noTagihan = !empty($itemData['no_tagihan']) ? $itemData['no_tagihan'] : ('INV-' . date('Ymd', strtotime($itemData['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $item_id));

                $insert = $conn->prepare("INSERT INTO sewa_dibatalkan 
                    (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

                $insert->bind_param(
                    "issiiidssss",
                    $itemData['id_users'],
                    $noTagihan,
                    $itemData['nama_produk'],
                    $itemData['qty'],
                    $itemData['durasi'],
                    $itemData['total_harga'],
                    $itemData['biaya_pengambilan'],
                    $itemData['metode_pengambilan'],
                    $itemData['gambar'],
                    $itemData['tanggal_sewa'],
                    $statusFix
                );
                $insert->execute();
                $insert->close();

                // HAPUS DARI SEWA
                $delete = $conn->prepare("DELETE FROM sewa WHERE id = ?");
                $delete->bind_param("i", $item_id);
                $delete->execute();
                $delete->close();
            }
            /* ===== STATUS LAIN (Siap di ambil, Di antar, Berlangsung, dll) ===== */
            else {
                $update = $conn->prepare("UPDATE sewa SET status = ? WHERE id = ?");
                $update->bind_param("si", $statusInput, $item_id);
                $update->execute();
                $update->close();
            }
        }

        $conn->commit();
        $_SESSION['flash_success'] = "Status seluruh item dalam invoice berhasil diperbarui.";

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['flash_error'] = $e->getMessage();
    }

    header("Location: riwayat.php");
    exit();
}


/* ===============================
   HAPUS DATA + KEMBALIKAN STOK JIKA AKTIF
================================= */
if (isset($_POST['id']) && isset($_POST['tabel'])) {

    $id = (int) $_POST['id'];
    $tabel = $_POST['tabel'];
    $redirectTab = ($tabel === 'sewa_dibatalkan') ? 'dibatalkan' : 'berlangsung';

    $conn->begin_transaction();

    try {

        // =========================
        // HAPUS DARI TABEL SEWA
        // =========================
        if ($tabel === 'sewa') {

            // ambil data dulu
            $get = $conn->prepare("SELECT id, no_tagihan, id_users, id_alat, qty, status FROM sewa WHERE id = ?");
            $get->bind_param("i", $id);
            $get->execute();
            $data = $get->get_result()->fetch_assoc();
            $get->close();

            if ($data) {
                $allItemsToDelete = [$data];
                $noTag = $data['no_tagihan'] ?? '';
                $uId = (int)$data['id_users'];

                if (!empty($noTag)) {
                    $qOther = mysqli_query($conn, "SELECT id, no_tagihan, id_users, id_alat, qty, status FROM sewa WHERE id_users = $uId AND no_tagihan = '$noTag'");
                    if ($qOther && mysqli_num_rows($qOther) > 0) {
                        $allItemsToDelete = [];
                        while ($oRow = mysqli_fetch_assoc($qOther)) {
                            $allItemsToDelete[] = $oRow;
                        }
                    }
                }

                $activeStatuses = ['siap di ambil', 'di antar', 'diantar', 'berlangsung'];

                foreach ($allItemsToDelete as $delItem) {
                    $statusRow = strtolower(trim($delItem['status']));
                    // Hanya kembalikan stok jika statusnya sedang aktif disewa
                    if (in_array($statusRow, $activeStatuses) && !empty($delItem['id_alat'])) {
                        $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
                        $updateStok->bind_param("ii", $delItem['qty'], $delItem['id_alat']);
                        $updateStok->execute();
                        $updateStok->close();
                    }

                    $stmtDel = $conn->prepare("DELETE FROM sewa WHERE id = ?");
                    $stmtDel->bind_param("i", $delItem['id']);
                    $stmtDel->execute();
                    $stmtDel->close();
                }
            }

        }

        // =========================
        // HAPUS DARI SEWA DIBATALKAN
        // =========================
        if ($tabel === 'sewa_dibatalkan') {
            $getD = $conn->prepare("SELECT id, no_tagihan, id_users FROM sewa_dibatalkan WHERE id = ?");
            $getD->bind_param("i", $id);
            $getD->execute();
            $dataD = $getD->get_result()->fetch_assoc();
            $getD->close();

            if ($dataD && !empty($dataD['no_tagihan'])) {
                $noTagD = $dataD['no_tagihan'];
                $uIdD = (int)$dataD['id_users'];
                $stmtD = $conn->prepare("DELETE FROM sewa_dibatalkan WHERE id_users = ? AND no_tagihan = ?");
                $stmtD->bind_param("is", $uIdD, $noTagD);
                $stmtD->execute();
                $stmtD->close();
            } else {
                $stmtD = $conn->prepare("DELETE FROM sewa_dibatalkan WHERE id = ?");
                $stmtD->bind_param("i", $id);
                $stmtD->execute();
                $stmtD->close();
            }
        }

        $conn->commit();

        $_SESSION['flash_success'] = "Data berhasil dihapus.";

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['flash_error'] = "Gagal menghapus data.";
    }

    header("Location: riwayat.php?tab=" . $redirectTab);
    exit();
}
?>