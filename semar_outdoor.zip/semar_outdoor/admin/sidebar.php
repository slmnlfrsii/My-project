<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$in_subfolder = (basename(dirname($_SERVER['PHP_SELF'])) !== 'admin');
$admin_base = $in_subfolder ? '../' : './';
$assets_base = $in_subfolder ? '../../' : '../';

$current_page = basename($_SERVER['PHP_SELF']);

// Ambil foto & nama dari akun admin yang sedang login
$sidebar_admin_foto = null;
$sidebar_admin_nama = 'RuangAdmin';

if (isset($_SESSION['id_admin'])) {
    $admin_id_sess = (int)$_SESSION['id_admin'];
    
    // Pastikan koneksi database tersedia
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $koneksi_file = $in_subfolder ? '../../koneksi.php' : '../koneksi.php';
        if (file_exists($koneksi_file)) {
            include_once $koneksi_file;
        }
    }
    
    if (isset($conn) && $conn instanceof mysqli) {
        $stmt_sidebar = $conn->prepare("SELECT nama, foto FROM admin WHERE id = ?");
        if ($stmt_sidebar) {
            $stmt_sidebar->bind_param("i", $admin_id_sess);
            $stmt_sidebar->execute();
            $res_sidebar = $stmt_sidebar->get_result()->fetch_assoc();
            if ($res_sidebar) {
                if (!empty($res_sidebar['foto'])) {
                    $uploads_check = ($in_subfolder ? '../' : './') . 'uploads/admin/' . $res_sidebar['foto'];
                    if (file_exists($uploads_check)) {
                        $sidebar_admin_foto = $admin_base . 'uploads/admin/' . htmlspecialchars($res_sidebar['foto']);
                    }
                }
                if (!empty($res_sidebar['nama'])) {
                    $sidebar_admin_nama = htmlspecialchars($res_sidebar['nama']);
                }
            }
            $stmt_sidebar->close();
        }
    }
}

// Fallback jika belum pasang foto profil
if (!$sidebar_admin_foto) {
    $sidebar_admin_foto = $assets_base . 'assets/images/default-profile.jpg';
}
?>

<!-- Mobile Topbar Navigation (Visible on screen < 992px) -->
<div class="mobile-topbar d-lg-none" id="mobileTopbar">
  <button id="mobileSidebarToggle" class="btn-mobile-toggle" type="button" aria-label="Buka Menu Sidebar">
    <i class="fa fa-bars"></i>
  </button>
  <div class="mobile-brand">
    <img src="<?= $sidebar_admin_foto ?>" alt="Foto Admin" class="mobile-logo">
    <span class="mobile-title">RuangAdmin</span>
  </div>
  <a href="<?= $admin_base ?>profile_admin.php" class="mobile-profile-btn" title="Profil Admin">
    <i class="fa fa-user-circle"></i>
  </a>
</div>

<!-- Backdrop Overlay for Mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Main Admin Sidebar -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <div class="header-top-actions">
      <!-- Desktop Collapse Button -->
      <button id="toggleSidebar" class="btn-sidebar-toggle d-none d-lg-flex" type="button" aria-label="Toggle Sidebar" title="Sembunyikan / Buka Sidebar">
        <i class="fa fa-bars"></i>
      </button>
      <!-- Mobile Close Button -->
      <button id="closeSidebarMobile" class="btn-sidebar-close d-lg-none" type="button" aria-label="Tutup Sidebar">
        <i class="fa fa-times"></i>
      </button>
    </div>

    <a href="<?= $admin_base ?>profile_admin.php" class="brand-wrapper" title="Buka Profil Admin">
      <img src="<?= $sidebar_admin_foto ?>" alt="Foto Admin" class="logo-sidebar">
      <h4 class="brand-name">RuangAdmin</h4>
    </a>
  </div>

  <div class="sidebar-menu-wrapper">
    <ul class="sidebar-menu">
      <li class="menu-item">
        <a href="<?= $admin_base ?>dashboard/dashboard.php" class="menu-link <?= ($current_page == 'dashboard.php') ? 'active' : '' ?>" data-title="Dashboard" title="Dashboard">
          <i class="fa fa-tachometer-alt"></i>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>pengguna/pengguna.php" class="menu-link <?= ($current_page == 'pengguna.php') ? 'active' : '' ?>" data-title="Pengguna" title="Pengguna">
          <i class="fa fa-users"></i>
          <span class="menu-text">Pengguna</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>alat/list_alat.php" class="menu-link <?= ($current_page == 'list_alat.php') ? 'active' : '' ?>" data-title="Alat Rental" title="Alat Rental">
          <i class="fa fa-toolbox"></i>
          <span class="menu-text">Alat Rental</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>riwayat/riwayat.php" class="menu-link <?= ($current_page == 'riwayat.php') ? 'active' : '' ?>" data-title="Riwayat Sewa" title="Riwayat Sewa">
          <i class="fa fa-shopping-cart"></i>
          <span class="menu-text">Riwayat Sewa</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>pengembalian/pengembalian.php" class="menu-link <?= ($current_page == 'pengembalian.php') ? 'active' : '' ?>" data-title="Pengembalian" title="Pengembalian">
          <i class="fa fa-undo-alt"></i>
          <span class="menu-text">Pengembalian</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>pembayaran/pembayaran.php" class="menu-link <?= ($current_page == 'pembayaran.php') ? 'active' : '' ?>" data-title="Pembayaran" title="Pembayaran">
          <i class="fa fa-credit-card"></i>
          <span class="menu-text">Pembayaran</span>
        </a>
      </li>

      <li class="menu-divider"></li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>profile_admin.php" class="menu-link <?= ($current_page == 'profile_admin.php') ? 'active' : '' ?>" data-title="Profil Admin" title="Profil Admin">
          <i class="fa fa-user-cog"></i>
          <span class="menu-text">Profil Admin</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>logout_admin.php" class="menu-link text-danger-hover" data-title="Logout" title="Logout">
          <i class="fa fa-sign-out-alt text-danger"></i>
          <span class="menu-text text-danger">Logout</span>
        </a>
      </li>
    </ul>
  </div>

  <div class="sidebar-footer">
    <small class="version-text text-muted">&copy; <?= date('Y') ?> Semar Outdoor</small>
  </div>
</nav>

<style>
:root {
  --admin-sidebar-width: 240px;
  --admin-sidebar-collapsed-width: 72px;
  --admin-sidebar-bg: #091e17;
  --admin-sidebar-hover: #8e5a12;
  --admin-sidebar-active: #8e5a12;
  --admin-sidebar-text: #e2e8f0;
}

body {
  background-color: #f8f9fc;
  min-height: 100vh;
  margin: 0;
}

/* Mobile Topbar */
.mobile-topbar {
  display: none;
  background-color: var(--admin-sidebar-bg);
  color: white;
  padding: 10px 16px;
  position: sticky;
  top: 0;
  z-index: 1025;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 2px 10px rgba(0,0,0,0.18);
}

.btn-mobile-toggle, .mobile-profile-btn {
  background: none;
  border: none;
  color: white;
  font-size: 20px;
  padding: 6px 10px;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s;
  text-decoration: none;
}

.btn-mobile-toggle:hover, .mobile-profile-btn:hover {
  background: rgba(255,255,255,0.12);
  color: #fff;
}

.mobile-brand {
  display: flex;
  align-items: center;
  gap: 10px;
}

.mobile-logo {
  height: 34px;
  width: 34px;
  border-radius: 50%;
  object-fit: cover;
  border: 1.5px solid rgba(255,255,255,0.3);
}

.mobile-title {
  font-size: 1.1rem;
  font-weight: 700;
  letter-spacing: 0.5px;
}

/* Sidebar Overlay */
.sidebar-overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(2px);
  z-index: 1040;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.sidebar-overlay.show {
  display: block;
  opacity: 1;
}

/* Sidebar Core */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  width: var(--admin-sidebar-width);
  height: 100vh;
  background-color: var(--admin-sidebar-bg);
  color: var(--admin-sidebar-text);
  z-index: 1045;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 12px rgba(0,0,0,0.15);
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), left 0.3s ease;
}

.sidebar-header {
  padding: 14px 14px 16px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  position: relative;
  width: 100%;
}

.header-top-actions {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 6px;
}

.brand-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  color: #fff;
  width: 100%;
  text-align: center;
}

.logo-sidebar {
  width: 90px;
  height: 90px;
  min-width: 90px;
  max-width: 90px;
  min-height: 90px;
  max-height: 90px;
  object-fit: cover;
  border-radius: 50%;
  background: #ffffff;
  padding: 3px;
  margin: 0 auto 10px auto;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  border: 2px solid rgba(255,255,255,0.2);
  transition: all 0.3s ease;
  display: block;
}

.brand-name {
  font-size: 1.15rem;
  font-weight: 700;
  letter-spacing: 0.8px;
  white-space: nowrap;
  margin: 0;
  color: #fff;
  text-align: center;
  transition: opacity 0.2s ease;
}

.btn-sidebar-toggle, .btn-sidebar-close {
  background: rgba(255,255,255,0.08);
  border: none;
  color: white;
  font-size: 15px;
  width: 34px;
  height: 34px;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: background-color 0.2s, transform 0.2s;
}

.btn-sidebar-toggle:hover, .btn-sidebar-close:hover {
  background: rgba(255,255,255,0.18);
}

.sidebar-menu-wrapper {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 14px 10px;
}

.sidebar-menu-wrapper::-webkit-scrollbar {
  width: 5px;
}
.sidebar-menu-wrapper::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.15);
  border-radius: 4px;
}

.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.menu-item {
  width: 100%;
}

.menu-link {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 11px 16px;
  color: rgba(255,255,255,0.85);
  text-decoration: none;
  font-size: 0.93rem;
  font-weight: 500;
  border-radius: 8px;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.menu-link i {
  font-size: 1.1rem;
  width: 22px;
  text-align: center;
  flex-shrink: 0;
}

.menu-link:hover {
  background-color: var(--admin-sidebar-hover);
  color: #ffffff;
  transform: translateX(3px);
}

.menu-link.active {
  background-color: var(--admin-sidebar-active);
  color: #ffffff;
  font-weight: 600;
  box-shadow: 0 4px 10px rgba(142, 90, 18, 0.35);
}

.menu-link.text-danger-hover:hover {
  background-color: rgba(220, 53, 69, 0.2);
}

.menu-divider {
  height: 1px;
  background: rgba(255,255,255,0.08);
  margin: 8px 6px;
}

.sidebar-footer {
  padding: 12px 16px;
  border-top: 1px solid rgba(255,255,255,0.08);
  text-align: center;
  font-size: 0.75rem;
  white-space: nowrap;
  overflow: hidden;
}

/* ========================================================= */
/* 🌟 COLLAPSED SIDEBAR RULES (Always active when .collapsed) */
/* ========================================================= */
.sidebar.collapsed {
  width: var(--admin-sidebar-collapsed-width) !important;
  overflow: visible !important;
}

.sidebar.collapsed .sidebar-header {
  padding: 12px 4px !important;
  gap: 8px !important;
  min-height: auto !important;
}

.sidebar.collapsed .header-top-actions {
  justify-content: center !important;
  margin-bottom: 0 !important;
  width: 100% !important;
}

.sidebar.collapsed .brand-wrapper {
  display: flex !important;
  flex-direction: column !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  margin: 0 auto !important;
  padding: 0 !important;
}

.sidebar.collapsed .logo-sidebar {
  display: block !important;
  width: 32px !important;
  height: 32px !important;
  min-width: 32px !important;
  max-width: 32px !important;
  min-height: 32px !important;
  max-height: 32px !important;
  object-fit: cover !important;
  border-radius: 50% !important;
  background: #ffffff !important;
  padding: 1px !important;
  margin: 6px auto 0 auto !important;
  box-shadow: 0 2px 6px rgba(0,0,0,0.3) !important;
  border: 1px solid rgba(255,255,255,0.2) !important;
}

.sidebar.collapsed .brand-name,
.sidebar.collapsed .menu-text,
.sidebar.collapsed .sidebar-footer {
  display: none !important;
}

.sidebar.collapsed .btn-sidebar-toggle {
  margin: 0 auto !important;
  width: 34px !important;
  height: 34px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
}

.sidebar.collapsed .sidebar-menu-wrapper {
  padding: 10px 4px !important;
  overflow: visible !important;
}

.sidebar.collapsed .sidebar-menu {
  align-items: center !important;
}

.sidebar.collapsed .menu-item {
  display: flex !important;
  justify-content: center !important;
  width: 100% !important;
}

.sidebar.collapsed .menu-link {
  width: 42px !important;
  height: 42px !important;
  padding: 0 !important;
  margin: 0 auto !important;
  border-radius: 8px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  position: relative !important;
}

.sidebar.collapsed .menu-link i {
  font-size: 1.15rem !important;
  margin: 0 !important;
  width: auto !important;
}

.sidebar.collapsed .menu-link:hover {
  transform: none !important;
  background-color: rgba(255,255,255,0.12) !important;
}

.sidebar.collapsed .menu-link.active {
  background-color: var(--admin-sidebar-active) !important;
  color: #fff !important;
  box-shadow: 0 4px 12px rgba(142, 90, 18, 0.4) !important;
}

/* Floating Tooltips on Collapsed Hover */
.sidebar.collapsed .menu-link::after {
  content: attr(data-title);
  position: absolute;
  left: calc(100% + 14px);
  top: 50%;
  transform: translateY(-50%) scale(0.92);
  background: #091e17;
  border: 1px solid rgba(255,255,255,0.2);
  color: #ffffff;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 0.82rem;
  font-weight: 600;
  letter-spacing: 0.3px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease, transform 0.15s ease;
  box-shadow: 0 4px 14px rgba(0,0,0,0.35);
  z-index: 1065;
}

.sidebar.collapsed .menu-link::before {
  content: '';
  position: absolute;
  left: calc(100% + 8px);
  top: 50%;
  transform: translateY(-50%);
  border-width: 5px 6px 5px 0;
  border-style: solid;
  border-color: transparent #091e17 transparent transparent;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  z-index: 1065;
}

.sidebar.collapsed .menu-link:hover::after {
  opacity: 1;
  transform: translateY(-50%) scale(1);
}

.sidebar.collapsed .menu-link:hover::before {
  opacity: 1;
}

.sidebar.collapsed .menu-divider {
  width: 36px !important;
  margin: 8px auto !important;
}

/* Desktop Styles */
@media (min-width: 992px) {
  .main-content {
    margin-left: var(--admin-sidebar-width);
    padding: 30px 40px;
    min-height: 100vh;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .main-content.collapsed {
    margin-left: var(--admin-sidebar-collapsed-width) !important;
  }
}

/* Mobile & Tablet Responsive (< 992px) */
@media (max-width: 991.98px) {
  .mobile-topbar {
    display: flex !important;
  }

  .sidebar {
    left: -280px;
    width: 260px;
    transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .sidebar.mobile-show {
    left: 0 !important;
  }

  .main-content {
    margin-left: 0 !important;
    padding: 20px 15px !important;
    width: 100% !important;
  }

  .table-responsive {
    margin-bottom: 1rem;
    border-radius: 8px;
    background: #fff;
  }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const sidebar = document.getElementById('sidebar');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  const toggleBtn = document.getElementById('toggleSidebar');
  const mobileToggleBtn = document.getElementById('mobileSidebarToggle');
  const closeSidebarMobile = document.getElementById('closeSidebarMobile');
  const mainContent = document.querySelector('.main-content');

  // Load desktop collapsed state from localStorage
  if (window.innerWidth >= 992) {
    const isCollapsed = localStorage.getItem('semar_admin_sidebar_collapsed') === 'true';
    if (isCollapsed) {
      sidebar.classList.add('collapsed');
      if (mainContent) mainContent.classList.add('collapsed');
    }
  }

  // Desktop Toggle
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function(e) {
      e.preventDefault();
      sidebar.classList.toggle('collapsed');
      if (mainContent) mainContent.classList.toggle('collapsed');
      const collapsed = sidebar.classList.contains('collapsed');
      localStorage.setItem('semar_admin_sidebar_collapsed', collapsed ? 'true' : 'false');
    });
  }

  // Mobile Open Sidebar
  function openMobileSidebar() {
    sidebar.classList.add('mobile-show');
    sidebarOverlay.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  // Mobile Close Sidebar
  function closeMobileSidebar() {
    sidebar.classList.remove('mobile-show');
    sidebarOverlay.classList.remove('show');
    document.body.style.overflow = '';
  }

  if (mobileToggleBtn) {
    mobileToggleBtn.addEventListener('click', function(e) {
      e.preventDefault();
      openMobileSidebar();
    });
  }

  if (closeSidebarMobile) {
    closeSidebarMobile.addEventListener('click', function(e) {
      e.preventDefault();
      closeMobileSidebar();
    });
  }

  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', function() {
      closeMobileSidebar();
    });
  }

  // Close on Escape key press
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && sidebar.classList.contains('mobile-show')) {
      closeMobileSidebar();
    }
  });

  // Handle window resize
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 992) {
      closeMobileSidebar();
      const isCollapsed = localStorage.getItem('semar_admin_sidebar_collapsed') === 'true';
      if (isCollapsed) {
        sidebar.classList.add('collapsed');
        if (mainContent) mainContent.classList.add('collapsed');
      } else {
        sidebar.classList.remove('collapsed');
        if (mainContent) mainContent.classList.remove('collapsed');
      }
    }
  });
});
</script>