<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$in_subfolder = (basename(dirname($_SERVER['PHP_SELF'])) !== 'admin');
$admin_base = $in_subfolder ? '../' : './';
$assets_base = $in_subfolder ? '../../' : '../';

$current_page = basename($_SERVER['PHP_SELF']);

// Ambil foto & nama dari akun admin yang sedang login
$sidebar_admin_foto = null;
$sidebar_admin_nama = 'RuangAdmin';

if (isset($_SESSION['id_admin'])) {
    $admin_id_sess = (int)$_SESSION['id_admin'];
    
    // Pastikan koneksi database tersedia
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $koneksi_file = $in_subfolder ? '../../koneksi.php' : '../koneksi.php';
        if (file_exists($koneksi_file)) {
            include_once $koneksi_file;
        }
    }
    
    if (isset($conn) && $conn instanceof mysqli) {
        $stmt_sidebar = $conn->prepare("SELECT nama, foto FROM admin WHERE id = ?");
        if ($stmt_sidebar) {
            $stmt_sidebar->bind_param("i", $admin_id_sess);
            $stmt_sidebar->execute();
            $res_sidebar = $stmt_sidebar->get_result()->fetch_assoc();
            if ($res_sidebar) {
                if (!empty($res_sidebar['foto'])) {
                    $uploads_check = ($in_subfolder ? '../' : './') . 'uploads/admin/' . $res_sidebar['foto'];
                    if (file_exists($uploads_check)) {
                        $sidebar_admin_foto = $admin_base . 'uploads/admin/' . htmlspecialchars($res_sidebar['foto']);
                    }
                }
                if (!empty($res_sidebar['nama'])) {
                    $sidebar_admin_nama = htmlspecialchars($res_sidebar['nama']);
                }
            }
            $stmt_sidebar->close();
        }
    }
}

// Fallback jika belum pasang foto profil
if (!$sidebar_admin_foto) {
    $sidebar_admin_foto = $assets_base . 'assets/images/default-profile.jpg';
}

// ==========================================
// 🔔 HITUNG NOTIFIKASI OPERASIONAL ADMIN (REAL-TIME)
// ==========================================
$notif_pembayaran = 0;
$notif_sewa = 0;
$notif_pengembalian = 0;
$notif_items = [];

if (isset($conn) && $conn instanceof mysqli) {
    // 1. Pembayaran Menunggu Konfirmasi
    $qNP = mysqli_query($conn, "SELECT COUNT(id) AS cnt FROM pembayaran WHERE LOWER(TRIM(status)) = 'menunggu konfirmasi'");
    if ($qNP) {
        $notif_pembayaran = (int)(mysqli_fetch_assoc($qNP)['cnt'] ?? 0);
    }
    
    // 2. Sewa Perlu Disiapkan / Diantar
    $qNS = mysqli_query($conn, "SELECT COUNT(id) AS cnt FROM sewa WHERE LOWER(TRIM(status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar')");
    if ($qNS) {
        $notif_sewa = (int)(mysqli_fetch_assoc($qNS)['cnt'] ?? 0);
    }
    
    // 3. Pengembalian: Sewa yang selesai
    $qNK = mysqli_query($conn, "SELECT COUNT(DISTINCT no_tagihan) AS cnt FROM sewa WHERE LOWER(TRIM(status)) = 'selesai'");
    if ($qNK) {
        $notif_pengembalian = (int)(mysqli_fetch_assoc($qNK)['cnt'] ?? 0);
    }

    // Ambil daftar notifikasi terkini untuk dropdown lonceng
    $qRecentPay = mysqli_query($conn, "
        SELECT p.id, p.jumlah_bayar, p.tanggal_bayar, u.nama 
        FROM pembayaran p
        JOIN users u ON p.id_users = u.id
        WHERE LOWER(TRIM(p.status)) = 'menunggu konfirmasi'
        ORDER BY p.tanggal_bayar DESC, p.id DESC
        LIMIT 3
    ");
    if ($qRecentPay) {
        while ($r = mysqli_fetch_assoc($qRecentPay)) {
            $notif_items[] = [
                'icon' => 'fas fa-cash-register text-danger',
                'bg' => 'bg-danger bg-opacity-10',
                'title' => 'Pembayaran Menunggu Konfirmasi',
                'desc' => htmlspecialchars($r['nama']) . ' menyetor Rp ' . number_format($r['jumlah_bayar'], 0, ',', '.'),
                'time' => !empty($r['tanggal_bayar']) ? date('H:i, d M', strtotime($r['tanggal_bayar'])) : 'Baru saja',
                'url' => $admin_base . 'pembayaran/pembayaran.php?tab=semua'
            ];
        }
    }
    
    $qRecentSewa = mysqli_query($conn, "
        SELECT s.id, s.nama_produk, s.status, u.nama
        FROM sewa s
        JOIN users u ON s.id_users = u.id
        WHERE LOWER(TRIM(s.status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar')
        ORDER BY s.id DESC
        LIMIT 2
    ");
    if ($qRecentSewa) {
        while ($r = mysqli_fetch_assoc($qRecentSewa)) {
            $notif_items[] = [
                'icon' => 'fas fa-box-open text-danger',
                'bg' => 'bg-danger bg-opacity-10',
                'title' => 'Pesanan Perlu Disiapkan',
                'desc' => htmlspecialchars($r['nama']) . ' - ' . htmlspecialchars($r['nama_produk']),
                'time' => ucfirst($r['status']),
                'url' => $admin_base . 'riwayat/riwayat.php?tab=berlangsung'
            ];
        }
    }

    $qRecentKembali = mysqli_query($conn, "
        SELECT s.id, s.nama_produk, u.nama
        FROM sewa s
        JOIN users u ON s.id_users = u.id
        WHERE LOWER(TRIM(s.status)) = 'berlangsung'
        ORDER BY s.id DESC
        LIMIT 2
    ");
    if ($qRecentKembali) {
        while ($r = mysqli_fetch_assoc($qRecentKembali)) {
            $notif_items[] = [
                'icon' => 'fas fa-undo-alt text-warning',
                'bg' => 'bg-warning bg-opacity-10',
                'title' => 'Alat Sedang Disewa',
                'desc' => htmlspecialchars($r['nama']) . ' - ' . htmlspecialchars($r['nama_produk']),
                'time' => 'Menunggu Pengembalian',
                'url' => $admin_base . 'riwayat/riwayat.php?tab=berlangsung'
            ];
        }
    }
}
$total_notif = $notif_pembayaran + $notif_sewa + $notif_pengembalian;
?>

<!-- Mobile Topbar Navigation (Visible on screen < 992px) -->
<div class="mobile-topbar d-lg-none" id="mobileTopbar">
  <button id="mobileSidebarToggle" class="btn-mobile-toggle" type="button" aria-label="Buka Menu Sidebar">
    <i class="fa fa-bars"></i>
  </button>
  <div class="mobile-brand">
    <img src="<?= $sidebar_admin_foto ?>" alt="Foto Admin" class="mobile-logo">
    <span class="mobile-title">RuangAdmin</span>
  </div>
  <a href="<?= $admin_base ?>profile_admin.php" class="mobile-profile-btn" title="Profil Admin">
    <i class="fa fa-user-circle"></i>
  </a>
</div>

<!-- Backdrop Overlay for Mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Main Admin Sidebar -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <div class="header-top-actions">
      <!-- Desktop Collapse Button -->
      <button id="toggleSidebar" class="btn-sidebar-toggle d-none d-lg-flex" type="button" aria-label="Toggle Sidebar" title="Sembunyikan / Buka Sidebar">
        <i class="fa fa-bars"></i>
      </button>
      <!-- Mobile Close Button -->
      <button id="closeSidebarMobile" class="btn-sidebar-close d-lg-none" type="button" aria-label="Tutup Sidebar">
        <i class="fa fa-times"></i>
      </button>
    </div>

    <a href="<?= $admin_base ?>profile_admin.php" class="brand-wrapper" title="Buka Profil Admin">
      <img src="<?= $sidebar_admin_foto ?>" alt="Foto Admin" class="logo-sidebar">
      <h4 class="brand-name">RuangAdmin</h4>
    </a>
  </div>

  <div class="sidebar-menu-wrapper">
    <ul class="sidebar-menu">
      <li class="menu-item">
        <a href="<?= $admin_base ?>dashboard/dashboard.php" class="menu-link <?= ($current_page == 'dashboard.php') ? 'active' : '' ?>" data-title="Dashboard" title="Dashboard">
          <i class="fa fa-tachometer-alt"></i>
          <span class="menu-text">Dashboard</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>pengguna/pengguna.php" class="menu-link <?= ($current_page == 'pengguna.php') ? 'active' : '' ?>" data-title="Pengguna" title="Pengguna">
          <i class="fa fa-users"></i>
          <span class="menu-text">Pengguna</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>alat/list_alat.php" class="menu-link <?= ($current_page == 'list_alat.php') ? 'active' : '' ?>" data-title="Alat Rental" title="Alat Rental">
          <i class="fa fa-toolbox"></i>
          <span class="menu-text">Alat Rental</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>riwayat/riwayat.php" class="menu-link <?= ($current_page == 'riwayat.php') ? 'active' : '' ?>" data-title="Riwayat Sewa" title="Riwayat Sewa">
          <i class="fa fa-shopping-cart"></i>
          <span class="menu-text">Riwayat Sewa</span>
          <span class="menu-notif-bell ms-auto <?= ($notif_sewa > 0) ? '' : 'd-none' ?>" id="wrapSewa" style="<?= ($notif_sewa > 0) ? '' : 'display: none !important;' ?>">
            <i class="fa fa-bell notif-bell-icon"></i>
            <span class="notif-badge-circle" id="badgeSewa"><?= $notif_sewa ?></span>
          </span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>pengembalian/pengembalian.php" class="menu-link <?= ($current_page == 'pengembalian.php') ? 'active' : '' ?>" data-title="Pengembalian" title="Pengembalian">
          <i class="fa fa-undo-alt"></i>
          <span class="menu-text">Pengembalian</span>
          <span class="menu-notif-bell ms-auto <?= ($notif_pengembalian > 0) ? '' : 'd-none' ?>" id="wrapPengembalian" style="<?= ($notif_pengembalian > 0) ? '' : 'display: none !important;' ?>">
            <i class="fa fa-bell notif-bell-icon"></i>
            <span class="notif-badge-circle" id="badgePengembalian"><?= $notif_pengembalian ?></span>
          </span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>pembayaran/pembayaran.php" class="menu-link <?= ($current_page == 'pembayaran.php') ? 'active' : '' ?>" data-title="Pembayaran" title="Pembayaran">
          <i class="fa fa-credit-card"></i>
          <span class="menu-text">Pembayaran</span>
          <span class="menu-notif-bell ms-auto <?= ($notif_pembayaran > 0) ? '' : 'd-none' ?>" id="wrapPembayaran" style="<?= ($notif_pembayaran > 0) ? '' : 'display: none !important;' ?>">
            <i class="fa fa-bell notif-bell-icon"></i>
            <span class="notif-badge-circle" id="badgePembayaran"><?= $notif_pembayaran ?></span>
          </span>
        </a>
      </li>

      <li class="menu-divider"></li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>profile_admin.php" class="menu-link <?= ($current_page == 'profile_admin.php') ? 'active' : '' ?>" data-title="Profil Admin" title="Profil Admin">
          <i class="fa fa-user-cog"></i>
          <span class="menu-text">Profil Admin</span>
        </a>
      </li>

      <li class="menu-item">
        <a href="<?= $admin_base ?>logout_admin.php" class="menu-link text-danger-hover" data-title="Logout" title="Logout">
          <i class="fa fa-sign-out-alt text-danger"></i>
          <span class="menu-text text-danger">Logout</span>
        </a>
      </li>
    </ul>
  </div>

  <div class="sidebar-footer">
    <small class="version-text text-muted">&copy; <?= date('Y') ?> Semar Outdoor</small>
  </div>
</nav>

<!-- Live Toast Notification Container -->
<div class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 999999;" id="adminToastContainer"></div>

<style>
:root {
  --admin-sidebar-width: 190px;
  --admin-sidebar-collapsed-width: 58px;
  --admin-sidebar-bg: #091e17;
  --admin-sidebar-hover: #237042;
  --admin-sidebar-hover-gradient: linear-gradient(135deg, #1e633a 0%, #2e8b4e 100%);
  --admin-sidebar-active: #e2e1de;
  --admin-sidebar-active-gradient: linear-gradient(135deg, #fdfbf9 0%, #ece8e2 100%);
  --admin-sidebar-text: #e2e8f0;
}

body {
  background-color: #f8f9fc;
  min-height: 100vh;
  margin: 0;
}

/* Mobile Topbar */
.mobile-topbar {
  display: none;
  background-color: var(--admin-sidebar-bg);
  color: white;
  padding: 8px 14px;
  position: sticky;
  top: 0;
  z-index: 1025;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 2px 10px rgba(0,0,0,0.18);
}

.btn-mobile-toggle, .mobile-profile-btn {
  background: none;
  border: none;
  color: white;
  font-size: 18px;
  padding: 4px 8px;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s;
  text-decoration: none;
}

.btn-mobile-toggle:hover, .mobile-profile-btn:hover {
  background: rgba(255,255,255,0.12);
  color: #fff;
}

.mobile-brand {
  display: flex;
  align-items: center;
  gap: 8px;
}

.mobile-logo {
  height: 30px;
  width: 30px;
  border-radius: 50%;
  object-fit: cover;
  border: 1.5px solid rgba(255,255,255,0.3);
}

.mobile-title {
  font-size: 1.0rem;
  font-weight: 700;
  letter-spacing: 0.4px;
}

/* Sidebar Overlay */
.sidebar-overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.55);
  backdrop-filter: blur(2px);
  z-index: 1040;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.sidebar-overlay.show {
  display: block;
  opacity: 1;
}

/* Sidebar Core */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  width: var(--admin-sidebar-width);
  height: 100vh;
  background-color: var(--admin-sidebar-bg);
  color: var(--admin-sidebar-text);
  z-index: 1045;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 12px rgba(0,0,0,0.15);
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1), transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), left 0.3s ease;
}

.sidebar-header {
  padding: 10px 10px 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  position: relative;
  width: 100%;
}

.header-top-actions {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 4px;
}

.brand-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  color: #fff;
  width: 100%;
  text-align: center;
}

.logo-sidebar {
  width: 48px;
  height: 48px;
  min-width: 48px;
  max-width: 48px;
  min-height: 48px;
  max-height: 48px;
  object-fit: cover;
  border-radius: 50%;
  background: #ffffff;
  padding: 2px;
  margin: 0 auto 5px auto;
  box-shadow: 0 3px 8px rgba(0,0,0,0.25);
  border: 1.5px solid rgba(255,255,255,0.25);
  transition: all 0.3s ease;
  display: block;
}

.brand-name {
  font-size: 0.92rem;
  font-weight: 700;
  letter-spacing: 0.4px;
  white-space: nowrap;
  margin: 0;
  color: #fff;
  text-align: center;
  transition: opacity 0.2s ease;
}

.btn-sidebar-toggle, .btn-sidebar-close {
  background: rgba(255,255,255,0.08);
  border: none;
  color: white;
  font-size: 13px;
  width: 28px;
  height: 28px;
  border-radius: 5px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: background-color 0.2s, transform 0.2s;
}

.btn-sidebar-toggle:hover, .btn-sidebar-close:hover {
  background: rgba(255,255,255,0.18);
}

.sidebar-menu-wrapper {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  padding: 8px 6px;
}

.sidebar-menu-wrapper::-webkit-scrollbar {
  width: 4px;
}
.sidebar-menu-wrapper::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.15);
  border-radius: 4px;
}

.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.menu-item {
  width: 100%;
}

.menu-link {
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 7px 10px;
  color: rgba(226, 232, 240, 0.75);
  text-decoration: none;
  font-size: 0.80rem;
  font-weight: 500;
  border-radius: 6px;
  border: 1px solid transparent;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  white-space: nowrap;
}

.menu-link i {
  font-size: 0.92rem;
  width: 18px;
  text-align: center;
  flex-shrink: 0;
  color: rgba(226, 232, 240, 0.65);
  transition: color 0.2s ease;
}

.menu-link:hover {
  background: rgba(35, 112, 66, 0.22) !important;
  color: #ecfdf5 !important;
  border-color: rgba(74, 222, 128, 0.28) !important;
  transform: translateX(2px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

.menu-link:hover i {
  color: #6ee7b7 !important;
}

.menu-link.active {
  background: rgba(221, 218, 215, 0.22) !important;
  color: #f3f2ef !important;
  border-color: rgba(247, 244, 239, 0.38) !important;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(238, 237, 235, 0.18);
}

.menu-link.active i {
  color: #f1f0eb !important;
}

.menu-link.text-danger-hover:hover {
  background: rgba(239, 68, 68, 0.15) !important;
  border-color: rgba(239, 68, 68, 0.25) !important;
  color: #fca5a5 !important;
}
.menu-link.text-danger-hover:hover i {
  color: #f87171 !important;
}

.menu-divider {
  height: 1px;
  background: rgba(255,255,255,0.08);
  margin: 5px 4px;
}

.sidebar-footer {
  padding: 8px 10px;
  border-top: 1px solid rgba(255,255,255,0.08);
  text-align: center;
  font-size: 0.68rem;
  white-space: nowrap;
  overflow: hidden;
}

/* ========================================================= */
/* 🌟 COLLAPSED SIDEBAR RULES (Always active when .collapsed) */
/* ========================================================= */
.sidebar.collapsed {
  width: var(--admin-sidebar-collapsed-width) !important;
  overflow: visible !important;
}

.sidebar.collapsed .sidebar-header {
  padding: 8px 4px !important;
  gap: 6px !important;
  min-height: auto !important;
}

.sidebar.collapsed .header-top-actions {
  justify-content: center !important;
  margin-bottom: 0 !important;
  width: 100% !important;
}

.sidebar.collapsed .brand-wrapper {
  display: flex !important;
  flex-direction: column !important;
  justify-content: center !important;
  align-items: center !important;
  width: 100% !important;
  margin: 0 auto !important;
  padding: 0 !important;
}

.sidebar.collapsed .logo-sidebar {
  display: block !important;
  width: 28px !important;
  height: 28px !important;
  min-width: 28px !important;
  max-width: 28px !important;
  min-height: 28px !important;
  max-height: 28px !important;
  object-fit: cover !important;
  border-radius: 50% !important;
  background: #ffffff !important;
  padding: 1px !important;
  margin: 4px auto 0 auto !important;
  box-shadow: 0 2px 6px rgba(0,0,0,0.3) !important;
  border: 1px solid rgba(255,255,255,0.2) !important;
}

.sidebar.collapsed .brand-name,
.sidebar.collapsed .menu-text,
.sidebar.collapsed .sidebar-footer {
  display: none !important;
}

.sidebar.collapsed .btn-sidebar-toggle {
  margin: 0 auto !important;
  width: 28px !important;
  height: 28px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
}

.sidebar.collapsed .sidebar-menu-wrapper {
  padding: 8px 3px !important;
  overflow: visible !important;
}

.sidebar.collapsed .sidebar-menu {
  align-items: center !important;
}

.sidebar.collapsed .menu-item {
  display: flex !important;
  justify-content: center !important;
  width: 100% !important;
}

.sidebar.collapsed .menu-link {
  width: 36px !important;
  height: 36px !important;
  padding: 0 !important;
  margin: 0 auto !important;
  border-radius: 6px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  position: relative !important;
}

.sidebar.collapsed .menu-link i {
  font-size: 1.0rem !important;
  margin: 0 !important;
  width: auto !important;
}

.sidebar.collapsed .menu-link:hover {
  transform: none !important;
  background: rgba(35, 112, 66, 0.25) !important;
  border-color: rgba(74, 222, 128, 0.3) !important;
  color: #ecfdf5 !important;
}

.sidebar.collapsed .menu-link:hover i {
  color: #6ee7b7 !important;
}

.sidebar.collapsed .menu-link.active {
  background: rgba(217, 119, 6, 0.25) !important;
  border-color: rgba(251, 191, 36, 0.4) !important;
  color: #fef3c7 !important;
  box-shadow: 0 2px 8px rgba(217, 119, 6, 0.2);
}

.sidebar.collapsed .menu-link.active i {
  color: #fcd34d !important;
}

/* Floating Tooltips on Collapsed Hover */
.sidebar.collapsed .menu-link::after {
  content: attr(data-title);
  position: absolute;
  left: calc(100% + 12px);
  top: 50%;
  transform: translateY(-50%) scale(0.92);
  background: #091e17;
  border: 1px solid rgba(255,255,255,0.2);
  color: #ffffff;
  padding: 5px 10px;
  border-radius: 5px;
  font-size: 0.78rem;
  font-weight: 600;
  letter-spacing: 0.3px;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease, transform 0.15s ease;
  box-shadow: 0 4px 14px rgba(0,0,0,0.35);
  z-index: 1065;
}

.sidebar.collapsed .menu-link::before {
  content: '';
  position: absolute;
  left: calc(100% + 6px);
  top: 50%;
  transform: translateY(-50%);
  border-width: 5px 6px 5px 0;
  border-style: solid;
  border-color: transparent #091e17 transparent transparent;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s ease;
  z-index: 1065;
}

.sidebar.collapsed .menu-link:hover::after {
  opacity: 1;
  transform: translateY(-50%) scale(1);
}

.sidebar.collapsed .menu-link:hover::before {
  opacity: 1;
}

.sidebar.collapsed .menu-divider {
  width: 28px !important;
  margin: 6px auto !important;
}

/* Desktop Styles */
@media (min-width: 992px) {
  .main-content {
    margin-left: var(--admin-sidebar-width);
    padding: 20px 26px;
    min-height: 100vh;
    transition: margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .main-content.collapsed {
    margin-left: var(--admin-sidebar-collapsed-width) !important;
  }
}

/* Mobile & Tablet Responsive (< 992px) */
@media (max-width: 991.98px) {
  .mobile-topbar {
    display: flex !important;
  }

  .sidebar {
    left: -240px;
    width: 210px;
    transition: left 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .sidebar.mobile-show {
    left: 0 !important;
  }

  .main-content {
    margin-left: 0 !important;
    padding: 16px 12px !important;
    width: 100% !important;
  }

  .table-responsive {
    margin-bottom: 1rem;
    border-radius: 8px;
    background: #fff;
  }
}

/* ========================================================= */
/* 🌟 UNIVERSAL SMOOTH & SOFT ADMIN PALETTE & STYLES         */
/* ========================================================= */
:root {
  --brand-primary: #0e4430;
  --brand-primary-hover: #155e43;
  --brand-accent: #f59e0b;
  --surface-bg: #f8fafc;
  --card-border: #e2e8f0;
}

body {
  font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background-color: var(--surface-bg) !important;
  color: #1e293b;
}

.table-responsive {
  background: #ffffff !important;
  border-radius: 10px !important;
  border: 1px solid #e2e8f0 !important;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.03) !important;
  margin-bottom: 1.25rem !important;
  overflow-x: auto !important;
}

.table {
  margin-bottom: 0 !important;
  font-size: 0.80rem !important;
  border-collapse: collapse !important;
  background: #ffffff !important;
}

.table thead th {
  background-color: #f1f5f9 !important;
  color: #334155 !important;
  font-size: 0.72rem !important;
  font-weight: 700 !important;
  text-transform: uppercase !important;
  letter-spacing: 0.5px !important;
  padding: 8px 10px !important;
  border-bottom: 2px solid #cbd5e1 !important;
  border-top: none !important;
  white-space: nowrap !important;
  vertical-align: middle !important;
}

.table tbody td {
  padding: 7px 10px !important;
  vertical-align: middle !important;
  color: #1e293b !important;
  border-color: #f1f5f9 !important;
  line-height: 1.35 !important;
  font-size: 0.80rem !important;
}

.table tbody tr:hover {
  background-color: #f8fafc !important;
}

/* 🌿 Soft Pastel Badges */
.badge {
  font-size: 0.70rem !important;
  font-weight: 600 !important;
  padding: 3px 7px !important;
  letter-spacing: 0.2px !important;
  border-radius: 5px !important;
  display: inline-flex !important;
  align-items: center !important;
  line-height: 1.2 !important;
}

.badge.bg-primary {
  background-color: #e0f2fe !important;
  color: #0369a1 !important;
  border: 1px solid #bae6fd !important;
}

.badge.bg-success {
  background-color: #ecfdf5 !important;
  color: #065f46 !important;
  border: 1px solid #a7f3d0 !important;
}

.badge.bg-warning {
  background-color: #fef3c7 !important;
  color: #92400e !important;
  border: 1px solid #fde68a !important;
}

.badge.bg-danger {
  background-color: #fef2f2 !important;
  color: #991b1b !important;
  border: 1px solid #fecaca !important;
}

.badge.bg-secondary {
  background-color: #f1f5f9 !important;
  color: #475569 !important;
  border: 1px solid #cbd5e1 !important;
}

.badge.bg-dark {
  background-color: #1e293b !important;
  color: #f8fafc !important;
  border: 1px solid #334155 !important;
}

.badge.bg-info {
  background-color: #ecfeff !important;
  color: #0e7490 !important;
  border: 1px solid #a5f3fc !important;
}

.badge.bg-light {
  background-color: #f8fafc !important;
  color: #334155 !important;
  border: 1px solid #e2e8f0 !important;
}

/* 🎨 Soft Smooth Action Buttons */
.btn-primary {
  background: linear-gradient(135deg, #0e4430 0%, #155e43 100%) !important;
  border-color: #0e4430 !important;
  color: #ffffff !important;
  box-shadow: 0 2px 6px rgba(14, 68, 48, 0.2) !important;
  transition: all 0.2s ease !important;
}
.btn-primary:hover {
  background: linear-gradient(135deg, #155e43 0%, #1c7454 100%) !important;
  border-color: #155e43 !important;
  transform: translateY(-1px) !important;
  box-shadow: 0 4px 10px rgba(14, 68, 48, 0.28) !important;
}

.btn-warning {
  background-color: #fef3c7 !important;
  color: #92400e !important;
  border: 1px solid #fde68a !important;
  transition: all 0.15s ease !important;
}
.btn-warning:hover {
  background-color: #fde68a !important;
  color: #78350f !important;
  transform: translateY(-1px) !important;
}

.btn-danger {
  background-color: #fee2e2 !important;
  color: #991b1b !important;
  border: 1px solid #fecaca !important;
  transition: all 0.15s ease !important;
}
.btn-danger:hover {
  background-color: #fecaca !important;
  color: #7f1d1d !important;
  transform: translateY(-1px) !important;
}

.btn-outline-primary {
  background-color: #f0fdf4 !important;
  color: #0e4430 !important;
  border-color: #bbf7d0 !important;
  transition: all 0.15s ease !important;
}
.btn-outline-primary:hover {
  background-color: #0e4430 !important;
  color: #ffffff !important;
  border-color: #0e4430 !important;
  transform: translateY(-1px) !important;
}

.btn-outline-danger {
  background-color: #fff1f2 !important;
  color: #991b1b !important;
  border-color: #fecdd3 !important;
  transition: all 0.15s ease !important;
}
.btn-outline-danger:hover {
  background-color: #e11d48 !important;
  color: #ffffff !important;
  border-color: #e11d48 !important;
  transform: translateY(-1px) !important;
}

.btn-outline-success {
  background-color: #f0fdf4 !important;
  color: #166534 !important;
  border-color: #bbf7d0 !important;
  transition: all 0.15s ease !important;
}
.btn-outline-success:hover {
  background-color: #166534 !important;
  color: #ffffff !important;
  border-color: #166534 !important;
  transform: translateY(-1px) !important;
}

.btn-outline-info {
  background-color: #f0f9ff !important;
  color: #0369a1 !important;
  border-color: #bae6fd !important;
  transition: all 0.15s ease !important;
}
.btn-outline-info:hover {
  background-color: #0284c7 !important;
  color: #ffffff !important;
  border-color: #0284c7 !important;
  transform: translateY(-1px) !important;
}

.table .img-thumb, 
.table .img-thumb-bukti,
.table .thumbnail {
  width: 32px !important;
  height: 32px !important;
  object-fit: cover !important;
  border-radius: 6px !important;
  border: 1px solid #cbd5e1 !important;
  transition: transform 0.15s ease, box-shadow 0.15s ease !important;
}

.table .img-thumb-bukti:hover {
  transform: scale(1.3) !important;
  box-shadow: 0 4px 10px rgba(0,0,0,0.15) !important;
  z-index: 10 !important;
}

.aksi-btn {
  display: flex !important;
  gap: 5px !important;
  align-items: center !important;
  justify-content: center !important;
  flex-wrap: nowrap !important;
  white-space: nowrap !important;
}

/* ========================================================= */
/* 🌟 STANDARDIZED ACTION BUTTONS & SEARCH SIZING           */
/* ========================================================= */

/* Header Top Action Buttons (Tambah, Cetak, etc.) */
.btn-admin-header {
  height: 34px !important;
  padding: 0 13px !important;
  font-size: 0.82rem !important;
  font-weight: 600 !important;
  border-radius: 6px !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 6px !important;
  line-height: 1 !important;
  white-space: nowrap !important;
  text-decoration: none !important;
}

/* Header Top Search Bar */
.search-input-admin, 
.form-control.search-input-admin {
  height: 34px !important;
  padding: 0 12px !important;
  font-size: 0.82rem !important;
  border-radius: 6px !important;
  border: 1px solid #cbd5e1 !important;
  background-color: #ffffff !important;
}

/* Standardized Card & Table Action Buttons (Edit, Hapus, Detail, Status, Bukti, Invoice) */
.btn-admin-action, 
.table .btn-admin-action,
.table .btn-sm,
.aksi-btn .btn,
.admin-order-card .btn {
  height: 28px !important;
  padding: 0 9px !important;
  font-size: 0.74rem !important;
  font-weight: 600 !important;
  border-radius: 5px !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 4px !important;
  line-height: 1 !important;
  white-space: nowrap !important;
  text-decoration: none !important;
}

/* ========================================================= */
/* 🌟 STANDARDIZED PAGE HEADER BAR COMPONENT                */
/* ========================================================= */
.admin-page-header {
  background: #ffffff !important;
  border-radius: 9px !important;
  border: 1px solid #e2e8f0 !important;
  padding: 12px 16px !important;
  margin-bottom: 1.15rem !important;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.03) !important;
  display: flex !important;
  flex-direction: column !important;
  gap: 10px !important;
}

@media (min-width: 768px) {
  .admin-page-header {
    flex-direction: row !important;
    align-items: center !important;
    justify-content: space-between !important;
    gap: 14px !important;
  }
}

.admin-header-title {
  font-size: 1.15rem !important;
  font-weight: 700 !important;
  color: #0e4430 !important;
  margin: 0 0 3px 0 !important;
  display: flex !important;
  align-items: center !important;
  line-height: 1.3 !important;
}

.admin-header-chips {
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  flex-wrap: wrap !important;
}

.admin-header-actions {
  display: flex !important;
  align-items: center !important;
  gap: 8px !important;
  flex-wrap: wrap !important;
}

/* Headings & Navigation */
.main-content h3 {
  font-size: 1.18rem !important;
  font-weight: 700 !important;
  margin-bottom: 0.75rem !important;
  color: #0e4430 !important;
}

/* Soft Pills & Nav Tabs */
.nav-pills .nav-link {
  background-color: #f1f5f9;
  color: #475569;
  border: 1px solid #e2e8f0;
  font-size: 0.80rem !important;
  padding: 6px 14px !important;
  border-radius: 7px !important;
  font-weight: 600;
  transition: all 0.2s ease;
}
.nav-pills .nav-link:hover {
  background-color: #e2e8f0;
  color: #1e293b;
}
.nav-pills .nav-link.active {
  background: linear-gradient(135deg, #0e4430 0%, #155e43 100%) !important;
  color: #ffffff !important;
  border-color: #0e4430 !important;
  box-shadow: 0 2px 6px rgba(14, 68, 48, 0.25) !important;
}

.form-control, .form-select {
  font-size: 0.82rem !important;
  padding: 5px 10px !important;
  border-radius: 6px !important;
  border-color: #cbd5e1 !important;
}
.form-control:focus, .form-select:focus {
  border-color: #155e43 !important;
  box-shadow: 0 0 0 0.2rem rgba(14, 68, 48, 0.15) !important;
}

/* Soft Alerts */
.alert {
  padding: 8px 14px !important;
  font-size: 0.82rem !important;
  border-radius: 8px !important;
}
.alert-success {
  background-color: #ecfdf5 !important;
  color: #065f46 !important;
  border-color: #a7f3d0 !important;
}
.alert-danger {
  background-color: #fef2f2 !important;
  color: #991b1b !important;
  border-color: #fecaca !important;
}
.alert-info {
  background-color: #eff6ff !important;
  color: #1e40af !important;
  border-color: #bfdbfe !important;
}
.alert-warning {
  background-color: #fffbeb !important;
  color: #92400e !important;
  border-color: #fde68a !important;
}

/* Soft Modals */
.modal-content {
  border-radius: 12px !important;
  border: none !important;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12) !important;
  overflow: hidden !important;
}
.modal-header {
  background: linear-gradient(135deg, #0e4430 0%, #155e43 100%) !important;
  color: #ffffff !important;
  padding: 12px 18px !important;
  border-bottom: none !important;
}

/* Modern Compact Admin Cards */
.admin-order-card {
  background: #ffffff;
  border: 1px solid #e2e8f0;
  border-radius: 9px;
  padding: 11px 13px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.03);
  display: flex;
  flex-direction: column;
  height: 100%;
  transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
}
.admin-order-card:hover {
  border-color: #cbd5e1;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}
.admin-order-card.card-locked {
  background: #f8fafc;
  opacity: 0.90;
  border: 1px dashed #cbd5e1;
}

/* ========================================================= */
/* 🔔 NOTIFICATION BELL WITH FLOATING RED BADGE (Exact Look) */
/* ========================================================= */
.menu-notif-bell {
  position: relative !important;
  display: inline-flex;
  align-items: center !important;
  justify-content: center !important;
  width: 22px !important;
  height: 22px !important;
  margin-left: auto !important;
  flex-shrink: 0 !important;
}

.menu-notif-bell.d-none {
  display: none !important;
}

.menu-notif-bell .notif-bell-icon {
  color: #ffffff !important; /* Lonceng Putih Bersih */
  font-size: 0.95rem !important; /* Ukuran pas menyerupai gambar referensi */
  line-height: 1 !important;
  margin: 0 !important;
  width: auto !important;
  transition: transform 0.2s ease !important;
  filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.35)) !important;
}

.menu-link:hover .menu-notif-bell .notif-bell-icon {
  transform: rotate(12deg) scale(1.1) !important;
}

.menu-notif-bell .notif-badge-circle {
  position: absolute !important;
  top: -4px !important;
  right: -5px !important;
  background-color: #ef4444 !important; /* Merah cerah seperti di gambar referensi */
  color: #ffffff !important;           /* Angka Putih */
  font-size: 0.58rem !important;
  font-weight: 800 !important;
  min-width: 15px !important;
  height: 15px !important;
  padding: 0 3.5px !important;
  border-radius: 50rem !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  line-height: 1 !important;
  border: 1.5px solid #091e17 !important; /* Ring pemisah tepi gelap */
  box-shadow: 0 2px 5px rgba(239, 68, 68, 0.5) !important;
  letter-spacing: -0.2px !important;
}

.sidebar.collapsed .menu-notif-bell {
  position: absolute !important;
  top: 5px !important;
  right: 5px !important;
  width: auto !important;
  height: auto !important;
}

.sidebar.collapsed .menu-notif-bell.d-none {
  display: none !important;
}

.sidebar.collapsed .menu-notif-bell .notif-bell-icon {
  display: none !important;
}

.sidebar.collapsed .menu-notif-bell .notif-badge-circle {
  position: static !important;
  width: 8px !important;
  height: 8px !important;
  min-width: 8px !important;
  padding: 0 !important;
  font-size: 0 !important;
  border: 1.5px solid #091e17 !important;
  box-shadow: 0 0 6px rgba(239, 68, 68, 0.85) !important;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const sidebar = document.getElementById('sidebar');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  const toggleBtn = document.getElementById('toggleSidebar');
  const mobileToggleBtn = document.getElementById('mobileSidebarToggle');
  const closeSidebarMobile = document.getElementById('closeSidebarMobile');
  const mainContent = document.querySelector('.main-content');

  // Load desktop collapsed state from localStorage
  if (window.innerWidth >= 992) {
    const isCollapsed = localStorage.getItem('semar_admin_sidebar_collapsed') === 'true';
    if (isCollapsed) {
      sidebar.classList.add('collapsed');
      if (mainContent) mainContent.classList.add('collapsed');
    }
  }

  // Desktop Toggle
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function(e) {
      e.preventDefault();
      sidebar.classList.toggle('collapsed');
      if (mainContent) mainContent.classList.toggle('collapsed');
      const collapsed = sidebar.classList.contains('collapsed');
      localStorage.setItem('semar_admin_sidebar_collapsed', collapsed ? 'true' : 'false');
    });
  }

  // Mobile Open Sidebar
  function openMobileSidebar() {
    sidebar.classList.add('mobile-show');
    sidebarOverlay.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  // Mobile Close Sidebar
  function closeMobileSidebar() {
    sidebar.classList.remove('mobile-show');
    sidebarOverlay.classList.remove('show');
    document.body.style.overflow = '';
  }

  if (mobileToggleBtn) {
    mobileToggleBtn.addEventListener('click', function(e) {
      e.preventDefault();
      openMobileSidebar();
    });
  }

  if (closeSidebarMobile) {
    closeSidebarMobile.addEventListener('click', function(e) {
      e.preventDefault();
      closeMobileSidebar();
    });
  }

  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', function() {
      closeMobileSidebar();
    });
  }

  // Close on Escape key press
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && sidebar.classList.contains('mobile-show')) {
      closeMobileSidebar();
    }
  });

  // Handle window resize
  window.addEventListener('resize', function() {
    if (window.innerWidth >= 992) {
      closeMobileSidebar();
      const isCollapsed = localStorage.getItem('semar_admin_sidebar_collapsed') === 'true';
      if (isCollapsed) {
        sidebar.classList.add('collapsed');
        if (mainContent) mainContent.classList.add('collapsed');
      } else {
        sidebar.classList.remove('collapsed');
        if (mainContent) mainContent.classList.remove('collapsed');
      }
    }
  });

  // ========================================================
  // 🔔 REAL-TIME LIVE NOTIFICATION POLLING & AUDIO ALERT
  // ========================================================
  let lastNotifCount = <?= (int)$total_notif ?>;
  const adminBase = '<?= $admin_base ?>';

  function playNotificationChime() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      // Tone 1
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      gain1.gain.setValueAtTime(0.12, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.35);

      // Tone 2
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880, now + 0.10); // A5
      gain2.gain.setValueAtTime(0.16, now + 0.10);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.60);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.10);
      osc2.stop(now + 0.60);
    } catch(e) {}
  }

  function showAdminLiveToast(title, message, linkUrl) {
    const container = document.getElementById('adminToastContainer');
    if (!container) return;
    const toastId = 'toast_' + Date.now();
    const toastHtml = `
      <div id="${toastId}" class="toast align-items-center text-bg-dark border-0 shadow-lg mb-2" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body d-flex align-items-center gap-2.5 py-2.5 px-3">
            <i class="fa fa-bell text-danger fs-5"></i>
            <div>
              <div class="fw-bold small text-white">${title}</div>
              <div class="text-light" style="font-size: 0.72rem;">${message}</div>
              ${linkUrl ? `<a href="${linkUrl}" class="btn btn-sm btn-danger text-white py-0 px-2 mt-1 fw-bold" style="font-size: 0.68rem;">Buka Sekarang &raquo;</a>` : ''}
            </div>
          </div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
      </div>
    `;
    container.insertAdjacentHTML('beforeend', toastHtml);
    const toastEl = document.getElementById(toastId);
    if (toastEl && window.bootstrap && window.bootstrap.Toast) {
      const bsToast = new bootstrap.Toast(toastEl, { delay: 6000 });
      bsToast.show();
    }
  }

  function updateAdminBadges(data) {
    const wrapP = document.getElementById('wrapPembayaran');
    const wrapS = document.getElementById('wrapSewa');
    const wrapK = document.getElementById('wrapPengembalian');
    const bBayar = document.getElementById('badgePembayaran');
    const bSewa = document.getElementById('badgeSewa');
    const bKembali = document.getElementById('badgePengembalian');

    const countBayar = parseInt(data.count_pembayaran) || 0;
    const countSewa = parseInt(data.count_sewa) || 0;
    const countKembali = parseInt(data.count_pengembalian) || 0;

    // Update Menu Bell Badges
    if (bBayar) bBayar.textContent = countBayar;
    if (wrapP) {
      if (countBayar > 0) {
        wrapP.classList.remove('d-none');
        wrapP.style.setProperty('display', 'inline-flex', 'important');
      } else {
        wrapP.classList.add('d-none');
        wrapP.style.setProperty('display', 'none', 'important');
      }
    }

    if (bSewa) bSewa.textContent = countSewa;
    if (wrapS) {
      if (countSewa > 0) {
        wrapS.classList.remove('d-none');
        wrapS.style.setProperty('display', 'inline-flex', 'important');
      } else {
        wrapS.classList.add('d-none');
        wrapS.style.setProperty('display', 'none', 'important');
      }
    }

    if (bKembali) bKembali.textContent = countKembali;
    if (wrapK) {
      if (countKembali > 0) {
        wrapK.classList.remove('d-none');
        wrapK.style.setProperty('display', 'inline-flex', 'important');
      } else {
        wrapK.classList.add('d-none');
        wrapK.style.setProperty('display', 'none', 'important');
      }
    }
  }

  function checkAdminNotifications() {
    fetch(adminBase + 'ajax_notifikasi.php')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'success') {
          if (data.total > lastNotifCount) {
            playNotificationChime();
            showAdminLiveToast(
              'Notifikasi Tugas Baru!',
              `Ada ${data.total - lastNotifCount} transaksi/pembayaran baru yang membutuhkan tindakan.`,
              adminBase + 'pembayaran/pembayaran.php'
            );
          }
          lastNotifCount = data.total;
          updateAdminBadges(data);
        }
      })
      .catch(() => {});
  }

  // Poll every 15 seconds
  setInterval(checkAdminNotifications, 15000);
});
</script>