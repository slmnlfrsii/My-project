<?php
session_start();
require_once "../../koneksi.php";

$upload_dir = "../uploads/alat/";

function upload_gambar($file_input_name) {
    global $upload_dir;

    if (isset($_FILES[$file_input_name]) && $_FILES[$file_input_name]['error'] === UPLOAD_ERR_OK) {
        $tmp_name = $_FILES[$file_input_name]['tmp_name'];
        $original_name = basename($_FILES[$file_input_name]['name']);
        $ext = pathinfo($original_name, PATHINFO_EXTENSION);
        $new_name = uniqid("alat_", true) . '.' . strtolower($ext);
        $target_file = $upload_dir . $new_name;

        // Validasi ekstensi (optional)
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (!in_array(strtolower($ext), $allowed_ext)) {
            return false;
        }

        if (move_uploaded_file($tmp_name, $target_file)) {
            return $new_name;
        }
    }
    return false;
}

// Tambah Alat
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_alat'])) {
        $nama = $conn->real_escape_string(trim($_POST['nama']));
        $deskripsi = $conn->real_escape_string(trim($_POST['deskripsi']));
        $stok_awal = isset($_POST['stok_awal']) ? max(0, (int)$_POST['stok_awal']) : (isset($_POST['stok']) ? max(0, (int)$_POST['stok']) : 0);
        $sisa_stok = isset($_POST['sisa_stok']) ? max(0, (int)$_POST['sisa_stok']) : $stok_awal;
        $harga_per_hari = (float)$_POST['harga_per_hari'];
        $gambar = upload_gambar('gambar');

        // Validasi Deskripsi Wajib Diisi
        if (empty($deskripsi)) {
            $_SESSION['error'] = "Gagal: Deskripsi alat wajib diisi!";
            header("Location: list_alat.php");
            exit;
        }

        // Validasi Harga Kelipatan Ribuan (000)
        if ($harga_per_hari < 1000 || $harga_per_hari % 1000 !== 0) {
            $_SESSION['error'] = "Gagal: Harga sewa per hari harus bernilai kelipatan ribuan genap (contoh: 10.000, 15.000, 25.000, dst.)!";
            header("Location: list_alat.php");
            exit;
        }

        $sql = "INSERT INTO alat (nama, deskripsi, stok_awal, sisa_stok, harga_per_hari, gambar)
                VALUES ('$nama', '$deskripsi', $stok_awal, $sisa_stok, $harga_per_hari, " . ($gambar ? "'$gambar'" : "NULL") . ")";
        if ($conn->query($sql)) {
            $_SESSION['success'] = "Alat berhasil ditambahkan.";
        } else {
            $_SESSION['error'] = "Gagal menambahkan alat: " . $conn->error;
        }
        header("Location: list_alat.php");
        exit;
    }

    // Edit Alat
    if (isset($_POST['edit_alat'])) {
        $id = (int)$_POST['id'];
        $nama = $conn->real_escape_string(trim($_POST['nama']));
        $deskripsi = $conn->real_escape_string(trim($_POST['deskripsi']));
        $stok_awal = isset($_POST['stok_awal']) ? max(0, (int)$_POST['stok_awal']) : 0;
        $sisa_stok = isset($_POST['sisa_stok']) ? max(0, (int)$_POST['sisa_stok']) : (isset($_POST['stok']) ? max(0, (int)$_POST['stok']) : 0);
        $harga_per_hari = (float)$_POST['harga_per_hari'];
        $gambar = upload_gambar('gambar');

        // Validasi Deskripsi Wajib Diisi
        if (empty($deskripsi)) {
            $_SESSION['error'] = "Gagal: Deskripsi alat wajib diisi!";
            header("Location: list_alat.php");
            exit;
        }

        // Validasi Harga Kelipatan Ribuan (000)
        if ($harga_per_hari < 1000 || $harga_per_hari % 1000 !== 0) {
            $_SESSION['error'] = "Gagal: Harga sewa per hari harus bernilai kelipatan ribuan genap (contoh: 10.000, 15.000, 25.000, dst.)!";
            header("Location: list_alat.php");
            exit;
        }

        // Validasi: Sisa stok tidak boleh melebihi stok awal
        if ($sisa_stok > $stok_awal) {
            $_SESSION['error'] = "Gagal: Sisa stok ($sisa_stok) tidak boleh melebihi stok awal ($stok_awal).";
            header("Location: list_alat.php");
            exit;
        }

        if ($gambar) {
            // Hapus gambar lama
            $old = $conn->query("SELECT gambar FROM alat WHERE id = $id")->fetch_assoc();
            if ($old && $old['gambar'] && file_exists($upload_dir . $old['gambar'])) {
                unlink($upload_dir . $old['gambar']);
            }

            $sql = "UPDATE alat SET 
                        nama = '$nama',
                        deskripsi = '$deskripsi',
                        stok_awal = $stok_awal,
                        sisa_stok = $sisa_stok,
                        harga_per_hari = $harga_per_hari,
                        gambar = '$gambar'
                    WHERE id = $id";
        } else {
            $sql = "UPDATE alat SET 
                        nama = '$nama',
                        deskripsi = '$deskripsi',
                        stok_awal = $stok_awal,
                        sisa_stok = $sisa_stok,
                        harga_per_hari = $harga_per_hari
                    WHERE id = $id";
        }

        if ($conn->query($sql)) {
            $_SESSION['success'] = "Alat berhasil diupdate.";
        } else {
            $_SESSION['error'] = "Gagal update alat: " . $conn->error;
        }
        header("Location: list_alat.php");
        exit;
    }
}

// Hapus Alat
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    // Hapus gambar jika ada
    $res = $conn->query("SELECT gambar FROM alat WHERE id = $id");
    if ($res && $res->num_rows > 0) {
        $data = $res->fetch_assoc();
        if ($data['gambar'] && file_exists($upload_dir . $data['gambar'])) {
            unlink($upload_dir . $data['gambar']);
        }
    }

    $sql = "DELETE FROM alat WHERE id = $id";
    if ($conn->query($sql)) {
        $_SESSION['success'] = "Alat berhasil dihapus.";
    } else {
        $_SESSION['error'] = "Gagal hapus alat: " . $conn->error;
    }
    header("Location: list_alat.php");
    exit;
}

// Redirect default
header("Location: list_alat.php");
exit;
