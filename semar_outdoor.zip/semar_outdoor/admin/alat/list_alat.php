<?php
session_start();
require_once "../../koneksi.php";
include '../cek_login.php';

$result = $conn->query("
    SELECT a.*,
           GREATEST(0, a.stok_awal - IFNULL(SUM(
               CASE 
                   WHEN s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai') THEN s.qty 
                   ELSE 0 
               END
           ), 0)) AS sisa_stok_dinamis
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat
    GROUP BY a.id
    ORDER BY a.id DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>List Alat Rental - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
<style>
  body { background-color: #f8f9fc; }
  img.thumbnail {
    max-height: 80px;
  }
</style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
<h3 class="mb-4 fw-bold">List Alat Rental</h3>

  <?php if (!empty($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-3">
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">
      <i class="fa fa-plus me-1"></i> Tambah Alat
    </button>
    <div style="max-width: 320px; width: 100%;">
      <input type="text" id="liveSearchAlat" class="form-control"
             placeholder="Cari alat / deskripsi...">
    </div>
  </div>
  <div class="table-responsive">
    <table class="table table-bordered align-middle" id="alatTable">
      <thead class="table-secondary text-center">
        <tr>
          <th>No</th>
          <th>Gambar</th>
          <th>Nama Alat</th>
          <th>Stok Awal</th>
          <th>Sisa Stok</th>
          <th>Harga/hari</th>
          <th>Deskripsi</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php $no=1; while($row = $result->fetch_assoc()): 
            $stok_awal = isset($row['stok_awal']) ? (int)$row['stok_awal'] : 0;
            $sisa_stok = isset($row['sisa_stok_dinamis']) ? (int)$row['sisa_stok_dinamis'] : (int)($row['sisa_stok'] ?? 0);
          ?>
          <tr>
            <td class="text-center"><?= $no++ ?></td>
            <td class="text-center">
              <?php if (!empty($row['gambar'])): ?>
              <img src="../uploads/alat/<?= htmlspecialchars($row['gambar']) ?>" class="thumbnail" style="max-width: 50px; height: auto;" alt="<?= htmlspecialchars($row['nama']) ?>">
              <?php else: ?>
                <em>Tidak ada</em>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['nama']) ?></td>
            <td class="text-center"><?= $stok_awal ?></td>
            <td class="text-center"><?= $sisa_stok ?></td>
            <td class="text-center">Rp.<?= number_format($row['harga_per_hari'], 0, ',', '.') ?></td>
            <td><?= htmlspecialchars($row['deskripsi']) ?></td>
            <td class="text-center">
              <button 
                class="btn btn-warning btn-sm btn-edit" 
                data-id="<?= $row['id'] ?>"
                data-nama="<?= htmlspecialchars($row['nama']) ?>"
                data-deskripsi="<?= htmlspecialchars($row['deskripsi']) ?>"
                data-stok_awal="<?= $stok_awal ?>"
                data-sisa_stok="<?= $sisa_stok ?>"
                data-harga="<?= $row['harga_per_hari'] ?>"
                data-bs-toggle="modal" data-bs-target="#editModal"
              >
                <i class="fa fa-edit"></i>
              </button>
              <a href="aksi_alat.php?action=delete&id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus alat ini?')">
                <i class="fa fa-trash"></i>
              </a>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="8" class="text-center">Data alat kosong.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Tambah Alat -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="aksi_alat.php" method="post" class="modal-content" enctype="multipart/form-data">
      <div class="modal-header">
        <h5 class="modal-title" id="addModalLabel">Tambah Alat</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="nama" class="form-label">Nama Alat <span class="text-danger">*</span></label>
          <input type="text" name="nama" id="nama" class="form-control" placeholder="Contoh: Tenda Dome Kapasitas 4 Orang" required />
        </div>
        <div class="mb-3">
          <label for="deskripsi" class="form-label">Deskripsi Alat <span class="text-danger">*</span></label>
          <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3" placeholder="Masukkan spesifikasi, kelengkapan frame/pasak, dan deskripsi alat..." required></textarea>
        </div>
        <div class="mb-3">
          <label for="stok_awal_add" class="form-label">Stok Awal <span class="text-danger">*</span></label>
          <input type="number" name="stok_awal" id="stok_awal_add" class="form-control" min="0" value="1" required />
        </div>
        <div class="mb-3">
          <label for="harga_per_hari" class="form-label">Harga per Hari (Rp) <span class="text-danger">*</span></label>
          <input type="number" name="harga_per_hari" id="harga_per_hari" class="form-control" min="1000" step="1000" placeholder="Contoh: 15000 (kelipatan Rp 1.000)" required />
          <small class="text-muted d-block mt-1" style="font-size: 0.8rem;">* Nominal wajib kelipatan ribuan (contoh: 10.000, 15.000, 20.000, 25.000, dst.).</small>
        </div>
        <div class="mb-3">
          <label for="gambar" class="form-label">Gambar Alat</label>
          <input type="file" name="gambar" id="gambar" class="form-control" accept="image/*" />
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="add_alat" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Edit Alat -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="aksi_alat.php" method="post" class="modal-content" enctype="multipart/form-data">
      <input type="hidden" name="id" id="edit_id" />
      <div class="modal-header">
        <h5 class="modal-title" id="editModalLabel">Edit Alat</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="edit_nama" class="form-label">Nama Alat <span class="text-danger">*</span></label>
          <input type="text" name="nama" id="edit_nama" class="form-control" required />
        </div>
        <div class="mb-3">
          <label for="edit_deskripsi" class="form-label">Deskripsi Alat <span class="text-danger">*</span></label>
          <textarea name="deskripsi" id="edit_deskripsi" class="form-control" rows="3" required></textarea>
        </div>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="edit_stok_awal" class="form-label">Stok Awal <span class="text-danger">*</span></label>
            <input type="number" name="stok_awal" id="edit_stok_awal" class="form-control" min="0" required />
          </div>
          <div class="col-md-6 mb-3">
            <label for="edit_sisa_stok" class="form-label">Sisa Stok <span class="text-danger">*</span></label>
            <input type="number" name="sisa_stok" id="edit_sisa_stok" class="form-control" min="0" required />
          </div>
        </div>
        <div class="mb-3">
          <label for="edit_harga_per_hari" class="form-label">Harga per Hari (Rp) <span class="text-danger">*</span></label>
          <input type="number" name="harga_per_hari" id="edit_harga_per_hari" class="form-control" min="1000" step="1000" required />
          <small class="text-muted d-block mt-1" style="font-size: 0.8rem;">* Nominal wajib kelipatan ribuan (contoh: 10.000, 15.000, 20.000, 25.000, dst.).</small>
        </div>
        <div class="mb-3">
          <label for="edit_gambar" class="form-label">Ganti Gambar (opsional)</label>
          <input type="file" name="gambar" id="edit_gambar" class="form-control" accept="image/*" />
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="edit_alat" class="btn btn-primary">Update</button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const editStokAwal = document.getElementById('edit_stok_awal');
  const editSisaStok = document.getElementById('edit_sisa_stok');

  function validateStokLimits() {
    const awal = parseInt(editStokAwal.value) || 0;
    const sisa = parseInt(editSisaStok.value) || 0;
    editSisaStok.max = awal;

    if (sisa > awal) {
      editSisaStok.setCustomValidity('Sisa stok (' + sisa + ') tidak boleh melebihi stok awal (' + awal + ').');
    } else {
      editSisaStok.setCustomValidity('');
    }
  }

  editStokAwal.addEventListener('input', validateStokLimits);
  editSisaStok.addEventListener('input', validateStokLimits);

  document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('edit_id').value = btn.getAttribute('data-id');
      document.getElementById('edit_nama').value = btn.getAttribute('data-nama');
      document.getElementById('edit_deskripsi').value = btn.getAttribute('data-deskripsi');
      const stokAwal = btn.getAttribute('data-stok_awal') || 0;
      const sisaStok = btn.getAttribute('data-sisa_stok') || 0;
      editStokAwal.value = stokAwal;
      editSisaStok.value = sisaStok;
      editSisaStok.max = stokAwal;
      editSisaStok.setCustomValidity('');
      document.getElementById('edit_harga_per_hari').value = btn.getAttribute('data-harga');
    });
  });
</script>
<script>
document.getElementById('liveSearchAlat').addEventListener('keyup', function () {
    let keyword = this.value.toLowerCase();
    let rows = document.querySelectorAll('#alatTable tbody tr');

    rows.forEach(row => {

        let text = row.textContent.toLowerCase();
        let cells = row.querySelectorAll('td');

        if (text.includes(keyword)) {
            row.style.display = '';

            cells.forEach((td, index) => {

                // ❗ skip kolom terakhir (AKSI)
                if (index === cells.length - 1) return;

                // simpan original pertama kali
                if (!td.dataset.original) {
                    td.dataset.original = td.innerHTML;
                }

                if (keyword !== '') {
                    let regex = new RegExp(`(${keyword})`, 'gi');
                    td.innerHTML = td.dataset.original.replace(
                        regex,
                        `<span class="highlight">$1</span>`
                    );
                } else {
                    td.innerHTML = td.dataset.original;
                }
            });

        } else {
            row.style.display = 'none';
        }
    });
});
</script>

</body>
</html>