<?php
session_start();
require_once "../../koneksi.php";
include '../cek_login.php';

$result = $conn->query("
    SELECT a.*,
           GREATEST(0, a.stok_awal - IFNULL(SUM(
               CASE 
                   WHEN s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai') THEN s.qty 
                   ELSE 0 
               END
           ), 0)) AS sisa_stok_dinamis
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat
    GROUP BY a.id
    ORDER BY a.id DESC
");

$total_jenis = 0;
$total_stok_unit = 0;
$total_sisa_unit = 0;
$alatListArray = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $stok_awal = isset($row['stok_awal']) ? (int)$row['stok_awal'] : 0;
        $sisa_stok = isset($row['sisa_stok_dinamis']) ? (int)$row['sisa_stok_dinamis'] : (int)($row['sisa_stok'] ?? 0);
        $total_jenis++;
        $total_stok_unit += $stok_awal;
        $total_sisa_unit += $sisa_stok;
        $row['stok_awal_val'] = $stok_awal;
        $row['sisa_stok_val'] = $sisa_stok;
        $alatListArray[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>List Alat Rental - Admin Semar Outdoor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  :root {
    --brand-primary: #0e4430;
    --brand-primary-hover: #165b42;
    --brand-accent: #f59e0b;
    --surface-bg: #f8fafc;
    --card-border: #e2e8f0;
  }
  body { 
    background-color: var(--surface-bg); 
    font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }
  
  /* Smooth Action Header */
  .btn-tambah-alat {
    background: linear-gradient(135deg, #0e4430 0%, #155e43 100%);
    color: #ffffff;
    border: none;
    font-weight: 600;
    font-size: 0.82rem;
    padding: 6px 14px;
    border-radius: 6px;
    box-shadow: 0 2px 6px rgba(14, 68, 48, 0.2);
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    text-decoration: none;
  }
  .btn-tambah-alat:hover {
    background: linear-gradient(135deg, #155e43 0%, #1c7454 100%);
    color: #ffffff;
    box-shadow: 0 4px 10px rgba(14, 68, 48, 0.28);
    transform: translateY(-1px);
  }

  /* Smooth Stat Badges */
  .stat-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 0.74rem;
    font-weight: 600;
  }
  .stat-pill-primary {
    background: #ecfdf5;
    color: #065f46;
    border: 1px solid #a7f3d0;
  }
  .stat-pill-info {
    background: #eff6ff;
    color: #1e40af;
    border: 1px solid #bfdbfe;
  }

  /* Smooth Table Styling */
  .alat-table-container {
    background: #ffffff;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 6px rgba(0, 0, 0, 0.03);
    overflow: hidden;
    margin-bottom: 1.5rem;
  }
  .alat-table thead th {
    background: #f1f5f9 !important;
    color: #334155 !important;
    font-size: 0.72rem !important;
    font-weight: 700 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.5px !important;
    border-bottom: 2px solid #cbd5e1 !important;
    padding: 9px 10px !important;
    white-space: nowrap !important;
    vertical-align: middle !important;
  }
  .alat-table tbody td {
    padding: 7px 10px !important;
    border-color: #f1f5f9 !important;
    font-size: 0.80rem !important;
    vertical-align: middle !important;
    color: #1e293b !important;
  }
  .alat-table tbody tr:hover {
    background-color: #f8fafc !important;
  }

  /* Image Thumbnail */
  .img-thumb-alat {
    width: 36px;
    height: 36px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #cbd5e1;
    background: #fff;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
  }
  .img-thumb-alat:hover {
    transform: scale(1.25);
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
    z-index: 5;
    position: relative;
  }

  /* Smooth Action Buttons */
  .btn-action-edit {
    background: #fef3c7;
    color: #92400e;
    border: 1px solid #fde68a;
    font-size: 0.72rem;
    padding: 3px 8px;
    border-radius: 5px;
    font-weight: 600;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    text-decoration: none;
  }
  .btn-action-edit:hover {
    background: #fde68a;
    color: #78350f;
    transform: translateY(-1px);
  }
  .btn-action-delete {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
    font-size: 0.72rem;
    padding: 3px 8px;
    border-radius: 5px;
    font-weight: 600;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    text-decoration: none;
  }
  .btn-action-delete:hover {
    background: #fecaca;
    color: #7f1d1d;
    transform: translateY(-1px);
  }

  /* Smooth Modal */
  .modal-header-custom {
    background: linear-gradient(135deg, #0e4430 0%, #155e43 100%);
    color: #ffffff;
    padding: 12px 18px;
    border-bottom: none;
  }
  .modal-content {
    border: none;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
  }
</style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
  <!-- Standard Page Header Bar -->
  <div class="admin-page-header">
    <div>
      <div class="admin-header-title">
        <i class="fas fa-toolbox me-2 text-warning"></i>Daftar Alat Rental
      </div>
      <div class="admin-header-chips">
        <span class="badge bg-success px-2.5 py-1 rounded-pill">
          <i class="fas fa-boxes me-1"></i> <?= $total_jenis ?> Jenis Alat
        </span>
        <span class="badge bg-primary px-2.5 py-1 rounded-pill">
          <i class="fas fa-layer-group me-1"></i> <?= $total_stok_unit ?> Total Unit
        </span>
        <span class="badge bg-success px-2.5 py-1 rounded-pill">
          <i class="fas fa-check-circle me-1"></i> <?= $total_sisa_unit ?> Unit Tersedia
        </span>
      </div>
    </div>

    <!-- Actions & Search Bar -->
    <div class="admin-header-actions">
      <button class="btn btn-primary btn-admin-header flex-shrink-0" data-bs-toggle="modal" data-bs-target="#addModal">
        <i class="fa fa-plus me-1.5"></i> Tambah Alat
      </button>
      <div style="width: 220px;">
        <input type="text" id="liveSearchAlat" class="form-control search-input-admin"
               placeholder="Cari alat / deskripsi...">
      </div>
    </div>
  </div>

  <?php if (!empty($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show mb-3" role="alert" style="font-size: 0.82rem; padding: 8px 14px;">
      <i class="fas fa-check-circle me-1.5"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 10px;"></button>
    </div>
  <?php endif; ?>

  <?php if (!empty($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert" style="font-size: 0.82rem; padding: 8px 14px;">
      <i class="fas fa-exclamation-triangle me-1.5"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="padding: 10px;"></button>
    </div>
  <?php endif; ?>

  <!-- Table Container -->
  <div class="alat-table-container">
    <div class="table-responsive mb-0">
      <table class="table alat-table align-middle mb-0" id="alatTable">
        <thead>
          <tr class="text-center">
            <th style="width: 45px;">No</th>
            <th style="width: 55px;">Foto</th>
            <th class="text-start">Nama Alat</th>
            <th style="width: 95px;">Stok Awal</th>
            <th style="width: 105px;">Sisa Stok</th>
            <th style="width: 120px;" class="text-end">Harga / Hari</th>
            <th class="text-start">Deskripsi</th>
            <th style="width: 130px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($alatListArray)): ?>
            <?php $no=1; foreach($alatListArray as $row): 
              $stok_awal = $row['stok_awal_val'];
              $sisa_stok = $row['sisa_stok_val'];
            ?>
            <tr>
              <td class="text-center fw-bold text-muted"><?= $no++ ?></td>
              <td class="text-center">
                <?php if (!empty($row['gambar'])): ?>
                  <img src="../uploads/alat/<?= htmlspecialchars($row['gambar']) ?>" class="img-thumb-alat" alt="<?= htmlspecialchars($row['nama']) ?>">
                <?php else: ?>
                  <span class="badge bg-light text-muted border px-1.5 py-0.5" style="font-size: 0.68rem;">Nihil</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="fw-bold text-dark d-block" style="font-size: 0.82rem;"><?= htmlspecialchars($row['nama']) ?></span>
              </td>
              <td class="text-center">
                <span class="badge bg-light text-secondary border px-2 py-1" style="font-size: 0.72rem; font-weight: 600;">
                  <?= $stok_awal ?> Unit
                </span>
              </td>
              <td class="text-center">
                <?php if ($sisa_stok > 0): ?>
                  <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1" style="font-size: 0.72rem; font-weight: 700;">
                    <i class="fas fa-check-circle me-1"></i><?= $sisa_stok ?> Sisa
                  </span>
                <?php else: ?>
                  <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2 py-1" style="font-size: 0.72rem; font-weight: 700;">
                    <i class="fas fa-times-circle me-1"></i>Habis
                  </span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <span class="fw-bold" style="color: #0e4430; font-size: 0.84rem;">Rp<?= number_format($row['harga_per_hari'], 0, ',', '.') ?></span>
              </td>
              <td class="small text-muted" style="max-width: 260px; line-height: 1.35; font-size: 0.76rem;">
                <?= htmlspecialchars($row['deskripsi']) ?>
              </td>
              <td class="text-center">
                <div class="aksi-btn">
                  <button 
                    type="button"
                    class="btn btn-warning btn-admin-action btn-edit" 
                    data-id="<?= $row['id'] ?>"
                    data-nama="<?= htmlspecialchars($row['nama']) ?>"
                    data-deskripsi="<?= htmlspecialchars($row['deskripsi']) ?>"
                    data-stok_awal="<?= $stok_awal ?>"
                    data-sisa_stok="<?= $sisa_stok ?>"
                    data-harga="<?= $row['harga_per_hari'] ?>"
                    data-bs-toggle="modal" data-bs-target="#editModal"
                    title="Edit Alat"
                  >
                    <i class="fa fa-edit me-1"></i>Edit
                  </button>
                  <a href="aksi_alat.php?action=delete&id=<?= $row['id'] ?>" class="btn btn-danger btn-admin-action" onclick="return confirm('Apakah Anda yakin ingin menghapus alat ini?')" title="Hapus Alat">
                    <i class="fa fa-trash me-1"></i>Hapus
                  </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="8" class="text-center py-4 text-muted">Data alat rental masih kosong.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Alat -->
<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <form action="aksi_alat.php" method="post" class="modal-content" enctype="multipart/form-data">
      <div class="modal-header modal-header-custom">
        <h5 class="modal-title fw-bold" id="addModalLabel" style="font-size: 0.95rem;">
          <i class="fa fa-plus-circle me-1.5 text-warning"></i> Tambah Alat Rental Baru
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-3.5">
        <div class="mb-2.5">
          <label for="nama" class="form-label fw-semibold" style="font-size: 0.80rem;">Nama Alat <span class="text-danger">*</span></label>
          <input type="text" name="nama" id="nama" class="form-control" style="font-size: 0.82rem;" placeholder="Contoh: Tenda Dome Kapasitas 4 Orang" required />
        </div>
        <div class="mb-2.5">
          <label for="deskripsi" class="form-label fw-semibold" style="font-size: 0.80rem;">Deskripsi Alat <span class="text-danger">*</span></label>
          <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3" style="font-size: 0.82rem;" placeholder="Masukkan spesifikasi, kelengkapan frame/pasak, dan deskripsi alat..." required></textarea>
        </div>
        <div class="row g-2 mb-2.5">
          <div class="col-6">
            <label for="stok_awal_add" class="form-label fw-semibold" style="font-size: 0.80rem;">Stok Awal <span class="text-danger">*</span></label>
            <input type="number" name="stok_awal" id="stok_awal_add" class="form-control" style="font-size: 0.82rem;" min="0" value="1" required />
          </div>
          <div class="col-6">
            <label for="harga_per_hari" class="form-label fw-semibold" style="font-size: 0.80rem;">Harga per Hari (Rp) <span class="text-danger">*</span></label>
            <input type="number" name="harga_per_hari" id="harga_per_hari" class="form-control" style="font-size: 0.82rem;" min="1000" step="1000" placeholder="15000" required />
          </div>
        </div>
        <div class="mb-2">
          <label for="gambar" class="form-label fw-semibold" style="font-size: 0.80rem;">Gambar Foto Alat</label>
          <input type="file" name="gambar" id="gambar" class="form-control" style="font-size: 0.82rem;" accept="image/*" />
        </div>
      </div>
      <div class="modal-footer p-2.5 bg-light border-top">
        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal" style="font-size: 0.80rem;">Batal</button>
        <button type="submit" name="add_alat" class="btn-tambah-alat px-3 py-1.5">
          <i class="fas fa-save me-1"></i> Simpan Alat
        </button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Edit Alat -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <form action="aksi_alat.php" method="post" class="modal-content" enctype="multipart/form-data">
      <input type="hidden" name="id" id="edit_id" />
      <div class="modal-header modal-header-custom">
        <h5 class="modal-title fw-bold" id="editModalLabel" style="font-size: 0.95rem;">
          <i class="fa fa-pen-to-square me-1.5 text-warning"></i> Perbarui Data Alat
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-3.5">
        <div class="mb-2.5">
          <label for="edit_nama" class="form-label fw-semibold" style="font-size: 0.80rem;">Nama Alat <span class="text-danger">*</span></label>
          <input type="text" name="nama" id="edit_nama" class="form-control" style="font-size: 0.82rem;" required />
        </div>
        <div class="mb-2.5">
          <label for="edit_deskripsi" class="form-label fw-semibold" style="font-size: 0.80rem;">Deskripsi Alat <span class="text-danger">*</span></label>
          <textarea name="deskripsi" id="edit_deskripsi" class="form-control" rows="3" style="font-size: 0.82rem;" required></textarea>
        </div>
        <div class="row g-2 mb-2.5">
          <div class="col-6">
            <label for="edit_stok_awal" class="form-label fw-semibold" style="font-size: 0.80rem;">Stok Awal <span class="text-danger">*</span></label>
            <input type="number" name="stok_awal" id="edit_stok_awal" class="form-control" style="font-size: 0.82rem;" min="0" required />
          </div>
          <div class="col-6">
            <label for="edit_sisa_stok" class="form-label fw-semibold" style="font-size: 0.80rem;">Sisa Stok <span class="text-danger">*</span></label>
            <input type="number" name="sisa_stok" id="edit_sisa_stok" class="form-control" style="font-size: 0.82rem;" min="0" required />
          </div>
        </div>
        <div class="mb-2.5">
          <label for="edit_harga_per_hari" class="form-label fw-semibold" style="font-size: 0.80rem;">Harga per Hari (Rp) <span class="text-danger">*</span></label>
          <input type="number" name="harga_per_hari" id="edit_harga_per_hari" class="form-control" style="font-size: 0.82rem;" min="1000" step="1000" required />
        </div>
        <div class="mb-2">
          <label for="edit_gambar" class="form-label fw-semibold" style="font-size: 0.80rem;">Ganti Foto Alat (opsional)</label>
          <input type="file" name="gambar" id="edit_gambar" class="form-control" style="font-size: 0.82rem;" accept="image/*" />
        </div>
      </div>
      <div class="modal-footer p-2.5 bg-light border-top">
        <button type="button" class="btn btn-sm btn-light border px-3" data-bs-dismiss="modal" style="font-size: 0.80rem;">Batal</button>
        <button type="submit" name="edit_alat" class="btn-tambah-alat px-3 py-1.5">
          <i class="fas fa-check me-1"></i> Perbarui
        </button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const editStokAwal = document.getElementById('edit_stok_awal');
  const editSisaStok = document.getElementById('edit_sisa_stok');

  function validateStokLimits() {
    const awal = parseInt(editStokAwal.value) || 0;
    const sisa = parseInt(editSisaStok.value) || 0;
    editSisaStok.max = awal;

    if (sisa > awal) {
      editSisaStok.setCustomValidity('Sisa stok (' + sisa + ') tidak boleh melebihi stok awal (' + awal + ').');
    } else {
      editSisaStok.setCustomValidity('');
    }
  }

  editStokAwal.addEventListener('input', validateStokLimits);
  editSisaStok.addEventListener('input', validateStokLimits);

  document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('edit_id').value = btn.getAttribute('data-id');
      document.getElementById('edit_nama').value = btn.getAttribute('data-nama');
      document.getElementById('edit_deskripsi').value = btn.getAttribute('data-deskripsi');
      const stokAwal = btn.getAttribute('data-stok_awal') || 0;
      const sisaStok = btn.getAttribute('data-sisa_stok') || 0;
      editStokAwal.value = stokAwal;
      editSisaStok.value = sisaStok;
      editSisaStok.max = stokAwal;
      editSisaStok.setCustomValidity('');
      document.getElementById('edit_harga_per_hari').value = btn.getAttribute('data-harga');
    });
  });
</script>
<script>
document.getElementById('liveSearchAlat').addEventListener('keyup', function () {
    let keyword = this.value.toLowerCase().trim();
    let rows = document.querySelectorAll('#alatTable tbody tr');

    rows.forEach(row => {
        let text = row.textContent.toLowerCase();
        if (text.includes(keyword)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});
</script>

</body>
</html>