<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../koneksi.php';
date_default_timezone_set('Asia/Jakarta');

header('Content-Type: application/json');

if (!isset($_SESSION['id_admin'])) {
    echo json_encode(['status' => 'unauthorized', 'total' => 0]);
    exit;
}

// Ambil parameter timestamp terakhir kali admin melihat menu Pengguna
$lastViewedUser = isset($_GET['last_viewed_user']) ? $_GET['last_viewed_user'] : null;

// 1. Hitung Pengguna Baru (Hanya pendaftaran SETELAH menu Pengguna dibuka terakhir kali)
if ($lastViewedUser && $lastViewedUser !== 'null' && $lastViewedUser !== '') {
    $lastViewedClean = date('Y-m-d H:i:s', strtotime($lastViewedUser));
    $qPengguna = mysqli_query($conn, "
        SELECT COUNT(id) AS total_user 
        FROM users 
        WHERE created_at > '$lastViewedClean'
    ");
} else {
    // Fallback jika belum pernah ada riwayat buka menu (24 jam terakhir)
    $qPengguna = mysqli_query($conn, "
        SELECT COUNT(id) AS total_user 
        FROM users 
        WHERE created_at >= NOW() - INTERVAL 1 DAY
    ");
}
$rowU = mysqli_fetch_assoc($qPengguna);
$cntPengguna = (int)($rowU['total_user'] ?? 0);

// 2. Hitung Alat (Jumlah alat yang sisa_stok-nya berkurang dari stok_awal)
$qAlat = mysqli_query($conn, "
    SELECT COUNT(id) AS total_alat_kurang 
    FROM alat 
    WHERE sisa_stok < stok_awal
");
$rowA = mysqli_fetch_assoc($qAlat);
$cntAlat = (int)($rowA['total_alat_kurang'] ?? 0);

// 3. Hitung Pembayaran Menunggu Konfirmasi
$qPembayaran = mysqli_query($conn, "
    SELECT COUNT(id) AS total_pending 
    FROM pembayaran 
    WHERE LOWER(TRIM(status)) = 'menunggu konfirmasi'
");
$rowP = mysqli_fetch_assoc($qPembayaran);
$cntPembayaran = (int)($rowP['total_pending'] ?? 0);

// 4. Hitung Sewa Perlu Disiapkan / Diantar
$qSewa = mysqli_query($conn, "
    SELECT COUNT(id) AS total_siap 
    FROM sewa 
    WHERE LOWER(TRIM(status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar')
");
$rowS = mysqli_fetch_assoc($qSewa);
$cntSewa = (int)($rowS['total_siap'] ?? 0);

// 5. Hitung Pengembalian: Sewa yang selesai
$qPengembalian = mysqli_query($conn, "
    SELECT COUNT(DISTINCT no_tagihan) AS total_kembali
    FROM sewa
    WHERE LOWER(TRIM(status)) = 'selesai'
");
$rowK = mysqli_fetch_assoc($qPengembalian);
$cntPengembalian = (int)($rowK['total_kembali'] ?? 0);

$totalNotif = $cntPengguna + $cntAlat + $cntPembayaran + $cntSewa + $cntPengembalian;

// Ambil Daftar Notifikasi Terkini
$items = [];

// A. Pembayaran Menunggu Konfirmasi Terkini
$qListBayar = mysqli_query($conn, "
    SELECT p.id, p.jumlah_bayar, p.tanggal_bayar, u.nama 
    FROM pembayaran p
    JOIN users u ON p.id_users = u.id
    WHERE LOWER(TRIM(p.status)) = 'menunggu konfirmasi'
    ORDER BY p.tanggal_bayar DESC, p.id DESC
    LIMIT 3
");
if ($qListBayar) {
    while ($rb = mysqli_fetch_assoc($qListBayar)) {
        $tglStr = !empty($rb['tanggal_bayar']) ? date('H:i, d M', strtotime($rb['tanggal_bayar'])) : 'Baru saja';
        $items[] = [
            'type' => 'pembayaran',
            'icon' => 'fas fa-cash-register text-danger',
            'bg' => 'bg-danger bg-opacity-10',
            'title' => 'Pembayaran Menunggu Konfirmasi',
            'desc' => htmlspecialchars($rb['nama']) . ' menyetorkan Rp ' . number_format($rb['jumlah_bayar'], 0, ',', '.'),
            'time' => $tglStr,
            'url' => 'pembayaran/pembayaran.php?tab=semua'
        ];
    }
}

// B. Sewa Siap Diambil / Diantar Terkini
$qListSewa = mysqli_query($conn, "
    SELECT s.id, s.no_tagihan, s.nama_produk, s.status, s.metode_pengambilan, u.nama
    FROM sewa s
    JOIN users u ON s.id_users = u.id
    WHERE LOWER(TRIM(s.status)) IN ('siap di ambil', 'siap diambil', 'di antar', 'diantar')
    ORDER BY s.id DESC
    LIMIT 2
");
if ($qListSewa) {
    while ($rs = mysqli_fetch_assoc($qListSewa)) {
        $items[] = [
            'type' => 'sewa',
            'icon' => 'fas fa-box-open text-danger',
            'bg' => 'bg-danger bg-opacity-10',
            'title' => 'Pesanan Perlu Disiapkan',
            'desc' => htmlspecialchars($rs['nama']) . ' - ' . htmlspecialchars($rs['nama_produk']),
            'time' => ucfirst($rs['status']),
            'url' => 'riwayat/riwayat.php?tab=berlangsung'
        ];
    }
}

// C. Pengembalian Sedang Berlangsung Terkini
$qListKembali = mysqli_query($conn, "
    SELECT s.id, s.no_tagihan, s.nama_produk, s.tanggal_sewa, s.durasi, u.nama
    FROM sewa s
    JOIN users u ON s.id_users = u.id
    WHERE LOWER(TRIM(s.status)) = 'berlangsung'
    ORDER BY s.id DESC
    LIMIT 2
");
if ($qListKembali) {
    while ($rk = mysqli_fetch_assoc($qListKembali)) {
        $items[] = [
            'type' => 'pengembalian',
            'icon' => 'fas fa-undo-alt text-warning',
            'bg' => 'bg-warning bg-opacity-10',
            'title' => 'Alat Sedang Disewa',
            'desc' => htmlspecialchars($rk['nama']) . ' - ' . htmlspecialchars($rk['nama_produk']),
            'time' => 'Menunggu Pengembalian',
            'url' => 'riwayat/riwayat.php?tab=berlangsung'
        ];
    }
}

echo json_encode([
    'status' => 'success',
    'total' => $totalNotif,
    'count_pengguna' => $cntPengguna,
    'count_alat' => $cntAlat,
    'count_pembayaran' => $cntPembayaran,
    'count_sewa' => $cntSewa,
    'count_pengembalian' => $cntPengembalian,
    'items' => $items
]);