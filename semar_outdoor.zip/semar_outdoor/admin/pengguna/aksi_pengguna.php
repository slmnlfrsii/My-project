<?php
require_once "../../koneksi.php";
date_default_timezone_set('Asia/Jakarta');
// ================= TAMBAH PENGGUNA =================
if (isset($_POST['tambah_pengguna'])) {

    $nama     = $_POST['nama'];
    $email    = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $no_hp    = $_POST['no_hp'];
    $alamat   = $_POST['alamat'];

    // ❗ FIX: tidak boleh input manual (harus sekarang)
    $created_at = date('Y-m-d H:i:s');

    // upload foto (jika ada fungsi kamu tetap dipakai)
    $foto = null;
    if (!empty($_FILES['foto']['name'])) {
        $targetDir = "../uploads/pengguna/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0755, true);

        $fileName = time() . "_" . basename($_FILES["foto"]["name"]);
        $targetFile = $targetDir . $fileName;

        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $targetFile)) {
            $foto = $fileName;
        }
    }

    // CEK EMAIL SUDAH ADA ATAU BELUM
$cek = $conn->prepare("SELECT id FROM users WHERE email = ?");
$cek->bind_param("s", $email);
$cek->execute();
$cek->store_result();

if ($cek->num_rows > 0) {
    // email sudah ada
    header("Location: pengguna.php?error=email_duplikat");
    exit;
}
$cek->close();

// INSERT USER BARU
$stmt = $conn->prepare("
    INSERT INTO users (nama, email, password, no_hp, alamat, foto, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->bind_param("sssssss", $nama, $email, $password, $no_hp, $alamat, $foto, $created_at);
$stmt->execute();

header("Location: pengguna.php?success=1");
exit;
}


// ================= EDIT PENGGUNA =================
if (isset($_POST['edit_pengguna'])) {

    $id     = $_POST['id'];
    $nama   = $_POST['nama'];
    $email  = $_POST['email'];
    $no_hp  = $_POST['no_hp'];
    $alamat = $_POST['alamat'];

    $created_at = $_POST['created_at'];

    // ❗ FIX: anti tanggal lama
    if (strtotime($created_at) < strtotime(date('Y-m-d'))) {
        $created_at = date('Y-m-d H:i:s');
    }

    $stmt = $conn->prepare("
        UPDATE users 
        SET nama=?, email=?, no_hp=?, alamat=?, created_at=? 
        WHERE id=?
    ");
    $stmt->bind_param("sssssi", $nama, $email, $no_hp, $alamat, $created_at, $id);
    $stmt->execute();

    header("Location: pengguna.php?success=1");
    exit;
}


// ================= HAPUS PENGGUNA (FIX TOTAL FK ERROR) =================
if (isset($_POST['hapus_pengguna'])) {

    $id = $_POST['id'];

    // hapus pembayaran
    $stmt = $conn->prepare("DELETE FROM pembayaran WHERE id_users = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // hapus keranjang
    $stmt = $conn->prepare("DELETE FROM keranjang WHERE id_users = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // hapus sewa dibatalkan
    $stmt = $conn->prepare("DELETE FROM sewa_dibatalkan WHERE id_users = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // hapus sewa
    $stmt = $conn->prepare("DELETE FROM sewa WHERE id_users = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // ambil foto
    $get = $conn->prepare("SELECT foto FROM users WHERE id = ?");
    $get->bind_param("i", $id);
    $get->execute();
    $get->bind_result($foto);
    $get->fetch();
    $get->close();

    if (!empty($foto)) {
        $file = "../uploads/pengguna/" . $foto;
        if (file_exists($file)) unlink($file);
    }

    // hapus user
    $del = $conn->prepare("DELETE FROM users WHERE id = ?");
    $del->bind_param("i", $id);
    $del->execute();

    header("Location: pengguna.php?success=hapus");
    exit;
}


// fallback
header("Location: pengguna.php");
exit;