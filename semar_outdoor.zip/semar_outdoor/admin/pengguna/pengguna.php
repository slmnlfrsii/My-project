<?php
session_start();
require_once "../../koneksi.php";
include '../cek_login.php';


// Ambil data pengguna
$result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>List Pengguna - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />

</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
<h3 class="mb-4 fw-bold">Data Pengguna</h3>
  
<?php if (isset($_GET['error']) && $_GET['error'] == 'email_duplikat'): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-triangle me-1"></i> Email sudah terdaftar, gunakan email lain.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>
<?php if (isset($_GET['error']) && $_GET['error'] == 'masih_punya_pembayaran'): ?>
    <script>
        alert("Gagal menghapus pengguna: pengguna masih memiliki riwayat pembayaran!");
    </script>
<?php endif; ?>

<div class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-3">
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahModal">
    <i class="fa fa-user-plus me-1"></i> Tambah Pengguna
  </button>
  <div style="max-width: 320px; width: 100%;">
    <!-- LIVE SEARCH -->
    <input type="text" id="liveSearch" class="form-control"
           placeholder="Cari nama / email...">
  </div>
</div>

  <!-- Tabel pengguna -->
  <div class="table-responsive">
    <table class="table table-bordered align-middle" id="userTable">
      <thead class="table-secondary text-center">
        <tr>
          <th>No</th>
          <th>Gambar</th>
          <th>Nama</th>
          <th>Email</th>
          <th>No HP</th>
          <th>Alamat</th>
          <th>Tgl.Daftar</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php $no = 1; while($row = $result->fetch_assoc()): ?>
          <tr>
            <td class="text-center"><?= $no++ ?></td>
            <td class="text-center">
            <?php if (!empty($row['foto'])): ?>
              <img src="../uploads/pengguna/<?= htmlspecialchars($row['foto']) ?>"
                class="rounded-circle"
                style="width: 50px; height: 50px; object-fit: cover;"
                alt="<?= htmlspecialchars($row['nama']) ?>">
             <?php else: ?>
            
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['nama'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['no_hp'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['alamat'] ?? '') ?></td>
            <td><?= !empty($row['created_at']) ? date('d M Y H:i:s', strtotime($row['created_at'])) : '-' ?></td>
            <td class="text-center">
              <div class="d-flex gap-2 justify-content-center">
  
                <!-- tombol edit -->
                <button 
                  class="btn btn-warning btn-sm btn-edit"
                  data-id="<?= $row['id'] ?>"
                  data-nama="<?= htmlspecialchars($row['nama'] ?? '') ?>"
                  data-email="<?= htmlspecialchars($row['email'] ?? '') ?>"
                  data-no_hp="<?= htmlspecialchars($row['no_hp'] ?? '') ?>"
                  data-alamat="<?= htmlspecialchars($row['alamat'] ?? '') ?>"
                  data-created_at="<?= $row['created_at'] ?>"
                  data-gambar="<?= htmlspecialchars($row['foto'] ?? '') ?>"
                  data-bs-toggle="modal" 
                  data-bs-target="#editModal"
                >
                  <i class="fa fa-edit"></i>
                </button>

                <!-- tombol hapus -->
                <form action="aksi_pengguna.php" method="post"
                      onsubmit="return confirm('Yakin ingin menghapus pengguna ini?')">
                  <input type="hidden" name="id" value="<?= $row['id'] ?>">
                  <button type="submit" name="hapus_pengguna"
                          class="btn btn-danger btn-sm">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>

              </div>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="8" class="text-center">Data pengguna kosong.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<!-- Modal Tambah Pengguna -->
<div class="modal fade" id="tambahModal" tabindex="-1" aria-labelledby="tambahModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="aksi_pengguna.php" method="post" class="modal-content" enctype="multipart/form-data">
      <div class="modal-header">
        <h5 class="modal-title" id="tambahModalLabel">Tambah Pengguna</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label for="tambah_nama" class="form-label">Nama</label>
          <input type="text" name="nama" id="tambah_nama" class="form-control" required />
        </div>
        <div class="mb-3">
          <label for="tambah_email" class="form-label">Email</label>
          <input type="email" name="email" id="tambah_email" class="form-control" required />
        </div>
        <div class="mb-3">
          <label for="tambah_password" class="form-label">Password</label>
          <input type="password" name="password" id="tambah_password" class="form-control" required />
        </div>
        <div class="mb-3">
          <label for="tambah_no_hp" class="form-label">No HP</label>
          <input type="text" name="no_hp" id="tambah_no_hp" class="form-control" required />
        </div>
        <div class="mb-3">
          <label for="tambah_alamat" class="form-label">Alamat</label>
          <textarea name="alamat" id="tambah_alamat" class="form-control" rows="3" required></textarea>
        </div>
           <div class="mb-3">
            <label for="edit_created_at" class="form-label">Tgl.Daftar</label>
           <input type="datetime-local" name="created_at"
              min="<?= date('Y-m-d\TH:i') ?>"
              class="form-control"
              required>
          </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah_pengguna" class="btn btn-primary">Simpan</button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
      </div>
    </form>
  </div>
</div>


<!-- Modal Edit Pengguna -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <form action="aksi_pengguna.php" method="post" class="modal-content" enctype="multipart/form-data">
      <input type="hidden" name="id" id="edit_id" />
      <div class="modal-header">
        <h5 class="modal-title" id="editModalLabel">Edit Pengguna</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <div class="mb-3">
            <label for="edit_nama" class="form-label">Nama</label>
            <input type="text" name="nama" id="edit_nama" class="form-control" required />
          </div>
          <div class="mb-3">
            <label for="edit_email" class="form-label">Email</label>
            <input type="email" name="email" id="edit_email" class="form-control" required />
          </div>
          <div class="mb-3">
            <label for="edit_no_hp" class="form-label">No HP</label>
            <input type="text" name="no_hp" id="edit_no_hp" class="form-control" required />
          </div>
          <div class="mb-3">
            <label for="edit_alamat" class="form-label">Alamat</label>
            <textarea name="alamat" id="edit_alamat" class="form-control" rows="3" required></textarea>
          </div>
          <div class="mb-3">
            <label for="edit_created_at" class="form-label">Tgl.Daftar</label>
            <input type="datetime-local" name="created_at" id="edit_created_at" class="form-control" required />
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="edit_pengguna" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
        </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Isi modal edit dengan data dari tombol edit
      document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', () => {
          document.getElementById('edit_id').value = btn.getAttribute('data-id');
          document.getElementById('edit_nama').value = btn.getAttribute('data-nama') ?? '';
          document.getElementById('edit_email').value = btn.getAttribute('data-email') ?? '';
          document.getElementById('edit_no_hp').value = btn.getAttribute('data-no_hp') ?? '';
          document.getElementById('edit_alamat').value = btn.getAttribute('data-alamat') ?? '';
          document.getElementById('edit_created_at').value = btn.getAttribute('data-created_at') ?? '';
        });
      });
</script>
<script>
document.getElementById('liveSearch').addEventListener('keyup', function () {
    let keyword = this.value.toLowerCase();
    let rows = document.querySelectorAll('#userTable tbody tr');

    rows.forEach(row => {

        let text = row.textContent.toLowerCase();
        let cells = row.querySelectorAll('td');

        // tampil/sembunyi row
        if (text.includes(keyword)) {
            row.style.display = '';

            cells.forEach((td, index) => {

                // ❗ jangan highlight kolom terakhir (AKSI)
                if (index === cells.length - 1) return;

                let originalText = td.getAttribute('data-original');

                // simpan original pertama kali
                if (!originalText) {
                    td.setAttribute('data-original', td.innerHTML);
                    originalText = td.innerHTML;
                }

                if (keyword !== '') {
                    let regex = new RegExp(`(${keyword})`, 'gi');
                    td.innerHTML = originalText.replace(regex, `<span class="highlight">$1</span>`);
                } else {
                    td.innerHTML = originalText;
                }
            });

        } else {
            row.style.display = 'none';
        }
    });
});
</script>
</body>
</html>
