<?php
session_start();
require_once "../../koneksi.php";
include '../cek_login.php';

// Ambil data pengguna
$result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");

$usersList = [];
$total_users = 0;
if ($result && $result->num_rows > 0) {
    while ($r = $result->fetch_assoc()) {
        $total_users++;
        $usersList[] = $r;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Data Pengguna - Admin Semar Outdoor</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
  .stat-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 0.74rem;
    font-weight: 600;
  }
  .stat-pill-primary {
    background: #ecfdf5;
    color: #065f46;
    border: 1px solid #a7f3d0;
  }
</style>
</head>
<body>

<?php include '../sidebar.php'; ?>

<div class="main-content">
  <!-- Standard Page Header Bar -->
  <div class="admin-page-header">
    <div>
      <div class="admin-header-title">
        <i class="fas fa-users me-2 text-warning"></i>Data Pengguna & Member
      </div>
      <div class="admin-header-chips">
        <span class="badge bg-success px-2.5 py-1 rounded-pill">
          <i class="fas fa-user-check me-1"></i> <?= $total_users ?> Pengguna Terdaftar
        </span>
      </div>
    </div>

    <!-- Search Bar -->
    <div class="admin-header-actions">
      <div style="width: 240px;">
        <input type="text" id="liveSearch" class="form-control search-input-admin"
               placeholder="Cari pengguna...">
      </div>
    </div>
  </div>
  
  <?php if (isset($_GET['error']) && $_GET['error'] == 'email_duplikat'): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> Email sudah terdaftar, silakan gunakan email lain.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>
  <?php if (isset($_GET['error']) && $_GET['error'] == 'masih_punya_pembayaran'): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
      <i class="fas fa-exclamation-triangle me-1"></i> Gagal menghapus pengguna: Pengguna masih memiliki riwayat transaksi/pembayaran aktif!
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Tabel pengguna -->
  <div class="table-responsive">
    <table class="table align-middle" id="userTable">
      <thead>
        <tr class="text-center">
          <th style="width: 45px;">No</th>
          <th style="width: 55px;">Foto</th>
          <th class="text-start">Nama Pengguna</th>
          <th class="text-start">Email</th>
          <th style="width: 130px;">No. HP</th>
          <th class="text-start">Alamat Domisili</th>
          <th style="width: 140px;">Tgl. Daftar</th>
          <th style="width: 90px;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($usersList)): ?>
          <?php $no = 1; foreach($usersList as $row): ?>
          <tr>
            <td class="text-center fw-bold text-muted"><?= $no++ ?></td>
            <td class="text-center">
              <?php if (!empty($row['foto'])): ?>
                <img src="../uploads/pengguna/<?= htmlspecialchars($row['foto']) ?>"
                  class="rounded-circle border"
                  style="width: 32px; height: 32px; object-fit: cover;"
                  alt="<?= htmlspecialchars($row['nama']) ?>">
              <?php else: ?>
                <div class="rounded-circle bg-light border d-inline-flex align-items-center justify-content-center text-muted" style="width: 32px; height: 32px; font-size: 0.75rem;">
                  <i class="fas fa-user"></i>
                </div>
              <?php endif; ?>
            </td>
            <td><strong class="text-dark" style="font-size: 0.82rem;"><?= htmlspecialchars($row['nama'] ?? '') ?></strong></td>
            <td><span class="text-muted" style="font-size: 0.78rem;"><?= htmlspecialchars($row['email'] ?? '') ?></span></td>
            <td class="text-center"><span class="badge bg-light text-dark border px-2 py-0.5" style="font-size: 0.72rem;"><?= htmlspecialchars($row['no_hp'] ?? '-') ?></span></td>
            <td class="small text-muted" style="max-width: 240px; line-height: 1.35;"><?= htmlspecialchars($row['alamat'] ?? '-') ?></td>
            <td class="text-center text-muted" style="font-size: 0.74rem;">
              <i class="far fa-calendar-alt me-1 text-secondary"></i><?= !empty($row['created_at']) ? date('d M Y H:i', strtotime($row['created_at'])) : '-' ?>
            </td>
            <td class="text-center">
              <!-- tombol hapus -->
              <form action="aksi_pengguna.php" method="post"
                    onsubmit="return confirm('Apakah Anda yakin ingin menghapus data pengguna ini?')" style="display:inline;">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <button type="submit" name="hapus_pengguna"
                        class="btn btn-danger btn-admin-action" title="Hapus Pengguna">
                  <i class="fa fa-trash me-1"></i>Hapus
                </button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="8" class="text-center py-4 text-muted">Data pengguna masih kosong.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('liveSearch').addEventListener('keyup', function () {
    let keyword = this.value.toLowerCase().trim();
    let rows = document.querySelectorAll('#userTable tbody tr');

    rows.forEach(row => {
        let text = row.textContent.toLowerCase();
        if (text.includes(keyword)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});
</script>
</body>
</html>
