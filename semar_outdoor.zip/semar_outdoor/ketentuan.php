<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Syarat & Ketentuan Sewa - Semar Outdoor</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
      scroll-behavior: smooth;
    }

    .page-header {
      background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
      color: #ffffff;
      padding: 120px 20px 50px;
      text-align: center;
    }

    .page-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(2rem, 4vw, 2.7rem);
      font-weight: 800;
      margin-bottom: 10px;
    }

    .page-subtitle {
      color: #cbd5e1;
      font-size: 1.02rem;
      max-width: 620px;
      margin: 0 auto;
    }

    .terms-card {
      background: #ffffff;
      border-radius: 20px;
      border: 1px solid rgba(0,0,0,0.06);
      box-shadow: 0 10px 30px rgba(0,0,0,0.05);
      padding: 40px 35px;
      margin-top: -30px;
      margin-bottom: 70px;
      position: relative;
      z-index: 10;
    }

    .rule-item {
      display: flex;
      align-items: flex-start;
      gap: 18px;
      padding: 16px 20px;
      background: #f8fafc;
      border-radius: 14px;
      border: 1px solid rgba(0,0,0,0.04);
      margin-bottom: 14px;
      transition: all 0.25s ease;
    }

    .rule-item:hover {
      background: #ffffff;
      transform: translateX(5px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.05);
      border-color: rgba(194, 120, 3, 0.3);
    }

    .rule-icon {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      background: rgba(14, 68, 48, 0.08);
      color: var(--brand-green);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.25rem;
      flex-shrink: 0;
      transition: all 0.25s ease;
    }

    .rule-item:hover .rule-icon {
      background: var(--brand-gold);
      color: #ffffff;
      transform: scale(1.08);
    }

    .rule-content h5 {
      font-size: 1.02rem;
      font-weight: 700;
      color: var(--brand-teal);
      margin-bottom: 4px;
    }

    .rule-content p {
      font-size: 0.9rem;
      color: var(--text-muted);
      margin: 0;
      line-height: 1.5;
    }

    .btn-agree-cta {
      background: linear-gradient(135deg, var(--brand-teal) 0%, var(--brand-green) 100%);
      color: #ffffff;
      font-weight: 700;
      font-size: 1.05rem;
      padding: 14px 38px;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 6px 20px rgba(14, 68, 48, 0.35);
      border: none;
    }

    .btn-agree-cta:hover {
      background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
      color: #ffffff;
      transform: translateY(-3px);
      box-shadow: 0 10px 25px rgba(194, 120, 3, 0.5);
    }

    /* Footer */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 65px;
    }

    .footer-brand-logo {
      height: 42px;
      width: auto;
      max-height: 42px;
      object-fit: contain;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: 0.4px;
    }

    .footer-title {
      color: #ffffff;
      font-size: 1.05rem;
      font-weight: 700;
      margin-bottom: 18px;
      position: relative;
      padding-bottom: 8px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 32px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 10px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-links-list a:hover {
      color: #fde047;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 4px;
    }

    .footer-contact-item a {
      color: #cbd5e1;
      text-decoration: none;
    }

    .footer-contact-item a:hover {
      color: #fde047;
    }

    .footer-map-container {
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 170px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 20px 0;
      margin-top: 50px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.85rem;
      color: #64748b;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header Section -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Syarat & Ketentuan Sewa</h1>
      <p class="page-subtitle">Harap membaca dan memahami ketentuan berikut demi kenyamanan bersama selama masa sewa.</p>
    </div>
  </section>

  <!-- Content Section -->
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-9">
        <div class="terms-card">
          
          <div class="rule-item">
            <div class="rule-icon">
              <i class="fas fa-id-card"></i>
            </div>
            <div class="rule-content">
              <h5>1. Jaminan Identitas Resmi</h5>
              <p>Penyewa wajib menunjukkan identitas asli yang masih berlaku (KTP / SIM / Kartu Pelajar / Mahasiswa) saat pengambilan alat sewa di toko.</p>
            </div>
          </div>

          <div class="rule-item">
            <div class="rule-icon">
              <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="rule-content">
              <h5>2. Pembayaran Uang Muka (DP)</h5>
              <p>Pembayaran DP minimal Rp 10.000 atau lunas dilakukan melalui transfer bank / e-wallet untuk mengunci ketersediaan alat yang dipesan.</p>
            </div>
          </div>

          <div class="rule-item">
            <div class="rule-icon">
              <i class="fas fa-hand-holding-usd"></i>
            </div>
            <div class="rule-content">
              <h5>3. Pelunasan Pembayaran</h5>
              <p>Sisa tagihan sewa dapat dilunasi sebelum pengambilan atau langsung saat pengambilan alat di tempat kami.</p>
            </div>
          </div>

          <div class="rule-item">
            <div class="rule-icon">
              <i class="fas fa-calendar-times"></i>
            </div>
            <div class="rule-content">
              <h5>4. Keterlambatan Pengembalian</h5>
              <p>Denda keterlambatan sebesar Rp 10.000 per hari berlaku jika alat dikembalikan melewati batas tanggal sewa yang telah disepakati.</p>
            </div>
          </div>

          <div class="rule-item">
            <div class="rule-icon">
              <i class="fas fa-tools"></i>
            </div>
            <div class="rule-content">
              <h5>5. Kerusakan & Kehilangan Alat</h5>
              <p>Penyewa bertanggung jawab menjaga alat dengan baik. Kerusakan berat atau kehilangan komponen/alat akan dikenakan biaya penggantian wajar.</p>
            </div>
          </div>

          <div class="rule-item">
            <div class="rule-icon">
              <i class="fas fa-undo-alt"></i>
            </div>
            <div class="rule-content">
              <h5>6. Pembatalan Sewa</h5>
              <p>Pembatalan sewa dapat dilakukan secara mandiri oleh penyewa selama status pesanan masih dalam status "Menunggu Pembayaran".</p>
            </div>
          </div>

          <div class="text-center mt-4 pt-2">
            <a href="alat.php" class="btn-agree-cta">
              <i class="fas fa-check-circle"></i> Saya Paham & Mulai Sewa
            </a>
          </div>

        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
