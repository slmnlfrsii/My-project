<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include './koneksi.php';

if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}

$id_users = $_SESSION['id_users'];

/* =========================================================================
   🚫 CEK STATUS TRANSAKSI / PEMBAYARAN SEBELUM BOLEH CHECKOUT BARU
   Jika user memiliki transaksi yang berstatus:
   - 'Menunggu konfirmasi' (sedang diverifikasi admin)
   - 'Belum lunas' (sudah bayar DP, belum dilunasi)
   - 'Menunggu pembayaran' (belum dibayar sama sekali)
   Maka checkout baru TIDAK DIIZINKAN sampai transaksi sebelumnya selesai/lunas.
   ========================================================================= */
$q_blocking_checkout = mysqli_query($conn, "
    SELECT s.id, s.no_tagihan, s.status AS status_sewa,
    (
        SELECT status FROM pembayaran 
        WHERE (id_sewa = s.id OR FIND_IN_SET(s.id, id_sewa) OR (s.no_tagihan IS NOT NULL AND s.no_tagihan != '' AND EXISTS (
            SELECT 1 FROM sewa s2 WHERE s2.no_tagihan = s.no_tagihan AND (pembayaran.id_sewa = s2.id OR FIND_IN_SET(s2.id, pembayaran.id_sewa))
        )))
        ORDER BY tanggal_bayar DESC, id DESC LIMIT 1
    ) AS status_pembayaran
    FROM sewa s
    WHERE s.id_users = $id_users
    AND s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai')
");

$ada_transaksi_blocking = false;
$pesan_blocking = '';

if ($q_blocking_checkout && mysqli_num_rows($q_blocking_checkout) > 0) {
    while ($bRow = mysqli_fetch_assoc($q_blocking_checkout)) {
        $stPay = strtolower(trim($bRow['status_pembayaran'] ?? ''));
        $stSewa = strtolower(trim($bRow['status_sewa'] ?? ''));

        if ($stPay === 'menunggu konfirmasi') {
            $ada_transaksi_blocking = true;
            $pesan_blocking = "Anda memiliki transaksi yang sedang berstatus 'Menunggu Konfirmasi' dari Admin. Mohon tunggu konfirmasi admin terlebih dahulu sebelum menyewa alat baru.";
            break;
        } elseif ($stPay === 'belum lunas' || $stSewa === 'belum lunas') {
            $ada_transaksi_blocking = true;
            $pesan_blocking = "Anda masih memiliki tagihan yang berstatus 'Belum Lunas'. Silakan lakukan pelunasan tagihan terlebih dahulu sebelum melakukan checkout baru.";
            break;
        } elseif (empty($stPay) || $stSewa === 'menunggu pembayaran') {
            $ada_transaksi_blocking = true;
            $pesan_blocking = "Anda masih memiliki tagihan sewa aktif yang belum dibayar. Silakan selesaikan pembayaran tagihan Anda terlebih dahulu.";
            break;
        }
    }
}

if ($ada_transaksi_blocking) {
    echo "<!DOCTYPE html>
    <html lang='id'>
    <head>
        <meta charset='UTF-8'>
        <title>Checkout Ditangguhkan - Semar Outdoor</title>
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
    </head>
    <body style='font-family: sans-serif; background-color: #f4f6f9;'>
    <script>
        Swal.fire({
            icon: 'warning',
            title: 'Checkout Tidak Diizinkan!',
            text: '" . addslashes($pesan_blocking) . "',
            confirmButtonColor: '#0e4430',
            confirmButtonText: 'Ke Halaman Tagihan'
        }).then((result) => {
            window.location = 'tagihan.php';
        });
    </script>
    </body>
    </html>";
    exit(); 
}

$error = null;
$durasi = 1;
$keranjang_items = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_items_json'])) {
    $_POST['selected_items'] = json_decode($_POST['selected_items_json'], true);
}

// Ambil data keranjang + Hitung sisa stok dinamis real-time
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_items'])) {
    $selected_ids = $_POST['selected_items'];

    if (!empty($selected_ids)) {
        $placeholders = implode(',', array_fill(0, count($selected_ids), '?'));
        $types = str_repeat('i', count($selected_ids));
        
        $sql = "SELECT k.id, k.id_alat, k.jumlah as qty, a.nama as nama_produk, a.gambar, a.harga_per_hari,
                        GREATEST(0, a.stok_awal - IFNULL(s.total_disewa, 0)) AS sisa_stok_dinamis
                FROM keranjang k
                JOIN alat a ON k.id_alat = a.id
                LEFT JOIN (
                    SELECT id_alat, SUM(qty) AS total_disewa
                    FROM sewa
                    WHERE status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai')
                    GROUP BY id_alat
                ) s ON a.id = s.id_alat
                WHERE k.id_users = ? AND k.id IN ($placeholders)";

        $stmt = $conn->prepare($sql);
        $params = array_merge([$id_users], $selected_ids);
        
        $bind_types = "i" . $types;
        $stmt->bind_param($bind_types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $nama_lc = strtolower($row['nama_produk']);
            $row['is_consumable'] = (strpos($nama_lc, 'gas') !== false);
            $keranjang_items[] = $row;
        }
        $stmt->close();
    } else {
        $error = "Tidak ada item yang dipilih.";
    }
}

// Proses simpan ke tabel sewa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['konfirmasi'])) {
    $tanggal_sewa = $_POST['tanggal_sewa'];
    $durasi = (int)$_POST['durasi'];
    $metode_pengambilan = $_POST['metode_pengambilan'] ?? 'Ambil Ke toko';
    $selected_ids = $_POST['selected_ids'] ?? [];

    $tanggal_valid = DateTime::createFromFormat('Y-m-d', $tanggal_sewa);
    if (!$tanggal_sewa || $durasi < 1 || !$tanggal_valid) {
        $error = "Tanggal sewa, durasi minimal 1 hari, dan format tanggal harus valid.";
    } elseif (empty($selected_ids)) {
        $error = "Tidak ada item yang diproses.";
    } else {
        if ($ada_transaksi_blocking) {
            $_SESSION['error'] = $pesan_blocking;
            header("Location: tagihan.php");
            exit();
        }

        $tanggal_mysql = $tanggal_valid->format('Y-m-d');
        
        // COD 1x per checkout
        $biaya_cod_global = ($metode_pengambilan === 'COD') ? 10000 : 0;
        $is_first_item = true;

        // Generate nomor invoice tunggal dan seragam untuk seluruh item checkout ini
        $tgl_inv = date('Ymd');
        $qLast = $conn->query("SELECT MAX(id) AS max_id FROM sewa");
        $maxId = ($qLast && $rowLast = $qLast->fetch_assoc()) ? (int)$rowLast['max_id'] : 0;
        $no_tagihan_session = "INV-" . $tgl_inv . "-" . sprintf("%04d", $maxId + 1);

        foreach ($selected_ids as $id_keranjang) {
            $stmt = $conn->prepare("SELECT k.id, k.id_alat, k.jumlah as qty, a.nama, a.gambar, a.harga_per_hari 
                                    FROM keranjang k 
                                    JOIN alat a ON k.id_alat = a.id 
                                    WHERE k.id = ? AND k.id_users = ?");
            $stmt->bind_param("ii", $id_keranjang, $id_users);
            $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ($item) {
                // 1. CEK SISA STOK DINAMIS (Kondisi Real-Time)
                $cek = $conn->prepare("
                    SELECT GREATEST(0, a.stok_awal - IFNULL(s.total_disewa, 0)) AS sisa_stok_dinamis 
                    FROM alat a
                    LEFT JOIN (
                        SELECT id_alat, SUM(qty) AS total_disewa
                        FROM sewa
                        WHERE status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai')
                        GROUP BY id_alat
                    ) s ON a.id = s.id_alat
                    WHERE a.id = ?
                ");
                $cek->bind_param("i", $item['id_alat']);
                $cek->execute();
                $sisa_stok_dinamis = $cek->get_result()->fetch_assoc()['sisa_stok_dinamis'];
                $cek->close();

                if ($sisa_stok_dinamis < $item['qty']) {
                    die("Maaf, sisa stok tidak cukup untuk " . htmlspecialchars($item['nama']));
                }

                // 2. LOGIKA HARGA GAS / ITEM PAKAI HABIS
                $nama_lc = strtolower($item['nama']);
                $is_consumable = (strpos($nama_lc, 'gas') !== false);

                // Jika Gas = tidak dikali durasi; Jika Alat = dikali durasi
                $subtotal_sewa = $is_consumable 
                    ? ($item['harga_per_hari'] * $item['qty']) 
                    : ($item['harga_per_hari'] * $item['qty'] * $durasi);

                $biaya_pengambilan = $is_first_item ? $biaya_cod_global : 0;
                $is_first_item = false;

                $total_harga_item = $subtotal_sewa + $biaya_pengambilan;
                $status_awal = 'Menunggu pembayaran';

                // Insert ke tabel sewa dengan nomor invoice seragam dan status 'Menunggu pembayaran'
                $stmt = $conn->prepare("INSERT INTO sewa 
                    (id_users, id_alat, nama_produk, total_harga, gambar, qty, tanggal_sewa, durasi, metode_pengambilan, biaya_pengambilan, status, no_tagihan, tanggal_buat) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->bind_param("iisisisissss",
                    $id_users,
                    $item['id_alat'],
                    $item['nama'],
                    $total_harga_item,
                    $item['gambar'],
                    $item['qty'],
                    $tanggal_mysql,
                    $durasi,
                    $metode_pengambilan,
                    $biaya_pengambilan,
                    $status_awal,
                    $no_tagihan_session
                );
                $stmt->execute();
                $stmt->close();

                // Hapus item dari keranjang setelah berhasil dikonfirmasi sewa
                $conn->query("DELETE FROM keranjang WHERE id = $id_keranjang AND id_users = $id_users");
            }
        }

        header("Location: proses_checkout.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Formulir Checkout Sewa - Semar Outdoor</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
    }

    .page-header {
      background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
      color: #ffffff;
      padding: 120px 20px 45px;
      text-align: center;
    }

    .page-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(2rem, 4vw, 2.7rem);
      font-weight: 800;
      margin-bottom: 8px;
    }

    .page-subtitle {
      color: #cbd5e1;
      font-size: 1.02rem;
      max-width: 600px;
      margin: 0 auto;
    }

    .checkout-content {
      padding: 40px 0 80px;
    }

    .checkout-card {
      background: #ffffff;
      border-radius: 20px;
      border: 1px solid rgba(0,0,0,0.06);
      box-shadow: 0 6px 22px rgba(0,0,0,0.04);
      padding: 28px;
    }

    .product-row-item {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 16px 0;
      border-bottom: 1px solid rgba(0, 0, 0, 0.06);
    }

    .product-row-item:last-child {
      border-bottom: none;
    }

    .product-thumb {
      width: 75px;
      height: 75px;
      border-radius: 12px;
      object-fit: cover;
      background: #f1f5f9;
      flex-shrink: 0;
    }

    .product-details {
      flex-grow: 1;
    }

    .product-title {
      font-weight: 700;
      font-size: 1.05rem;
      color: var(--brand-teal);
      margin-bottom: 2px;
      font-family: 'Quicksand', sans-serif;
    }

    .product-price-tag {
      font-weight: 800;
      color: var(--brand-gold);
      font-size: 1.05rem;
      text-align: right;
      min-width: 120px;
    }

    .form-label-custom {
      font-weight: 700;
      font-size: 0.92rem;
      color: var(--brand-teal);
      margin-bottom: 6px;
    }

    .form-control-custom, .form-select-custom {
      border: 1.5px solid #e2e8f0;
      border-radius: 12px;
      padding: 11px 16px;
      font-size: 0.95rem;
      transition: all 0.2s ease;
    }

    .form-control-custom:focus, .form-select-custom:focus {
      border-color: var(--brand-gold);
      box-shadow: 0 0 0 4px rgba(194, 120, 3, 0.15);
      outline: none;
    }

    .total-bill-box {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 20px;
      margin-top: 24px;
    }

    .btn-confirm-checkout {
      background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
      color: #ffffff;
      font-weight: 700;
      font-size: 1.05rem;
      padding: 14px;
      border-radius: 14px;
      border: none;
      width: 100%;
      transition: all 0.25s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      box-shadow: 0 6px 20px rgba(194, 120, 3, 0.35);
    }

    .btn-confirm-checkout:hover {
      background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(194, 120, 3, 0.5);
      color: #ffffff;
    }

    /* Footer */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 65px;
    }

    .footer-brand-logo {
      height: 42px;
      width: auto;
      max-height: 42px;
      object-fit: contain;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: 0.4px;
    }

    .footer-title {
      color: #ffffff;
      font-size: 1.05rem;
      font-weight: 700;
      margin-bottom: 18px;
      position: relative;
      padding-bottom: 8px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 32px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 10px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-links-list a:hover {
      color: #fde047;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 4px;
    }

    .footer-contact-item a {
      color: #cbd5e1;
      text-decoration: none;
    }

    .footer-contact-item a:hover {
      color: #fde047;
    }

    .footer-map-container {
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 170px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 20px 0;
      margin-top: 50px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.85rem;
      color: #64748b;
    }

    /* Mobile Responsiveness */
    @media (max-width: 768px) {
      .page-header {
        padding: 85px 16px 20px !important;
      }
      .page-title {
        font-size: 1.35rem !important;
      }
      .page-subtitle {
        font-size: 0.82rem !important;
      }
      .checkout-content {
        padding: 16px 0 40px !important;
      }
      .checkout-card {
        padding: 14px 16px !important;
        border-radius: 12px !important;
      }
      .product-row-item {
        padding: 8px 10px !important;
        gap: 10px !important;
      }
      .product-thumb {
        width: 48px !important;
        height: 48px !important;
        border-radius: 6px !important;
      }
      .product-title {
        font-size: 0.88rem !important;
      }
      .product-price-tag {
        font-size: 0.9rem !important;
      }
      .total-bill-box {
        padding: 10px 12px !important;
        font-size: 0.82rem !important;
      }
      .btn-confirm-checkout {
        padding: 9px 14px !important;
        font-size: 0.88rem !important;
      }
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Formulir Checkout Sewa</h1>
      <p class="page-subtitle">Tentukan tanggal mulai sewa, durasi pemakaian, serta metode pengambilan alat Anda.</p>
    </div>
  </section>

  <!-- Checkout Section -->
  <section class="checkout-content">
    <div class="container">
      
      <?php if ($error): ?>
        <div class="alert alert-danger rounded-4 mb-4 shadow-sm">
          <i class="fas fa-exclamation-triangle me-2"></i> <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <?php if (!empty($keranjang_items)): ?>
        <div class="row g-4">
          <!-- Kolom Kiri: Daftar Alat yang Dipesan -->
          <div class="col-lg-7">
            <div class="checkout-card">
              <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
                <i class="fas fa-box-open text-warning me-2"></i> Rincian Perlengkapan
              </h5>

              <div class="product-list">
                <?php foreach ($keranjang_items as $item): 
                  $harga_dasar = $item['harga_per_hari'] * $item['qty'];
                  $subtotal_awal = $item['is_consumable'] ? $harga_dasar : ($harga_dasar * $durasi);
                ?>
                  <div class="product-row-item">
                    <img src="admin/uploads/alat/<?= htmlspecialchars($item['gambar']) ?>" class="product-thumb" alt="<?= htmlspecialchars($item['nama_produk']) ?>">
                    
                    <div class="product-details">
                      <div class="product-title"><?= htmlspecialchars($item['nama_produk']) ?></div>
                      <div class="text-muted small">
                        Jumlah: <strong><?= $item['qty'] ?> unit</strong> &bull; Rp<?= number_format($item['harga_per_hari'], 0, ',', '.') ?>/hari
                      </div>
                    </div>

                    <div class="product-price-tag harga-item" 
                         data-harga-dasar="<?= $harga_dasar ?>"
                         data-is-consumable="<?= $item['is_consumable'] ? 'true' : 'false' ?>">
                      Rp <?= number_format($subtotal_awal, 0, ',', '.') ?>
                    </div>
                    
                    <input type="hidden" name="selected_ids[]" value="<?= $item['id'] ?>" form="formSewa">
                  </div>
                <?php endforeach; ?>
              </div>

              <div class="mt-4 pt-3 border-top text-center text-muted small">
                <i class="fas fa-shield-alt text-success me-1"></i> Transaksi Aman & Terpercaya di Semar Outdoor
              </div>
            </div>
          </div>

          <!-- Kolom Kanan: Pengaturan Sewa & Tombol Konfirmasi -->
          <div class="col-lg-5">
            <div class="checkout-card">
              <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
                <i class="fas fa-calendar-check text-success me-2"></i> Detail Pengambilan
              </h5>

              <form method="POST" id="formSewa">
                <input type="hidden" name="konfirmasi" value="1">
                
                <div class="mb-3">
                  <label class="form-label-custom">Tanggal Mulai Sewa:</label>
                  <input type="date" name="tanggal_sewa" class="form-control form-control-custom" required value="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>">
                </div>

                <div class="mb-3">
                  <label class="form-label-custom">Durasi Sewa (Hari):</label>
                  <input type="number" name="durasi" class="form-control form-control-custom" id="durasi" min="1" required value="<?= $durasi ?>">
                  <small class="text-muted" style="font-size: 0.8rem;">Contoh: 2 untuk sewa selama 2 hari.</small>
                </div>

                <div class="mb-3">
                  <label class="form-label-custom">Metode:</label>
                  <select name="metode_pengambilan" class="form-select form-select-custom" id="metode">
                    <option value="Ambil Ke toko">Ambil di Toko (Gratis)</option>
                    <option value="COD">Diantar / COD (+Rp 10.000)</option>
                  </select>
                </div>

                <div class="total-bill-box">
                  <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small">Subtotal Sewa</span>
                    <span class="fw-bold" id="subtotalSewaDisplay">Rp 0</span>
                  </div>
                  <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small">Ongkir</span>
                    <span class="fw-bold text-secondary" id="ongkirDisplay">Rp 0</span>
                  </div>
                  <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                    <span class="fw-bold" style="color: var(--brand-teal);">Total Tagihan</span>
                    <span class="fs-4 fw-bold text-success">Rp <span id="totalHarga">0</span></span>
                  </div>
                </div>

                <button type="submit" class="btn-confirm-checkout mt-4">
                  <i class="fas fa-check-circle"></i> Konfirmasi Sewa
                </button>
                <a href="keranjang.php" class="btn btn-outline-secondary w-100 mt-2 py-2 d-flex align-items-center justify-content-center gap-2" style="border-radius: 10px; font-weight: 600; font-size: 0.9rem;">
                  <i class="fas fa-arrow-left"></i> Kembali ke Keranjang
                </a>
              </form>
            </div>
          </div>
        </div>
      <?php else: ?>
        <div class="text-center py-5">
          <p class="text-muted">Tidak ada item yang dipilih untuk diproses.</p>
          <a href="keranjang.php" class="btn btn-dark" style="background: var(--brand-teal); border-radius: 10px;">Kembali ke Keranjang</a>
        </div>
      <?php endif; ?>

    </div>
  </section>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Tasikmalaya, Jawa Barat, Indonesia</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script>
    const durasiInput = document.getElementById('durasi');
    const metodeInput = document.getElementById('metode');
    const totalHargaElem = document.getElementById('totalHarga');
    const subtotalSewaDisplay = document.getElementById('subtotalSewaDisplay');
    const ongkirDisplay = document.getElementById('ongkirDisplay');
    const hargaItemElements = document.querySelectorAll('.harga-item');

    function updateTotal() {
        if (!durasiInput || !metodeInput) return;
        const durasi = parseInt(durasiInput.value) || 1;
        const metode = metodeInput.value;
        const ongkir = (metode === 'COD') ? 10000 : 0;

        let totalSewa = 0;

        hargaItemElements.forEach(el => {
            const hargaDasar = parseInt(el.dataset.hargaDasar);
            const isConsumable = el.dataset.isConsumable === 'true';
            
            // JIKA GAS / CONSUMABLE: TIDAK DIKALI DURASI
            const subtotalItem = isConsumable ? hargaDasar : (hargaDasar * durasi);
            
            el.textContent = 'Rp ' + new Intl.NumberFormat('id-ID').format(subtotalItem);
            totalSewa += subtotalItem;
        });

        if (subtotalSewaDisplay) {
            subtotalSewaDisplay.textContent = 'Rp ' + new Intl.NumberFormat('id-ID').format(totalSewa);
        }
        if (ongkirDisplay) {
            ongkirDisplay.textContent = (ongkir > 0) ? 'Rp ' + new Intl.NumberFormat('id-ID').format(ongkir) : 'Gratis';
        }

        const totalKeseluruhan = totalSewa + ongkir;
        if (totalHargaElem) {
            totalHargaElem.textContent = new Intl.NumberFormat('id-ID').format(totalKeseluruhan);
        }
    }

    if (durasiInput && metodeInput) {
        durasiInput.addEventListener('input', updateTotal);
        metodeInput.addEventListener('change', updateTotal);
        updateTotal();
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
