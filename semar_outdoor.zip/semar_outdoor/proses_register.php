<?php
session_start();
include './koneksi.php';

$nama = trim($_POST['nama'] ?? '');
$email = trim($_POST['email'] ?? '');
$no_hp = trim($_POST['no_hp'] ?? '');
$alamat = trim($_POST['alamat'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$role = 'users'; // default

// Validasi password dan konfirmasi
if ($password !== $confirm_password) {
    header("Location: register.php?status=password_tidak_sama");
    exit;
}

// Cek apakah email sudah ada
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    header("Location: register.php?status=email_sudah_terdaftar");
    exit;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Tambahkan waktu pendaftaran
$created_at = date('Y-m-d H:i:s');

// Simpan ke database
$stmt = $conn->prepare("INSERT INTO users (nama, email, no_hp, alamat, password, created_at) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $nama, $email, $no_hp, $alamat, $hashed_password, $created_at);

if ($stmt->execute()) {
    header("Location: register.php?status=berhasil");
} else {
    header("Location: register.php?status=gagal");
}
?>
