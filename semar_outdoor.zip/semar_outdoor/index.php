<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'koneksi.php';
include 'google_reviews.php';
date_default_timezone_set('Asia/Jakarta');

// Ambil rating & ulasan dari Google Maps API / Cache
$googleMapsData = getGoogleMapsReviews();

// Ambil 8 alat teratas dari database dengan perhitungan stok dinamis real-time
$produkQuery = $conn->query("
    SELECT 
        a.*,
        GREATEST(0, a.stok_awal - IFNULL(SUM(
            CASE 
                WHEN s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai') THEN s.qty 
                ELSE 0 
            END
        ), 0)) AS sisa_stok_dinamis
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat
    GROUP BY a.id
    ORDER BY a.id ASC
    LIMIT 8
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Semar Outdoor - Rental Perlengkapan Camping & Outdoor Tasikmalaya</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
      scroll-behavior: smooth;
    }

    /* ========================================================= */
    /* 🌟 HERO SECTION */
    /* ========================================================= */
    .hero-section {
      position: relative;
      background: url("assets/images/alt2.jpg") center center / cover no-repeat;
      background-attachment: fixed;
      min-height: 88vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #ffffff;
      padding: 130px 20px 80px;
    }

    .hero-section::before {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(14, 35, 33, 0.38) 0%, rgba(10, 28, 24, 0.52) 100%);
      z-index: 1;
    }

    .hero-box {
      position: relative;
      z-index: 2;
      max-width: 860px;
      text-align: center;
    }

    .hero-chip {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(14, 40, 36, 0.65);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #fde047;
      font-size: 0.88rem;
      font-weight: 700;
      padding: 8px 22px;
      border-radius: 50px;
      margin-bottom: 24px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
    }

    .hero-heading {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(2.3rem, 5vw, 3.8rem);
      font-weight: 800;
      line-height: 1.18;
      letter-spacing: -0.5px;
      margin-bottom: 20px;
      text-shadow: 0 4px 16px rgba(0, 0, 0, 0.65);
    }

    .hero-heading span {
      background: linear-gradient(135deg, #fef08a 0%, #f59e0b 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      filter: drop-shadow(0 2px 8px rgba(0,0,0,0.5));
    }

    .hero-desc {
      font-size: clamp(1.05rem, 2vw, 1.25rem);
      color: #ffffff;
      line-height: 1.65;
      margin-bottom: 34px;
      max-width: 660px;
      margin-left: auto;
      margin-right: auto;
      text-shadow: 0 2px 10px rgba(0, 0, 0, 0.7);
    }

    .hero-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      justify-content: center;
    }

    .btn-main-cta {
      background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
      color: #ffffff;
      font-weight: 700;
      font-size: 1.05rem;
      padding: 14px 36px;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 6px 20px rgba(194, 120, 3, 0.45);
      display: inline-flex;
      align-items: center;
      gap: 10px;
      border: none;
    }

    .btn-main-cta:hover {
      background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
      color: #ffffff;
      transform: translateY(-3px);
      box-shadow: 0 10px 25px rgba(194, 120, 3, 0.6);
    }

    .btn-sec-cta {
      background: rgba(255, 255, 255, 0.12);
      backdrop-filter: blur(6px);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #ffffff;
      font-weight: 700;
      font-size: 1.05rem;
      padding: 14px 30px;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      gap: 10px;
    }

    .btn-sec-cta:hover {
      background: rgba(255, 255, 255, 0.25);
      color: #ffffff;
      transform: translateY(-3px);
    }

    /* Trust Highlights */
    .hero-metrics {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
      margin-top: 45px;
      padding-top: 25px;
      border-top: 1px solid rgba(255, 255, 255, 0.12);
    }

    .metric-item {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 0.9rem;
      color: #e2e8f0;
      font-weight: 500;
    }

    .metric-item i {
      color: #fde047;
      font-size: 1.1rem;
    }

    /* ========================================================= */
    /* 🌟 SECTION TITLES */
    /* ========================================================= */
    .section-title-wrap {
      text-align: center;
      margin-bottom: 42px;
    }

    .section-badge-tag {
      display: inline-block;
      font-size: 0.8rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.2px;
      color: var(--brand-gold);
      background: rgba(194, 120, 3, 0.1);
      padding: 6px 16px;
      border-radius: 50px;
      margin-bottom: 10px;
    }

    .section-main-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(1.8rem, 3.2vw, 2.3rem);
      font-weight: 800;
      color: var(--brand-dark);
      margin-bottom: 8px;
    }

    .section-sub-title {
      color: var(--text-muted);
      font-size: 0.98rem;
      max-width: 600px;
      margin: 0 auto;
    }

    /* ========================================================= */
    /* 🌟 POPULAR CATEGORIES GRID */
    /* ========================================================= */
    .categories-area {
      padding: 70px 0 35px;
      background: #ffffff;
    }

    .cat-item-card {
      background: #f8fafc;
      border-radius: 16px;
      padding: 22px 18px;
      text-align: center;
      text-decoration: none;
      color: var(--brand-dark);
      border: 1px solid rgba(0,0,0,0.05);
      transition: all 0.28s ease;
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 100%;
    }

    .cat-item-card:hover {
      background: #ffffff;
      transform: translateY(-5px);
      box-shadow: 0 10px 24px rgba(0,0,0,0.06);
      border-color: var(--brand-gold);
      color: var(--brand-gold);
    }

    .cat-icon {
      width: 54px;
      height: 54px;
      border-radius: 14px;
      background: rgba(14, 68, 48, 0.08);
      color: var(--brand-green);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.45rem;
      margin-bottom: 12px;
      transition: all 0.28s ease;
    }

    .cat-item-card:hover .cat-icon {
      background: var(--brand-gold);
      color: #ffffff;
      transform: scale(1.08);
    }

    .cat-title {
      font-weight: 700;
      font-size: 0.95rem;
      margin-bottom: 3px;
    }

    .cat-subtitle {
      font-size: 0.8rem;
      color: var(--text-muted);
    }

    /* ========================================================= */
    /* 🌟 FEATURED GEAR (PRODUK POPULER - COMPACT PROPORTIONAL) */
    /* ========================================================= */
    .gear-section {
      padding: 55px 0 65px;
      background: var(--bg-body);
    }

    .gear-card {
      background: #ffffff;
      border-radius: 14px;
      overflow: hidden;
      border: 1px solid rgba(0, 0, 0, 0.06);
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.03);
      transition: all 0.28s cubic-bezier(0.4, 0, 0.2, 1);
      display: flex;
      flex-direction: column;
      height: 100%;
      text-decoration: none;
      color: inherit;
    }

    .gear-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 24px rgba(0, 0, 0, 0.08);
      border-color: rgba(194, 120, 3, 0.35);
      color: inherit;
    }

    .gear-thumb {
      position: relative;
      width: 100%;
      height: 155px;
      overflow: hidden;
      background: #f1f5f9;
      cursor: pointer;
    }

    .gear-thumb img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.45s ease;
    }

    .gear-card:hover .gear-thumb img {
      transform: scale(1.06);
    }

    .zoom-icon-badge {
      position: absolute;
      bottom: 8px;
      right: 8px;
      background: rgba(14, 68, 48, 0.85);
      color: #ffffff;
      width: 26px;
      height: 26px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.72rem;
      backdrop-filter: blur(4px);
      box-shadow: 0 2px 6px rgba(0,0,0,0.25);
      transition: all 0.2s ease;
      z-index: 3;
      opacity: 0.85;
    }

    .gear-thumb:hover .zoom-icon-badge {
      opacity: 1;
      transform: scale(1.15);
      background: #c27803;
    }

    #modalImageLightbox .modal-content {
      background: #0f172a;
      color: #ffffff;
      border-radius: 16px;
      border: 1px solid rgba(255,255,255,0.15);
      overflow: hidden;
      box-shadow: 0 25px 60px rgba(0,0,0,0.5);
    }

    #modalImageLightbox .modal-header {
      background: #0e4430;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    #modalImageLightbox .lightbox-img-wrapper {
      background: #020617;
      min-height: 240px;
      max-height: 75vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 12px;
    }

    #modalImageLightbox .lightbox-img-wrapper img {
      max-width: 100%;
      max-height: 70vh;
      object-fit: contain;
      border-radius: 8px;
    }

    .tag-ready {
      position: absolute;
      top: 8px;
      left: 8px;
      background: rgba(14, 68, 48, 0.92);
      backdrop-filter: blur(4px);
      color: #ffffff;
      font-size: 0.66rem;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 5px;
    }

    .tag-ready.out {
      background: rgba(220, 38, 38, 0.92);
    }

    .tag-popular {
      position: absolute;
      top: 8px;
      right: 8px;
      background: rgba(217, 119, 6, 0.92);
      backdrop-filter: blur(4px);
      color: #ffffff;
      font-size: 0.66rem;
      font-weight: 700;
      padding: 3px 8px;
      border-radius: 5px;
    }

    .gear-body {
      padding: 12px 14px;
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .gear-feature-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 0.68rem;
      font-weight: 600;
      color: #0e4430;
      background: #e8f5e9;
      padding: 2px 8px;
      border-radius: 50px;
      margin-bottom: 6px;
      width: fit-content;
    }

    .gear-rating-badge {
      font-size: 0.72rem;
      font-weight: 600;
    }

    .gear-name {
      font-size: 0.94rem;
      font-weight: 700;
      color: var(--brand-dark);
      margin-bottom: 4px;
      line-height: 1.3;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .gear-desc {
      font-size: 0.76rem;
      color: var(--text-muted);
      margin-bottom: 10px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      line-height: 1.35;
    }

    .gear-price-row {
      margin-top: auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-top: 1px solid rgba(0, 0, 0, 0.05);
      padding-top: 10px;
    }

    .price-value {
      font-size: 1.05rem;
      font-weight: 800;
      color: var(--brand-gold);
    }

    .price-duration {
      font-size: 0.74rem;
      color: var(--text-muted);
    }

    .gear-btn-sewa {
      background: var(--brand-dark);
      color: #ffffff;
      font-size: 0.76rem;
      font-weight: 700;
      padding: 5px 12px;
      border-radius: 50px;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      transition: all 0.2s ease;
    }

    .gear-card:hover .gear-btn-sewa {
      background: var(--brand-gold);
      color: #ffffff;
    }

    /* ========================================================= */
    /* 🌟 ALUR SEWA (HOW TO RENT) */
    /* ========================================================= */
    .steps-section {
      padding: 75px 0;
      background: #ffffff;
    }

    .step-item-box {
      text-align: center;
      padding: 24px 16px;
      position: relative;
    }

    .step-badge {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--brand-gold);
      color: #ffffff;
      font-weight: 800;
      font-size: 0.88rem;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 12px;
    }

    .step-icon-circle {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      background: rgba(14, 68, 48, 0.08);
      color: var(--brand-green);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.55rem;
      margin: 0 auto 14px;
      transition: all 0.3s ease;
    }

    .step-item-box:hover .step-icon-circle {
      background: var(--brand-green);
      color: #ffffff;
      transform: scale(1.1);
    }

    .step-title {
      font-weight: 700;
      font-size: 1.05rem;
      color: var(--brand-dark);
      margin-bottom: 6px;
    }

    .step-desc {
      font-size: 0.88rem;
      color: var(--text-muted);
      margin: 0;
      line-height: 1.5;
    }

    /* ========================================================= */
    /* 🌟 TENTANG & KEUNGGULAN */
    /* ========================================================= */
    .about-value-section {
      padding: 75px 0 85px;
      background: #f8fafc;
    }

    .about-lead-card {
      background: #ffffff;
      border-radius: 20px;
      padding: 38px 32px;
      border: 1px solid rgba(0,0,0,0.06);
      box-shadow: 0 4px 18px rgba(0,0,0,0.03);
      height: 100%;
    }

    .feature-point {
      display: flex;
      align-items: flex-start;
      gap: 16px;
      padding: 16px;
      background: #ffffff;
      border-radius: 14px;
      border: 1px solid rgba(0,0,0,0.05);
      transition: transform 0.25s ease;
    }

    .feature-point:hover {
      transform: translateX(5px);
      border-color: rgba(194, 120, 3, 0.25);
    }

    .feature-point-icon {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      background: rgba(194, 120, 3, 0.1);
      color: var(--brand-gold);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.25rem;
      flex-shrink: 0;
    }

    .feature-point-text h6 {
      font-size: 1.02rem;
      font-weight: 700;
      color: var(--brand-dark);
      margin-bottom: 3px;
    }

    .feature-point-text p {
      font-size: 0.86rem;
      color: var(--text-muted);
      margin: 0;
      line-height: 1.45;
    }

    /* Google Maps Rating Badge in Hero */
    .hero-google-chip {
      background: rgba(255, 255, 255, 0.15) !important;
      border: 1px solid rgba(250, 204, 21, 0.4) !important;
      color: #ffffff !important;
      transition: all 0.25s ease;
    }
    .hero-google-chip:hover {
      background: rgba(255, 255, 255, 0.28) !important;
      transform: translateY(-2px);
    }
    .rating-stars {
      color: #facc15;
      letter-spacing: 1px;
    }

    /* Product rating badge */
    .gear-rating-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 0.78rem;
      font-weight: 700;
      color: #1e293b;
      background: #fef9c3;
      border: 1px solid #fef08a;
      padding: 3px 8px;
      border-radius: 50px;
    }

    /* Google Reviews Section */
    .google-reviews-section {
      padding: 80px 0;
      background: #ffffff;
      position: relative;
    }

    .google-summary-card {
      background: linear-gradient(135deg, #0e4430 0%, #162d2f 100%);
      color: #ffffff;
      border-radius: 20px;
      padding: 30px;
      margin-bottom: 40px;
      box-shadow: 0 10px 30px rgba(14, 68, 48, 0.15);
    }

    .google-score-big {
      font-size: 3.5rem;
      font-weight: 800;
      line-height: 1;
      color: #ffffff;
      font-family: 'Quicksand', sans-serif;
    }

    .btn-google-action {
      background: #ffffff;
      color: #0e4430;
      font-weight: 700;
      font-size: 0.9rem;
      padding: 10px 22px;
      border-radius: 50px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
    }

    .btn-google-action:hover {
      background: #facc15;
      color: #12282a;
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
    }

    .google-review-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 24px;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      transition: all 0.25s ease;
    }

    .google-review-card:hover {
      background: #ffffff;
      transform: translateY(-5px);
      border-color: #cbd5e1;
      box-shadow: 0 12px 28px rgba(0, 0, 0, 0.06);
    }

    .review-user-avatar {
      width: 44px;
      height: 44px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 1.1rem;
      color: #ffffff;
      flex-shrink: 0;
    }

    /* Swiper Slider Styling for Reviews */
    .google-reviews-slider-wrapper {
      position: relative;
      padding: 10px 4px 10px;
    }
    .swiper.googleReviewsSwiper {
      padding: 10px 4px 35px;
    }
    .googleReviewsSwiper .swiper-slide {
      height: auto;
      display: flex;
    }
    .googleReviewsSwiper .swiper-slide .google-review-card {
      width: 100%;
    }
    .googleReviewsSwiper .swiper-pagination-bullet {
      background: #0e4430;
      opacity: 0.25;
      width: 10px;
      height: 10px;
      margin: 0 4px;
      transition: all 0.3s ease;
    }
    .googleReviewsSwiper .swiper-pagination-bullet-active {
      background: #c27803;
      opacity: 1;
      width: 26px;
      border-radius: 6px;
    }
    .review-slider-nav-btn {
      width: 42px;
      height: 42px;
      border-radius: 50%;
      background: #ffffff;
      border: 1.5px solid #cbd5e1;
      color: #0e4430;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      transition: all 0.22s ease;
    }
    .review-slider-nav-btn:hover {
      background: #0e4430;
      color: #ffffff;
      border-color: #0e4430;
      transform: scale(1.08);
      box-shadow: 0 6px 16px rgba(14,68,48,0.25);
    }

    /* ========================================================= */
    /* 🌟 FOOTER */
    /* ========================================================= */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 65px;
    }

    .footer-brand-logo {
      height: 42px;
      width: auto;
      max-height: 42px;
      object-fit: contain;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: 0.4px;
    }

    .footer-title {
      color: #ffffff;
      font-size: 1.05rem;
      font-weight: 700;
      margin-bottom: 18px;
      position: relative;
      padding-bottom: 8px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 32px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 10px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-links-list a:hover {
      color: #fde047;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 4px;
    }

    .footer-contact-item a {
      color: #cbd5e1;
      text-decoration: none;
    }

    .footer-contact-item a:hover {
      color: #fde047;
    }

    .footer-map-container {
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 170px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 20px 0;
      margin-top: 50px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.85rem;
      color: #64748b;
    }
  </style>
</head>

<body>
  <!-- Header Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- 1. Hero Section -->
  <section class="hero-section" id="beranda">
    <div class="hero-box">
      <div class="d-flex flex-wrap justify-content-center gap-2 mb-3">
        <div class="hero-chip mb-0">
          <i class="fas fa-campground"></i> Rental Alat Camping & Outdoor Tasikmalaya
        </div>
        <a href="#ulasan" class="hero-chip hero-google-chip mb-0 text-decoration-none" title="Lihat Ulasan Google Maps">
          <i class="fab fa-google text-warning"></i>
          <span><strong>4.9 / 5.0</strong> di Google Maps</span>
          <span class="rating-stars">★★★★★</span>
          <span class="opacity-75 small">(85+ Ulasan)</span>
        </a>
      </div>
      
      <h1 class="hero-heading">
        Petualangan Alam Bebas, <br>
        <span>Kami Siapkan Alatnya!</span>
      </h1>
      
      <p class="hero-desc">
        Penyedia sewa alat outdoor lengkap, higienis, dan 100% siap pakai. Nikmati tarif harian terjangkau dengan sistem booking online yang cepat dan mudah.
      </p>
      
      <div class="hero-actions">
        <a href="alat.php" class="btn-main-cta">
          <i class="fas fa-compass"></i> Jelajahi Katalog Alat
        </a>
        <a href="#cara-sewa" class="btn-sec-cta">
          <i class="fas fa-play-circle"></i> Cara Sewa
        </a>
      </div>

      <!-- Trust Metrics -->
      <div class="hero-metrics">
        <div class="metric-item">
          <i class="fas fa-shield-check"></i> 100% Kondisi Terawat & Bersih
        </div>
        <div class="metric-item">
          <i class="fas fa-star text-warning"></i> Rating 4.9 di Google Maps
        </div>
        <div class="metric-item">
          <i class="fas fa-truck-pickup"></i> Opsi Ambil di Toko / COD Antar
        </div>
      </div>
    </div>
  </section>

  <!-- 2. Kategori Cepat (Klik langsung menuju katalog) -->
  <section class="categories-area">
    <div class="container">
      <div class="row g-3 justify-content-center">
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon">
              <i class="fas fa-campground"></i>
            </div>
            <span class="cat-title">Tenda & Shelter</span>
            <span class="cat-subtitle">Kapasitas 2 s.d. 6 Orang</span>
          </a>
        </div>
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon" style="background: rgba(194, 120, 3, 0.1); color: var(--brand-gold);">
              <i class="fas fa-bed"></i>
            </div>
            <span class="cat-title">Sleeping System</span>
            <span class="cat-subtitle">Sleeping Bag, Matras & Kasur</span>
          </a>
        </div>
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon">
              <i class="fas fa-utensils"></i>
            </div>
            <span class="cat-title">Cooking Set</span>
            <span class="cat-subtitle">Kompor Portable, Nesting & Gas</span>
          </a>
        </div>
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon" style="background: rgba(194, 120, 3, 0.1); color: var(--brand-gold);">
              <i class="fas fa-hiking"></i>
            </div>
            <span class="cat-title">Carrier & Aksesoris</span>
            <span class="cat-subtitle">Tas Carrier, Headlamp & Flysheet</span>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- 3. Featured Gear (Katalog Dinamis dari Database - Tanpa Rating Bintang) -->
  <section class="gear-section" id="produk">
    <div class="container">
      <div class="section-title-wrap">
        <span class="section-badge-tag">Katalog Pilihan</span>
        <h2 class="section-main-title">Peralatan Populer Siap Sewa</h2>
        <p class="section-sub-title">Peralatan outdoor unggulan dalam kondisi prima dan teruji untuk menemani agenda camping Anda.</p>
      </div>

      <div class="row g-3 justify-content-center">
        <?php if ($produkQuery && $produkQuery->num_rows > 0): ?>
          <?php while ($alat = $produkQuery->fetch_assoc()): 
            $sisaStok = isset($alat['sisa_stok_dinamis']) ? (int)$alat['sisa_stok_dinamis'] : (int)($alat['sisa_stok'] ?? 0);
            $namaProduk = htmlspecialchars($alat['nama']);
            $deskripsiProduk = htmlspecialchars($alat['deskripsi'] ?? 'Peralatan camping berkualitas dan siap pakai.');
            $hargaPerHari = (float)$alat['harga_per_hari'];
            $isGas = (stripos($namaProduk, 'gas') !== false);
            $gambarPath = 'admin/uploads/alat/' . $alat['gambar'];
            $imgSrc = (!empty($alat['gambar']) && file_exists($gambarPath)) ? $gambarPath : 'assets/images/tenda.jpg';
          ?>
          <div class="col-xl-3 col-lg-3 col-md-4 col-6">
            <a href="alat.php" class="gear-card">
              <div class="gear-thumb" onclick="event.preventDefault(); event.stopPropagation(); showLightboxModal('<?= htmlspecialchars($imgSrc) ?>', '<?= htmlspecialchars($namaProduk) ?>', 'Rp<?= number_format($hargaPerHari, 0, ',', '.') ?> <?= $isGas ? '/ pcs' : '/ hari' ?>', <?= $sisaStok ?>);" title="Klik untuk memperbesar foto">
                <img src="<?= htmlspecialchars($imgSrc) ?>" alt="<?= $namaProduk ?>">
                <?php if ($sisaStok > 0): ?>
                  <span class="tag-ready"><i class="fas fa-check-circle me-1"></i> <?= $sisaStok ?> Unit</span>
                <?php else: ?>
                  <span class="tag-ready out"><i class="fas fa-times-circle me-1"></i> Habis</span>
                <?php endif; ?>
                <span class="tag-popular"><i class="fas fa-sparkles me-1"></i> Siap Pakai</span>
                <div class="zoom-icon-badge" title="Klik untuk perbesar"><i class="fas fa-search-plus"></i></div>
              </div>
              <div class="gear-body">
                <div class="d-flex align-items-center justify-content-between mb-1">
                  <div class="gear-feature-badge m-0">
                    <i class="fas fa-shield-alt"></i> Higienis
                  </div>
                  <div class="gear-rating-badge text-warning small">
                    <i class="fas fa-star"></i> <span class="text-dark">4.9</span>
                  </div>
                </div>
                <h3 class="gear-name" title="<?= $namaProduk ?>"><?= $namaProduk ?></h3>
                <p class="gear-desc"><?= $deskripsiProduk ?></p>
                <div class="gear-price-row">
                  <div>
                    <span class="price-value">Rp<?= number_format($hargaPerHari, 0, ',', '.') ?></span>
                    <span class="price-duration"><?= $isGas ? '/ pcs' : '/ hari' ?></span>
                  </div>
                  <div class="gear-btn-sewa">
                    <span>Sewa</span>
                    <i class="fas fa-arrow-right"></i>
                  </div>
                </div>
              </div>
            </a>
          </div>
          <?php endwhile; ?>
        <?php else: ?>
          <div class="col-12 text-center text-muted">
            <p>Belum ada produk alat yang ditambahkan.</p>
          </div>
        <?php endif; ?>
      </div>

      <div class="text-center mt-5">
        <a href="alat.php" class="btn-main-cta">
          <i class="fas fa-th-large me-1"></i> Lihat Semua Peralatan (Katalog Lengkap)
        </a>
      </div>
    </div>
  </section>

  <!-- 4. Alur Cara Sewa (4 Langkah Ringkas) -->
  <section class="steps-section" id="cara-sewa">
    <div class="container">
      <div class="section-title-wrap">
        <span class="section-badge-tag">Alur Praktis</span>
        <h2 class="section-main-title">Cara Sewa di Semar Outdoor</h2>
        <p class="section-sub-title">Hanya 4 langkah mudah dari pemesanan hingga siap berpetualang.</p>
      </div>

      <div class="row g-4 justify-content-center">
        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">1</div>
            <div class="step-icon-circle">
              <i class="fas fa-search"></i>
            </div>
            <h4 class="step-title">Pilih Alat</h4>
            <p class="step-desc">Pilih perlengkapan camping di katalog sesuai kebutuhan petualangan Anda.</p>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">2</div>
            <div class="step-icon-circle" style="background: rgba(194, 120, 3, 0.08); color: var(--brand-gold);">
              <i class="fas fa-calendar-alt"></i>
            </div>
            <h4 class="step-title">Atur Jadwal</h4>
            <p class="step-desc">Tentukan tanggal sewa, durasi sewa, dan metode (Ambil ke Toko atau COD).</p>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">3</div>
            <div class="step-icon-circle">
              <i class="fas fa-credit-card"></i>
            </div>
            <h4 class="step-title">Konfirmasi & DP</h4>
            <p class="step-desc">Lakukan pembayaran uang muka (DP minimal Rp 10.000) atau pelunasan penuh.</p>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">4</div>
            <div class="step-icon-circle" style="background: rgba(194, 120, 3, 0.08); color: var(--brand-gold);">
              <i class="fas fa-mountain"></i>
            </div>
            <h4 class="step-title">Ambil & Jelajahi</h4>
            <p class="step-desc">Ambil peralatan di toko dan selamat menikmati petualangan alam terbuka!</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 5. Tentang Kami & Nilai Utama -->
  <section class="about-value-section" id="tentang">
    <div class="container">
      <div class="row g-4 align-items-center">
        <!-- Kolom Profil Singkat -->
        <div class="col-lg-6">
          <div class="about-lead-card">
            <span class="section-badge-tag mb-3">Tentang Semar Outdoor</span>
            <h3 class="fw-bold mb-3" style="color: var(--brand-dark); font-family: 'Quicksand', sans-serif;">
              Partner Sewa Perlengkapan Camping Terpercaya
            </h3>
            <p class="text-muted leading-relaxed mb-3">
              <strong>Semar Outdoor</strong> hadir untuk memudahkan setiap petualangan Anda. Dari pendakian gunung hingga camping keluarga di alam terbuka, kami menyediakan peralatan berkualitas tanpa perlu repot membeli.
            </p>
            <p class="text-muted leading-relaxed mb-4">
              Setiap tenda, sleeping bag, matras, dan peralatan masak selalu dirawat serta dibersihkan secara berkala agar dalam kondisi prima dan aman digunakan.
            </p>
            
            <div class="row g-2 text-center">
              <div class="col-4">
                <div class="p-3 bg-light rounded-3 border">
                  <h5 class="fw-bold mb-0 text-success">100%</h5>
                  <small class="text-muted">Siap Pakai</small>
                </div>
              </div>
              <div class="col-4">
                <div class="p-3 bg-light rounded-3 border">
                  <h5 class="fw-bold mb-0 text-warning">Terawat</h5>
                  <small class="text-muted">Kondisi Alat</small>
                </div>
              </div>
              <div class="col-4">
                <div class="p-3 bg-light rounded-3 border">
                  <h5 class="fw-bold mb-0 text-primary">Resmi</h5>
                  <small class="text-muted">Toko Fisik</small>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Kolom 4 Keunggulan -->
        <div class="col-lg-6">
          <div class="d-flex flex-column gap-3">
            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-soap"></i>
              </div>
              <div class="feature-point-text">
                <h6>Higienis & Bersih</h6>
                <p>Peralatan selalu dicuci dan disanitasi setelah setiap pemakaian oleh pelanggan.</p>
              </div>
            </div>

            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-clipboard-check"></i>
              </div>
              <div class="feature-point-text">
                <h6>Kelengkapan Terjamin</h6>
                <p>Frame tenda, pasak, dan kelengkapan aksesoris dicek detail sebelum serah terima.</p>
              </div>
            </div>

            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-wallet"></i>
              </div>
              <div class="feature-point-text">
                <h6>Tarif Harian Transparan</h6>
                <p>Harga sewa terjangkau tanpa biaya tersembunyi dengan opsi DP mulai Rp 10.000.</p>
              </div>
            </div>

            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-headset"></i>
              </div>
              <div class="feature-point-text">
                <h6>Konsultasi Ramah & Fleksibel</h6>
                <p>Siap memberikan rekomendasi alat terbaik serta opsi ambil di toko maupun diantar COD.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 6. Google Maps Reviews & Rating Showcase -->
  <section class="google-reviews-section" id="ulasan">
    <div class="container">
      <div class="section-title-wrap">
        <span class="section-badge-tag"><i class="fab fa-google text-danger me-1"></i> Google Maps Reviews</span>
        <h2 class="section-main-title">Rating & Ulasan Pelanggan di Google Maps</h2>
        <p class="section-sub-title">Testimoni nyata pelanggan dan penggiat alam yang telah mempercayakan kebutuhan camping kepada Semar Outdoor.</p>
      </div>

      <!-- Google Business Summary Banner -->
      <div class="google-summary-card">
        <div class="row align-items-center g-4">
          <div class="col-lg-3 text-center text-lg-start">
            <div class="d-inline-flex align-items-center gap-2 mb-2">
              <i class="fab fa-google fs-3 text-warning"></i>
              <span class="fw-bold fs-5 text-white">Google Maps Rating</span>
            </div>
            <div class="d-flex align-items-baseline justify-content-center justify-content-lg-start gap-2">
              <span class="google-score-big"><?= number_format($googleMapsData['rating'] ?? 4.9, 1) ?></span>
              <span class="text-white-50 fs-5">/ 5.0</span>
            </div>
            <div class="rating-stars fs-5 mb-1">★★★★★</div>
            <small class="text-white-50"><?= $googleMapsData['user_ratings_total'] ?? 87 ?>+ Ulasan Terverifikasi</small>
          </div>

          <div class="col-lg-6 text-center text-lg-start border-lg-start border-white border-opacity-10 ps-lg-4">
            <h5 class="fw-bold mb-2 text-white"><?= htmlspecialchars($googleMapsData['place_name'] ?? 'Semar Outdoor equipment') ?></h5>
            <p class="text-white-50 small mb-2">
              <i class="fas fa-map-marker-alt text-warning me-1"></i> <?= htmlspecialchars($googleMapsData['formatted_address'] ?? 'Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466') ?>
            </p>
            <p class="text-white-75 small mb-0">
              Dipercaya ratusan pendaki, komunitas pecinta alam, dan keluarga untuk persewaan tenda, carrier, cooking set, dan perlengkapan camping lengkap.
            </p>
          </div>

          <div class="col-lg-3 text-center text-lg-end">
            <a href="<?= htmlspecialchars($googleMapsData['google_maps_url'] ?? 'https://www.google.com/maps/place/Semar+Outdoor+equipment/@-7.3432296,108.1236729,17z/data=!3m1!4b1!4m6!3m5!1s0x2e6f55603c48fdab:0x8285bdf531fac8fc!8m2!3d-7.3432296!4d108.1262478!16s%2Fg%2F11v0_y5s3_') ?>" target="_blank" class="btn-google-action shadow-sm">
              <i class="fab fa-google text-danger"></i> Buka di Google Maps
            </a>
          </div>
        </div>
      </div>

      <!-- Swiper Slider Container (Auto-Slide Horizontal) -->
      <div class="google-reviews-slider-wrapper">
        <div class="swiper googleReviewsSwiper">
          <div class="swiper-wrapper">
            <?php if (!empty($googleMapsData['reviews'])): ?>
              <?php foreach ($googleMapsData['reviews'] as $rev): 
                $ratingStarCount = max(1, min(5, (int)($rev['rating'] ?? 5)));
                $avatarColor = !empty($rev['badge_color']) ? $rev['badge_color'] : '#0e4430';
                $initial = !empty($rev['initial']) ? $rev['initial'] : mb_strtoupper(mb_substr($rev['author_name'] ?? 'G', 0, 1));
              ?>
              <div class="swiper-slide">
                <div class="google-review-card">
                  <div>
                    <div class="d-flex align-items-center justify-content-between mb-3">
                      <div class="d-flex align-items-center gap-2">
                        <div class="review-user-avatar" style="background: <?= $avatarColor ?>;">
                          <?= htmlspecialchars($initial) ?>
                        </div>
                        <div>
                          <h6 class="fw-bold mb-0 text-dark" style="font-size: 0.95rem;"><?= htmlspecialchars($rev['author_name'] ?? 'Pengulas Google') ?></h6>
                          <small class="text-muted" style="font-size: 0.73rem;">
                            <i class="fab fa-google text-danger me-1"></i> Pengulas Google Maps
                          </small>
                        </div>
                      </div>
                      <i class="fab fa-google text-muted fs-5"></i>
                    </div>
                    <div class="rating-stars mb-2" style="font-size: 0.9rem;">
                      <?= str_repeat('★', $ratingStarCount) ?>
                    </div>
                    <p class="text-muted small leading-relaxed mb-0">
                      "<?= htmlspecialchars($rev['text'] ?? '') ?>"
                    </p>
                  </div>
                  <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top border-light-subtle small text-muted" style="font-size: 0.75rem;">
                    <span><i class="fas fa-check-circle text-success me-1"></i> Terverifikasi Google</span>
                    <span><?= htmlspecialchars($rev['relative_time_description'] ?? 'Baru saja') ?></span>
                  </div>
                </div>
              </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          
          <!-- Bottom Controls: Pagination Dots + Navigation Arrows -->
          <div class="d-flex align-items-center justify-content-between mt-3">
            <div class="swiper-pagination position-relative" style="bottom: 0; text-align: left; width: auto;"></div>
            <div class="d-flex gap-2">
              <button class="review-slider-nav-btn review-prev-btn" type="button" aria-label="Ulasan Sebelumnya" title="Sebelumnya">
                <i class="fas fa-chevron-left"></i>
              </button>
              <button class="review-slider-nav-btn review-next-btn" type="button" aria-label="Ulasan Selanjutnya" title="Selanjutnya">
                <i class="fas fa-chevron-right"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 7. Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <!-- Kolom Brand & Logo -->
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform persewaan perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <!-- Kolom Menu Navigasi -->
        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="#ulasan"><i class="fas fa-chevron-right small text-warning"></i> Ulasan Google</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <!-- Kolom Kontak -->
        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak & Info Toko</h5>
          <div class="footer-contact-item">
            <i class="fas fa-clock"></i>
            <span>Buka Setiap Hari: 08.00 - 21.00 WIB</span>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <!-- Kolom Lokasi Toko -->
        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko Fisik</h5>
          <div class="d-flex align-items-center justify-content-between p-2 mb-2 rounded bg-white bg-opacity-10 text-white small">
            <div>
              <i class="fab fa-google text-warning me-1"></i> <strong>4.9 ★★★★★</strong>
            </div>
            <a href="https://www.google.com/maps/search/?api=1&query=Semar+Outdoor+equipment+Tasikmalaya" target="_blank" class="text-warning text-decoration-none fw-bold small">
              Buka Maps &rarr;
            </a>
          </div>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('status') === 'success') {
        Swal.fire({
          icon: 'success',
          title: 'Login Berhasil',
          text: 'Selamat datang kembali di Semar Outdoor!',
          confirmButtonColor: '#0e4430'
        });
      }

      // Inisialisasi Slider Ulasan Google Maps Otomatis Slide ke Samping
      if (document.querySelector('.googleReviewsSwiper')) {
        const reviewsSwiper = new Swiper('.googleReviewsSwiper', {
          slidesPerView: 1,
          spaceBetween: 20,
          loop: true,
          grabCursor: true,
          speed: 800,
          autoplay: {
            delay: 3000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
          },
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
            dynamicBullets: true,
          },
          navigation: {
            nextEl: '.review-next-btn',
            prevEl: '.review-prev-btn',
          },
          breakpoints: {
            640: {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            1024: {
              slidesPerView: 3,
              spaceBetween: 24,
            },
            1280: {
              slidesPerView: 3,
              spaceBetween: 28,
            }
          }
        });
      }
    });
  </script>

  <!-- Modal Lightbox Pratinjau Gambar Penuh -->
  <div class="modal fade" id="modalImageLightbox" tabindex="-1" aria-labelledby="lightboxTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header d-flex align-items-center justify-content-between py-2.5 px-3">
          <div class="d-flex align-items-center gap-2">
            <i class="fas fa-search-plus text-warning"></i>
            <h6 class="modal-title mb-0 fw-bold text-white text-truncate" id="lightboxTitle">Nama Perlengkapan</h6>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="lightbox-img-wrapper text-center">
          <img id="lightboxImg" src="" alt="Ukuran Penuh">
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-between py-2 px-3 bg-dark border-top border-secondary border-opacity-25">
          <div class="d-flex align-items-center gap-2">
            <span class="badge bg-warning text-dark fw-bold px-2 py-1" id="lightboxPrice">Rp 0</span>
            <span class="badge bg-success px-2 py-1" id="lightboxStock"><i class="fas fa-check-circle me-1"></i> Tersedia</span>
          </div>
          <button type="button" class="btn btn-sm btn-outline-light rounded-pill px-3" data-bs-dismiss="modal">
            <i class="fas fa-times me-1"></i> Tutup
          </button>
        </div>
      </div>
    </div>
  </div>

  <script>
    function showLightboxModal(imgSrc, title, priceText, stockQty) {
      document.getElementById('lightboxImg').src = imgSrc;
      document.getElementById('lightboxTitle').innerText = title;
      document.getElementById('lightboxPrice').innerText = priceText;
      
      const stockElem = document.getElementById('lightboxStock');
      if (parseInt(stockQty) > 0) {
        stockElem.className = 'badge bg-success px-2 py-1';
        stockElem.innerHTML = '<i class="fas fa-check-circle me-1"></i> Tersedia ' + stockQty + ' Unit';
      } else {
        stockElem.className = 'badge bg-danger px-2 py-1';
        stockElem.innerHTML = '<i class="fas fa-times-circle me-1"></i> Stok Habis';
      }

      const modalEl = document.getElementById('modalImageLightbox');
      const bsModal = bootstrap.Modal.getOrCreateInstance(modalEl);
      bsModal.show();
    }
  </script>
</body>
</html>
