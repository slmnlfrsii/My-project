<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'koneksi.php';
include 'google_reviews.php';
date_default_timezone_set('Asia/Jakarta');

// Ambil rating & ulasan dari Google Maps API / Cache
$googleMapsData = getGoogleMapsReviews();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Semar Outdoor - Rental Perlengkapan Camping & Outdoor Tasikmalaya</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
      scroll-behavior: smooth;
    }

    /* ========================================================= */
    /* 🌟 HERO SECTION (Diberi space aman dari Navbar Fixed) */
    /* ========================================================= */
    .hero-section {
      position: relative;
      background: url("assets/images/alt2.jpg") center center / cover no-repeat;
      background-attachment: fixed;
      min-height: 80vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #ffffff;
      /* Distance aman dari navbar fixed */
      padding: 140px 16px 60px;
    }

    .hero-section::before {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(14, 35, 33, 0.45) 0%, rgba(10, 28, 24, 0.65) 100%);
      z-index: 1;
    }

    .hero-box {
      position: relative;
      z-index: 2;
      max-width: 860px;
      text-align: center;
    }

    .hero-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(14, 40, 36, 0.65);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #fde047;
      font-size: 0.8rem;
      font-weight: 700;
      padding: 6px 16px;
      border-radius: 50px;
      margin-bottom: 16px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
    }

    .hero-heading {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(1.8rem, 4.5vw, 3.4rem);
      font-weight: 800;
      line-height: 1.2;
      letter-spacing: -0.5px;
      margin-bottom: 16px;
      text-shadow: 0 4px 16px rgba(0, 0, 0, 0.65);
    }

    .hero-heading span {
      background: linear-gradient(135deg, #fef08a 0%, #f59e0b 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      filter: drop-shadow(0 2px 8px rgba(0,0,0,0.5));
    }

    .hero-desc {
      font-size: clamp(0.9rem, 1.8vw, 1.15rem);
      color: #ffffff;
      line-height: 1.55;
      margin-bottom: 24px;
      max-width: 620px;
      margin-left: auto;
      margin-right: auto;
      text-shadow: 0 2px 10px rgba(0, 0, 0, 0.7);
    }

    .hero-actions {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      justify-content: center;
    }

    .btn-main-cta {
      background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
      color: #ffffff;
      font-weight: 700;
      font-size: 0.92rem;
      padding: 12px 26px;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      box-shadow: 0 6px 20px rgba(194, 120, 3, 0.45);
      display: inline-flex;
      align-items: center;
      gap: 8px;
      border: none;
    }

    .btn-main-cta:hover {
      background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
      color: #ffffff;
      transform: translateY(-2px);
    }

    .btn-sec-cta {
      background: rgba(255, 255, 255, 0.12);
      backdrop-filter: blur(6px);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #ffffff;
      font-weight: 700;
      font-size: 0.92rem;
      padding: 12px 22px;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }

    .hero-metrics {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 14px;
      margin-top: 28px;
      padding-top: 16px;
      border-top: 1px solid rgba(255, 255, 255, 0.15);
    }

    .metric-item {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 0.82rem;
      color: #e2e8f0;
      font-weight: 500;
    }

    .metric-item i {
      color: #fde047;
      font-size: 0.92rem;
    }

    /* ========================================================= */
    /* 🌟 SECTION TITLES */
    /* ========================================================= */
    .section-title-wrap {
      text-align: center;
      margin-bottom: 28px;
    }

    .section-badge-tag {
      display: inline-block;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--brand-gold);
      background: rgba(194, 120, 3, 0.1);
      padding: 4px 12px;
      border-radius: 50px;
      margin-bottom: 8px;
    }

    .section-main-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(1.35rem, 2.8vw, 1.9rem);
      font-weight: 800;
      color: var(--brand-dark);
      margin-bottom: 6px;
    }

    /* ========================================================= */
    /* 🌟 CATEGORIES GRID */
    /* ========================================================= */
    .categories-area {
      padding: 40px 0 25px;
      background: #ffffff;
    }

    .cat-item-card {
      background: #f8fafc;
      border-radius: 12px;
      padding: 16px 12px;
      text-align: center;
      text-decoration: none;
      color: var(--brand-dark);
      border: 1px solid rgba(0,0,0,0.05);
      transition: all 0.28s ease;
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 100%;
    }

    .cat-item-card:hover {
      background: #ffffff;
      transform: translateY(-3px);
      box-shadow: 0 8px 18px rgba(0,0,0,0.06);
      border-color: var(--brand-gold);
      color: var(--brand-gold);
    }

    .cat-icon {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      background: rgba(14, 68, 48, 0.08);
      color: var(--brand-green);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      margin-bottom: 8px;
      transition: all 0.28s ease;
    }

    .cat-title {
      font-weight: 700;
      font-size: 0.88rem;
      margin-bottom: 2px;
    }

    .cat-subtitle {
      font-size: 0.75rem;
      color: var(--text-muted);
    }

    /* ========================================================= */
    /* 🌟 ALUR SEWA */
    /* ========================================================= */
    .steps-section {
      padding: 40px 0;
      background: #f8fafc;
    }

    .step-item-box {
      text-align: center;
      padding: 14px 10px;
      position: relative;
    }

    .step-badge {
      width: 26px;
      height: 26px;
      border-radius: 50%;
      background: var(--brand-gold);
      color: #ffffff;
      font-weight: 800;
      font-size: 0.78rem;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 8px;
    }

    .step-icon-circle {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: rgba(14, 68, 48, 0.08);
      color: var(--brand-green);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      margin: 0 auto 8px;
    }

    .step-title {
      font-weight: 700;
      font-size: 0.9rem;
      color: var(--brand-dark);
      margin-bottom: 4px;
    }

    .step-desc {
      font-size: 0.78rem;
      color: var(--text-muted);
      margin: 0;
      line-height: 1.4;
    }

    /* ========================================================= */
    /* 🌟 TENTANG KAMI */
    /* ========================================================= */
    .about-value-section {
      padding: 40px 0 50px;
      background: #ffffff;
    }

    .about-lead-card {
      background: #f8fafc;
      border-radius: 14px;
      padding: 22px 18px;
      border: 1px solid rgba(0,0,0,0.06);
      height: 100%;
    }

    .feature-point {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 12px;
      background: #f8fafc;
      border-radius: 12px;
      border: 1px solid rgba(0,0,0,0.05);
    }

    .feature-point-icon {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      background: rgba(194, 120, 3, 0.1);
      color: var(--brand-gold);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1rem;
      flex-shrink: 0;
    }

    .feature-point-text h6 {
      font-size: 0.88rem;
      font-weight: 700;
      color: var(--brand-dark);
      margin-bottom: 2px;
    }

    .feature-point-text p {
      font-size: 0.78rem;
      color: var(--text-muted);
      margin: 0;
      line-height: 1.35;
    }

    .rating-stars {
      color: #facc15;
      letter-spacing: 1px;
    }

    /* ========================================================= */
    /* 🌟 GOOGLE REVIEWS SECTION (Rating Card + Inner Slider) */
    /* ========================================================= */
    .google-reviews-section {
      padding: 40px 0;
      background: #f8fafc;
    }

    .google-summary-card {
      background: linear-gradient(135deg, #0e4430 0%, #162d2f 100%);
      color: #ffffff;
      border-radius: 20px;
      padding: 24px;
      box-shadow: 0 10px 30px rgba(14, 68, 48, 0.15);
    }

    .google-score-big {
      font-size: 3rem;
      font-weight: 800;
      line-height: 1;
      color: #ffffff;
      font-family: 'Quicksand', sans-serif;
    }

    /* Card ulasan khusus di dalam card rating dark */
    .google-review-card-inner {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 14px;
      padding: 18px;
      height: 100%;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      color: #ffffff;
    }

    .review-user-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 0.9rem;
      color: #ffffff;
      flex-shrink: 0;
    }

    .swiper.googleReviewsSwiper {
      padding: 5px 2px 35px;
    }

    .googleReviewsSwiper .swiper-slide {
      height: auto;
      display: flex;
    }

    .googleReviewsSwiper .swiper-slide .google-review-card-inner {
      width: 100%;
    }

    .review-slider-nav-btn {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: #ffffff;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .review-slider-nav-btn:hover {
      background: #ffffff;
      color: #0e4430;
    }

    /* Custom pagination dots untuk theme gelap */
    .google-summary-card .swiper-pagination-bullet {
      background: rgba(255, 255, 255, 0.4);
    }
    .google-summary-card .swiper-pagination-bullet-active {
      background: #facc15;
    }

    /* ========================================================= */
    /* 🌟 FOOTER */
    /* ========================================================= */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 40px;
    }

    .footer-brand-logo {
      height: 34px;
      width: auto;
      object-fit: contain;
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.05rem;
      font-weight: 800;
      color: #ffffff;
    }

    .footer-title {
      color: #ffffff;
      font-size: 0.9rem;
      font-weight: 700;
      margin-bottom: 12px;
      position: relative;
      padding-bottom: 6px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 24px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 8px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.8rem;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      margin-bottom: 10px;
      font-size: 0.8rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 3px;
    }

    .footer-map-container {
      border-radius: 10px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 130px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 14px 0;
      margin-top: 30px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.75rem;
      color: #64748b;
    }

    /* ========================================================= */
    /* 📱 OPTIMISASI SPESIFIK ANDROID / MOBILE */
    /* ========================================================= */
    @media (max-width: 576px) {
      .hero-section {
        /* Padding atas disesuaikan untuk layar HP agar gambar background & teks bebas tertutup navbar */
        padding: 115px 14px 35px;
        min-height: auto;
      }
      .hero-heading {
        font-size: 1.75rem;
      }
      .hero-desc {
        font-size: 0.85rem;
        margin-bottom: 18px;
      }
      .btn-main-cta, .btn-sec-cta {
        padding: 9px 18px;
        font-size: 0.82rem;
        flex: 1 1 auto;
        justify-content: center;
        max-width: 48%;
      }
      .hero-metrics {
        flex-direction: column;
        align-items: center;
        gap: 8px;
      }
      .categories-area, .steps-section, .about-value-section, .google-reviews-section {
        padding: 30px 0;
      }
      .cat-item-card {
        padding: 12px 6px;
      }
      .cat-icon {
        width: 36px;
        height: 36px;
        font-size: 0.95rem;
        margin-bottom: 6px;
      }
      .cat-title {
        font-size: 0.78rem;
      }
      .cat-subtitle {
        font-size: 0.68rem;
      }
      .google-summary-card {
        padding: 18px;
      }
    }
  </style>
</head>

<body>
  <!-- Header Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- 1. Hero Section -->
  <section class="hero-section" id="beranda">
    <div class="hero-box">
      <h1 class="hero-heading">
        Jelajahi Alam Bebas, <br>
        <span>Kami Siapkan Alatnya!</span>
      </h1>
      
      <p class="hero-desc">
        Nikmati booking online sewa perlengkapan outdoor yang cepat, higienis, dan praktis.
      </p>
      
      <div class="hero-actions">
        <a href="#tentang" class="btn-main-cta">
          <i class="fas fa-users"></i> Tentang Kami
        </a>
        <a href="#cara-sewa" class="btn-sec-cta">
          <i class="fas fa-play-circle"></i> Cara Sewa
        </a>
      </div>

      <!-- Trust Metrics -->
      <div class="hero-metrics">
        <div class="metric-item">
          <i class="fas fa-truck-pickup"></i> Opsi Ambil di Toko / Layanan COD
        </div>
        <div class="metric-item">
          <i class="fas fa-campground"></i> Rental Alat Camping & Outdoor Tasikmalaya
        </div>
        <div class="metric-item">
          <i class="fas fa-star text-warning"></i> Rating 4.9 Google Maps
        </div>
      </div>
    </div>
  </section>

  <!-- 2. Kategori Cepat -->
  <section class="categories-area">
    <div class="container">
      <div class="section-title-wrap">
        <span class="section-badge-tag">Kategori Peralatan</span>
        <h2 class="section-main-title">Pilih Berdasarkan Kebutuhan</h2>
      </div>
      <div class="row g-2 justify-content-center">
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon">
              <i class="fas fa-campground"></i>
            </div>
            <span class="cat-title">Tenda & Shelter</span>
            <span class="cat-subtitle">Kapasitas 2 - 6 Orang</span>
          </a>
        </div>
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon" style="background: rgba(194, 120, 3, 0.1); color: var(--brand-gold);">
              <i class="fas fa-bed"></i>
            </div>
            <span class="cat-title">Sleeping System</span>
            <span class="cat-subtitle">SB, Matras & Kasur</span>
          </a>
        </div>
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon">
              <i class="fas fa-utensils"></i>
            </div>
            <span class="cat-title">Cooking Set</span>
            <span class="cat-subtitle">Kompor, Nesting & Gas</span>
          </a>
        </div>
        <div class="col-6 col-md-3">
          <a href="alat.php" class="cat-item-card">
            <div class="cat-icon" style="background: rgba(194, 120, 3, 0.1); color: var(--brand-gold);">
              <i class="fas fa-hiking"></i>
            </div>
            <span class="cat-title">Carrier & Aksesoris</span>
            <span class="cat-subtitle">Tas Carrier & Lampu</span>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- 3. Tentang Kami -->
  <section class="about-value-section" id="tentang">
    <div class="container">
      <div class="row g-3 align-items-center">
        <div class="col-lg-6">
          <div class="about-lead-card">
            <span class="section-badge-tag mb-2">Tentang Semar Outdoor</span>
            <h3 class="fw-bold mb-2 fs-6" style="color: var(--brand-dark); font-family: 'Quicksand', sans-serif;">
              Partner Sewa Perlengkapan Camping Terpercaya
            </h3>
            <p class="text-muted leading-relaxed small mb-3">
              <strong>Semar Outdoor</strong> hadir untuk memudahkan setiap petualangan Anda. Dari pendakian gunung hingga camping keluarga di alam terbuka, kami menyediakan peralatan berkualitas tanpa perlu repot membeli.
            </p>

            <div class="row g-2 text-center">
              <div class="col-4">
                <div class="p-2 bg-light rounded-3 border">
                  <h6 class="fw-bold mb-0 text-success">100%</h6>
                  <small class="text-muted" style="font-size: 0.68rem;">Siap Pakai</small>
                </div>
              </div>
              <div class="col-4">
                <div class="p-2 bg-light rounded-3 border">
                  <h6 class="fw-bold mb-0 text-warning">Terawat</h6>
                  <small class="text-muted" style="font-size: 0.68rem;">Kondisi Alat</small>
                </div>
              </div>
              <div class="col-4">
                <div class="p-2 bg-light rounded-3 border">
                  <h6 class="fw-bold mb-0 text-primary">Resmi</h6>
                  <small class="text-muted" style="font-size: 0.68rem;">Toko Fisik</small>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="d-flex flex-column gap-2">
            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-soap"></i>
              </div>
              <div class="feature-point-text">
                <h6>Higienis & Bersih</h6>
                <p>Peralatan selalu dicuci dan disanitasi setelah pemakaian.</p>
              </div>
            </div>

            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-clipboard-check"></i>
              </div>
              <div class="feature-point-text">
                <h6>Kelengkapan Terjamin</h6>
                <p>Frame tenda dan aksesoris dicek detail sebelum serah terima.</p>
              </div>
            </div>

            <div class="feature-point">
              <div class="feature-point-icon">
                <i class="fas fa-wallet"></i>
              </div>
              <div class="feature-point-text">
                <h6>Tarif Harian Transparan</h6>
                <p>Harga terjangkau tanpa biaya tersembunyi dengan DP hemat.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 4. Alur Cara Sewa -->
  <section class="steps-section" id="cara-sewa">
    <div class="container">
      <div class="section-title-wrap">
        <span class="section-badge-tag">Alur Praktis</span>
        <h2 class="section-main-title">Cara Sewa di Semar Outdoor</h2>
      </div>

      <div class="row g-2 justify-content-center">
        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">1</div>
            <div class="step-icon-circle">
              <i class="fas fa-search"></i>
            </div>
            <h4 class="step-title">Pilih Alat</h4>
            <p class="step-desc">Pilih peralatan camping sesuai kebutuhan Anda.</p>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">2</div>
            <div class="step-icon-circle" style="background: rgba(194, 120, 3, 0.08); color: var(--brand-gold);">
              <i class="fas fa-calendar-alt"></i>
            </div>
            <h4 class="step-title">Atur Jadwal</h4>
            <p class="step-desc">Tentukan tanggal & opsi Pengambilan/COD.</p>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">3</div>
            <div class="step-icon-circle">
              <i class="fas fa-credit-card"></i>
            </div>
            <h4 class="step-title">Konfirmasi DP</h4>
            <p class="step-desc">Bayar DP minimal Rp 10.000 atau pelunasan.</p>
          </div>
        </div>

        <div class="col-6 col-lg-3">
          <div class="step-item-box">
            <div class="step-badge">4</div>
            <div class="step-icon-circle" style="background: rgba(194, 120, 3, 0.08); color: var(--brand-gold);">
              <i class="fas fa-mountain"></i>
            </div>
            <h4 class="step-title">Ambil & Siap!</h4>
            <p class="step-desc">Ambil peralatan dan nikmati petualangan!</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 5. Google Maps Reviews (Ulasan Menyatu di Dalam Card Rating) -->
  <section class="google-reviews-section" id="ulasan">
    <div class="container">
      <div class="section-title-wrap">
        <span class="section-badge-tag"><i class="fab fa-google text-danger me-1"></i> Google Maps</span>
        <h2 class="section-main-title">Rating & Ulasan Pelanggan</h2>
      </div>

      <div class="google-summary-card">
        <div class="row align-items-center g-4">
          <!-- Sisi Kiri: Informasi Skor Rating -->
          <div class="col-lg-4 text-center text-lg-start border-lg-end border-white border-opacity-10 pe-lg-4">
            <div class="d-inline-flex align-items-center gap-2 mb-2">
              <i class="fab fa-google fs-4 text-warning"></i>
              <span class="fw-bold text-white small">Google Maps Rating</span>
            </div>
            <div class="d-flex align-items-baseline justify-content-center justify-content-lg-start gap-2 mb-1">
              <span class="google-score-big"><?= number_format($googleMapsData['rating'] ?? 4.9, 1) ?></span>
              <span class="text-white-50 small">/ 5.0</span>
            </div>
            <div class="rating-stars small mb-2">★★★★★</div>
            <div class="mb-3">
              <h6 class="fw-bold mb-1 text-white small"><?= htmlspecialchars($googleMapsData['place_name'] ?? 'Semar Outdoor equipment') ?></h6>
              <p class="text-white-50 small mb-0" style="font-size: 0.75rem;">
                <i class="fas fa-map-marker-alt text-warning me-1"></i> <?= htmlspecialchars($googleMapsData['formatted_address'] ?? 'Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kab. Tasikmalaya') ?>
              </p>
            </div>
            <small class="text-white-50" style="font-size: 0.72rem;">
              <i class="fas fa-shield-alt text-success me-1"></i> <?= $googleMapsData['user_ratings_total'] ?? 87 ?>+ Ulasan Terverifikasi
            </small>
          </div>

          <!-- Sisi Kanan: Slider Ulasan (Slide kesamping di dalam card rating) -->
          <div class="col-lg-8">
            <div class="google-reviews-slider-wrapper">
              <div class="swiper googleReviewsSwiper">
                <div class="swiper-wrapper">
                  <?php if (!empty($googleMapsData['reviews'])): ?>
                    <?php foreach ($googleMapsData['reviews'] as $rev): 
                      $ratingStarCount = max(1, min(5, (int)($rev['rating'] ?? 5)));
                      $avatarColor = !empty($rev['badge_color']) ? $rev['badge_color'] : '#0e4430';
                      $initial = !empty($rev['initial']) ? $rev['initial'] : mb_strtoupper(mb_substr($rev['author_name'] ?? 'G', 0, 1));
                    ?>
                    <div class="swiper-slide">
                      <div class="google-review-card-inner">
                        <div>
                          <div class="d-flex align-items-center justify-content-between mb-2">
                            <div class="d-flex align-items-center gap-2">
                              <div class="review-user-avatar" style="background: <?= $avatarColor ?>;">
                                <?= htmlspecialchars($initial) ?>
                              </div>
                              <div>
                                <h6 class="fw-bold mb-0 text-white small" style="font-size: 0.82rem;"><?= htmlspecialchars($rev['author_name'] ?? 'Pengulas Google') ?></h6>
                                <small class="text-white-50" style="font-size: 0.68rem;">
                                  <i class="fab fa-google text-warning me-1"></i> Pengulas Google
                                </small>
                              </div>
                            </div>
                          </div>
                          <div class="rating-stars mb-2 small">
                            <?= str_repeat('★', $ratingStarCount) ?>
                          </div>
                          <p class="text-white-50 small leading-relaxed mb-0" style="font-size: 0.78rem;">
                            "<?= htmlspecialchars($rev['text'] ?? '') ?>"
                          </p>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top border-white border-opacity-10 text-white-50" style="font-size: 0.68rem;">
                          <span><i class="fas fa-check-circle text-success me-1"></i> Terverifikasi</span>
                          <span><?= htmlspecialchars($rev['relative_time_description'] ?? 'Baru saja') ?></span>
                        </div>
                      </div>
                    </div>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </div>
                
                <div class="d-flex align-items-center justify-content-between mt-2">
                  <div class="swiper-pagination position-relative" style="bottom: 0; text-align: left; width: auto;"></div>
                  <div class="d-flex gap-2">
                    <button class="review-slider-nav-btn review-prev-btn" type="button" aria-label="Ulasan Sebelumnya">
                      <i class="fas fa-chevron-left small"></i>
                    </button>
                    <button class="review-slider-nav-btn review-next-btn" type="button" aria-label="Ulasan Selanjutnya">
                      <i class="fas fa-chevron-right small"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- 6. Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-3">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-2">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important; font-size: 0.78rem;">
            Platform persewaan perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan kondisi prima.
          </p>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="#ulasan"><i class="fas fa-chevron-right small text-warning"></i> Ulasan Google</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak Toko</h5>
          <div class="footer-contact-item">
            <i class="fas fa-clock"></i>
            <span>Setiap Hari: 08.00 - 21.00 WIB</span>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kab. Tasikmalaya</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('status') === 'success') {
        Swal.fire({
          icon: 'success',
          title: 'Login Berhasil',
          text: 'Selamat datang kembali di Semar Outdoor!',
          confirmButtonColor: '#0e4430'
        });
      }

      if (document.querySelector('.googleReviewsSwiper')) {
        const reviewsSwiper = new Swiper('.googleReviewsSwiper', {
          slidesPerView: 1,
          spaceBetween: 14,
          loop: true,
          grabCursor: true,
          speed: 800,
          autoplay: {
            delay: 3500,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
          },
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
            dynamicBullets: true,
          },
          navigation: {
            nextEl: '.review-next-btn',
            prevEl: '.review-prev-btn',
          },
          breakpoints: {
            768: { slidesPerView: 2, spaceBetween: 16 }
          }
        });
      }
    });
  </script>
</body>
</html>