<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id_sewa'])) {
    header("Location: tagihan.php");
    exit();
}

$id_users = (int)$_SESSION['id_users'];
$id_sewa_terpilih = $_POST['id_sewa'];

if (empty($id_sewa_terpilih) || !is_array($id_sewa_terpilih)) {
    header("Location: tagihan.php");
    exit();
}

$id_sewa_terpilih_int = array_values(array_filter(array_map('intval', $id_sewa_terpilih)));
if (empty($id_sewa_terpilih_int)) {
    header("Location: tagihan.php");
    exit();
}

/* =========================================================================
   [FIFO LOGIC] VALIDASI STRICT FIFO DI SISI SERVER (BACKEND)
   - Memastikan tidak ada user yang mem-bypass urutan pembayaran antrean tagihan
   - Jika user mencoba membayar tagihan #2 tanpa menyertakan tagihan #1 yang belum lunas,
     sistem akan menolak dan mengarahkan kembali ke halaman tagihan.
   ========================================================================= */
// 1. Ambil seluruh tagihan aktif user yang belum lunas & tidak sedang menunggu konfirmasi (diurutkan tanggal_buat ASC, id ASC)
$qAllTagihan = mysqli_query($conn, "
    SELECT s.id, s.no_tagihan, s.tanggal_buat, s.status AS status_sewa,
    (
        SELECT status FROM pembayaran 
        WHERE (id_sewa = s.id OR FIND_IN_SET(s.id, id_sewa) OR (s.no_tagihan IS NOT NULL AND s.no_tagihan != '' AND EXISTS (
            SELECT 1 FROM sewa s2 WHERE s2.no_tagihan = s.no_tagihan AND (pembayaran.id_sewa = s2.id OR FIND_IN_SET(s2.id, pembayaran.id_sewa))
        )))
        ORDER BY tanggal_bayar DESC, id DESC LIMIT 1
    ) AS status_akhir
    FROM sewa s
    WHERE s.id_users = $id_users
    AND s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai')
    ORDER BY COALESCE(s.tanggal_buat, '1970-01-01 00:00:00') ASC, s.id ASC
");

$antrean_wajib = [];
if ($qAllTagihan && mysqli_num_rows($qAllTagihan) > 0) {
    while ($tRow = mysqli_fetch_assoc($qAllTagihan)) {
        $st = $tRow['status_akhir'] ?? '';
        $stSewa = strtolower(trim($tRow['status_sewa'] ?? ''));
        if (in_array($st, ['Lunas', 'Menunggu konfirmasi']) || in_array($stSewa, ['dibatalkan', 'selesai'])) {
            continue;
        }
        $antrean_wajib[] = (int)$tRow['id'];
    }
}

// 2. [FIFO] Cek apakah item yang dipilih melompati tagihan yang lebih awal di antrean FIFO
$posisi_tertinggi = -1;
foreach ($id_sewa_terpilih_int as $selected_id) {
    $idx = array_search($selected_id, $antrean_wajib);
    if ($idx !== false) {
        if ($idx > $posisi_tertinggi) {
            $posisi_tertinggi = $idx;
        }
    }
}

// 3. [FIFO] Jika ada antrean sebelum posisi tertinggi yang tidak ikut dibayar -> Blokir
if ($posisi_tertinggi >= 0) {
    for ($i = 0; $i <= $posisi_tertinggi; $i++) {
        if (!in_array($antrean_wajib[$i], $id_sewa_terpilih_int)) {
            echo "<!DOCTYPE html>
            <html lang='id'>
            <head>
                <meta charset='UTF-8'>
                <title>Peringatan Antrean - Semar Outdoor</title>
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            </head>
            <body style='font-family: sans-serif; background-color: #f4f6f9;'>
            <script>
                Swal.fire({
                    icon: 'warning',
                    title: 'Urutan Pembayaran Tidak Sesuai!',
                    text: 'Pembayaran wajib mengikuti urutan tagihan terlama (FIFO). Harap sertakan tagihan sebelumnya.',
                    confirmButtonColor: '#0e4430',
                    confirmButtonText: 'Kembali ke Tagihan'
                }).then(() => {
                    window.location = 'tagihan.php';
                });
            </script>
            </body>
            </html>";
            exit();
        }
    }
}

$total_tagihan = 0;
$detail_tagihan = [];
$selected_invoices = [];
$total_subtotal_semua = 0;

$id_list = implode(",", $id_sewa_terpilih_int);

// Query JOIN ke tabel alat untuk mengambil harga satuan asli
$query = "SELECT s.*, COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat 
          FROM sewa s 
          LEFT JOIN alat a ON s.id_alat = a.id 
          WHERE s.id IN ($id_list)
          ORDER BY s.tanggal_buat ASC, s.id ASC";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {

    // FORMAT INVOICE
    if (empty($row['no_tagihan'])) {
        $tgl_inv = !empty($row['tanggal_sewa']) ? date('Ymd', strtotime($row['tanggal_sewa'])) : date('Ymd');
        $row['no_tagihan'] = "INV-" . $tgl_inv . "-" . sprintf("%04d", $row['id']);
    }

    // HARGA SATUAN & KALKULASI GAS / CONSUMABLE
    $harga_satuan = (float)$row['harga_satuan_alat'];
    $nama_lc = strtolower($row['nama_produk']);
    $is_consumable = (strpos($nama_lc, 'gas') !== false);

    $subtotal_produk = $is_consumable 
        ? ($harga_satuan * $row['qty']) 
        : ($harga_satuan * $row['qty'] * $row['durasi']);

    $subtotal = $subtotal_produk + $row['biaya_pengambilan'];

    // DENDA KETERLAMBATAN (Gas Bebas Denda)
    $denda = 0;
    $hari_terlambat = 0;
    if (!$is_consumable) {
        $tanggal_kembali = date('Y-m-d', strtotime($row['tanggal_sewa'] . ' + ' . $row['durasi'] . ' days'));
        $hari_ini = date('Y-m-d');

        if ($hari_ini > $tanggal_kembali) {
            $selisih = (strtotime($hari_ini) - strtotime($tanggal_kembali)) / 86400;
            if ($selisih > 0) {
                $hari_terlambat = floor($selisih);
                $denda = $hari_terlambat * 10000;
            }
        }
    }

    $total_bayar = $subtotal + $denda;

    $row['harga_satuan'] = $harga_satuan;
    $row['is_consumable'] = $is_consumable;
    $row['subtotal_produk'] = $subtotal_produk;
    $row['subtotal'] = $subtotal;
    $row['denda'] = $denda;
    $row['hari_terlambat'] = $hari_terlambat;
    $row['total_bayar'] = $total_bayar;
    $row['sisa_tagihan'] = $total_bayar;

    $total_subtotal_semua += $total_bayar;
    $selected_invoices[$row['no_tagihan']][] = (int)$row['id'];
    $detail_tagihan[] = $row;
}

// Hitung total yang sudah dibayar (DP) untuk invoice-invoice yang dipilih
$total_sudah_dibayar_semua = 0;
foreach ($selected_invoices as $invNum => $iIds) {
    $idsCsv = implode(',', $iIds);
    $qBayar = mysqli_query($conn, "
        SELECT SUM(jumlah_bayar) AS total 
        FROM pembayaran
        WHERE id_users = $id_users
        AND status IN ('Lunas','Belum lunas','Menunggu konfirmasi')
        AND (
            FIND_IN_SET('$invNum', id_sewa)
            OR id_sewa IN ($idsCsv)
            OR EXISTS (
                SELECT 1 FROM sewa s4 
                WHERE s4.no_tagihan = '$invNum' 
                AND (pembayaran.id_sewa = s4.id OR FIND_IN_SET(s4.id, pembayaran.id_sewa))
            )
        )
    ");
    $rB = mysqli_fetch_assoc($qBayar);
    $total_sudah_dibayar_semua += (float)($rB['total'] ?? 0);
}

$total_tagihan = max(0, $total_subtotal_semua - $total_sudah_dibayar_semua);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pembayaran - Semar Outdoor</title>
    
    <!-- CSS & Fonts -->
    <link rel="stylesheet" href="assets/css/navbar.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <style>
        :root {
            --brand-dark: #12282a;
            --brand-teal: #162d2f;
            --brand-green: #0e4430;
            --brand-gold: #c27803;
            --brand-gold-glow: #ffc107;
            --bg-body: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            overflow-x: hidden;
        }

        .page-header {
            background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
            color: #ffffff;
            padding: 120px 20px 45px;
            text-align: center;
        }

        .page-title {
            font-family: 'Quicksand', sans-serif;
            font-size: clamp(2rem, 4vw, 2.7rem);
            font-weight: 800;
            margin-bottom: 8px;
        }

        .page-subtitle {
            color: #cbd5e1;
            font-size: 1.02rem;
            max-width: 600px;
            margin: 0 auto;
        }

        .pay-content-section {
            padding: 40px 0 80px;
        }

        .payment-box-card {
            background: #ffffff;
            border-radius: 20px;
            border: 1px solid rgba(0,0,0,0.06);
            box-shadow: 0 6px 24px rgba(0,0,0,0.04);
            padding: 28px;
        }

        /* Payment Channel Cards */
        .method-options-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
            gap: 12px;
            margin-bottom: 18px;
        }

        .method-card {
            cursor: pointer;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            padding: 14px 10px;
            text-align: center;
            transition: all 0.25s ease;
            background: #f8fafc;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .method-card:hover {
            border-color: var(--brand-gold);
            background: #ffffff;
            transform: translateY(-2px);
        }

        .method-card.active {
            border-color: var(--brand-gold);
            background-color: #fefce8;
            box-shadow: 0 4px 12px rgba(194, 120, 3, 0.2);
        }

        .method-card img {
            height: 34px;
            max-width: 80px;
            object-fit: contain;
            margin-bottom: 6px;
            user-select: none;
        }

        .method-card .method-name {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--brand-dark);
        }

        .rekening-box-alert {
            background: #f0fdf4;
            border: 1.5px solid #bbf7d0;
            border-left: 5px solid #16a34a;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: none;
            color: #166534;
        }

        .rekening-box-alert strong {
            font-size: 1.05rem;
            display: block;
            margin-top: 4px;
        }

        /* Payment Type Option Cards */
        .type-option-card {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 14px 16px;
            cursor: pointer;
            transition: all 0.2s ease;
            background: #ffffff;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 12px;
        }

        .type-option-card:hover {
            border-color: #0e4430;
            background: #f8fafc;
        }

        .type-option-card.active {
            border-color: #0e4430;
            background: #f0fdf4;
            box-shadow: 0 4px 14px rgba(14, 68, 48, 0.08);
        }

        .type-option-card input[type="radio"] {
            margin-top: 3px;
            accent-color: #0e4430;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .btn-submit-pay {
            background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
            color: #ffffff;
            font-weight: 700;
            font-size: 1.05rem;
            padding: 14px;
            border-radius: 14px;
            border: none;
            width: 100%;
            transition: all 0.25s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 6px 20px rgba(194, 120, 3, 0.35);
        }

        .btn-submit-pay:hover {
            background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(194, 120, 3, 0.5);
            color: #ffffff;
        }

        /* Footer */
        footer {
            background: #0b1d1f;
            color: #e2e8f0;
            padding-top: 65px;
        }

        .footer-brand-logo {
            height: 42px;
            width: auto;
            max-height: 42px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }

        .footer-brand-name {
            font-family: 'Quicksand', sans-serif;
            font-size: 1.25rem;
            font-weight: 800;
            color: #ffffff;
            letter-spacing: 0.4px;
        }

        .footer-title {
            color: #ffffff;
            font-size: 1.05rem;
            font-weight: 700;
            margin-bottom: 18px;
            position: relative;
            padding-bottom: 8px;
        }

        .footer-title::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 32px;
            height: 2px;
            background: #f59e0b;
            border-radius: 2px;
        }

        .footer-links-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links-list li {
            margin-bottom: 10px;
        }

        .footer-links-list a {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .footer-links-list a:hover {
            color: #fde047;
        }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 14px;
            font-size: 0.9rem;
            color: #cbd5e1;
        }

        .footer-contact-item i {
            color: #fde047;
            margin-top: 4px;
        }

        .footer-contact-item a {
            color: #cbd5e1;
            text-decoration: none;
        }

        .footer-contact-item a:hover {
            color: #fde047;
        }

        .footer-map-container {
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-map-container iframe {
            display: block;
            width: 100%;
            height: 170px;
            border: 0;
        }

        .footer-copy-bar {
            background: #061112;
            padding: 20px 0;
            margin-top: 50px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            font-size: 0.85rem;
            color: #64748b;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .page-header {
                padding: 85px 16px 20px !important;
            }
            .page-title {
                font-size: 1.35rem !important;
            }
            .page-subtitle {
                font-size: 0.82rem !important;
            }
            .payment-section {
                padding: 16px 0 40px !important;
            }
            .payment-box-card {
                padding: 14px 16px !important;
                border-radius: 12px !important;
            }
            .item-order-row {
                padding: 8px 10px !important;
                gap: 10px !important;
            }
            .img-order-thumb {
                width: 45px !important;
                height: 45px !important;
                border-radius: 6px !important;
            }
            .item-order-title {
                font-size: 0.88rem !important;
            }
            .method-options-grid {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 8px !important;
            }
            .method-card {
                padding: 10px 8px !important;
            }
            .method-logo {
                height: 24px !important;
            }
            .method-name {
                font-size: 0.78rem !important;
            }
            .rekening-box {
                padding: 10px 12px !important;
            }
            .btn-submit-pay {
                padding: 9px 14px !important;
                font-size: 0.88rem !important;
            }
        }
    </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Konfirmasi Pembayaran</h1>
      <p class="page-subtitle">Selesaikan pembayaran sewa perlengkapan Anda dengan transfer bank atau e-wallet.</p>
    </div>
  </section>

  <!-- Payment Form Section -->
  <section class="pay-content-section">
    <div class="container">
      <div class="row g-4 justify-content-center">
        
        <!-- Kolom Kiri: Rincian Tagihan -->
        <div class="col-lg-6">
          <div class="payment-box-card h-100">
            <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
              <i class="fas fa-receipt text-warning me-2"></i> Rincian Tagihan Terpilih
            </h5>

            <div class="mb-3">
              <?php foreach ($detail_tagihan as $tagihan): ?>
                <div class="p-3 bg-light rounded-3 border mb-3">
                  <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="badge bg-secondary small"><?= $tagihan['no_tagihan'] ?></span>
                    <small class="text-muted">Metode: <strong><?= htmlspecialchars($tagihan['metode_pengambilan']) ?></strong></small>
                  </div>
                  
                  <h6 class="fw-bold mb-1" style="color: var(--brand-teal);"><?= htmlspecialchars($tagihan['nama_produk']) ?></h6>
                  <div class="text-muted small mb-2">
                    Jumlah: <?= $tagihan['qty'] ?> unit &bull; Durasi: <?= $tagihan['is_consumable'] ? '-' : $tagihan['durasi'] . ' hari' ?>
                  </div>

                  <!-- Perhitungan Subtotal Produk -->
                  <div class="p-2 bg-white rounded border small text-dark mb-2">
                    <strong>Subtotal Produk:</strong><br>
                    <?php if ($tagihan['is_consumable']): ?>
                      Rp<?= number_format($tagihan['harga_satuan'], 0, ',', '.') ?> × <?= $tagihan['qty'] ?> unit = <strong>Rp<?= number_format($tagihan['subtotal_produk'], 0, ',', '.') ?></strong>
                    <?php else: ?>
                      Rp<?= number_format($tagihan['harga_satuan'], 0, ',', '.') ?> × <?= $tagihan['qty'] ?> unit × <?= $tagihan['durasi'] ?> hari = <strong>Rp<?= number_format($tagihan['subtotal_produk'], 0, ',', '.') ?></strong>
                    <?php endif; ?>
                  </div>

                  <div class="d-flex justify-content-between small text-muted">
                    <span>Biaya Antar / Ongkir:</span>
                    <span>Rp<?= number_format($tagihan['biaya_pengambilan'], 0, ',', '.') ?></span>
                  </div>

                  <?php if ($tagihan['denda'] > 0): ?>
                    <div class="d-flex justify-content-between small text-danger fw-semibold">
                      <span>Denda Keterlambatan:</span>
                      <span>Rp<?= number_format($tagihan['denda'], 0, ',', '.') ?></span>
                    </div>
                  <?php endif; ?>

                  <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                    <span class="small text-muted">Sisa Tagihan Item:</span>
                    <span class="fw-bold text-danger">Rp<?= number_format($tagihan['sisa_tagihan'] ?? $tagihan['total_bayar'] ?? 0, 0, ',', '.') ?></span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>

            <div class="p-3 rounded-3 bg-white border border-success d-flex justify-content-between align-items-center mt-auto">
              <span class="fw-bold" style="color: var(--brand-teal);">Total Tagihan yang Harus Dibayar:</span>
              <span class="fs-4 fw-bold text-success">Rp<?= number_format($total_tagihan, 0, ',', '.') ?></span>
            </div>
          </div>
        </div>

        <!-- Kolom Kanan: Form Pembayaran -->
        <div class="col-lg-6">
          <div class="payment-box-card">
            <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
              <i class="fas fa-credit-card text-success me-2"></i> Formulir Pembayaran
            </h5>

            <form action="proses_pembayaran.php" method="POST" enctype="multipart/form-data" id="formPembayaran">
              <?php foreach ($id_sewa_terpilih as $id): ?>
                <input type="hidden" name="id_sewa[]" value="<?= htmlspecialchars($id) ?>">
              <?php endforeach; ?>

              <input type="hidden" name="metode" id="metode" required>

              <div class="mb-3">
                <label class="form-label fw-bold small text-muted">1. PILIH METODE PEMBAYARAN</label>
                <div class="method-options-grid">
                  <div class="method-card" data-value="bank_bca">
                    <img src="assets/images/Bca.png" alt="BCA" />
                    <span class="method-name">BCA</span>
                  </div>
                  <div class="method-card" data-value="bank_bri">
                    <img src="assets/images/bri.png" alt="BRI" />
                    <span class="method-name">BRI</span>
                  </div>
                  <div class="method-card" data-value="ewallet_gopay">
                    <img src="assets/images/gopay.png" alt="GOPAY" />
                    <span class="method-name">GoPay</span>
                  </div>
                  <div class="method-card" data-value="ewallet_dana">
                    <img src="assets/images/dana.png" alt="DANA" />
                    <span class="method-name">DANA</span>
                  </div>
                </div>
              </div>

              <!-- Rekening Info Alert Box -->
              <div id="rekening-info" class="rekening-box-alert">
                <div class="d-flex align-items-center gap-2 mb-1">
                  <i class="fas fa-money-check-alt fs-5"></i>
                  <span class="fw-bold">Tujuan Transfer / Pembayaran:</span>
                </div>
                <strong id="rekeningText" class="fs-6 font-monospace"></strong>
              </div>

              <?php if ($total_sudah_dibayar_semua > 0): ?>
                <!-- OPSI PELUNASAN SISA TAGIHAN (Karena DP telah dibayar sebelumnya) -->
                <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">2. PEMBAYARAN PELUNASAN SISA TAGIHAN</label>
                  <div class="p-3 bg-light rounded-3 border d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <strong class="text-dark d-block"><i class="fas fa-check-circle text-success me-1"></i> Pelunasan Sisa Tagihan (100%)</strong>
                      <small class="text-muted">Melunasi sisa tagihan sewa setelah pembayaran uang muka (DP) sebelumnya.</small>
                    </div>
                    <span class="badge bg-success fs-6">Rp <?= number_format($total_tagihan, 0, ',', '.') ?></span>
                  </div>
                  <div class="alert alert-info py-2 px-3 small border border-info border-opacity-25 mb-0" style="font-size: 0.82rem;">
                    <i class="fas fa-info-circle me-1"></i> Uang muka (DP) sebelumnya sebesar <strong>Rp <?= number_format($total_sudah_dibayar_semua, 0, ',', '.') ?></strong> telah terbayar. Silakan transfer sejumlah <strong>Rp <?= number_format($total_tagihan, 0, ',', '.') ?></strong> untuk melunasi pesanan sewa Anda.
                  </div>
                  <input type="hidden" name="tipe_pembayaran" id="tipe_lunas" value="lunas" />
                  <input type="hidden" name="jumlah_bayar" id="jumlah_bayar" value="<?= (float)$total_tagihan ?>" />
                </div>

              <?php elseif ($total_tagihan > 10000): ?>
                <!-- 2. PILIH JENIS PEMBAYARAN (Hanya untuk tagihan baru > Rp 10.000) -->
                <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">2. PILIH JENIS PEMBAYARAN <span class="text-danger">*</span></label>
                  
                  <!-- Opsi 1: Bayar Uang Muka (DP) -->
                  <label class="type-option-card" id="cardTipeDP" for="tipe_dp">
                    <input type="radio" name="tipe_pembayaran" id="tipe_dp" value="dp" required />
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-center mb-1">
                        <strong class="text-dark"><i class="fas fa-coins text-warning me-1"></i> Bayar Uang Muka (DP)</strong>
                        <span class="badge bg-warning text-dark">Minimal Rp 10.000</span>
                      </div>
                      <small class="text-muted d-block" style="font-size: 0.82rem;">
                        Bayar uang muka terlebih dahulu untuk mengonfirmasi pesanan sewa Anda.
                      </small>
                    </div>
                  </label>

                  <!-- Opsi 2: Bayar Lunas Penuh -->
                  <label class="type-option-card" id="cardTipeLunas" for="tipe_lunas">
                    <input type="radio" name="tipe_pembayaran" id="tipe_lunas" value="lunas" required />
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-center mb-1">
                        <strong class="text-dark"><i class="fas fa-check-circle text-success me-1"></i> Bayar Lunas Penuh (100%)</strong>
                        <span class="badge bg-success">Rp <?= number_format($total_tagihan, 0, ',', '.') ?></span>
                      </div>
                      <small class="text-muted d-block" style="font-size: 0.82rem;">
                        Bayar lunas seluruh total tagihan sekaligus tanpa sisa pembayaran.
                      </small>
                    </div>
                  </label>
                </div>

                <!-- 3. Input Nominal Bayar (Muncul Saat Jenis Dipilih) -->
                <div class="mb-3 d-none" id="infoPembayaranDP">
                  <label for="jumlah_bayar" class="form-label fw-bold small text-muted">3. JUMLAH NOMINAL YANG DIBAYARKAN (RP) <span class="text-danger">*</span></label>
                  <input type="number" class="form-control form-control-lg fw-bold" name="jumlah_bayar" id="jumlah_bayar" 
                         min="10000" step="1000" max="<?= (float)$total_tagihan ?>" required />
                  <small class="text-muted d-block mt-1" id="instruksi_bayar" style="font-size: 0.82rem;"></small>
                </div>

              <?php else: ?>
                <!-- 2. TOTAL PEMBAYARAN LUNAS (Tagihan baru <= Rp 10.000: Langsung Lunas Otomatis) -->
                <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">2. JUMLAH PEMBAYARAN LUNAS</label>
                  <div class="p-3 bg-light rounded-3 border d-flex justify-content-between align-items-center">
                    <div>
                      <strong class="text-dark d-block"><i class="fas fa-check-circle text-success me-1"></i> Pelunasan Penuh (100%)</strong>
                      <small class="text-muted">Tagihan Rp <?= number_format($total_tagihan, 0, ',', '.') ?> langsung dibayar lunas.</small>
                    </div>
                    <span class="badge bg-success fs-6">Rp <?= number_format($total_tagihan, 0, ',', '.') ?></span>
                  </div>
                  <input type="hidden" name="tipe_pembayaran" id="tipe_lunas" value="lunas" />
                  <input type="hidden" name="jumlah_bayar" id="jumlah_bayar" value="<?= (float)$total_tagihan ?>" />
                </div>
              <?php endif; ?>

              <!-- Upload Bukti -->
              <div class="mb-4">
                <label for="bukti" class="form-label fw-bold small text-muted">4. UPLOAD BUKTI TRANSFER / PEMBAYARAN <span class="text-danger">*</span></label>
                <input type="file" class="form-control" name="bukti" id="bukti" required accept="image/*,application/pdf" />
                <div class="mt-2 text-center">
                  <img id="preview" class="img-fluid rounded border shadow-sm d-none" style="max-height: 180px;" alt="Preview Bukti" />
                </div>
              </div>

              <button type="submit" class="btn-submit-pay">
                <i class="fas fa-paper-plane"></i> Kirim Konfirmasi Pembayaran
              </button>
              <a href="tagihan.php" class="btn btn-outline-secondary w-100 mt-2 py-2 d-flex align-items-center justify-content-center gap-2" style="border-radius: 10px; font-weight: 600; font-size: 0.9rem;">
                <i class="fas fa-arrow-left"></i> Kembali ke Halaman Tagihan
              </a>
            </form>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Tasikmalaya, Jawa Barat, Indonesia</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id_sewa'])) {
    header("Location: tagihan.php");
    exit();
}

$id_users = (int)$_SESSION['id_users'];
$id_sewa_terpilih = $_POST['id_sewa'];

if (empty($id_sewa_terpilih) || !is_array($id_sewa_terpilih)) {
    header("Location: tagihan.php");
    exit();
}

$id_sewa_terpilih_int = array_values(array_filter(array_map('intval', $id_sewa_terpilih)));
if (empty($id_sewa_terpilih_int)) {
    header("Location: tagihan.php");
    exit();
}

/* =========================================================================
   [FIFO LOGIC] VALIDASI STRICT FIFO DI SISI SERVER (BACKEND)
   - Memastikan tidak ada user yang mem-bypass urutan pembayaran antrean tagihan
   - Jika user mencoba membayar tagihan #2 tanpa menyertakan tagihan #1 yang belum lunas,
     sistem akan menolak dan mengarahkan kembali ke halaman tagihan.
   ========================================================================= */
// 1. Ambil seluruh tagihan aktif user yang belum lunas & tidak sedang menunggu konfirmasi (diurutkan tanggal_buat ASC, id ASC)
$qAllTagihan = mysqli_query($conn, "
    SELECT s.id, s.no_tagihan, s.tanggal_buat, s.status AS status_sewa,
    (
        SELECT status FROM pembayaran 
        WHERE (id_sewa = s.id OR FIND_IN_SET(s.id, id_sewa) OR (s.no_tagihan IS NOT NULL AND s.no_tagihan != '' AND EXISTS (
            SELECT 1 FROM sewa s2 WHERE s2.no_tagihan = s.no_tagihan AND (pembayaran.id_sewa = s2.id OR FIND_IN_SET(s2.id, pembayaran.id_sewa))
        )))
        ORDER BY tanggal_bayar DESC, id DESC LIMIT 1
    ) AS status_akhir
    FROM sewa s
    WHERE s.id_users = $id_users
    AND s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai')
    ORDER BY COALESCE(s.tanggal_buat, '1970-01-01 00:00:00') ASC, s.id ASC
");

$antrean_wajib = [];
if ($qAllTagihan && mysqli_num_rows($qAllTagihan) > 0) {
    while ($tRow = mysqli_fetch_assoc($qAllTagihan)) {
        $st = $tRow['status_akhir'] ?? '';
        $stSewa = strtolower(trim($tRow['status_sewa'] ?? ''));
        if (in_array($st, ['Lunas', 'Menunggu konfirmasi']) || in_array($stSewa, ['dibatalkan', 'selesai'])) {
            continue;
        }
        $antrean_wajib[] = (int)$tRow['id'];
    }
}

// 2. [FIFO] Cek apakah item yang dipilih melompati tagihan yang lebih awal di antrean FIFO
$posisi_tertinggi = -1;
foreach ($id_sewa_terpilih_int as $selected_id) {
    $idx = array_search($selected_id, $antrean_wajib);
    if ($idx !== false) {
        if ($idx > $posisi_tertinggi) {
            $posisi_tertinggi = $idx;
        }
    }
}

// 3. [FIFO] Jika ada antrean sebelum posisi tertinggi yang tidak ikut dibayar -> Blokir
if ($posisi_tertinggi >= 0) {
    for ($i = 0; $i <= $posisi_tertinggi; $i++) {
        if (!in_array($antrean_wajib[$i], $id_sewa_terpilih_int)) {
            echo "<!DOCTYPE html>
            <html lang='id'>
            <head>
                <meta charset='UTF-8'>
                <title>Peringatan Antrean - Semar Outdoor</title>
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            </head>
            <body style='font-family: sans-serif; background-color: #f4f6f9;'>
            <script>
                Swal.fire({
                    icon: 'warning',
                    title: 'Urutan Pembayaran Tidak Sesuai!',
                    text: 'Pembayaran wajib mengikuti urutan tagihan terlama (FIFO). Harap sertakan tagihan sebelumnya.',
                    confirmButtonColor: '#0e4430',
                    confirmButtonText: 'Kembali ke Tagihan'
                }).then(() => {
                    window.location = 'tagihan.php';
                });
            </script>
            </body>
            </html>";
            exit();
        }
    }
}

$total_tagihan = 0;
$detail_tagihan = [];
$selected_invoices = [];
$total_subtotal_semua = 0;

$id_list = implode(",", $id_sewa_terpilih_int);

// Query JOIN ke tabel alat untuk mengambil harga satuan asli
$query = "SELECT s.*, COALESCE(a.harga_per_hari, s.total_harga) AS harga_satuan_alat 
          FROM sewa s 
          LEFT JOIN alat a ON s.id_alat = a.id 
          WHERE s.id IN ($id_list)
          ORDER BY s.tanggal_buat ASC, s.id ASC";
$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {

    // FORMAT INVOICE
    if (empty($row['no_tagihan'])) {
        $tgl_inv = !empty($row['tanggal_sewa']) ? date('Ymd', strtotime($row['tanggal_sewa'])) : date('Ymd');
        $row['no_tagihan'] = "INV-" . $tgl_inv . "-" . sprintf("%04d", $row['id']);
    }

    // HARGA SATUAN & KALKULASI GAS / CONSUMABLE
    $harga_satuan = (float)$row['harga_satuan_alat'];
    $nama_lc = strtolower($row['nama_produk']);
    $is_consumable = (strpos($nama_lc, 'gas') !== false);

    $subtotal_produk = $is_consumable 
        ? ($harga_satuan * $row['qty']) 
        : ($harga_satuan * $row['qty'] * $row['durasi']);

    $subtotal = $subtotal_produk + $row['biaya_pengambilan'];

    // DENDA KETERLAMBATAN (Gas Bebas Denda)
    $denda = 0;
    $hari_terlambat = 0;
    if (!$is_consumable) {
        $tanggal_kembali = date('Y-m-d', strtotime($row['tanggal_sewa'] . ' + ' . $row['durasi'] . ' days'));
        $hari_ini = date('Y-m-d');

        if ($hari_ini > $tanggal_kembali) {
            $selisih = (strtotime($hari_ini) - strtotime($tanggal_kembali)) / 86400;
            if ($selisih > 0) {
                $hari_terlambat = floor($selisih);
                $denda = $hari_terlambat * 10000;
            }
        }
    }

    $total_bayar = $subtotal + $denda;

    $row['harga_satuan'] = $harga_satuan;
    $row['is_consumable'] = $is_consumable;
    $row['subtotal_produk'] = $subtotal_produk;
    $row['subtotal'] = $subtotal;
    $row['denda'] = $denda;
    $row['hari_terlambat'] = $hari_terlambat;
    $row['total_bayar'] = $total_bayar;
    $row['sisa_tagihan'] = $total_bayar;

    $total_subtotal_semua += $total_bayar;
    $selected_invoices[$row['no_tagihan']][] = (int)$row['id'];
    $detail_tagihan[] = $row;
}

// Hitung total yang sudah dibayar (DP) untuk invoice-invoice yang dipilih
$total_sudah_dibayar_semua = 0;
foreach ($selected_invoices as $invNum => $iIds) {
    $idsCsv = implode(',', $iIds);
    $qBayar = mysqli_query($conn, "
        SELECT SUM(jumlah_bayar) AS total 
        FROM pembayaran
        WHERE id_users = $id_users
        AND status IN ('Lunas','Belum lunas','Menunggu konfirmasi')
        AND (
            FIND_IN_SET('$invNum', id_sewa)
            OR id_sewa IN ($idsCsv)
            OR EXISTS (
                SELECT 1 FROM sewa s4 
                WHERE s4.no_tagihan = '$invNum' 
                AND (pembayaran.id_sewa = s4.id OR FIND_IN_SET(s4.id, pembayaran.id_sewa))
            )
        )
    ");
    $rB = mysqli_fetch_assoc($qBayar);
    $total_sudah_dibayar_semua += (float)($rB['total'] ?? 0);
}

$total_tagihan = max(0, $total_subtotal_semua - $total_sudah_dibayar_semua);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Pembayaran - Semar Outdoor</title>
    
    <!-- CSS & Fonts -->
    <link rel="stylesheet" href="assets/css/navbar.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <style>
        :root {
            --brand-dark: #12282a;
            --brand-teal: #162d2f;
            --brand-green: #0e4430;
            --brand-gold: #c27803;
            --brand-gold-glow: #ffc107;
            --bg-body: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            overflow-x: hidden;
        }

        .page-header {
            background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
            color: #ffffff;
            padding: 120px 20px 45px;
            text-align: center;
        }

        .page-title {
            font-family: 'Quicksand', sans-serif;
            font-size: clamp(2rem, 4vw, 2.7rem);
            font-weight: 800;
            margin-bottom: 8px;
        }

        .page-subtitle {
            color: #cbd5e1;
            font-size: 1.02rem;
            max-width: 600px;
            margin: 0 auto;
        }

        .pay-content-section {
            padding: 40px 0 80px;
        }

        .payment-box-card {
            background: #ffffff;
            border-radius: 20px;
            border: 1px solid rgba(0,0,0,0.06);
            box-shadow: 0 6px 24px rgba(0,0,0,0.04);
            padding: 28px;
        }

        /* Payment Channel Cards */
        .method-options-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
            gap: 12px;
            margin-bottom: 18px;
        }

        .method-card {
            cursor: pointer;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            padding: 14px 10px;
            text-align: center;
            transition: all 0.25s ease;
            background: #f8fafc;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .method-card:hover {
            border-color: var(--brand-gold);
            background: #ffffff;
            transform: translateY(-2px);
        }

        .method-card.active {
            border-color: var(--brand-gold);
            background-color: #fefce8;
            box-shadow: 0 4px 12px rgba(194, 120, 3, 0.2);
        }

        .method-card img {
            height: 34px;
            max-width: 80px;
            object-fit: contain;
            margin-bottom: 6px;
            user-select: none;
        }

        .method-card .method-name {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--brand-dark);
        }

        .rekening-box-alert {
            background: #f0fdf4;
            border: 1.5px solid #bbf7d0;
            border-left: 5px solid #16a34a;
            padding: 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: none;
            color: #166534;
        }

        .rekening-box-alert strong {
            font-size: 1.05rem;
            display: block;
            margin-top: 4px;
        }

        /* Payment Type Option Cards */
        .type-option-card {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 14px 16px;
            cursor: pointer;
            transition: all 0.2s ease;
            background: #ffffff;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 12px;
        }

        .type-option-card:hover {
            border-color: #0e4430;
            background: #f8fafc;
        }

        .type-option-card.active {
            border-color: #0e4430;
            background: #f0fdf4;
            box-shadow: 0 4px 14px rgba(14, 68, 48, 0.08);
        }

        .type-option-card input[type="radio"] {
            margin-top: 3px;
            accent-color: #0e4430;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .btn-submit-pay {
            background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
            color: #ffffff;
            font-weight: 700;
            font-size: 1.05rem;
            padding: 14px;
            border-radius: 14px;
            border: none;
            width: 100%;
            transition: all 0.25s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 6px 20px rgba(194, 120, 3, 0.35);
        }

        .btn-submit-pay:hover {
            background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(194, 120, 3, 0.5);
            color: #ffffff;
        }

        /* Footer */
        footer {
            background: #0b1d1f;
            color: #e2e8f0;
            padding-top: 65px;
        }

        .footer-brand-logo {
            height: 42px;
            width: auto;
            max-height: 42px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }

        .footer-brand-name {
            font-family: 'Quicksand', sans-serif;
            font-size: 1.25rem;
            font-weight: 800;
            color: #ffffff;
            letter-spacing: 0.4px;
        }

        .footer-title {
            color: #ffffff;
            font-size: 1.05rem;
            font-weight: 700;
            margin-bottom: 18px;
            position: relative;
            padding-bottom: 8px;
        }

        .footer-title::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 32px;
            height: 2px;
            background: #f59e0b;
            border-radius: 2px;
        }

        .footer-links-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links-list li {
            margin-bottom: 10px;
        }

        .footer-links-list a {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .footer-links-list a:hover {
            color: #fde047;
        }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 14px;
            font-size: 0.9rem;
            color: #cbd5e1;
        }

        .footer-contact-item i {
            color: #fde047;
            margin-top: 4px;
        }

        .footer-contact-item a {
            color: #cbd5e1;
            text-decoration: none;
        }

        .footer-contact-item a:hover {
            color: #fde047;
        }

        .footer-map-container {
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .footer-map-container iframe {
            display: block;
            width: 100%;
            height: 170px;
            border: 0;
        }

        .footer-copy-bar {
            background: #061112;
            padding: 20px 0;
            margin-top: 50px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            font-size: 0.85rem;
            color: #64748b;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .page-header {
                padding: 85px 16px 20px !important;
            }
            .page-title {
                font-size: 1.35rem !important;
            }
            .page-subtitle {
                font-size: 0.82rem !important;
            }
            .payment-section {
                padding: 16px 0 40px !important;
            }
            .payment-box-card {
                padding: 14px 16px !important;
                border-radius: 12px !important;
            }
            .item-order-row {
                padding: 8px 10px !important;
                gap: 10px !important;
            }
            .img-order-thumb {
                width: 45px !important;
                height: 45px !important;
                border-radius: 6px !important;
            }
            .item-order-title {
                font-size: 0.88rem !important;
            }
            .method-options-grid {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 8px !important;
            }
            .method-card {
                padding: 10px 8px !important;
            }
            .method-logo {
                height: 24px !important;
            }
            .method-name {
                font-size: 0.78rem !important;
            }
            .rekening-box {
                padding: 10px 12px !important;
            }
            .btn-submit-pay {
                padding: 9px 14px !important;
                font-size: 0.88rem !important;
            }
        }
    </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Konfirmasi Pembayaran</h1>
      <p class="page-subtitle">Selesaikan pembayaran sewa perlengkapan Anda dengan transfer bank atau e-wallet.</p>
    </div>
  </section>

  <!-- Payment Form Section -->
  <section class="pay-content-section">
    <div class="container">
      <div class="row g-4 justify-content-center">
        
        <!-- Kolom Kiri: Rincian Tagihan -->
        <div class="col-lg-6">
          <div class="payment-box-card h-100">
            <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
              <i class="fas fa-receipt text-warning me-2"></i> Rincian Tagihan Terpilih
            </h5>

            <div class="mb-3">
              <?php foreach ($detail_tagihan as $tagihan): ?>
                <div class="p-3 bg-light rounded-3 border mb-3">
                  <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="badge bg-secondary small"><?= $tagihan['no_tagihan'] ?></span>
                    <small class="text-muted">Metode: <strong><?= htmlspecialchars($tagihan['metode_pengambilan']) ?></strong></small>
                  </div>
                  
                  <h6 class="fw-bold mb-1" style="color: var(--brand-teal);"><?= htmlspecialchars($tagihan['nama_produk']) ?></h6>
                  <div class="text-muted small mb-2">
                    Jumlah: <?= $tagihan['qty'] ?> unit &bull; Durasi: <?= $tagihan['is_consumable'] ? '-' : $tagihan['durasi'] . ' hari' ?>
                  </div>

                  <!-- Perhitungan Subtotal Produk -->
                  <div class="p-2 bg-white rounded border small text-dark mb-2">
                    <strong>Subtotal Produk:</strong><br>
                    <?php if ($tagihan['is_consumable']): ?>
                      Rp<?= number_format($tagihan['harga_satuan'], 0, ',', '.') ?> × <?= $tagihan['qty'] ?> unit = <strong>Rp<?= number_format($tagihan['subtotal_produk'], 0, ',', '.') ?></strong>
                    <?php else: ?>
                      Rp<?= number_format($tagihan['harga_satuan'], 0, ',', '.') ?> × <?= $tagihan['qty'] ?> unit × <?= $tagihan['durasi'] ?> hari = <strong>Rp<?= number_format($tagihan['subtotal_produk'], 0, ',', '.') ?></strong>
                    <?php endif; ?>
                  </div>

                  <div class="d-flex justify-content-between small text-muted">
                    <span>Biaya Antar / Ongkir:</span>
                    <span>Rp<?= number_format($tagihan['biaya_pengambilan'], 0, ',', '.') ?></span>
                  </div>

                  <?php if ($tagihan['denda'] > 0): ?>
                    <div class="d-flex justify-content-between small text-danger fw-semibold">
                      <span>Denda Keterlambatan:</span>
                      <span>Rp<?= number_format($tagihan['denda'], 0, ',', '.') ?></span>
                    </div>
                  <?php endif; ?>

                  <div class="d-flex justify-content-between align-items-center mt-2 pt-2 border-top">
                    <span class="small text-muted">Sisa Tagihan Item:</span>
                    <span class="fw-bold text-danger">Rp<?= number_format($tagihan['sisa_tagihan'] ?? $tagihan['total_bayar'] ?? 0, 0, ',', '.') ?></span>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>

            <div class="p-3 rounded-3 bg-white border border-success d-flex justify-content-between align-items-center mt-auto">
              <span class="fw-bold" style="color: var(--brand-teal);">Total Tagihan yang Harus Dibayar:</span>
              <span class="fs-4 fw-bold text-success">Rp<?= number_format($total_tagihan, 0, ',', '.') ?></span>
            </div>
          </div>
        </div>

        <!-- Kolom Kanan: Form Pembayaran -->
        <div class="col-lg-6">
          <div class="payment-box-card">
            <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
              <i class="fas fa-credit-card text-success me-2"></i> Formulir Pembayaran
            </h5>

            <form action="proses_pembayaran.php" method="POST" enctype="multipart/form-data" id="formPembayaran">
              <?php foreach ($id_sewa_terpilih as $id): ?>
                <input type="hidden" name="id_sewa[]" value="<?= htmlspecialchars($id) ?>">
              <?php endforeach; ?>

              <input type="hidden" name="metode" id="metode" required>

              <div class="mb-3">
                <label class="form-label fw-bold small text-muted">1. PILIH METODE PEMBAYARAN</label>
                <div class="method-options-grid">
                  <div class="method-card" data-value="bank_bca">
                    <img src="assets/images/Bca.png" alt="BCA" />
                    <span class="method-name">BCA</span>
                  </div>
                  <div class="method-card" data-value="bank_bri">
                    <img src="assets/images/bri.png" alt="BRI" />
                    <span class="method-name">BRI</span>
                  </div>
                  <div class="method-card" data-value="ewallet_gopay">
                    <img src="assets/images/gopay.png" alt="GOPAY" />
                    <span class="method-name">GoPay</span>
                  </div>
                  <div class="method-card" data-value="ewallet_dana">
                    <img src="assets/images/dana.png" alt="DANA" />
                    <span class="method-name">DANA</span>
                  </div>
                </div>
              </div>

              <!-- Rekening Info Alert Box -->
              <div id="rekening-info" class="rekening-box-alert">
                <div class="d-flex align-items-center gap-2 mb-1">
                  <i class="fas fa-money-check-alt fs-5"></i>
                  <span class="fw-bold">Tujuan Transfer / Pembayaran:</span>
                </div>
                <strong id="rekeningText" class="fs-6 font-monospace"></strong>
              </div>

              <?php if ($total_sudah_dibayar_semua > 0): ?>
                <!-- OPSI PELUNASAN SISA TAGIHAN (Karena DP telah dibayar sebelumnya) -->
                <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">2. PEMBAYARAN PELUNASAN SISA TAGIHAN</label>
                  <div class="p-3 bg-light rounded-3 border d-flex justify-content-between align-items-center mb-2">
                    <div>
                      <strong class="text-dark d-block"><i class="fas fa-check-circle text-success me-1"></i> Pelunasan Sisa Tagihan (100%)</strong>
                      <small class="text-muted">Melunasi sisa tagihan sewa setelah pembayaran uang muka (DP) sebelumnya.</small>
                    </div>
                    <span class="badge bg-success fs-6">Rp <?= number_format($total_tagihan, 0, ',', '.') ?></span>
                  </div>
                  <div class="alert alert-info py-2 px-3 small border border-info border-opacity-25 mb-0" style="font-size: 0.82rem;">
                    <i class="fas fa-info-circle me-1"></i> Uang muka (DP) sebelumnya sebesar <strong>Rp <?= number_format($total_sudah_dibayar_semua, 0, ',', '.') ?></strong> telah terbayar. Silakan transfer sejumlah <strong>Rp <?= number_format($total_tagihan, 0, ',', '.') ?></strong> untuk melunasi pesanan sewa Anda.
                  </div>
                  <input type="hidden" name="tipe_pembayaran" id="tipe_lunas" value="lunas" />
                  <input type="hidden" name="jumlah_bayar" id="jumlah_bayar" value="<?= (float)$total_tagihan ?>" />
                </div>

              <?php elseif ($total_tagihan > 10000): ?>
                <!-- 2. PILIH JENIS PEMBAYARAN (Hanya untuk tagihan baru > Rp 10.000) -->
                <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">2. PILIH JENIS PEMBAYARAN <span class="text-danger">*</span></label>
                  
                  <!-- Opsi 1: Bayar Uang Muka (DP) -->
                  <label class="type-option-card" id="cardTipeDP" for="tipe_dp">
                    <input type="radio" name="tipe_pembayaran" id="tipe_dp" value="dp" required />
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-center mb-1">
                        <strong class="text-dark"><i class="fas fa-coins text-warning me-1"></i> Bayar Uang Muka (DP)</strong>
                        <span class="badge bg-warning text-dark">Minimal Rp 10.000</span>
                      </div>
                      <small class="text-muted d-block" style="font-size: 0.82rem;">
                        Bayar uang muka terlebih dahulu untuk mengonfirmasi pesanan sewa Anda.
                      </small>
                    </div>
                  </label>

                  <!-- Opsi 2: Bayar Lunas Penuh -->
                  <label class="type-option-card" id="cardTipeLunas" for="tipe_lunas">
                    <input type="radio" name="tipe_pembayaran" id="tipe_lunas" value="lunas" required />
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-center mb-1">
                        <strong class="text-dark"><i class="fas fa-check-circle text-success me-1"></i> Bayar Lunas Penuh (100%)</strong>
                        <span class="badge bg-success">Rp <?= number_format($total_tagihan, 0, ',', '.') ?></span>
                      </div>
                      <small class="text-muted d-block" style="font-size: 0.82rem;">
                        Bayar lunas seluruh total tagihan sekaligus tanpa sisa pembayaran.
                      </small>
                    </div>
                  </label>
                </div>

                <!-- 3. Input Nominal Bayar (Muncul Saat Jenis Dipilih) -->
                <div class="mb-3 d-none" id="infoPembayaranDP">
                  <label for="jumlah_bayar" class="form-label fw-bold small text-muted">3. JUMLAH NOMINAL YANG DIBAYARKAN (RP) <span class="text-danger">*</span></label>
                  <input type="number" class="form-control form-control-lg fw-bold" name="jumlah_bayar" id="jumlah_bayar" 
                         min="10000" step="1000" max="<?= (float)$total_tagihan ?>" required />
                  <small class="text-muted d-block mt-1" id="instruksi_bayar" style="font-size: 0.82rem;"></small>
                </div>

              <?php else: ?>
                <!-- 2. TOTAL PEMBAYARAN LUNAS (Tagihan baru <= Rp 10.000: Langsung Lunas Otomatis) -->
                <div class="mb-3">
                  <label class="form-label fw-bold small text-muted">2. JUMLAH PEMBAYARAN LUNAS</label>
                  <div class="p-3 bg-light rounded-3 border d-flex justify-content-between align-items-center">
                    <div>
                      <strong class="text-dark d-block"><i class="fas fa-check-circle text-success me-1"></i> Pelunasan Penuh (100%)</strong>
                      <small class="text-muted">Tagihan Rp <?= number_format($total_tagihan, 0, ',', '.') ?> langsung dibayar lunas.</small>
                    </div>
                    <span class="badge bg-success fs-6">Rp <?= number_format($total_tagihan, 0, ',', '.') ?></span>
                  </div>
                  <input type="hidden" name="tipe_pembayaran" id="tipe_lunas" value="lunas" />
                  <input type="hidden" name="jumlah_bayar" id="jumlah_bayar" value="<?= (float)$total_tagihan ?>" />
                </div>
              <?php endif; ?>

              <!-- Upload Bukti -->
              <div class="mb-4">
                <label for="bukti" class="form-label fw-bold small text-muted">4. UPLOAD BUKTI TRANSFER / PEMBAYARAN <span class="text-danger">*</span></label>
                <input type="file" class="form-control" name="bukti" id="bukti" required accept="image/*,application/pdf" />
                <div class="mt-2 text-center">
                  <img id="preview" class="img-fluid rounded border shadow-sm d-none" style="max-height: 180px;" alt="Preview Bukti" />
                </div>
              </div>

              <button type="submit" class="btn-submit-pay">
                <i class="fas fa-paper-plane"></i> Kirim Konfirmasi Pembayaran
              </button>
              <a href="tagihan.php" class="btn btn-outline-secondary w-100 mt-2 py-2 d-flex align-items-center justify-content-center gap-2" style="border-radius: 10px; font-weight: 600; font-size: 0.9rem;">
                <i class="fas fa-arrow-left"></i> Kembali ke Halaman Tagihan
              </a>
            </form>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Tasikmalaya, Jawa Barat, Indonesia</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    const cards = document.querySelectorAll('.method-card');
    const rekeningInfo = document.getElementById('rekening-info');
    const rekeningText = document.getElementById('rekeningText');
    const metodeInput = document.getElementById('metode');

    const rekeningData = {
        bank_bca: 'BCA: 1234567890 (a.n. Semar Outdoor)',
        bank_bri: 'BRI: 0987654321 (a.n. Semar Outdoor)',
        ewallet_gopay: 'GoPay: 081266957358 (a.n. Semar Outdoor)',
        ewallet_dana: 'DANA: 085693476566 (a.n. Semar Outdoor)'
    };

    cards.forEach(card => {
        card.addEventListener('click', function () {
            cards.forEach(c => c.classList.remove('active'));
            this.classList.add('active');

            const selected = this.getAttribute('data-value');
            metodeInput.value = selected;

            if (rekeningData[selected]) {
                rekeningInfo.style.display = 'block';
                rekeningText.textContent = rekeningData[selected];
            }
        });
    });

    document.getElementById('bukti').addEventListener('change', function (e) {
        const file = e.target.files[0];
        const preview = document.getElementById('preview');

        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        } else {
            preview.classList.add('d-none');
        }
    });

    // LOGIKA PEMILIHAN JENIS PEMBAYARAN (DP vs LUNAS)
    const radioDP = document.getElementById('tipe_dp');
    const radioLunas = document.getElementById('tipe_lunas');
    const cardDP = document.getElementById('cardTipeDP');
    const cardLunas = document.getElementById('cardTipeLunas');
    const boxNominal = document.getElementById('infoPembayaranDP');
    const jumlahBayar = document.getElementById('jumlah_bayar');
    const instruksiBayar = document.getElementById('instruksi_bayar');
    const buktiInput = document.getElementById('bukti');
    const totalTagihan = <?= (float)$total_tagihan ?>;

    // Batas Maksimal DP adalah 50% dari total tagihan
    const maxDPAllowed = Math.floor(totalTagihan / 2);

    function selectPaymentType(type) {
        if (boxNominal) boxNominal.classList.remove('d-none');

        // Fitur DP hanya aktif jika total tagihan di atas Rp 20.000 (karena minimal DP Rp 10.000)
        if (type === 'dp' && totalTagihan > 20000) {
            if (cardDP) cardDP.classList.add('active');
            if (cardLunas) cardLunas.classList.remove('active');
            if (radioDP) radioDP.checked = true;

            jumlahBayar.removeAttribute('readonly');
            jumlahBayar.value = 10000;
            jumlahBayar.min = 10000;
            jumlahBayar.max = maxDPAllowed;

            if (instruksiBayar) {
                instruksiBayar.innerHTML = '<span class="text-warning fw-bold">* Mode DP Aktif:</span> Masukkan nominal DP minimal Rp 10.000 s/d maksimal 50% tagihan (Maks. Rp ' + maxDPAllowed.toLocaleString('id-ID') + ').';
            }
            jumlahBayar.focus();
            jumlahBayar.select();
        } else {
            // Default ke Lunas Penuh
            if (cardLunas) cardLunas.classList.add('active');
            if (cardDP) cardDP.classList.remove('active');
            if (radioLunas) radioLunas.checked = true;

            if (jumlahBayar) {
                jumlahBayar.setAttribute('readonly', 'readonly');
                jumlahBayar.value = totalTagihan;
                jumlahBayar.min = totalTagihan;
                jumlahBayar.max = totalTagihan;
            }
            if (instruksiBayar) {
                instruksiBayar.innerHTML = '<span class="text-success fw-bold">* Pelunasan Penuh:</span> Anda akan membayar lunas total tagihan Rp ' + totalTagihan.toLocaleString('id-ID') + '.';
            }
        }
    }

    if (cardDP) {
        cardDP.addEventListener('click', function() {
            selectPaymentType('dp');
        });
    }

    if (cardLunas) {
        cardLunas.addEventListener('click', function() {
            selectPaymentType('lunas');
        });
    }

    if (radioDP) {
        radioDP.addEventListener('change', function() {
            if (this.checked) selectPaymentType('dp');
        });
    }

    if (radioLunas) {
        radioLunas.addEventListener('change', function() {
            if (this.checked) selectPaymentType('lunas');
        });
    }

    // Auto-select lunas jika 50% tagihan kurang dari Rp 10.000
    if (totalTagihan <= 20000) {
        selectPaymentType('lunas');
    }

    document.getElementById('formPembayaran').addEventListener('submit', function (e) {
        // 1. Validasi Metode Pembayaran
        if (!metodeInput.value) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Pilih Metode Pembayaran',
                text: 'Silakan pilih salah satu metode transfer / e-wallet (BCA, BRI, GoPay, atau DANA) terlebih dahulu!',
                confirmButtonColor: '#0e4430'
            });
            return false;
        }

        // 2. Validasi Jenis Pembayaran Wajib Dipilih
        const tipeDipilih = document.querySelector('input[name="tipe_pembayaran"]:checked') || document.querySelector('input[name="tipe_pembayaran"][type="hidden"]');
        if (!tipeDipilih) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Pilih Jenis Pembayaran',
                text: 'Anda wajib memilih salah satu jenis pembayaran: Bayar Uang Muka (DP) atau Bayar Lunas Penuh!',
                confirmButtonColor: '#0e4430'
            });
            return false;
        }

        // 3. Validasi Jumlah Nominal Bayar
        const nominal = parseInt(jumlahBayar.value) || 0;

        if (!jumlahBayar.value || nominal <= 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Nominal Bayar Kosong',
                text: 'Silakan masukkan jumlah nominal uang yang akan dibayarkan!',
                confirmButtonColor: '#0e4430'
            });
            jumlahBayar.focus();
            return false;
        }

        if (totalTagihan <= 20000) {
            // Jika tagihan <= Rp 20.000, 50%-nya tidak mencapai batas minimal DP (Rp 10.000)
            if (tipeDipilih.value === 'dp') {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Fitur DP Tidak Tersedia',
                    text: 'Fitur DP (maksimal 50%) hanya tersedia untuk tagihan di atas Rp 20.000.',
                    confirmButtonColor: '#0e4430'
                });
                selectPaymentType('lunas');
                return false;
            }
            jumlahBayar.value = totalTagihan;
        } else if (tipeDipilih.value === 'dp') {
            // Validasi Minimal DP Rp 10.000
            if (nominal < 10000) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Nominal DP Kurang',
                    text: 'Nominal pembayaran uang muka (DP) minimal adalah Rp 10.000!',
                    confirmButtonColor: '#0e4430'
                });
                jumlahBayar.focus();
                return false;
            }

            // Validasi Kelipatan 1.000 (Akhiran 000)
            if (nominal % 1000 !== 0) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Format Nominal Salah',
                    text: 'Nominal pembayaran harus bernilai ribuan genap (contoh: 10.000, 15.000, 20.000, dst.)!',
                    confirmButtonColor: '#0e4430'
                });
                jumlahBayar.focus();
                return false;
            }

            /* =========================================================================
               [BATAS MAKSIMAL DP 50%] VALIDASI NOMINAL DP MELEBIHI 50% TAGIHAN
               ========================================================================= */
            if (nominal > maxDPAllowed) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Nominal DP Melebihi Batas (50%)',
                    text: 'Nominal DP maksimal adalah 50% dari total tagihan (Maksimal Rp ' + maxDPAllowed.toLocaleString('id-ID') + '). Jika ingin membayar lebih dari 50%, silakan pilih opsi "Bayar Lunas Penuh (100%)".',
                    confirmButtonColor: '#0e4430',
                    confirmButtonText: 'Pilih Bayar Lunas Penuh'
                }).then((result) => {
                    if (result.isConfirmed) {
                        selectPaymentType('lunas');
                    }
                });
                jumlahBayar.focus();
                return false;
            }

        } else {
            // Pastikan nominal bernilai total tagihan saat pelunasan penuh
            jumlahBayar.value = totalTagihan;
        }

        // 4. Validasi Bukti Pembayaran
        if (!buktiInput.files || buktiInput.files.length === 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Upload Bukti Pembayaran',
                text: 'Silakan upload foto atau screenshot bukti transfer pembayaran Anda terlebih dahulu!',
                confirmButtonColor: '#0e4430'
            });
            buktiInput.focus();
            return false;
        }
    });
  </script>
</body>
</html>
