<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['id_users'])) {
    header("Location: login.php");
    exit();
}

// Menandai sewa sebagai selesai
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tandai sewa sebagai selesai
    if (isset($_POST['id'])) {
        $id_sewa = intval($_POST['id']);

        // Set status ke 'selesai' dan isi tanggal_kembali
        $tanggal_kembali = date('Y-m-d');
        $update = $conn->query("UPDATE sewa SET status = 'selesai', tanggal_dikembalikan = '$tanggal_kembali' WHERE id = $id_sewa AND id_users = {$_SESSION['id_users']}");

        if ($update) {
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Sewa berhasil ditandai sebagai selesai.'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Gagal menandai sewa sebagai selesai.'];
        }

        header("Location: riwayat_sewa.php");
        exit();
    }

    // Hapus data dari sewa yang sudah selesai
    if (isset($_POST['id_sewa'])) {
        $id_sewa = intval($_POST['id_sewa']);

        // Hanya hapus jika status = 'selesai'
        $check = $conn->query("SELECT * FROM sewa WHERE id = $id_sewa AND id_users = {$_SESSION['id_users']} AND status = 'selesai'");

        if ($check->num_rows > 0) {
            $delete = $conn->query("DELETE FROM sewa WHERE id = $id_sewa");

            if ($delete) {
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Riwayat sewa berhasil dihapus.'];
            } else {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Gagal menghapus riwayat sewa.'];
            }
        } else {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Data tidak ditemukan atau tidak valid.'];
        }

        header("Location: riwayat_sewa.php");
        exit();
    }
}

// Jika bukan metode POST
header("Location: riwayat_sewa.php");
exit();
?>
