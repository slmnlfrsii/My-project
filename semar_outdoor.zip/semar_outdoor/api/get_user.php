<?php
require '../koneksi.php';
header('Content-Type: application/json');

$id = $_POST['id_users'] ?? '';

if (empty($id)) {
    echo json_encode([
        'status' => false,
        'message' => 'ID user tidak ditemukan.'
    ]);
    exit;
}

$stmt = $conn->prepare("SELECT id AS id_users, nama, email, no_hp, alamat, foto, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    echo json_encode([
        'status' => true,
        'message' => 'Data user ditemukan.',
        'user' => $user
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'User tidak ditemukan.'
    ]);
}
?>
