<?php
require_once '../koneksi.php';
header('Content-Type: application/json');

// Ambil data JSON dari body request
$data = json_decode(file_get_contents("php://input"), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($data['id_users']) && isset($data['items'])) {
    $id_users = (int)$data['id_users'];
    $items = $data['items'];

    $success = true;

    // Generate 1 Nomor Invoice (no_tagihan) yang sama untuk seluruh item dalam 1 kali checkout
    $q_max = mysqli_query($conn, "SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM sewa");
    $next_id = mysqli_fetch_assoc($q_max)['next_id'] ?? 1;
    $batch_no_tagihan = 'INV-' . date('Ymd') . '-' . sprintf('%04d', $next_id);

    foreach ($items as $item) {
        // Ambil dan validasi data item
        $id_alat             = (int)$item['id_alat'];
        $qty                 = (int)($item['qty'] ?? 0);
        $tanggal_sewa        = $item['tanggal_sewa'] ?? '';
        $durasi              = (int)($item['durasi'] ?? 0);
        $tanggal_buat        = date('Y-m-d H:i:s');
        $metode_pengambilan  = $item['metode_pengambilan'] ?? '';
        $biaya_pengambilan   = (int)($item['biaya_pengambilan'] ?? 0);
        $status              = $item['status'] ?? 'Menunggu pembayaran';

        // Ambil harga_per_hari resmi langsung dari tabel alat
        $q_alat = $conn->prepare("SELECT nama, harga_per_hari, gambar FROM alat WHERE id = ?");
        $q_alat->bind_param("i", $id_alat);
        $q_alat->execute();
        $res_alat = $q_alat->get_result()->fetch_assoc();

        $nama_produk         = $res_alat['nama'] ?? ($item['nama_produk'] ?? '');
        $harga_per_hari      = isset($res_alat['harga_per_hari']) ? (int)$res_alat['harga_per_hari'] : (int)($item['harga_per_hari'] ?? 0);
        $gambar              = $res_alat['gambar'] ?? ($item['gambar'] ?? '');

        // Validasi input
        if (!$id_alat || !$qty || !$durasi || empty($tanggal_sewa) || empty($nama_produk)) {
            $success = false;
            break;
        }

        // Hitung total harga (Gas portable tidak dikali durasi)
        $is_gas = (stripos($nama_produk, 'gas') !== false);
        $mult_durasi = $is_gas ? 1 : $durasi;
        $total_harga = ($harga_per_hari * $qty * $mult_durasi) + $biaya_pengambilan;

        // Siapkan query insert dengan no_tagihan seragam
        $stmt = $conn->prepare("
            INSERT INTO sewa (
                id_users, id_alat, no_tagihan, nama_produk, total_harga, gambar, qty,
                tanggal_sewa, durasi, tanggal_buat, metode_pengambilan,
                biaya_pengambilan, status, tanggal_dikembalikan
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
        ");

        if (!$stmt) {
            echo json_encode([
                'status' => false,
                'message' => 'Gagal prepare statement: ' . $conn->error
            ]);
            exit;
        }

        // Binding parameter: iissdsisisdss (13 params)
        $stmt->bind_param(
            "iissdsisisdss",
            $id_users,
            $id_alat,
            $batch_no_tagihan,
            $nama_produk,
            $total_harga,
            $gambar,
            $qty,
            $tanggal_sewa,
            $durasi,
            $tanggal_buat,
            $metode_pengambilan,
            $biaya_pengambilan,
            $status
        );

        if (!$stmt->execute()) {
            echo json_encode([
                'status' => false,
                'message' => 'Gagal menyimpan data: ' . $stmt->error
            ]);
            exit;
        }

        // Hapus item dari keranjang
        $delete = $conn->prepare("DELETE FROM keranjang WHERE id_users = ? AND id_alat = ?");
        $delete->bind_param("ii", $id_users, $id_alat);
        $delete->execute();
        $delete->close();
    }

    echo json_encode([
        'status' => true,
        'message' => 'Berhasil checkout semua item'
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Data tidak valid'
    ]);
}
?>
