<?php
ob_start(); // Aktifkan output buffering
header("Content-Type: application/json");
error_reporting(0); // Nonaktifkan error output ke browser

include '../koneksi.php';

// Validasi data input
if (
    !isset($_POST['nama']) ||
    !isset($_POST['email']) ||
    !isset($_POST['password']) ||
    !isset($_POST['no_hp']) ||
    !isset($_POST['alamat'])
) {
    echo json_encode([
        "status" => false,
        "message" => "Data lengkap tidak ditemukan."
    ]);
    ob_end_flush(); exit;
}

$nama = trim($_POST['nama']);
$email = trim($_POST['email']);
$password = $_POST['password'];
$no_hp = trim($_POST['no_hp']);
$alamat = trim($_POST['alamat']);

// Validasi tambahan
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "status" => false,
        "message" => "Format email tidak valid."
    ]);
    ob_end_flush(); exit;
}

if (strlen($password) < 6) {
    echo json_encode([
        "status" => false,
        "message" => "Password harus minimal 6 karakter."
    ]);
    ob_end_flush(); exit;
}

// Cek apakah email sudah digunakan
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode([
        "status" => false,
        "message" => "Email sudah terdaftar."
    ]);
    $stmt->close();
    $conn->close();
    ob_end_flush(); exit;
}
$stmt->close();

// Simpan user baru
$password_hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (nama, email, password, no_hp, alamat) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $nama, $email, $password_hash, $no_hp, $alamat);

if ($stmt->execute()) {
    echo json_encode([
        "status" => true,
        "message" => "Registrasi berhasil."
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Gagal registrasi: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
ob_end_flush(); // ✅ Kirim output JSON
?>
