<?php
require_once '../koneksi.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id_users'])) {
    $id_users = intval($_GET['id_users']);

    // Ambil semua tagihan aktif dan jumlah pembayaran per sewa
    $query = "
        SELECT 
            s.*, 
            IFNULL((
                SELECT SUM(p.jumlah_bayar) 
                FROM pembayaran p 
                WHERE p.id_sewa = s.id
            ), 0) AS total_dibayar
        FROM sewa s
        WHERE s.id_users = ?
          AND s.status IN ('Menunggu pembayaran', 'Siap di ambil', 'di antar')
        ORDER BY s.tanggal_sewa DESC
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_users);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode([
        "success" => true,
        "data" => $data
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Parameter tidak valid"
    ]);
}
?>
