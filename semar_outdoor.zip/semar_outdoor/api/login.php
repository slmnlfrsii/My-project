<?php
header("Content-Type: application/json");
require_once '../koneksi.php';
error_reporting(0);

if (!isset($_POST['email']) || !isset($_POST['password'])) {
    echo json_encode([
        "status" => false,
        "message" => "Email dan password wajib diisi."
    ]);
    exit;
}

$email = trim($_POST['email']);
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT id AS id_users, nama, email, no_hp, alamat, foto, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $user = $result->fetch_assoc()) {
    if (password_verify($password, $user['password'])) {
        echo json_encode([
            "status" => true,
            "message" => "Login berhasil",
            "user" => [
                "id_users" => (int) $user['id_users'],
                "nama" => $user['nama'],
                "email" => $user['email'],
                "foto" => $user['foto'] ?? "default.jpg"
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Password salah"
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Akun tidak ditemukan"
    ]);
}

$stmt->close();
$conn->close();
?>
