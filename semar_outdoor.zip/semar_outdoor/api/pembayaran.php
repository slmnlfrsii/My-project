<?php
header("Content-Type: application/json");
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_users = $_POST['id_users'];
    $id_sewa = $_POST['id_sewa']; // array
    $jumlah_bayar = $_POST['jumlah_bayar']; // array
    $total_tagihan = $_POST['total_tagihan']; // array
    $metode = $_POST['metode'];

    $target_dir = "../bukti_pembayaran/";
    if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

    $file_name = time() . "_" . preg_replace("/[^A-Za-z0-9.]/", "_", basename($_FILES["bukti_pembayaran"]["name"]));
    $target_file = $target_dir . $file_name;

    if (!move_uploaded_file($_FILES["bukti_pembayaran"]["tmp_name"], $target_file)) {
        echo json_encode(["success" => false, "message" => "Gagal upload bukti pembayaran"]);
        exit;
    }

    $success = true;

    for ($i = 0; $i < count($id_sewa); $i++) {
        $sql = "INSERT INTO pembayaran (id_users, id_sewa, metode, bukti_pembayaran, jumlah_bayar, total_tagihan, status) 
                VALUES (?, ?, ?, ?, ?, ?, 'Menunggu konfirmasi')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "iissdd",
            $id_users,
            $id_sewa[$i],
            $metode,
            $file_name,
            $jumlah_bayar[$i],
            $total_tagihan[$i]
        );

        if (!$stmt->execute()) {
            $success = false;
            break;
        }
    }

    echo json_encode([
        "success" => $success,
        "message" => $success ? "Pembayaran berhasil" : "Gagal menyimpan ke database"
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Metode tidak valid"]);
}
?>
