<?php
include '../koneksi.php';
header('Content-Type: application/json');

if (isset($_GET['id_users'])) {
    $id_users = $_GET['id_users'];

    $stmt = $conn->prepare("
        SELECT k.id, k.id_alat, k.jumlah, k.total_harga, k.tanggal_ditambahkan,
               a.nama AS nama_alat, a.gambar, a.harga_per_hari
        FROM keranjang k
        JOIN alat a ON a.id = k.id_alat
        WHERE k.id_users = ?
    ");

    $stmt->bind_param("i", $id_users);
    $stmt->execute();
    $result = $stmt->get_result();

    $keranjang = [];

    while ($row = $result->fetch_assoc()) {
        $keranjang[] = [
            "id" => $row['id'],
            "id_alat" => $row['id_alat'],
            "nama_alat" => $row['nama_alat'],
            "gambar" => $row['gambar'],
            "jumlah" => $row['jumlah'],
            "harga_per_hari" => intval($row['harga_per_hari']),
            "total_harga" => intval($row['total_harga']),
            "tanggal_ditambahkan" => $row['tanggal_ditambahkan']
        ];
    }

    echo json_encode([
        "status" => true,
        "message" => "Berhasil",
        "keranjang" => $keranjang
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Parameter id_users tidak ditemukan"
    ]);
}
?>
