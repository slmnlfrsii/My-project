<?php
include '../koneksi.php';

$query = mysqli_query($conn, "SELECT * FROM alat");

$result = [];

while ($row = mysqli_fetch_assoc($query)) {
    $result[] = [
        "id" => $row['id'],
        "nama" => $row['nama'],
        "deskripsi" => $row['deskripsi'],
        "stok_awal" => (int)$row['stok_awal'],
        "sisa_stok" => (int)$row['sisa_stok'],
        "harga_per_hari" => $row['harga_per_hari'],
        "gambar" => $row['gambar']
    ];
}

$response = [
    "status" => true,
    "message" => "Data ditemukan",
    "alat" => $result
];

header('Content-Type: application/json');
echo json_encode($response);
