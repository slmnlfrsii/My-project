<?php
include "../koneksi.php";

// Ambil data dari POST
$id_users = $_POST['id_users'];
$id_alat = $_POST['id_alat'];
$jumlah = $_POST['jumlah'];
$total_harga = $_POST['total_harga'];
$tanggal_ditambahkan = date('Y-m-d H:i:s');

// Ambil nama alat dari tabel alat
$stmt_alat = $conn->prepare("SELECT nama FROM alat WHERE id = ?");
$stmt_alat->bind_param("i", $id_alat);
$stmt_alat->execute();
$result = $stmt_alat->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => false, "message" => "Alat tidak ditemukan"]);
    exit;
}

$row = $result->fetch_assoc();
$nama = $row['nama'];

// Cek apakah alat sudah ada di keranjang user
$stmt_cek = $conn->prepare("SELECT id, jumlah, total_harga FROM keranjang WHERE id_users = ? AND id_alat = ?");
$stmt_cek->bind_param("ii", $id_users, $id_alat);
$stmt_cek->execute();
$result_cek = $stmt_cek->get_result();

if ($result_cek->num_rows > 0) {
    // Kalau sudah ada, update jumlah dan total_harga
    $row = $result_cek->fetch_assoc();
    $jumlah_baru = $row['jumlah'] + $jumlah;
    $total_baru = $row['total_harga'] + $total_harga;

    $stmt_update = $conn->prepare("UPDATE keranjang SET jumlah = ?, total_harga = ?, tanggal_ditambahkan = ? WHERE id_users = ? AND id_alat = ?");
    $stmt_update->bind_param("iissi", $jumlah_baru, $total_baru, $tanggal_ditambahkan, $id_users, $id_alat);
    $success = $stmt_update->execute();
} else {
    // Kalau belum ada, insert baru
    $stmt = $conn->prepare("INSERT INTO keranjang (id_users, id_alat, jumlah, total_harga, tanggal_ditambahkan, nama) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiiss", $id_users, $id_alat, $jumlah, $total_harga, $tanggal_ditambahkan, $nama);
    $success = $stmt->execute();
}

if ($success) {
    echo json_encode(["status" => true, "message" => "Berhasil ditambahkan ke keranjang"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal menambahkan"]);
}
?>
