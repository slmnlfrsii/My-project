<?php
include "../koneksi.php";
$id = $_POST['id'];
$query = "DELETE FROM keranjang WHERE id = '$id'";
if (mysqli_query($conn, $query)) {
    echo json_encode(["status" => true, "message" => "Item dihapus"]);
} else {
    echo json_encode(["status" => false, "message" => "Gagal menghapus"]);
}
?>
