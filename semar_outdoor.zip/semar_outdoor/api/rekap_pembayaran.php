<?php
require_once '../koneksi.php'; // Sesuaikan path

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !isset($_GET['id_users'])) {
    http_response_code(400);
    echo json_encode(["message" => "Parameter id_users wajib disertakan"]);
    exit();
}

$id_users = intval($_GET['id_users']);

// Ambil rekap pembayaran dan join ke tabel sewa untuk ambil nama_produk
$sql = "SELECT 
            p.id, 
            p.id_users,
            p.id_sewa,
            s.nama_produk,
            p.metode,
            p.bukti_pembayaran,
            p.jumlah_bayar,
            p.total_tagihan,
            p.status,
            p.tanggal_bayar
        FROM pembayaran p
        LEFT JOIN sewa s ON p.id_sewa = s.id
        WHERE p.id_users = ?
        ORDER BY p.tanggal_bayar DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_users);
$stmt->execute();

$result = $stmt->get_result();
$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode($data);
?>
