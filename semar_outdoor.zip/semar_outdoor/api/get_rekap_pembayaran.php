<?php
require_once '../koneksi.php';
header('Content-Type: application/json');

// Cek apakah id_users dikirim
if (!isset($_GET['id_users'])) {
    echo json_encode([
        "success" => false,
        "message" => "Parameter id_users diperlukan"
    ]);
    exit;
}

$id_users = intval($_GET['id_users']);

// Query untuk ambil data rekap pembayaran beserta nama produk
$sql = "SELECT 
            s.nama_produk, 
            p.metode, 
            p.jumlah_bayar, 
            p.tanggal_bayar, 
            p.status
        FROM pembayaran p
        JOIN sewa s ON p.id_sewa = s.id
        WHERE p.id_users = ?
        ORDER BY p.tanggal_bayar DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_users);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        "nama_produk" => $row['nama_produk'],
        "metode" => $row['metode'],
        "jumlah_bayar" => (int)$row['jumlah_bayar'],
        "tanggal_bayar" => $row['tanggal_bayar'],
        "status" => $row['status']
    ];
}

echo json_encode([
    "success" => true,
    "data" => $data
]);
?>
