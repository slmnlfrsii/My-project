<?php
require_once '../koneksi.php';
header('Content-Type: application/json');

// Ambil dan validasi ID
$id_sewa = isset($_POST['id_sewa']) ? intval($_POST['id_sewa']) : null;

if (!$id_sewa) {
    echo json_encode(['success' => false, 'message' => 'ID sewa tidak ditemukan']);
    exit;
}

// Ambil data sewa dari tabel sewa
$stmt = $conn->prepare("SELECT * FROM sewa WHERE id = ?");
$stmt->bind_param("i", $id_sewa);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Data sewa tidak ditemukan']);
    exit;
}

$data = $result->fetch_assoc();

// Pastikan status masih bisa dibatalkan
if (strtolower($data['status']) !== 'menunggu pembayaran') {
    echo json_encode(['success' => false, 'message' => 'Sewa hanya bisa dibatalkan jika status masih Menunggu pembayaran']);
    exit;
}

// Mulai transaksi
$conn->begin_transaction();

try {
    // 1. Kembalikan stok alat jika status sedang aktif
    $activeStatuses = ['siap di ambil', 'di antar', 'diantar', 'berlangsung'];
    if (!empty($data['id_alat']) && in_array(strtolower(trim($data['status'])), $activeStatuses)) {
        $updateStok = $conn->prepare("UPDATE alat SET sisa_stok = LEAST(stok_awal, sisa_stok + ?) WHERE id = ?");
        $updateStok->bind_param("ii", $data['qty'], $data['id_alat']);
        $updateStok->execute();
        $updateStok->close();
    }

    // 2. Insert ke tabel sewa_dibatalkan
    $noTagihan = !empty($data['no_tagihan']) ? $data['no_tagihan'] : ('INV-' . date('Ymd', strtotime($data['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $id));

    $stmtInsert = $conn->prepare("
        INSERT INTO sewa_dibatalkan (
            id_users, no_tagihan, nama_produk, qty, durasi, total_harga,
            biaya_pengambilan, metode_pengambilan, gambar,
            tanggal_sewa, status, dibatalkan_pada
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Dibatalkan', NOW())
    ");
    $stmtInsert->bind_param(
        "issiiiisss",
        $data['id_users'],
        $noTagihan,
        $data['nama_produk'],
        $data['qty'],
        $data['durasi'],
        $data['total_harga'],
        $data['biaya_pengambilan'],
        $data['metode_pengambilan'],
        $data['gambar'],
        $data['tanggal_sewa']
    );

    if (!$stmtInsert->execute()) {
        throw new Exception("Gagal menyimpan ke sewa_dibatalkan");
    }

    // Hapus dari tabel sewa
    $stmtDelete = $conn->prepare("DELETE FROM sewa WHERE id = ?");
    $stmtDelete->bind_param("i", $id_sewa);
    if (!$stmtDelete->execute()) {
        throw new Exception("Gagal menghapus dari tabel sewa");
    }

    // Commit transaksi
    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Sewa berhasil dibatalkan dan dipindahkan']);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
