<?php
require_once '../koneksi.php';
header("Content-Type: application/json");

$id       = $_POST['id'] ?? '';
$nama     = $_POST['nama'] ?? '';
$email    = $_POST['email'] ?? '';
$no_hp    = $_POST['no_hp'] ?? '';
$alamat   = $_POST['alamat'] ?? '';
$password = $_POST['password'] ?? '';
$foto     = $_FILES['foto'] ?? null;

if (empty($id) || empty($nama) || empty($email)) {
    echo json_encode(['status' => false, 'message' => 'ID, nama, dan email wajib diisi']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => false, 'message' => 'Format email tidak valid']);
    exit;
}

$fotoName = '';

// Cek foto lama sebelum update
$stmt_old = $conn->prepare("SELECT foto FROM users WHERE id = ?");
$stmt_old->bind_param("i", $id);
$stmt_old->execute();
$result_old = $stmt_old->get_result();
$old_user = $result_old->fetch_assoc();
$oldFoto = $old_user['foto'] ?? null;

// Proses upload foto baru
if ($foto && $foto['tmp_name']) {
    $targetDir = "../admin/uploads/pengguna/";
    $fotoName = uniqid() . "_" . basename($foto['name']);
    $targetFile = $targetDir . $fotoName;

    if (!move_uploaded_file($foto['tmp_name'], $targetFile)) {
        echo json_encode(['status' => false, 'message' => 'Upload foto gagal']);
        exit;
    }

    // Hapus foto lama jika bukan default
    if (!empty($oldFoto) && file_exists($targetDir . $oldFoto)) {
        unlink($targetDir . $oldFoto);
    }
}

// Siapkan query update
if (!empty($password)) {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    if ($fotoName) {
        $stmt = $conn->prepare("UPDATE users SET nama=?, email=?, no_hp=?, alamat=?, password=?, foto=? WHERE id=?");
        $stmt->bind_param("ssssssi", $nama, $email, $no_hp, $alamat, $password_hash, $fotoName, $id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET nama=?, email=?, no_hp=?, alamat=?, password=? WHERE id=?");
        $stmt->bind_param("sssssi", $nama, $email, $no_hp, $alamat, $password_hash, $id);
    }
} else {
    if ($fotoName) {
        $stmt = $conn->prepare("UPDATE users SET nama=?, email=?, no_hp=?, alamat=?, foto=? WHERE id=?");
        $stmt->bind_param("sssssi", $nama, $email, $no_hp, $alamat, $fotoName, $id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET nama=?, email=?, no_hp=?, alamat=? WHERE id=?");
        $stmt->bind_param("ssssi", $nama, $email, $no_hp, $alamat, $id);
    }
}

// Eksekusi update
if ($stmt->execute()) {
    // Ambil data terbaru
    $get = $conn->prepare("SELECT id AS id_users, nama, email, no_hp, alamat, foto, created_at FROM users WHERE id = ?");
    $get->bind_param("i", $id);
    $get->execute();
    $result = $get->get_result();
    $user = $result->fetch_assoc();

    echo json_encode([
        'status' => true,
        'message' => 'Update berhasil',
        'user' => $user
    ]);
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Gagal update: ' . $stmt->error
    ]);
}
?>
