<?php
require '../koneksi.php';
header('Content-Type: application/json');

// Ambil id_users dari parameter GET
$id_users = isset($_GET['id_users']) ? intval($_GET['id_users']) : null;

// Cek apakah id_users tersedia
if (!$id_users) {
    echo json_encode(['status' => false, 'message' => 'Unauthorized']);
    exit;
}

// Fungsi untuk mengambil data dari database
function fetch_data($conn, $query) {
    $result = $conn->query($query);
    $data = [];

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    return $data;
}

// Ambil data dari tiga kategori: berlangsung, selesai, dibatalkan
$response = [
    'status' => true,
    'berlangsung' => fetch_data($conn, "
        SELECT * FROM sewa 
        WHERE id_users = $id_users 
        AND status IN ('Menunggu pembayaran', 'Berlangsung', 'Siap di ambil', 'di antar') 
        ORDER BY tanggal_sewa DESC
    "),
    'selesai' => fetch_data($conn, "
        SELECT * FROM sewa 
        WHERE id_users = $id_users 
        AND status = 'selesai'
    "),
    'dibatalkan' => fetch_data($conn, "
        SELECT * FROM sewa_dibatalkan 
        WHERE id_users = $id_users 
        ORDER BY tanggal_sewa DESC
    ")
];

// Kirim response dalam format JSON
echo json_encode($response);
?>
