<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'koneksi.php';

if (!isset($_SESSION['id_users'])) {
    header('Location: login.php');
    exit;
}
$id_users = (int)$_SESSION['id_users'];

// 1. Sewa Berlangsung (Menggunakan id_alat)
$sewa_berlangsung_query = $conn->query("
    SELECT s.*, u.nama, u.email, IFNULL(a.harga_per_hari, s.total_harga) AS harga_per_hari
    FROM sewa s
    JOIN users u ON s.id_users = u.id
    LEFT JOIN alat a ON s.id_alat = a.id
    WHERE s.id_users = $id_users AND s.status IN ('Menunggu pembayaran', 'Berlangsung','Siap di ambil','di antar')
    ORDER BY COALESCE(s.tanggal_buat, s.tanggal_sewa) DESC, s.id DESC
");

$grouped_berlangsung = [];
if ($sewa_berlangsung_query && $sewa_berlangsung_query->num_rows > 0) {
    while ($r = $sewa_berlangsung_query->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['tanggal_buat'] ?? $r['tanggal_sewa'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)$r['harga_per_hari'];
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $grouped_berlangsung[$noTag][] = $r;
    }
}

$sewa_berlangsung_list = [];
foreach ($grouped_berlangsung as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
    }

    $sewa_berlangsung_list[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => $primary['status'],
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'items' => $items
    ];
}

// 2. Sewa Selesai (Menggunakan id_alat)
$sewa_selesai_query = $conn->query("
    SELECT s.*, u.nama, u.email, IFNULL(a.harga_per_hari, s.total_harga) AS harga_per_hari 
    FROM sewa s
    JOIN users u ON s.id_users = u.id 
    LEFT JOIN alat a ON s.id_alat = a.id
    WHERE s.id_users = $id_users AND s.status = 'selesai'
    ORDER BY s.tanggal_dikembalikan DESC, s.id DESC
");

$grouped_selesai = [];
if ($sewa_selesai_query && $sewa_selesai_query->num_rows > 0) {
    while ($r = $sewa_selesai_query->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['tanggal_buat'] ?? $r['tanggal_sewa'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)$r['harga_per_hari'];
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $grouped_selesai[$noTag][] = $r;
    }
}

$sewa_selesai_list = [];
foreach ($grouped_selesai as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
    }

    $sewa_selesai_list[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => 'selesai',
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'tanggal_dikembalikan' => $primary['tanggal_dikembalikan'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'items' => $items
    ];
}

// 3. Sewa Dibatalkan (Menggunakan JOIN ke nama_produk karena tidak ada id_alat)
$sewa_dibatalkan_query = $conn->query("
    SELECT s.*, u.nama, u.email, IFNULL(a.harga_per_hari, s.total_harga) AS harga_per_hari 
    FROM sewa_dibatalkan s
    JOIN users u ON s.id_users = u.id
    LEFT JOIN alat a ON s.nama_produk = a.nama
    WHERE s.id_users = $id_users
    ORDER BY s.dibatalkan_pada DESC, s.id DESC
");

$grouped_dibatalkan = [];
if ($sewa_dibatalkan_query && $sewa_dibatalkan_query->num_rows > 0) {
    while ($r = $sewa_dibatalkan_query->fetch_assoc()) {
        $noTag = !empty($r['no_tagihan']) ? $r['no_tagihan'] : ('INV-' . date('Ymd', strtotime($r['dibatalkan_pada'] ?? 'now')) . '-' . sprintf('%04d', $r['id']));
        $r['no_tagihan_formatted'] = $noTag;
        $harga_satuan = (float)$r['harga_per_hari'];
        $is_gas = (stripos($r['nama_produk'], 'gas') !== false);
        $r['subtotal_item'] = ($harga_satuan * $r['qty'] * ($is_gas ? 1 : $r['durasi'])) + $r['biaya_pengambilan'];
        $grouped_dibatalkan[$noTag][] = $r;
    }
}

$sewa_dibatalkan_list = [];
foreach ($grouped_dibatalkan as $noTag => $items) {
    $primary = $items[0];
    $total_invoice = 0;
    $total_qty = 0;
    $total_ongkir = 0;

    foreach ($items as $it) {
        $total_invoice += $it['subtotal_item'];
        $total_qty += (int)$it['qty'];
        $total_ongkir += (float)$it['biaya_pengambilan'];
    }

    $sewa_dibatalkan_list[] = [
        'no_tagihan' => $noTag,
        'primary_id' => $primary['id'],
        'nama' => $primary['nama'],
        'email' => $primary['email'],
        'status' => 'Dibatalkan',
        'tanggal_sewa' => $primary['tanggal_sewa'],
        'durasi' => $primary['durasi'],
        'dibatalkan_pada' => $primary['dibatalkan_pada'],
        'metode_pengambilan' => $primary['metode_pengambilan'],
        'total_biaya' => $total_invoice,
        'total_ongkir' => $total_ongkir,
        'total_qty' => $total_qty,
        'items' => $items
    ];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Riwayat Sewa - Semar Outdoor</title>
    
    <!-- CSS & Fonts -->
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    <style>
      :root {
        --brand-dark: #12282a;
        --brand-teal: #162d2f;
        --brand-green: #0e4430;
        --brand-gold: #c27803;
        --brand-gold-glow: #ffc107;
        --bg-body: #f8fafc;
        --text-main: #1e293b;
        --text-muted: #64748b;
      }

      * {
        box-sizing: border-box;
      }

      body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--bg-body);
        color: var(--text-main);
        overflow-x: hidden;
      }

      .page-header {
        background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
        color: #ffffff;
        padding: 120px 20px 45px;
        text-align: center;
      }

      .page-title {
        font-family: 'Quicksand', sans-serif;
        font-size: clamp(2rem, 4vw, 2.7rem);
        font-weight: 800;
        margin-bottom: 8px;
      }

      .page-subtitle {
        color: #cbd5e1;
        font-size: 1.02rem;
        max-width: 600px;
        margin: 0 auto;
      }

      .history-section {
        padding: 35px 0 80px;
      }

      /* Custom Nav Tabs */
      .history-nav-tabs {
        border-bottom: 2px solid #e2e8f0;
        gap: 8px;
        margin-bottom: 24px;
      }

      .history-nav-tabs .nav-link {
        border: none;
        color: var(--text-muted);
        font-weight: 700;
        font-size: 0.98rem;
        padding: 12px 20px;
        border-radius: 12px 12px 0 0;
        transition: all 0.2s ease;
        background: transparent;
      }

      .history-nav-tabs .nav-link.active {
        color: var(--brand-teal);
        border-bottom: 3px solid var(--brand-gold);
        background: transparent;
      }

      /* Order History Card */
      .order-history-card {
        background: #ffffff;
        border-radius: 18px;
        border: 1px solid rgba(0,0,0,0.06);
        box-shadow: 0 4px 18px rgba(0,0,0,0.04);
        padding: 20px;
        margin-bottom: 20px;
        transition: all 0.25s ease;
        display: flex;
        gap: 18px;
        align-items: center;
      }

      .order-history-card:hover {
        box-shadow: 0 8px 24px rgba(0,0,0,0.08);
        border-color: rgba(194, 120, 3, 0.3);
      }

      @media (max-width: 576px) {
        .order-history-card {
          flex-direction: column;
          align-items: flex-start;
        }
      }

      .order-thumb-img {
        width: 100px;
        height: 100px;
        border-radius: 14px;
        object-fit: cover;
        background: #f1f5f9;
        flex-shrink: 0;
      }

      .order-content-main {
        flex-grow: 1;
        width: 100%;
      }

      .order-item-title {
        font-size: 1.12rem;
        font-weight: 700;
        color: var(--brand-teal);
        margin-bottom: 4px;
        font-family: 'Quicksand', sans-serif;
      }

      /* Footer */
      footer {
        background: #0b1d1f;
        color: #e2e8f0;
        padding-top: 65px;
      }

      .footer-brand-logo {
        height: 42px;
        width: auto;
        max-height: 42px;
        object-fit: contain;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
      }

      .footer-brand-name {
        font-family: 'Quicksand', sans-serif;
        font-size: 1.25rem;
        font-weight: 800;
        color: #ffffff;
        letter-spacing: 0.4px;
      }

      .footer-title {
        color: #ffffff;
        font-size: 1.05rem;
        font-weight: 700;
        margin-bottom: 18px;
        position: relative;
        padding-bottom: 8px;
      }

      .footer-title::after {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 32px;
        height: 2px;
        background: #f59e0b;
        border-radius: 2px;
      }

      .footer-links-list {
        list-style: none;
        padding: 0;
        margin: 0;
      }

      .footer-links-list li {
        margin-bottom: 10px;
      }

      .footer-links-list a {
        color: #cbd5e1;
        text-decoration: none;
        font-size: 0.9rem;
        transition: color 0.2s ease;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }

      .footer-links-list a:hover {
        color: #fde047;
      }

      .footer-contact-item {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        margin-bottom: 14px;
        font-size: 0.9rem;
        color: #cbd5e1;
      }

      .footer-contact-item i {
        color: #fde047;
        margin-top: 4px;
      }

      .footer-contact-item a {
        color: #cbd5e1;
        text-decoration: none;
      }

      .footer-contact-item a:hover {
        color: #fde047;
      }

      .footer-map-container {
        border-radius: 12px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.1);
      }

      .footer-map-container iframe {
        display: block;
        width: 100%;
        height: 170px;
        border: 0;
      }

      .footer-copy-bar {
        background: #061112;
        padding: 20px 0;
        margin-top: 50px;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        text-align: center;
        font-size: 0.85rem;
        color: #64748b;
      }
    </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Riwayat Sewa Perlengkapan</h1>
      <p class="page-subtitle">Pantau seluruh status pemesanan, pengambilan, dan pengembalian alat outdoor Anda.</p>
    </div>
  </section>

  <!-- History Content Section -->
  <section class="history-section">
    <div class="container">

      <!-- Navigation Tabs -->
      <ul class="nav history-nav-tabs" id="riwayatTabs" role="tablist">
          <li class="nav-item" role="presentation">
              <button class="nav-link active" id="berlangsung-tab" data-bs-toggle="tab" data-bs-target="#berlangsung" type="button" role="tab">
                  <i class="fas fa-spinner me-1"></i> Sewa Berlangsung (<?= count($sewa_berlangsung_list) ?>)
              </button>
          </li>
          <li class="nav-item" role="presentation">
              <button class="nav-link" id="selesai-tab" data-bs-toggle="tab" data-bs-target="#selesai" type="button" role="tab">
                  <i class="fas fa-check-circle me-1"></i> Sewa Selesai (<?= count($sewa_selesai_list) ?>)
              </button>
          </li>
          <li class="nav-item" role="presentation">
              <button class="nav-link" id="dibatalkan-tab" data-bs-toggle="tab" data-bs-target="#dibatalkan" type="button" role="tab">
                  <i class="fas fa-ban me-1"></i> Sewa Dibatalkan (<?= count($sewa_dibatalkan_list) ?>)
              </button>
          </li>
      </ul>

      <div class="tab-content mt-3" id="riwayatTabsContent">
          <!-- 1. TAB SEWA BERLANGSUNG -->
          <div class="tab-pane fade show active" id="berlangsung" role="tabpanel">
              <?php if (count($sewa_berlangsung_list) > 0): ?>
                  <div class="row g-3">
                      <?php foreach ($sewa_berlangsung_list as $inv): ?>
                          <?php
                              $statusBadge = 'bg-secondary';
                              if ($inv['status'] === 'Menunggu pembayaran') $statusBadge = 'bg-warning text-dark';
                              elseif ($inv['status'] === 'Berlangsung') $statusBadge = 'bg-primary';
                              elseif ($inv['status'] === 'Siap di ambil' || $inv['status'] === 'di antar') $statusBadge = 'bg-info text-dark';
                          ?>
                          <div class="col-12">
                              <div class="order-history-card">
                                  <div class="d-flex flex-column align-items-center gap-1 flex-shrink-0">
                                      <img src="admin/uploads/alat/<?= htmlspecialchars($inv['items'][0]['gambar']) ?>" alt="<?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>" class="order-thumb-img" />
                                      <?php if (count($inv['items']) > 1): ?>
                                          <span class="badge bg-light text-dark border small mt-1">+<?= count($inv['items']) - 1 ?> Alat Lain</span>
                                      <?php endif; ?>
                                  </div>
                                  
                                  <div class="order-content-main flex-grow-1">
                                      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                          <div class="d-flex align-items-center gap-2">
                                              <span class="badge bg-light text-primary border fw-bold px-3 py-2 rounded-pill font-monospace">
                                                  <i class="fas fa-receipt me-1"></i> <?= $inv['no_tagihan'] ?>
                                              </span>
                                              <span class="badge <?= $statusBadge ?> px-3 py-2 rounded-pill small">
                                                  <?= htmlspecialchars($inv['status']) ?>
                                              </span>
                                          </div>
                                          <span class="text-muted small">
                                              <i class="far fa-calendar-alt me-1"></i> Tanggal Sewa: <strong><?= date('d M Y', strtotime($inv['tanggal_sewa'])) ?></strong>
                                          </span>
                                      </div>

                                      <h5 class="order-item-title mb-2 fw-bold text-dark">
                                          <?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>
                                          <?php if (count($inv['items']) > 1): ?>
                                              <span class="text-muted fw-normal fs-6">dan <?= count($inv['items']) - 1 ?> alat lainnya</span>
                                          <?php endif; ?>
                                      </h5>

                                      <!-- Mini List of Items -->
                                      <div class="bg-light p-2 rounded-3 border mb-2">
                                          <div class="row g-2">
                                              <?php foreach ($inv['items'] as $it): ?>
                                                  <div class="col-sm-6 d-flex align-items-center gap-2">
                                                      <img src="admin/uploads/alat/<?= $it['gambar'] ?>" alt="alat" style="width: 28px; height: 28px; object-fit: cover; border-radius: 4px;" class="border flex-shrink-0">
                                                      <span class="small text-dark fw-semibold text-truncate"><?= htmlspecialchars($it['nama_produk']) ?></span>
                                                      <span class="badge bg-white text-dark border small ms-auto">x<?= $it['qty'] ?></span>
                                                  </div>
                                              <?php endforeach; ?>
                                          </div>
                                      </div>
                                      
                                      <div class="row g-2 text-muted small mb-2">
                                          <div class="col-sm-6">
                                              <span>Total Alat: <strong><?= $inv['total_qty'] ?> unit</strong> &bull; Durasi: <strong><?= $inv['durasi'] ?> hari</strong></span>
                                          </div>
                                          <div class="col-sm-6">
                                              <span>Metode: <strong><?= htmlspecialchars($inv['metode_pengambilan']) ?></strong></span>
                                          </div>
                                      </div>
                                      
                                      <div class="d-flex flex-wrap justify-content-between align-items-center pt-2 border-top gap-2">
                                          <div>
                                              <small class="text-muted d-block" style="font-size: 0.78rem;">Total Transaksi</small>
                                              <span class="fw-bold fs-5 text-success">Rp<?= number_format($inv['total_biaya'], 0, ',', '.') ?></span>
                                          </div>

                                          <div class="d-flex gap-2">
                                              <?php if ($inv['status'] === 'Menunggu pembayaran'): ?>
                                                  <a href="batalkan_sewa.php?id=<?= $inv['primary_id'] ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3" onclick="return confirm('Apakah Anda yakin ingin membatalkan seluruh pesanan dalam invoice ini?')">
                                                      <i class="fas fa-times me-1"></i> Batal
                                                  </a>
                                              <?php endif; ?>
                                              
                                              <button 
                                                  class="btn btn-sm btn-outline-secondary rounded-pill px-3 btn-detail" 
                                                  data-invoice='<?= json_encode($inv, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'
                                                  data-tab="berlangsung"
                                                  data-bs-toggle="modal" 
                                                  data-bs-target="#detailModal"
                                              >
                                                  <i class="fas fa-info-circle me-1"></i> Detail
                                              </button>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      <?php endforeach; ?>
                  </div>
              <?php else: ?>
                  <div class="card p-5 text-center rounded-4 border-0 shadow-sm">
                      <i class="fas fa-box-open fs-1 text-muted mb-3"></i>
                      <h4 class="fw-bold mb-1">Belum Ada Sewa Berlangsung</h4>
                      <p class="text-muted mb-0">Perlengkapan yang sedang Anda sewa akan tampil pada daftar ini.</p>
                  </div>
              <?php endif; ?>
          </div>

          <!-- 2. TAB SEWA SELESAI -->
          <div class="tab-pane fade" id="selesai" role="tabpanel">
              <?php if (count($sewa_selesai_list) > 0): ?>
                  <div class="row g-3">
                      <?php foreach ($sewa_selesai_list as $inv): ?>
                          <div class="col-12">
                              <div class="order-history-card">
                                  <div class="d-flex flex-column align-items-center gap-1 flex-shrink-0">
                                      <img src="admin/uploads/alat/<?= htmlspecialchars($inv['items'][0]['gambar']) ?>" alt="<?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>" class="order-thumb-img" />
                                      <?php if (count($inv['items']) > 1): ?>
                                          <span class="badge bg-light text-dark border small mt-1">+<?= count($inv['items']) - 1 ?> Alat Lain</span>
                                      <?php endif; ?>
                                  </div>
                                  
                                  <div class="order-content-main flex-grow-1">
                                      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                          <div class="d-flex align-items-center gap-2">
                                              <span class="badge bg-light text-primary border fw-bold px-3 py-2 rounded-pill font-monospace">
                                                  <i class="fas fa-receipt me-1"></i> <?= $inv['no_tagihan'] ?>
                                              </span>
                                              <span class="badge bg-success px-3 py-2 rounded-pill small">Selesai</span>
                                          </div>
                                          <span class="text-muted small">
                                              <i class="fas fa-check-circle text-success me-1"></i> Dikembalikan: <strong><?= htmlspecialchars($inv['tanggal_dikembalikan'] ?? '-') ?></strong>
                                          </span>
                                      </div>

                                      <h5 class="order-item-title mb-2 fw-bold text-dark">
                                          <?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>
                                          <?php if (count($inv['items']) > 1): ?>
                                              <span class="text-muted fw-normal fs-6">dan <?= count($inv['items']) - 1 ?> alat lainnya</span>
                                          <?php endif; ?>
                                      </h5>

                                      <!-- Mini List of Items -->
                                      <div class="bg-light p-2 rounded-3 border mb-2">
                                          <div class="row g-2">
                                              <?php foreach ($inv['items'] as $it): ?>
                                                  <div class="col-sm-6 d-flex align-items-center gap-2">
                                                      <img src="admin/uploads/alat/<?= $it['gambar'] ?>" alt="alat" style="width: 28px; height: 28px; object-fit: cover; border-radius: 4px;" class="border flex-shrink-0">
                                                      <span class="small text-dark fw-semibold text-truncate"><?= htmlspecialchars($it['nama_produk']) ?></span>
                                                      <span class="badge bg-white text-dark border small ms-auto">x<?= $it['qty'] ?></span>
                                                  </div>
                                              <?php endforeach; ?>
                                          </div>
                                      </div>
                                      
                                      <div class="row g-2 text-muted small mb-2">
                                          <div class="col-sm-6">
                                              <span>Total Alat: <strong><?= $inv['total_qty'] ?> unit</strong> &bull; Durasi: <strong><?= $inv['durasi'] ?> hari</strong></span>
                                          </div>
                                          <div class="col-sm-6">
                                              <span>Metode: <strong><?= htmlspecialchars($inv['metode_pengambilan']) ?></strong></span>
                                          </div>
                                      </div>
                                      
                                      <div class="d-flex flex-wrap justify-content-between align-items-center pt-2 border-top gap-2">
                                          <div>
                                              <small class="text-muted d-block" style="font-size: 0.78rem;">Total Transaksi</small>
                                              <span class="fw-bold fs-5 text-success">Rp<?= number_format($inv['total_biaya'], 0, ',', '.') ?></span>
                                          </div>

                                          <button 
                                              class="btn btn-sm btn-outline-secondary rounded-pill px-3 btn-detail" 
                                              data-invoice='<?= json_encode($inv, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'
                                              data-tab="selesai"
                                              data-bs-toggle="modal" 
                                              data-bs-target="#detailModal"
                                          >
                                              <i class="fas fa-info-circle me-1"></i> Detail
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      <?php endforeach; ?>
                  </div>
              <?php else: ?>
                  <div class="card p-5 text-center rounded-4 border-0 shadow-sm">
                      <i class="fas fa-check-double fs-1 text-muted mb-3"></i>
                      <h4 class="fw-bold mb-1">Belum Ada Sewa yang Selesai</h4>
                      <p class="text-muted mb-0">Pesanan yang telah selesai dan dikembalikan akan masuk ke arsip ini.</p>
                  </div>
              <?php endif; ?>
          </div>

          <!-- 3. TAB SEWA DIBATALKAN -->
          <div class="tab-pane fade" id="dibatalkan" role="tabpanel">
              <?php if (count($sewa_dibatalkan_list) > 0): ?>
                  <div class="row g-3">
                      <?php foreach ($sewa_dibatalkan_list as $inv): ?>
                          <div class="col-12">
                              <div class="order-history-card">
                                  <div class="d-flex flex-column align-items-center gap-1 flex-shrink-0">
                                      <img src="admin/uploads/alat/<?= htmlspecialchars($inv['items'][0]['gambar']) ?>" alt="<?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>" class="order-thumb-img" />
                                      <?php if (count($inv['items']) > 1): ?>
                                          <span class="badge bg-light text-dark border small mt-1">+<?= count($inv['items']) - 1 ?> Alat Lain</span>
                                      <?php endif; ?>
                                  </div>
                                  
                                  <div class="order-content-main flex-grow-1">
                                      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
                                          <div class="d-flex align-items-center gap-2">
                                              <span class="badge bg-light text-primary border fw-bold px-3 py-2 rounded-pill font-monospace">
                                                  <i class="fas fa-receipt me-1"></i> <?= $inv['no_tagihan'] ?>
                                              </span>
                                              <span class="badge bg-danger px-3 py-2 rounded-pill small">Dibatalkan</span>
                                          </div>
                                          <span class="text-muted small">
                                              <i class="fas fa-times-circle text-danger me-1"></i> Dibatalkan: <strong><?= htmlspecialchars($inv['dibatalkan_pada'] ?? '-') ?></strong>
                                          </span>
                                      </div>

                                      <h5 class="order-item-title mb-2 fw-bold text-dark">
                                          <?= htmlspecialchars($inv['items'][0]['nama_produk']) ?>
                                          <?php if (count($inv['items']) > 1): ?>
                                              <span class="text-muted fw-normal fs-6">dan <?= count($inv['items']) - 1 ?> alat lainnya</span>
                                          <?php endif; ?>
                                      </h5>

                                      <!-- Mini List of Items -->
                                      <div class="bg-light p-2 rounded-3 border mb-2">
                                          <div class="row g-2">
                                              <?php foreach ($inv['items'] as $it): ?>
                                                  <div class="col-sm-6 d-flex align-items-center gap-2">
                                                      <img src="admin/uploads/alat/<?= $it['gambar'] ?>" alt="alat" style="width: 28px; height: 28px; object-fit: cover; border-radius: 4px;" class="border flex-shrink-0">
                                                      <span class="small text-dark fw-semibold text-truncate"><?= htmlspecialchars($it['nama_produk']) ?></span>
                                                      <span class="badge bg-white text-dark border small ms-auto">x<?= $it['qty'] ?></span>
                                                  </div>
                                              <?php endforeach; ?>
                                          </div>
                                      </div>
                                      
                                      <div class="row g-2 text-muted small mb-2">
                                          <div class="col-sm-6">
                                              <span>Total Alat: <strong><?= $inv['total_qty'] ?> unit</strong> &bull; Durasi: <strong><?= $inv['durasi'] ?> hari</strong></span>
                                          </div>
                                          <div class="col-sm-6">
                                              <span>Metode: <strong><?= htmlspecialchars($inv['metode_pengambilan']) ?></strong></span>
                                          </div>
                                      </div>
                                      
                                      <div class="d-flex flex-wrap justify-content-between align-items-center pt-2 border-top gap-2">
                                          <div>
                                              <small class="text-muted d-block" style="font-size: 0.78rem;">Nominal Pemesanan</small>
                                              <span class="fw-bold fs-5 text-secondary">Rp<?= number_format($inv['total_biaya'], 0, ',', '.') ?></span>
                                          </div>

                                          <button 
                                              class="btn btn-sm btn-outline-secondary rounded-pill px-3 btn-detail" 
                                              data-invoice='<?= json_encode($inv, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'
                                              data-tab="dibatalkan"
                                              data-bs-toggle="modal" 
                                              data-bs-target="#detailModal"
                                          >
                                              <i class="fas fa-info-circle me-1"></i> Detail
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      <?php endforeach; ?>
                  </div>
              <?php else: ?>
                  <div class="card p-5 text-center rounded-4 border-0 shadow-sm">
                      <i class="fas fa-ban fs-1 text-muted mb-3"></i>
                      <h4 class="fw-bold mb-1">Tidak Ada Sewa Dibatalkan</h4>
                      <p class="text-muted mb-0">Riwayat pesanan yang dibatalkan akan tercatat di sini.</p>
                  </div>
              <?php endif; ?>
          </div>
      </div>

    </div>
  </section>

  <!-- Modal Detail Sewa -->
  <div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
      <div class="modal-content rounded-4 border-0 shadow">
        <div class="modal-header bg-dark text-white" style="background-color: var(--brand-teal) !important;">
          <h5 class="modal-title fw-bold" id="detailModalLabel"><i class="fas fa-receipt me-2 text-warning"></i> Rincian Lengkap Riwayat Sewa</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body p-4" id="detailContent">
          <!-- Konten modal diisi via JS -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script>
  document.querySelectorAll('.btn-detail').forEach(btn => {
      btn.addEventListener('click', () => {
          const inv = JSON.parse(btn.getAttribute('data-invoice'));
          const tab = btn.getAttribute('data-tab');
          
          let itemsHtml = '';
          inv.items.forEach(it => {
              const hg = parseFloat(it.harga_per_hari) || 0;
              const sub = parseFloat(it.subtotal_item) || 0;
              itemsHtml += `
                  <tr>
                      <td class="text-center">
                          <img src="admin/uploads/alat/${it.gambar}" alt="Foto Alat" style="width: 38px; height: 38px; object-fit: cover; border-radius: 6px;" class="border" />
                      </td>
                      <td><strong>${it.nama_produk}</strong></td>
                      <td class="text-center fw-bold">${it.qty}</td>
                      <td class="text-end">Rp${hg.toLocaleString('id-ID')}</td>
                      <td class="text-end fw-bold text-success">Rp${sub.toLocaleString('id-ID')}</td>
                  </tr>
              `;
          });

          let statusBadge = 'bg-secondary';
          if (inv.status === 'Menunggu pembayaran') statusBadge = 'bg-warning text-dark';
          else if (inv.status === 'Berlangsung') statusBadge = 'bg-primary';
          else if (inv.status === 'Siap di ambil' || inv.status === 'di antar') statusBadge = 'bg-info text-dark';
          else if (inv.status === 'selesai' || inv.status === 'Selesai') statusBadge = 'bg-success';
          else if (inv.status === 'dibatalkan' || inv.status === 'Dibatalkan') statusBadge = 'bg-danger';

          let html = `
              <div class="p-3 bg-light rounded-3 border mb-3">
                  <div class="row g-2 small">
                      <div class="col-sm-6"><strong>Nomor Tagihan:</strong> <span class="text-primary fw-bold">${inv.no_tagihan}</span></div>
                      <div class="col-sm-6"><strong>Status:</strong> <span class="badge ${statusBadge}">${inv.status}</span></div>
                      <div class="col-sm-6"><strong>Tanggal Sewa:</strong> ${inv.tanggal_sewa}</div>
                      <div class="col-sm-6"><strong>Durasi Sewa:</strong> ${inv.durasi} hari</div>
                      <div class="col-sm-6"><strong>Metode Pengambilan:</strong> ${inv.metode_pengambilan}</div>
                      <div class="col-sm-6"><strong>Total Unit:</strong> ${inv.total_qty} unit</div>
                  </div>
              </div>

              <h6 class="fw-bold mb-2 text-dark"><i class="fas fa-boxes me-1 text-primary"></i> Daftar Alat dalam Tagihan Ini:</h6>
              <div class="table-responsive mb-3">
                  <table class="table table-bordered table-hover align-middle mb-0 small">
                      <thead class="table-light text-center">
                          <tr>
                              <th style="width: 50px;">Foto</th>
                              <th>Nama Produk</th>
                              <th style="width: 60px;">Qty</th>
                              <th style="width: 100px;">Harga Satuan</th>
                              <th style="width: 110px;">Subtotal</th>
                          </tr>
                      </thead>
                      <tbody>
                          ${itemsHtml}
                      </tbody>
                  </table>
              </div>

              <div class="p-3 bg-white rounded-3 border mb-3">
                  <div class="d-flex justify-content-between small text-muted mb-1">
                      <span>Biaya Pengambilan / Ongkir:</span>
                      <span>Rp${parseFloat(inv.total_ongkir).toLocaleString('id-ID')}</span>
                  </div>
                  <hr class="my-2">
                  <div class="d-flex justify-content-between align-items-center">
                      <span class="fw-bold fs-6 text-dark">Total Tagihan Transaksi:</span>
                      <span class="fw-bold text-success fs-5">Rp${parseFloat(inv.total_biaya).toLocaleString('id-ID')}</span>
                  </div>
              </div>
          `;

          if (tab === 'selesai' && inv.tanggal_dikembalikan) {
              html += `<div class="alert alert-success small py-2 mb-2"><i class="fas fa-check-circle me-1"></i> Dikembalikan pada: ${inv.tanggal_dikembalikan}</div>`;
          }

          if (tab === 'dibatalkan' && inv.dibatalkan_pada) {
              html += `<div class="alert alert-danger small py-2 mb-2"><i class="fas fa-ban me-1"></i> Dibatalkan pada: ${inv.dibatalkan_pada}</div>`;
          }

          html += `
              <div class="small text-muted border-top pt-2">
                  <div><strong>Nama Akun:</strong> ${inv.nama}</div>
                  <div><strong>Email:</strong> ${inv.email}</div>
              </div>
          `;

          document.getElementById('detailContent').innerHTML = html;
      });
  });
  </script>
</body>
</html>
