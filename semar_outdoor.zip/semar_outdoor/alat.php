<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include './koneksi.php';

$is_logged_in = isset($_SESSION['id_users']);

// Query menghitung sisa stok dinamis real-time berdasarkan seluruh pesanan aktif
$query = "
    SELECT 
        a.*,
        GREATEST(0, a.stok_awal - IFNULL(SUM(
            CASE 
                WHEN s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai') THEN s.qty 
                ELSE 0 
            END
        ), 0)) AS sisa_stok_dinamis
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat
    GROUP BY a.id
    ORDER BY a.id DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Katalog Alat Rental - Semar Outdoor</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

  <style>
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
      scroll-behavior: smooth;
    }

    /* ========================================================= */
    /* 🌟 HERO / HEADER CATALOG */
    /* ========================================================= */
    .catalog-header {
      background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
      color: #ffffff;
      padding: 120px 20px 50px;
      position: relative;
      overflow: hidden;
    }

    .catalog-header::before {
      content: "";
      position: absolute;
      top: -40%;
      right: -10%;
      width: 400px;
      height: 400px;
      background: radial-gradient(circle, rgba(255, 218, 121, 0.1) 0%, transparent 70%);
      pointer-events: none;
    }

    .catalog-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(2rem, 4vw, 2.8rem);
      font-weight: 800;
      letter-spacing: -0.5px;
      margin-bottom: 10px;
    }

    .catalog-subtitle {
      color: #cbd5e1;
      font-size: 1.05rem;
      max-width: 650px;
      margin: 0 auto 30px;
      line-height: 1.6;
    }

    /* Search & Filter Bar */
    .search-filter-box {
      max-width: 720px;
      margin: 0 auto;
      background: rgba(255, 255, 255, 0.12);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.22);
      border-radius: 50px;
      padding: 6px 10px 6px 20px;
      display: flex;
      align-items: center;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.18);
    }

    .search-input {
      background: transparent;
      border: none;
      color: #ffffff;
      font-size: 0.95rem;
      width: 100%;
      padding: 8px 10px;
      outline: none;
    }

    .search-input::placeholder {
      color: #cbd5e1;
    }

    .btn-search-icon {
      background: var(--brand-gold);
      border: none;
      color: #ffffff;
      width: 42px;
      height: 42px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1rem;
      flex-shrink: 0;
      transition: all 0.2s ease;
    }

    .btn-search-icon:hover {
      background: #d97706;
      transform: scale(1.05);
    }

    /* Quick Filter Chips */
    .filter-chips-wrapper {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 10px;
      margin-top: 24px;
    }

    .chip-btn {
      background: rgba(255, 255, 255, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: #ffffff;
      padding: 6px 16px;
      border-radius: 50px;
      font-size: 0.85rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .chip-btn:hover, .chip-btn.active {
      background: #ffffff;
      color: var(--brand-teal);
      border-color: #ffffff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      transform: translateY(-2px);
    }

    /* ========================================================= */
    /* 🌟 CATALOG CONTENT & GRID */
    /* ========================================================= */
    .catalog-content-section {
      padding: 50px 0 80px;
    }

    .catalog-status-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 28px;
      padding-bottom: 14px;
      border-bottom: 1px solid rgba(0,0,0,0.06);
    }

    .catalog-count-text {
      font-size: 0.95rem;
      font-weight: 600;
      color: var(--text-muted);
    }

    .catalog-count-text strong {
      color: var(--brand-teal);
    }

    .alat-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(270px, 1fr));
      gap: 26px;
    }

    /* Product Card */
    .alat-card {
      background: #ffffff;
      border-radius: 18px;
      overflow: hidden;
      border: 1px solid rgba(0, 0, 0, 0.06);
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.04);
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      display: flex;
      flex-direction: column;
      height: 100%;
      position: relative;
    }

    .alat-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 16px 32px rgba(0, 0, 0, 0.09);
      border-color: rgba(194, 120, 3, 0.35);
    }

    .alat-media {
      position: relative;
      width: 100%;
      height: 200px;
      overflow: hidden;
      background: #f1f5f9;
    }

    .alat-media img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.45s ease;
    }

    .alat-card:hover .alat-media img {
      transform: scale(1.08);
    }

    .badge-stock {
      position: absolute;
      top: 12px;
      left: 12px;
      background: rgba(14, 68, 48, 0.92);
      backdrop-filter: blur(4px);
      color: #ffffff;
      font-size: 0.75rem;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 6px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.15);
    }

    .badge-stock.empty {
      background: rgba(100, 116, 139, 0.92);
    }

    .badge-condition {
      position: absolute;
      top: 12px;
      right: 12px;
      background: rgba(255, 255, 255, 0.92);
      backdrop-filter: blur(4px);
      color: var(--brand-dark);
      font-size: 0.72rem;
      font-weight: 700;
      padding: 4px 8px;
      border-radius: 6px;
      border: 1px solid rgba(0,0,0,0.06);
    }

    .alat-body {
      padding: 20px;
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .alat-title {
      font-size: 1.15rem;
      font-weight: 700;
      color: var(--brand-teal);
      margin-bottom: 8px;
      line-height: 1.35;
      font-family: 'Quicksand', sans-serif;
    }

    .alat-desc {
      font-size: 0.88rem;
      color: var(--text-muted);
      margin-bottom: 16px;
      line-height: 1.5;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
      min-height: 40px;
    }

    .alat-pricing-box {
      margin-top: auto;
      margin-bottom: 16px;
      padding-top: 12px;
      border-top: 1px dashed rgba(0, 0, 0, 0.08);
      display: flex;
      align-items: baseline;
      justify-content: space-between;
    }

    .alat-price {
      font-size: 1.28rem;
      font-weight: 800;
      color: var(--brand-gold);
    }

    .alat-price-unit {
      font-size: 0.82rem;
      color: var(--text-muted);
      font-weight: 500;
    }

    /* Qty Stepper & Add Button */
    .action-row {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .qty-stepper {
      display: inline-flex;
      align-items: center;
      background: #f1f5f9;
      border-radius: 10px;
      padding: 2px;
      border: 1px solid #e2e8f0;
      width: 100px;
      flex-shrink: 0;
    }

    .qty-btn {
      width: 28px;
      height: 32px;
      background: transparent;
      border: none;
      font-weight: 700;
      color: var(--text-main);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background 0.2s ease;
      border-radius: 6px;
    }

    .qty-btn:hover {
      background: rgba(0,0,0,0.06);
    }

    .qty-input {
      width: 40px;
      height: 32px;
      border: none;
      background: transparent;
      text-align: center;
      font-weight: 700;
      font-size: 0.9rem;
      color: var(--brand-dark);
      outline: none;
    }

    .btn-add-cart {
      flex: 1;
      background: var(--brand-teal);
      color: #ffffff;
      border: none;
      border-radius: 10px;
      padding: 10px 14px;
      font-size: 0.92rem;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: all 0.25s ease;
      cursor: pointer;
      text-decoration: none;
      height: 38px;
    }

    .btn-add-cart:hover {
      background: var(--brand-gold);
      color: #ffffff;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(194, 120, 3, 0.35);
    }

    .btn-out-stock {
      width: 100%;
      background: #94a3b8;
      color: #ffffff;
      border: none;
      border-radius: 10px;
      padding: 10px;
      font-size: 0.92rem;
      font-weight: 600;
      cursor: not-allowed;
      height: 38px;
    }

    /* Empty State */
    .empty-state-box {
      text-align: center;
      padding: 60px 20px;
      background: #ffffff;
      border-radius: 18px;
      border: 1px dashed rgba(0,0,0,0.1);
      margin-top: 20px;
    }

    .empty-state-icon {
      font-size: 3rem;
      color: var(--text-muted);
      margin-bottom: 16px;
    }

    /* ========================================================= */
    /* 🌟 MODAL LOGIN */
    /* ========================================================= */
    .modal-content {
      border-radius: 20px;
      overflow: hidden;
    }

    .modal-header-custom {
      background: var(--brand-teal);
      color: #ffffff;
      padding: 20px 24px;
      border-bottom: none;
    }

    /* ========================================================= */
    /* 🌟 FOOTER */
    /* ========================================================= */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 65px;
    }

    .footer-brand-logo {
      height: 42px;
      width: auto;
      max-height: 42px;
      object-fit: contain;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: 0.4px;
    }

    .footer-title {
      color: #ffffff;
      font-size: 1.05rem;
      font-weight: 700;
      margin-bottom: 18px;
      position: relative;
      padding-bottom: 8px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 32px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 10px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-links-list a:hover {
      color: #fde047;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 4px;
    }

    .footer-contact-item a {
      color: #cbd5e1;
      text-decoration: none;
    }

    .footer-contact-item a:hover {
      color: #fde047;
    }

    .footer-map-container {
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 170px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 20px 0;
      margin-top: 50px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.85rem;
      color: #64748b;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- 1. Header Banner & Search -->
  <section class="catalog-header text-center">
    <div class="container">
      <h1 class="catalog-title">Katalog Alat Outdoor</h1>
      <p class="catalog-subtitle">
        Temukan perlengkapan camping dan mendaki terbaik dalam kondisi bersih, steril, dan 100% siap pakai.
      </p>

      <!-- Live Search Box -->
      <div class="search-filter-box">
        <i class="fas fa-search text-warning me-2"></i>
        <input type="text" id="searchInput" class="search-input" placeholder="Cari nama alat (misal: Tenda, Sleeping Bag, Kompor, Jaket)..." onkeyup="filterAlat()">
        <button class="btn-search-icon" type="button" aria-label="Cari">
          <i class="fas fa-arrow-right"></i>
        </button>
      </div>

      <!-- Quick Category Filter Chips -->
      <div class="filter-chips-wrapper">
        <button class="chip-btn active" onclick="setCategoryFilter('all', this)"><i class="fas fa-border-all"></i> Semua</button>
        <button class="chip-btn" onclick="setCategoryFilter('tenda', this)"><i class="fas fa-campground"></i> Tenda</button>
        <button class="chip-btn" onclick="setCategoryFilter('sleeping', this)"><i class="fas fa-bed"></i> Sleeping Bag</button>
        <button class="chip-btn" onclick="setCategoryFilter('kompor', this)"><i class="fas fa-fire"></i> Kompor & Gas</button>
        <button class="chip-btn" onclick="setCategoryFilter('kursi', this)"><i class="fas fa-chair"></i> Kursi & Matras</button>
        <button class="chip-btn" onclick="setCategoryFilter('tersedia', this)"><i class="fas fa-check-circle"></i> Stok Tersedia</button>
      </div>
    </div>
  </section>

  <!-- 2. Grid Katalog Alat -->
  <section class="catalog-content-section">
    <div class="container">
      
      <div class="catalog-status-bar">
        <div class="catalog-count-text">
          Menampilkan <strong id="itemCount">0</strong> perlengkapan
        </div>
        <div class="text-muted small">
          <i class="fas fa-shield-alt text-success me-1"></i> Jaminan Alat Terawat & Steril
        </div>
      </div>

      <div class="alat-grid" id="alatGrid">
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): 
            $sisa_stok = (int)$row['sisa_stok_dinamis'];
            $namaAlat = htmlspecialchars($row['nama']);
            $deskripsi = htmlspecialchars($row['deskripsi'] ?? '');
            $harga = (int)$row['harga_per_hari'];
          ?>
            <div class="alat-card item-card" data-nama="<?= strtolower($namaAlat) ?>" data-deskripsi="<?= strtolower($deskripsi) ?>" data-stok="<?= $sisa_stok ?>">
              
              <div class="alat-media">
                <?php
                $gambarPath = 'admin/uploads/alat/' . $row['gambar'];
                if (!empty($row['gambar']) && file_exists($gambarPath)): ?>
                  <img src="<?= $gambarPath ?>" alt="<?= $namaAlat ?>">
                <?php else: ?>
                  <img src="https://via.placeholder.com/300x200?text=Semar+Outdoor" alt="<?= $namaAlat ?>">
                <?php endif; ?>

                <!-- Badge Sisa Stok -->
                <?php if ($sisa_stok > 0): ?>
                  <span class="badge-stock">
                    <i class="fas fa-check me-1"></i> Tersedia: <?= $sisa_stok ?>
                  </span>
                <?php else: ?>
                  <span class="badge-stock empty">
                    <i class="fas fa-times me-1"></i> Stok Habis
                  </span>
                <?php endif; ?>

                <span class="badge-condition">Siap Pakai</span>
              </div>

              <div class="alat-body">
                <h4 class="alat-title"><?= $namaAlat ?></h4>
                <p class="alat-desc"><?= !empty($deskripsi) ? $deskripsi : 'Perlengkapan outdoor berkualitas prima untuk kenyamanan camping Anda.' ?></p>
                
                <div class="alat-pricing-box">
                  <div>
                    <span class="alat-price">Rp<?= number_format($harga, 0, ',', '.') ?></span>
                    <span class="alat-price-unit">/ hari</span>
                  </div>
                </div>

                <?php if ($sisa_stok <= 0): ?>
                  <!-- Stok Habis -->
                  <button class="btn-out-stock" disabled>
                    <i class="fas fa-ban me-1"></i> Stok Habis
                  </button>
                <?php elseif (!$is_logged_in): ?>
                  <!-- Belum Login -->
                  <button class="btn-add-cart w-100" data-bs-toggle="modal" data-bs-target="#loginModal">
                    <i class="fas fa-cart-plus"></i> Masukkan Keranjang
                  </button>
                <?php else: ?>
                  <!-- Form Tambah ke Keranjang dengan Stepper -->
                  <form action="proses_sewa.php" method="POST" class="m-0">
                    <input type="hidden" name="id_alat" value="<?= $row['id'] ?>">
                    
                    <div class="action-row">
                      <div class="qty-stepper">
                        <button type="button" class="qty-btn" onclick="decreaseQty(this)">-</button>
                        <input type="number" name="jumlah" class="qty-input" value="1" min="1" max="<?= $sisa_stok ?>" readonly>
                        <button type="button" class="qty-btn" onclick="increaseQty(this, <?= $sisa_stok ?>)">+</button>
                      </div>
                      
                      <button type="submit" class="btn-add-cart">
                        <i class="fas fa-cart-plus"></i> Sewa
                      </button>
                    </div>
                  </form>
                <?php endif; ?>

              </div>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>

      <!-- No Match State -->
      <div id="noMatchBox" class="empty-state-box d-none">
        <i class="fas fa-search empty-state-icon"></i>
        <h4 class="fw-bold mb-2">Alat Tidak Ditemukan</h4>
        <p class="text-muted mb-3">Tidak ada perlengkapan yang cocok dengan kata kunci pencarian Anda.</p>
        <button class="btn btn-outline-dark rounded-pill px-4" onclick="resetSearch()">Lihat Semua Alat</button>
      </div>

    </div>
  </section>

  <!-- 3. Modal Login Diperlukan -->
  <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow">
        <div class="modal-header-custom d-flex justify-content-between align-items-center">
          <div class="d-flex align-items-center gap-2">
            <i class="fas fa-user-lock fs-5 text-warning"></i>
            <h5 class="modal-title mb-0 fw-bold" id="loginModalLabel">Login Diperlukan</h5>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body text-center p-4">
          <div class="mb-3">
            <div class="mx-auto bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 70px; height: 70px;">
              <i class="fas fa-shopping-basket fs-2 text-success"></i>
            </div>
          </div>
          <h5 class="fw-bold mb-2">Yuk, Masuk ke Akun Anda!</h5>
          <p class="text-muted mb-4 small">
            Anda perlu login terlebih dahulu untuk menambahkan perlengkapan ke keranjang dan melanjutkan proses pemesanan sewa.
          </p>
          <div class="d-grid gap-2">
            <a href="login.php" class="btn btn-dark py-2 fw-bold" style="background-color: var(--brand-teal); border-radius: 10px;">
              <i class="fas fa-sign-in-alt me-1"></i> Login Sekarang
            </a>
            <a href="register.php" class="btn btn-outline-secondary py-2 fw-semibold" style="border-radius: 10px;">
              Belum punya akun? Daftar
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 4. Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <!-- Kolom Brand & Logo (Ukuran persis sama dengan navbar: 42px) -->
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <!-- Kolom Menu Navigasi -->
        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <!-- Kolom Kontak -->
        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <!-- Kolom Lokasi Toko -->
        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    // Update Item Count on Load
    function updateItemCount() {
      const items = document.querySelectorAll('.item-card:not(.d-none)');
      const countElem = document.getElementById('itemCount');
      if (countElem) countElem.innerText = items.length;

      const noMatchBox = document.getElementById('noMatchBox');
      if (noMatchBox) {
        if (items.length === 0) {
          noMatchBox.classList.remove('d-none');
        } else {
          noMatchBox.classList.add('d-none');
        }
      }
    }

    // Live Search Filter
    function filterAlat() {
      const input = document.getElementById('searchInput').value.toLowerCase().trim();
      const items = document.querySelectorAll('.item-card');

      items.forEach(card => {
        const nama = card.getAttribute('data-nama') || '';
        const deskripsi = card.getAttribute('data-deskripsi') || '';
        
        if (nama.includes(input) || deskripsi.includes(input)) {
          card.classList.remove('d-none');
        } else {
          card.classList.add('d-none');
        }
      });

      updateItemCount();
    }

    // Category Chip Filter
    function setCategoryFilter(category, btnElement) {
      // Update active state on chips
      document.querySelectorAll('.chip-btn').forEach(btn => btn.classList.remove('active'));
      if (btnElement) btnElement.classList.add('active');

      const items = document.querySelectorAll('.item-card');
      const searchInput = document.getElementById('searchInput');
      if (searchInput) searchInput.value = '';

      items.forEach(card => {
        const nama = card.getAttribute('data-nama') || '';
        const stok = parseInt(card.getAttribute('data-stok') || '0', 10);

        if (category === 'all') {
          card.classList.remove('d-none');
        } else if (category === 'tersedia') {
          if (stok > 0) {
            card.classList.remove('d-none');
          } else {
            card.classList.add('d-none');
          }
        } else {
          if (nama.includes(category)) {
            card.classList.remove('d-none');
          } else {
            card.classList.add('d-none');
          }
        }
      });

      updateItemCount();
    }

    function resetSearch() {
      const searchInput = document.getElementById('searchInput');
      if (searchInput) searchInput.value = '';
      setCategoryFilter('all', document.querySelector('.chip-btn'));
    }

    // Quantity Stepper Handlers
    function increaseQty(btn, maxStok) {
      const input = btn.parentElement.querySelector('.qty-input');
      let val = parseInt(input.value, 10) || 1;
      if (val < maxStok) {
        input.value = val + 1;
      }
    }

    function decreaseQty(btn) {
      const input = btn.parentElement.querySelector('.qty-input');
      let val = parseInt(input.value, 10) || 1;
      if (val > 1) {
        input.value = val - 1;
      }
    }

    document.addEventListener("DOMContentLoaded", function() {
      updateItemCount();

      // Check URL parameters for SweetAlert notification
      <?php if (isset($_SESSION['error'])): ?>
        Swal.fire({
          icon: 'error',
          title: 'Pemberitahuan',
          text: '<?= addslashes($_SESSION['error']) ?>',
          confirmButtonColor: '#162d2f'
        });
        <?php unset($_SESSION['error']); ?>
      <?php endif; ?>

      <?php if (isset($_SESSION['success'])): ?>
        Swal.fire({
          icon: 'success',
          title: 'Berhasil',
          text: '<?= addslashes($_SESSION['success']) ?>',
          confirmButtonColor: '#162d2f'
        });
        <?php unset($_SESSION['success']); ?>
      <?php endif; ?>
    });
  </script>
</body>
</html>
