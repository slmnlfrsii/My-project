<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include './koneksi.php';

$is_logged_in = isset($_SESSION['id_users']);

// Query menghitung sisa stok dinamis real-time berdasarkan seluruh pesanan aktif
$query = "
    SELECT 
        a.*,
        GREATEST(0, a.stok_awal - IFNULL(SUM(
            CASE 
                WHEN s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai') THEN s.qty 
                ELSE 0 
            END
        ), 0)) AS sisa_stok_dinamis
    FROM alat a
    LEFT JOIN sewa s ON a.id = s.id_alat
    GROUP BY a.id
    ORDER BY a.id DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Katalog Alat Rental - Semar Outdoor</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

<style>
  :root {
    --brand-dark: #12282a;
    --brand-teal: #162d2f;
    --brand-green: #0e4430;
    --brand-gold: #c27803;
    --brand-gold-glow: #ffc107;
    --bg-body: #f8fafc;
    --text-main: #1e293b;
    --text-muted: #64748b;
  }

  * { box-sizing: border-box; }

  body {
    font-family: 'Plus Jakarta Sans', sans-serif;
    background-color: var(--bg-body);
    color: var(--text-main);
    overflow-x: hidden;
    scroll-behavior: smooth;
    padding-bottom: 0 !important;
  }

  /* HERO / HEADER CATALOG */
  .catalog-header {
    background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
    color: #ffffff;
    padding: 90px 16px 25px;
    position: relative;
    overflow: hidden;
  }

  .catalog-header::before {
    content: "";
    position: absolute;
    top: -40%;
    right: -10%;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(255, 218, 121, 0.1) 0%, transparent 70%);
    pointer-events: none;
  }

  .catalog-title {
    font-family: 'Quicksand', sans-serif;
    font-size: clamp(1.35rem, 4vw, 2.1rem);
    font-weight: 800;
    letter-spacing: -0.3px;
    margin-bottom: 6px;
  }

  .catalog-subtitle {
    color: #cbd5e1;
    font-size: clamp(0.8rem, 2.5vw, 0.9rem);
    max-width: 540px;
    margin: 0 auto 16px;
    line-height: 1.45;
  }

  /* Search & Filter Bar */
  .search-filter-box {
    max-width: 560px;
    margin: 0 auto;
    background: rgba(255, 255, 255, 0.12);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.22);
    border-radius: 40px;
    padding: 4px 6px 4px 14px;
    display: flex;
    align-items: center;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  }

  .search-input {
    background: transparent;
    border: none;
    color: #ffffff;
    font-size: 0.85rem;
    width: 100%;
    padding: 6px 8px;
    outline: none;
  }

  .search-input::placeholder { color: #cbd5e1; }

  .btn-search-icon {
    background: var(--brand-gold);
    border: none;
    color: #ffffff;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.82rem;
    flex-shrink: 0;
    transition: all 0.2s ease;
  }

  .btn-search-icon:hover {
    background: #d97706;
    transform: scale(1.05);
  }

  .filter-chips-wrapper {
    display: flex;
    flex-wrap: nowrap;
    justify-content: flex-start;
    gap: 8px;
    margin-top: 14px;
    overflow-x: auto;
    padding-bottom: 6px;
    -webkit-overflow-scrolling: touch;
    scrollbar-width: none;
  }

  .filter-chips-wrapper::-webkit-scrollbar {
    display: none;
  }

  @media (min-width: 768px) {
    .filter-chips-wrapper {
      flex-wrap: wrap;
      justify-content: center;
      overflow-x: visible;
    }
  }

  .chip-btn {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: #ffffff;
    padding: 5px 14px;
    border-radius: 30px;
    font-size: 0.76rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    white-space: nowrap;
    flex-shrink: 0;
  }

  .chip-btn:hover, .chip-btn.active {
    background: #ffffff;
    color: var(--brand-teal);
    border-color: #ffffff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.12);
  }

  /* CATALOG CONTENT & GRID RESPONSIVE */
  .catalog-content-section { 
    padding: 20px 0 80px !important;
  }

  .catalog-status-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 14px;
    padding-bottom: 8px;
    border-bottom: 1px solid rgba(0,0,0,0.06);
  }

  .catalog-count-text {
    font-size: 0.82rem;
    font-weight: 600;
    color: var(--text-muted);
  }

  .catalog-count-text strong { color: var(--brand-teal); }

  .alat-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
  }

  @media (min-width: 576px) {
    .alat-grid {
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 16px;
    }
  }

  .card-select-checkbox {
    position: absolute;
    top: 8px;
    right: 8px;
    z-index: 10;
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: var(--brand-gold);
  }

  /* Product Card */
  .alat-card {
    background: #ffffff;
    border-radius: 10px;
    overflow: hidden;
    border: 1px solid rgba(0, 0, 0, 0.08);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
    transition: all 0.2s ease;
    display: flex;
    flex-direction: column;
    height: 100%;
    position: relative;
  }

  .alat-card.selected {
    border-color: var(--brand-gold) !important;
    background-color: #fffdf5;
    box-shadow: 0 4px 12px rgba(194, 120, 3, 0.18);
  }

  .alat-media {
    position: relative;
    width: 100%;
    height: 120px;
    overflow: hidden;
    background: #f1f5f9;
    cursor: pointer;
  }

  @media (min-width: 576px) {
    .alat-media { height: 145px; }
  }

  .alat-media img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.35s ease;
  }

  /* Overlay Lingkaran "Habis" ala Shopee */
  .sold-out-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2;
  }

  .sold-out-badge {
    width: 65px;
    height: 65px;
    background: rgba(0, 0, 0, 0.72);
    color: #ffffff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.82rem;
    font-weight: 700;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
  }

  .zoom-icon-badge {
    position: absolute;
    bottom: 6px;
    right: 6px;
    background: rgba(14, 68, 48, 0.85);
    color: #ffffff;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.65rem;
    backdrop-filter: blur(4px);
    z-index: 3;
  }

  /* Status Badge Kompak & Ringkas */
  .badge-stock-inline {
    background: #dcfce7;
    color: #15803d;
    font-size: 0.60rem;
    font-weight: 700;
    padding: 1px 5px;
    border-radius: 3px;
    display: inline-flex;
    align-items: center;
    line-height: 1.2;
  }

  .badge-condition-inline {
    background: #fef3c7;
    color: #92400e;
    font-size: 0.60rem;
    font-weight: 700;
    padding: 1px 5px;
    border-radius: 3px;
    display: inline-flex;
    align-items: center;
    line-height: 1.2;
  }

  .alat-body {
    padding: 10px;
    display: flex;
    flex-direction: column;
    flex: 1;
  }

  .alat-title {
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--brand-teal);
    margin-bottom: 2px;
    line-height: 1.25;
    font-family: 'Quicksand', sans-serif;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 32px;
  }

  .alat-desc {
    font-size: 0.72rem;
    color: var(--text-muted);
    margin-bottom: 6px;
    line-height: 1.3;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
    min-height: 28px;
  }

  .alat-pricing-box {
    margin-top: auto;
    margin-bottom: 8px;
    padding-top: 6px;
    border-top: 1px dashed rgba(0, 0, 0, 0.08);
    display: flex;
    align-items: baseline;
    justify-content: space-between;
  }

  .alat-price {
    font-size: 0.92rem;
    font-weight: 800;
    color: var(--brand-gold);
  }

  .alat-price-unit {
    font-size: 0.68rem;
    color: var(--text-muted);
    font-weight: 500;
  }

  .action-row {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .qty-stepper {
    display: inline-flex;
    align-items: center;
    background: #f1f5f9;
    border-radius: 6px;
    padding: 1px;
    border: 1px solid #e2e8f0;
    width: 62px;
    flex-shrink: 0;
  }

  .qty-btn {
    width: 18px;
    height: 26px;
    background: transparent;
    border: none;
    font-weight: 700;
    color: var(--text-main);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-size: 0.70rem;
  }

  .qty-input {
    width: 24px;
    height: 26px;
    border: none;
    background: transparent;
    text-align: center;
    font-weight: 700;
    font-size: 0.75rem;
    color: var(--brand-dark);
    outline: none;
  }

  .btn-add-cart {
    flex: 1;
    background: var(--brand-teal);
    color: #ffffff;
    border: none;
    border-radius: 6px;
    padding: 4px 6px;
    font-size: 0.72rem;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 3px;
    transition: all 0.2s ease;
    cursor: pointer;
    text-decoration: none;
    height: 28px;
    white-space: nowrap;
  }

  .btn-add-cart:hover {
    background: var(--brand-gold);
    color: #ffffff;
  }

  .btn-out-stock {
    width: 100%;
    background: #94a3b8;
    color: #ffffff;
    border: none;
    border-radius: 6px;
    padding: 4px 6px;
    font-size: 0.72rem;
    font-weight: 600;
    cursor: not-allowed;
    height: 28px;
  }

  .bulk-action-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #162d2f;
    color: #ffffff;
    padding: 10px 16px;
    box-shadow: 0 -4px 20px rgba(0,0,0,0.2);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: space-between;
    transform: translateY(100%);
    transition: transform 0.3s ease-in-out;
  }

  .bulk-action-bar.show { transform: translateY(0); }

  .empty-state-box {
    text-align: center;
    padding: 30px 15px;
    background: #ffffff;
    border-radius: 12px;
    border: 1px dashed rgba(0,0,0,0.1);
    margin-top: 15px;
  }

  .empty-state-icon {
    font-size: 2rem;
    color: var(--text-muted);
    margin-bottom: 10px;
  }

  /* Footer Styling */
  footer {
    background: #0b1d1f;
    color: #e2e8f0;
    padding-top: 45px;
    margin-bottom: 0 !important;
  }

  .footer-brand-logo {
    height: 36px;
    width: auto;
    object-fit: contain;
  }

  .footer-brand-name {
    font-family: 'Quicksand', sans-serif;
    font-size: 1.15rem;
    font-weight: 800;
    color: #ffffff;
  }

  .footer-title {
    color: #ffffff;
    font-size: 0.95rem;
    font-weight: 700;
    margin-bottom: 14px;
    position: relative;
    padding-bottom: 6px;
  }

  .footer-title::after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 28px;
    height: 2px;
    background: #f59e0b;
    border-radius: 2px;
  }

  .footer-links-list {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .footer-links-list li { margin-bottom: 8px; }

  .footer-links-list a {
    color: #cbd5e1;
    text-decoration: none;
    font-size: 0.85rem;
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  .footer-contact-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    margin-bottom: 10px;
    font-size: 0.85rem;
    color: #cbd5e1;
  }

  .footer-contact-item i {
    color: #fde047;
    margin-top: 3px;
  }

  .footer-map-container {
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.1);
  }

  .footer-map-container iframe {
    display: block;
    width: 100%;
    height: 140px;
    border: 0;
  }

  .footer-copy-bar {
    background: #061112;
    padding: 16px 0;
    margin-top: 35px;
    border-top: 1px solid rgba(255, 255, 255, 0.06);
    text-align: center;
    font-size: 0.78rem;
    color: #64748b;
  }
</style>
</head>
<body>

  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- 1. Header Banner & Search -->
  <section class="catalog-header text-center">
    <div class="container px-3">
      <h1 class="catalog-title">Katalog Alat Outdoor</h1>
      <p class="catalog-subtitle">
        Perlengkapan camping & mendaki bersih, steril, dan 100% siap pakai.
      </p>

      <div class="search-filter-box">
        <i class="fas fa-search text-warning me-1"></i>
        <input type="text" id="searchInput" class="search-input" placeholder="Cari Tenda, Sleeping Bag, Kompor..." onkeyup="filterAlat()">
        <button class="btn-search-icon" type="button" aria-label="Cari">
          <i class="fas fa-arrow-right"></i>
        </button>
      </div>

      <div class="filter-chips-wrapper">
        <button class="chip-btn active" onclick="setCategoryFilter('all', this)"><i class="fas fa-border-all"></i> Semua</button>
        <button class="chip-btn" onclick="setCategoryFilter('tenda', this)"><i class="fas fa-campground"></i> Tenda</button>
        <button class="chip-btn" onclick="setCategoryFilter('sleeping', this)"><i class="fas fa-bed"></i> Sleeping Bag</button>
        <button class="chip-btn" onclick="setCategoryFilter('kompor', this)"><i class="fas fa-fire"></i> Kompor & Gas</button>
        <button class="chip-btn" onclick="setCategoryFilter('kursi', this)"><i class="fas fa-chair"></i> Kursi & Matras</button>
        <button class="chip-btn" onclick="setCategoryFilter('tersedia', this)"><i class="fas fa-check-circle"></i> Stok Tersedia</button>
      </div>
    </div>
  </section>

  <!-- Form Utama Katalog -->
  <form id="bulkCartForm" action="proses_sewa.php" method="POST">
    <input type="hidden" name="bulk_add" value="1">

    <!-- 2. Grid Katalog Alat -->
    <section class="catalog-content-section">
      <div class="container px-3">
        
        <div class="catalog-status-bar">
          <div class="catalog-count-text">
            Menampilkan <strong id="itemCount">0</strong> perlengkapan
          </div>
          <div class="text-muted small d-none d-sm-block">
            <i class="fas fa-shield-alt text-success me-1"></i> Terawat & Steril
          </div>
        </div>

        <div class="alat-grid" id="alatGrid">
          <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): 
              $sisa_stok = (int)$row['sisa_stok_dinamis'];
              $namaAlat = htmlspecialchars($row['nama']);
              $deskripsi = htmlspecialchars($row['deskripsi'] ?? '');
              $harga = (int)$row['harga_per_hari'];
            ?>
              <div class="alat-card item-card" id="card-<?= $row['id'] ?>" data-nama="<?= strtolower($namaAlat) ?>" data-deskripsi="<?= strtolower($deskripsi) ?>" data-stok="<?= $sisa_stok ?>">
                
                <!-- Checkbox Pilihan Banyak Alat -->
                <?php if ($sisa_stok > 0): ?>
                  <input type="checkbox" name="selected_items[]" value="<?= $row['id'] ?>" class="card-select-checkbox item-checkbox" onchange="toggleCardSelection(<?= $row['id'] ?>)">
                <?php endif; ?>

                <?php
                $gambarPath = 'admin/uploads/alat/' . $row['gambar'];
                $imgSrc = (!empty($row['gambar']) && file_exists($gambarPath)) ? $gambarPath : 'assets/images/tenda.jpg';
                ?>
                <div class="alat-media" onclick="showLightboxModal('<?= htmlspecialchars($imgSrc) ?>', '<?= htmlspecialchars($namaAlat) ?>', 'Rp<?= number_format($harga, 0, ',', '.') ?> / hari', <?= $sisa_stok ?>)" title="Klik untuk memperbesar foto">
                  <img src="<?= htmlspecialchars($imgSrc) ?>" alt="<?= $namaAlat ?>">
                  
                  <!-- Lingkaran Overlay "Habis" Saat Stok Kosong -->
                  <?php if ($sisa_stok <= 0): ?>
                    <div class="sold-out-overlay">
                      <div class="sold-out-badge">Habis</div>
                    </div>
                  <?php endif; ?>

                  <div class="zoom-icon-badge" title="Klik untuk perbesar"><i class="fas fa-search-plus"></i></div>
                </div>

                <div class="alat-body">
                  <h4 class="alat-title"><?= $namaAlat ?></h4>
                  
                  <p class="alat-desc"><?= !empty($deskripsi) ? $deskripsi : 'Perlengkapan outdoor berkualitas prima.' ?></p>
                      
                    <!-- Display Badge Ringkas Jika Stok Tersedia -->
                  <?php if ($sisa_stok > 0): ?>
                    <div class="d-flex align-items-center gap-1 mb-1.5">
                      <span class="badge-stock-inline">
                        <i class="fas fa-check me-1"></i> Stok Tersedia: <?= $sisa_stok ?>
                      </span>
                    </div>
                  <?php endif; ?>
                    
                  <div class="alat-pricing-box">
                    <div>
                      <span class="alat-price">Rp<?= number_format($harga, 0, ',', '.') ?></span>
                      <span class="alat-price-unit">/hari</span>
                    </div>
                  </div>

                  <?php if ($sisa_stok <= 0): ?>
                    <button type="button" class="btn-out-stock" disabled>
                      <i class="fas fa-ban me-1"></i> Stok Habis
                    </button>
                  <?php elseif (!$is_logged_in): ?>
                    <button type="button" class="btn-add-cart w-100" data-bs-toggle="modal" data-bs-target="#loginModal">
                      <i class="fas fa-cart-plus"></i> Sewa
                    </button>
                  <?php else: ?>
                    <div class="action-row">
                      <div class="qty-stepper">
                        <button type="button" class="qty-btn" onclick="decreaseQty(<?= $row['id'] ?>)">-</button>
                        <input type="number" name="jumlah[<?= $row['id'] ?>]" id="qty-<?= $row['id'] ?>" class="qty-input" value="1" min="1" max="<?= $sisa_stok ?>" readonly>
                        <button type="button" class="qty-btn" onclick="increaseQty(<?= $row['id'] ?>, <?= $sisa_stok ?>)">+</button>
                      </div>
                      
                      <button type="button" class="btn-add-cart" onclick="submitSingleItem(<?= $row['id'] ?>)">
                        <i class="fas fa-cart-plus"></i> Sewa
                      </button>
                    </div>
                  <?php endif; ?>

                </div>
              </div>
            <?php endwhile; ?>
          <?php endif; ?>
        </div>

        <!-- State Hasil Pencarian Kosong -->
        <div id="noMatchBox" class="empty-state-box d-none">
          <i class="fas fa-search empty-state-icon"></i>
          <h5 class="fw-bold mb-1 fs-6">Alat Tidak Ditemukan</h5>
          <p class="text-muted mb-3 small">Tidak ada perlengkapan yang cocok dengan kata kunci Anda.</p>
          <button type="button" class="btn btn-sm btn-outline-dark rounded-pill px-3" onclick="resetSearch()">Lihat Semua Alat</button>
        </div>

      </div>
    </section>

    <!-- Floating Bar saat Ada Centang Alat -->
    <div class="bulk-action-bar" id="bulkActionBar">
      <div class="container d-flex align-items-center justify-content-between px-2">
        <div>
          <span class="fw-bold fs-6 me-1" id="selectedCount">0</span> Alat Terpilih
        </div>
        <div>
          <?php if ($is_logged_in): ?>
            <button type="submit" class="btn btn-sm btn-warning fw-bold rounded-pill px-3">
              <i class="fas fa-cart-plus me-1"></i> Sewa Terpilih
            </button>
          <?php else: ?>
            <button type="button" class="btn btn-sm btn-warning fw-bold rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#loginModal">
              <i class="fas fa-cart-plus me-1"></i> Sewa Terpilih
            </button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </form>

  <!-- 3. Modal Login -->
  <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered px-3">
      <div class="modal-content border-0 shadow" style="border-radius: 16px; overflow: hidden;">
        <div class="p-3 text-white d-flex justify-content-between align-items-center" style="background: var(--brand-teal);">
          <div class="d-flex align-items-center gap-2">
            <i class="fas fa-user-lock fs-5 text-warning"></i>
            <h6 class="modal-title mb-0 fw-bold" id="loginModalLabel">Login Diperlukan</h6>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body text-center p-3">
          <div class="mb-2">
            <div class="mx-auto bg-light rounded-circle d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
              <i class="fas fa-shopping-basket fs-3 text-success"></i>
            </div>
          </div>
          <h6 class="fw-bold mb-1">Yuk, Masuk ke Akun Anda!</h6>
          <p class="text-muted mb-3 small">
            Anda perlu login terlebih dahulu untuk menyewa perlengkapan outdoor.
          </p>
          <div class="d-grid gap-2">
            <a href="login.php" class="btn btn-dark btn-sm py-2 fw-bold" style="background-color: var(--brand-teal); border-radius: 8px;">
              <i class="fas fa-sign-in-alt me-1"></i> Login Sekarang
            </a>
            <a href="register.php" class="btn btn-outline-secondary btn-sm py-2 fw-semibold" style="border-radius: 8px;">
              Belum punya akun? Daftar
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Lightbox Pratinjau Gambar Penuh -->
  <div class="modal fade" id="modalImageLightbox" tabindex="-1" aria-labelledby="lightboxTitleAlat" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg px-3">
      <div class="modal-content bg-dark text-white rounded-3 overflow-hidden">
        <div class="modal-header d-flex align-items-center justify-content-between py-2 px-3" style="background:#0e4430;">
          <div class="d-flex align-items-center gap-2">
            <i class="fas fa-search-plus text-warning"></i>
            <h6 class="modal-title mb-0 fw-bold text-white text-truncate" id="lightboxTitleAlat">Nama Perlengkapan</h6>
          </div>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="lightbox-img-wrapper text-center p-2" style="background:#020617; max-height:70vh;">
          <img id="lightboxImgAlat" src="" alt="Ukuran Penuh" style="max-width:100%; max-height:65vh; object-fit:contain;">
        </div>
        <div class="modal-footer d-flex align-items-center justify-content-between py-2 px-3 bg-dark border-top border-secondary">
          <div class="d-flex align-items-center gap-2">
            <span class="badge bg-warning text-dark fw-bold px-2 py-1" id="lightboxPriceAlat">Rp 0</span>
            <span class="badge bg-success px-2 py-1" id="lightboxStockAlat"><i class="fas fa-check-circle me-1"></i> Tersedia</span>
          </div>
          <button type="button" class="btn btn-sm btn-outline-light rounded-pill px-3" data-bs-dismiss="modal">
            Tutup
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    function toggleCardSelection(id) {
      const card = document.getElementById('card-' + id);
      const checkbox = card.querySelector('.item-checkbox');

      if (checkbox.checked) {
        card.classList.add('selected');
      } else {
        card.classList.remove('selected');
      }

      updateBulkBar();
    }

    function updateBulkBar() {
      const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
      const bulkBar = document.getElementById('bulkActionBar');
      const countLabel = document.getElementById('selectedCount');

      countLabel.innerText = checkedBoxes.length;

      if (checkedBoxes.length > 0) {
        bulkBar.classList.add('show');
      } else {
        bulkBar.classList.remove('show');
      }
    }

    function submitSingleItem(id) {
      document.querySelectorAll('.item-checkbox').forEach(cb => {
        cb.checked = false;
        cb.closest('.alat-card').classList.remove('selected');
      });
      
      const targetCheckbox = document.querySelector(`#card-${id} .item-checkbox`);
      if (targetCheckbox) {
        targetCheckbox.checked = true;
      }

      document.getElementById('bulkCartForm').submit();
    }

    function increaseQty(id, maxStok) {
      const input = document.getElementById('qty-' + id);
      let val = parseInt(input.value, 10) || 1;
      if (val < maxStok) {
        input.value = val + 1;
      }
    }

    function decreaseQty(id) {
      const input = document.getElementById('qty-' + id);
      let val = parseInt(input.value, 10) || 1;
      if (val > 1) {
        input.value = val - 1;
      }
    }

    function updateItemCount() {
      const items = document.querySelectorAll('.item-card:not(.d-none)');
      const countElem = document.getElementById('itemCount');
      if (countElem) countElem.innerText = items.length;

      const noMatchBox = document.getElementById('noMatchBox');
      if (noMatchBox) {
        if (items.length === 0) {
          noMatchBox.classList.remove('d-none');
        } else {
          noMatchBox.classList.add('d-none');
        }
      }
    }

    function filterAlat() {
      const input = document.getElementById('searchInput').value.toLowerCase().trim();
      const items = document.querySelectorAll('.item-card');

      items.forEach(card => {
        const nama = card.getAttribute('data-nama') || '';
        const deskripsi = card.getAttribute('data-deskripsi') || '';
        
        if (nama.includes(input) || deskripsi.includes(input)) {
          card.classList.remove('d-none');
        } else {
          card.classList.add('d-none');
        }
      });

      updateItemCount();
    }

    function setCategoryFilter(category, btnElement) {
      document.querySelectorAll('.chip-btn').forEach(btn => btn.classList.remove('active'));
      if (btnElement) btnElement.classList.add('active');

      const items = document.querySelectorAll('.item-card');
      const searchInput = document.getElementById('searchInput');
      if (searchInput) searchInput.value = '';

      items.forEach(card => {
        const nama = card.getAttribute('data-nama') || '';
        const stok = parseInt(card.getAttribute('data-stok') || '0', 10);

        if (category === 'all') {
          card.classList.remove('d-none');
        } else if (category === 'tersedia') {
          if (stok > 0) {
            card.classList.remove('d-none');
          } else {
            card.classList.add('d-none');
          }
        } else {
          if (nama.includes(category)) {
            card.classList.remove('d-none');
          } else {
            card.classList.add('d-none');
          }
        }
      });

      updateItemCount();
    }

    function resetSearch() {
      const searchInput = document.getElementById('searchInput');
      if (searchInput) searchInput.value = '';
      setCategoryFilter('all', document.querySelector('.chip-btn'));
    }

    function showLightboxModal(imgSrc, title, priceText, stockQty) {
      document.getElementById('lightboxImgAlat').src = imgSrc;
      document.getElementById('lightboxTitleAlat').innerText = title;
      document.getElementById('lightboxPriceAlat').innerText = priceText;
      
      const stockElem = document.getElementById('lightboxStockAlat');
      if (parseInt(stockQty) > 0) {
        stockElem.className = 'badge bg-success px-2 py-1';
        stockElem.innerHTML = '<i class="fas fa-check-circle me-1"></i> Tersedia ' + stockQty + ' Unit';
      } else {
        stockElem.className = 'badge bg-danger px-2 py-1';
        stockElem.innerHTML = '<i class="fas fa-times-circle me-1"></i> Stok Habis';
      }

      const modalEl = document.getElementById('modalImageLightbox');
      const bsModal = bootstrap.Modal.getOrCreateInstance(modalEl);
      bsModal.show();
    }

    document.addEventListener("DOMContentLoaded", function() {
      updateItemCount();

      <?php if (isset($_SESSION['error'])): ?>
        Swal.fire({
          icon: 'error',
          title: 'Pemberitahuan',
          text: '<?= addslashes($_SESSION['error']) ?>',
          confirmButtonColor: '#162d2f'
        });
        <?php unset($_SESSION['error']); ?>
      <?php endif; ?>

      <?php if (isset($_SESSION['success'])): ?>
        Swal.fire({
          icon: 'success',
          title: 'Berhasil',
          text: '<?= addslashes($_SESSION['success']) ?>',
          confirmButtonColor: '#162d2f'
        });
        <?php unset($_SESSION['success']); ?>
      <?php endif; ?>
    });
  </script>
</body>
</html>