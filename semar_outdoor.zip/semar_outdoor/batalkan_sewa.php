<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'koneksi.php';

if (!isset($_SESSION['id_users'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "ID transaksi tidak ditemukan.";
    header('Location: riwayat_sewa.php');
    exit;
}

$id = (int) $_GET['id'];
$id_user = (int)$_SESSION['id_users'];

// Ambil data sewa berdasarkan ID dan pastikan milik user yang sedang login
$sewa = $conn->query("SELECT * FROM sewa WHERE id = $id AND id_users = $id_user AND status = 'Menunggu pembayaran'");

if ($sewa->num_rows == 0) {
    $_SESSION['error'] = "Data sewa tidak ditemukan atau tidak bisa dibatalkan.";
    header('Location: riwayat_sewa.php');
    exit;
}

$data = $sewa->fetch_assoc();

// 🔐 MULAI TRANSAKSI
$conn->begin_transaction();

try {
    $noTag = $data['no_tagihan'] ?? '';
    $allItemsToCancel = [$data];

    if (!empty($noTag)) {
        $qOthers = mysqli_query($conn, "SELECT * FROM sewa WHERE id_users = $id_user AND no_tagihan = '$noTag' AND status = 'Menunggu pembayaran'");
        if ($qOthers && mysqli_num_rows($qOthers) > 0) {
            $allItemsToCancel = [];
            while ($oRow = mysqli_fetch_assoc($qOthers)) {
                $allItemsToCancel[] = $oRow;
            }
        }
    }

    foreach ($allItemsToCancel as $cItem) {
        $status = 'Dibatalkan User';
        $noTagFix = !empty($cItem['no_tagihan']) ? $cItem['no_tagihan'] : ('INV-' . date('Ymd', strtotime($cItem['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $cItem['id']));
        
        $stmt = $conn->prepare("
            INSERT INTO sewa_dibatalkan 
            (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");

        $stmt->bind_param(
            "issiiidssss",
            $cItem['id_users'],
            $noTagFix,
            $cItem['nama_produk'],
            $cItem['qty'],
            $cItem['durasi'],
            $cItem['total_harga'],
            $cItem['biaya_pengambilan'],
            $cItem['metode_pengambilan'],
            $cItem['gambar'],
            $cItem['tanggal_sewa'],
            $status
        );
        $stmt->execute();
        $stmt->close();

        // HAPUS DARI TABEL SEWA
        $delete = $conn->prepare("DELETE FROM sewa WHERE id = ? AND id_users = ?");
        $delete->bind_param("ii", $cItem['id'], $id_user);
        $delete->execute();
        $delete->close();
    }

    // ✅ SIMPAN SEMUA PERUBAHAN
    $conn->commit();
    $_SESSION['success'] = "Pesanan sewa berhasil dibatalkan.";

} catch (Exception $e) {
    // ❌ Jika gagal, batalkan transaksi
    $conn->rollback();
    $_SESSION['error'] = "Gagal membatalkan sewa: " . $e->getMessage();
}

header("Location: riwayat_sewa.php");
exit;
?>
