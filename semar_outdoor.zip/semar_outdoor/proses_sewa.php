<?php
session_start();
include './koneksi.php';

// 1. Cek Login
$id_user = $_SESSION['id_users'] ?? null;
if (!$id_user) {
    $_SESSION['error'] = "Anda harus login sebagai user untuk menyewa.";
    header("Location: login.php");
    exit;
}

// 2. Tampung item yang akan diproses ke dalam array
$items_to_process = [];

// Skenario A: Tambah Banyak Alat Sekaligus via Checkbox
if (isset($_POST['bulk_add']) && isset($_POST['selected_items']) && is_array($_POST['selected_items'])) {
    $selected_ids = $_POST['selected_items'];
    $jumlah_array = $_POST['jumlah'] ?? [];

    foreach ($selected_ids as $id) {
        $id_alat = (int)$id;
        $qty = isset($jumlah_array[$id_alat]) ? (int)$jumlah_array[$id_alat] : 1;
        if ($id_alat > 0 && $qty > 0) {
            $items_to_process[] = [
                'id_alat' => $id_alat,
                'jumlah'  => $qty
            ];
        }
    }
} 
// Skenario B: Tambah Satuan Alat via Tombol "Sewa"
elseif (isset($_POST['id_alat'])) {
    $id_alat = (int)$_POST['id_alat'];
    $jumlah = (int)($_POST['jumlah'] ?? 1);

    if ($id_alat > 0 && $jumlah > 0) {
        $items_to_process[] = [
            'id_alat' => $id_alat,
            'jumlah'  => $jumlah
        ];
    }
}

// Validasi jika tidak ada item yang valid
if (empty($items_to_process)) {
    $_SESSION['error'] = "Tidak ada alat yang dipilih atau data tidak valid.";
    header("Location: alat.php");
    exit;
}

$success_count = 0;

// 3. Loop untuk memproses setiap item ke dalam Keranjang
foreach ($items_to_process as $item) {
    $id_alat = $item['id_alat'];
    $jumlah = $item['jumlah'];

    // Ambil info alat & hitung sisa stok dinamis real-time
    $stmt = $conn->prepare("
        SELECT a.id, a.nama, a.harga_per_hari, a.stok_awal,
               GREATEST(0, a.stok_awal - IFNULL(s.total_disewa, 0)) AS sisa_stok_dinamis
        FROM alat a
        LEFT JOIN (
            SELECT id_alat, SUM(qty) AS total_disewa
            FROM sewa
            WHERE status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai')
            GROUP BY id_alat
        ) s ON a.id = s.id_alat
        WHERE a.id = ?
    ");
    $stmt->bind_param("i", $id_alat);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        continue; // Lewati jika alat tidak ditemukan
    }
    
    $alat = $result->fetch_assoc();
    $stmt->close();

    $stok_tersedia = (int)$alat['sisa_stok_dinamis'];
    $harga_per_hari = (int)$alat['harga_per_hari'];

    // Cek ketersediaan stok
    if ($jumlah > $stok_tersedia) {
        continue; // Lewati jika permintaan melebihi stok
    }

    // Cek apakah alat sudah ada di keranjang user
    $check = $conn->prepare("SELECT id, jumlah FROM keranjang WHERE id_alat = ? AND id_users = ?");
    $check->bind_param("ii", $id_alat, $id_user);
    $check->execute();
    $result_check = $check->get_result();

    if ($result_check->num_rows > 0) {
        // Update jumlah dan total_harga jika sudah ada di keranjang
        $row = $result_check->fetch_assoc();
        $new_jumlah = $row['jumlah'] + $jumlah;
        
        // Batasi agar total di keranjang tidak melebihi stok tersedia
        if ($new_jumlah > $stok_tersedia) {
            $new_jumlah = $stok_tersedia;
        }
        
        $total_harga = $harga_per_hari * $new_jumlah;

        $update = $conn->prepare("UPDATE keranjang SET jumlah = ?, total_harga = ? WHERE id = ? AND id_users = ?");
        $update->bind_param("iiii", $new_jumlah, $total_harga, $row['id'], $id_user);
        $update->execute();
        if ($update->affected_rows >= 0) {
            $success_count++;
        }
        $update->close();
    } else {
        // Insert data baru ke keranjang
        $total_harga = $harga_per_hari * $jumlah;

        $insert = $conn->prepare("INSERT INTO keranjang (id_users, id_alat, jumlah, total_harga, tanggal_ditambahkan) VALUES (?, ?, ?, ?, NOW())");
        $insert->bind_param("iiii", $id_user, $id_alat, $jumlah, $total_harga);
        $insert->execute();
        if ($insert->affected_rows > 0) {
            $success_count++;
        }
        $insert->close();
    }
    $check->close();
}

// 4. Set Pesan Feedback dan Redirect
if ($success_count > 0) {
    $_SESSION['success'] = "Berhasil menambahkan {$success_count} item ke keranjang.";
    header("Location: keranjang.php");
} else {
    $_SESSION['error'] = "Gagal menambahkan item ke keranjang. Periksa ketersediaan stok.";
    header("Location: alat.php");
}
exit;
?>