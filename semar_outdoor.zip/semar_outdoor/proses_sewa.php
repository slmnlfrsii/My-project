<?php
session_start();
include './koneksi.php';

// Cek login
$id_user = $_SESSION['id_users'] ?? null;
if (!$id_user) {
    $_SESSION['error'] = "Anda harus login sebagai user untuk menyewa.";
    header("Location: login.php");
    exit;
}

// Ambil data dari POST
$id_alat = $_POST['id_alat'] ?? null;
$jumlah = (int)($_POST['jumlah'] ?? 1); // default jumlah 1 jika tidak dikirim

if (!$id_alat || $jumlah < 1) {
    $_SESSION['error'] = "Data tidak valid.";
    header("Location: alat.php");
    exit;
}

// Ambil info alat & hitung sisa stok dinamis real-time
$stmt = $conn->prepare("
    SELECT a.id, a.nama, a.harga_per_hari, a.stok_awal,
           GREATEST(0, a.stok_awal - IFNULL(s.total_disewa, 0)) AS sisa_stok_dinamis
    FROM alat a
    LEFT JOIN (
        SELECT id_alat, SUM(qty) AS total_disewa
        FROM sewa
        WHERE status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai')
        GROUP BY id_alat
    ) s ON a.id = s.id_alat
    WHERE a.id = ?
");
$stmt->bind_param("i", $id_alat);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    $_SESSION['error'] = "Alat tidak ditemukan.";
    header("Location: alat.php");
    exit;
}
$alat = $result->fetch_assoc();
$stmt->close();

$stok_tersedia = (int)$alat['sisa_stok_dinamis'];
$harga_per_hari = (int)$alat['harga_per_hari'];

if ($jumlah > $stok_tersedia) {
    $_SESSION['error'] = "Jumlah melebihi sisa stok tersedia saat ini ({$stok_tersedia} unit).";
    header("Location: alat.php");
    exit;
}

// Cek apakah alat sudah ada di keranjang user
$check = $conn->prepare("SELECT id, jumlah FROM keranjang WHERE id_alat = ? AND id_users = ?");
$check->bind_param("ii", $id_alat, $id_user);
$check->execute();
$result_check = $check->get_result();

if ($result_check->num_rows > 0) {
    // Update jumlah dan total_harga
    $row = $result_check->fetch_assoc();
    $new_jumlah = $row['jumlah'] + $jumlah;
    $total_harga = $harga_per_hari * $new_jumlah;

    $update = $conn->prepare("UPDATE keranjang SET jumlah = ?, total_harga = ? WHERE id = ? AND id_users = ?");
    $update->bind_param("iiii", $new_jumlah, $total_harga, $row['id'], $id_user);
    $update->execute();
    $sukses = $update->affected_rows > 0;
    $update->close();
} else {
    // Hitung total_harga dan insert ke keranjang
    $total_harga = $harga_per_hari * $jumlah;

    $insert = $conn->prepare("INSERT INTO keranjang (id_users, id_alat, jumlah, total_harga, tanggal_ditambahkan) VALUES (?, ?, ?, ?, NOW())");
    $insert->bind_param("iiii", $id_user, $id_alat, $jumlah, $total_harga);
    $insert->execute();
    $sukses = $insert->affected_rows > 0;
    $insert->close();
}
$check->close();

if ($sukses) {
    $_SESSION['success'] = "Berhasil menambahkan ke keranjang.";
    header("Location: keranjang.php");
} else {
    $_SESSION['error'] = "Gagal menambahkan ke keranjang.";
    header("Location: alat.php");
}
?>
