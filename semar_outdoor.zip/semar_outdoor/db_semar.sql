-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 22, 2026 at 07:20 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_semar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `email`, `password`, `created_at`, `foto`) VALUES
(5, 'Admin Utama', 'admin@gmail.com', '$2y$10$sLUuMDImnjpSAW/UDocwq.j3G5BqSS1vnCx13.0Zo/eQ8F9.hFBY6', '2025-05-27 14:42:16', '683ead8836b24_logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `alat`
--

CREATE TABLE `alat` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `deskripsi` text,
  `stok_awal` int NOT NULL DEFAULT '0',
  `sisa_stok` int NOT NULL DEFAULT '0',
  `harga_per_hari` int NOT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `alat`
--

INSERT INTO `alat` (`id`, `nama`, `deskripsi`, `stok_awal`, `sisa_stok`, `harga_per_hari`, `gambar`) VALUES
(2, 'Sepatu', 'Rady size 38-42', 20, 20, 25000, 'alat_6833d88d21beb3.67567373.jpg'),
(3, 'Tenda', 'Kapasitas 4-5 orang', 15, 15, 35000, 'alat_6833d882104f95.69314576.jpg'),
(4, 'Kompor portable', 'kompor saja', 10, 10, 10000, 'alat_6833d859125067.64690111.jpg'),
(5, 'Sleeping Bag', 'nyaman dan hangat ketika di suhu yang dingin', 10, 10, 10000, 'alat_6833d9b58a82e7.72761150.jpg'),
(6, 'Jaket ', 'nyaman di segala cuaca', 10, 10, 15000, 'alat_6833da70c0be82.39220847.jpg'),
(7, 'Gas portabel', 'isi ulang', 50, 50, 10000, 'alat_6833dbe50e61e6.98844109.jpg'),
(8, 'Kursi Lipat', 'bisa dibawa kemana saja tanpa ribet ', 10, 10, 10000, 'alat_683dd474eda5f2.74398306.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id` int NOT NULL,
  `id_users` int NOT NULL,
  `id_alat` int NOT NULL,
  `jumlah` int NOT NULL,
  `total_harga` int NOT NULL,
  `tanggal_ditambahkan` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nama` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id`, `id_users`, `id_alat`, `jumlah`, `total_harga`, `tanggal_ditambahkan`, `nama`) VALUES
(110, 36, 8, 1, 10000, '2026-08-22 01:29:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int NOT NULL,
  `id_users` int NOT NULL,
  `id_sewa` int NOT NULL,
  `metode` varchar(50) NOT NULL,
  `bukti_pembayaran` varchar(255) NOT NULL,
  `jumlah_bayar` decimal(15,2) NOT NULL,
  `total_tagihan` decimal(15,2) NOT NULL,
  `status` enum('Menunggu konfirmasi','Lunas','Belum lunas','ditolak') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'Menunggu konfirmasi',
  `tanggal_bayar` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `id_users`, `id_sewa`, `metode`, `bukti_pembayaran`, `jumlah_bayar`, `total_tagihan`, `status`, `tanggal_bayar`) VALUES
(66, 36, 102, 'ewallet_dana', '1787331496_Screenshot 2026-05-19 203720.png', '12000.00', '20000.00', 'Menunggu konfirmasi', '2026-08-21 23:58:16');

-- --------------------------------------------------------

--
-- Table structure for table `sewa`
--

CREATE TABLE `sewa` (
  `id` int NOT NULL,
  `id_users` int DEFAULT NULL,
  `id_alat` int DEFAULT NULL,
  `nama_produk` varchar(255) DEFAULT NULL,
  `total_harga` int DEFAULT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `tanggal_sewa` date DEFAULT NULL,
  `durasi` int DEFAULT NULL,
  `tanggal_buat` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `metode_pengambilan` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'Ambil Ke toko',
  `biaya_pengambilan` int NOT NULL DEFAULT '0',
  `status` enum('Menunggu pembayaran','Berlangsung','Siap di ambil','di antar','Dibatalkan','selesai') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'Menunggu pembayaran',
  `tanggal_dikembalikan` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sewa`
--

INSERT INTO `sewa` (`id`, `id_users`, `id_alat`, `nama_produk`, `total_harga`, `gambar`, `qty`, `tanggal_sewa`, `durasi`, `tanggal_buat`, `metode_pengambilan`, `biaya_pengambilan`, `status`, `tanggal_dikembalikan`) VALUES
(102, 36, 7, 'Gas portabel', 40000, 'alat_6833dbe50e61e6.98844109.jpg', 2, '2026-08-21', 2, '2026-08-21 15:45:08', 'COD', 0, 'Menunggu pembayaran', NULL),
(110, 42, 5, 'Sleeping Bag', 10000, 'alat_6833d9b58a82e7.72761150.jpg', 1, '2026-08-22', 2, '2026-08-22 06:47:48', 'Diantar', 0, 'Menunggu pembayaran', NULL),
(111, 30, 2, 'Sepatu', 25000, 'alat_6833d88d21beb3.67567373.jpg', 1, '2026-08-22', 1, '2026-08-22 06:53:08', 'Diantar', 10000, 'Menunggu pembayaran', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sewa_dibatalkan`
--

CREATE TABLE `sewa_dibatalkan` (
  `id` int NOT NULL,
  `id_users` int DEFAULT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `durasi` int DEFAULT NULL,
  `total_harga` int DEFAULT NULL,
  `biaya_pengambilan` int DEFAULT NULL,
  `metode_pengambilan` enum('Ambil Ke toko','COD') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'Ambil Ke toko',
  `gambar` varchar(255) DEFAULT NULL,
  `tanggal_sewa` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `dibatalkan_pada` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sewa_dibatalkan`
--

INSERT INTO `sewa_dibatalkan` (`id`, `id_users`, `nama_produk`, `qty`, `durasi`, `total_harga`, `biaya_pengambilan`, `metode_pengambilan`, `gambar`, `tanggal_sewa`, `status`, `dibatalkan_pada`) VALUES
(54, 3, 'Gas portabel', 1, 1, 10000, 0, 'Ambil Ke toko', 'alat_6833dbe50e61e6.98844109.jpg', '2025-06-06', 'Dibatalkan', '2025-06-02 08:05:06'),
(56, 3, 'Jaket 3 layer', 1, 1, 15000, 0, 'Ambil Ke toko', 'alat_6833da70c0be82.39220847.jpg', '2025-06-13', 'Dibatalkan', '2025-06-02 11:14:44'),
(58, 3, 'Sleeping Bag', 1, 1, 10000, 0, 'Ambil Ke toko', 'alat_6833d9b58a82e7.72761150.jpg', '2025-06-02', 'Dibatalkan', '2025-06-02 11:35:18'),
(59, 9, 'Gas portabel', 1, 1, 10000, 0, 'Ambil Ke toko', 'alat_6833dbe50e61e6.98844109.jpg', '2025-06-05', 'Dibatalkan', '2025-06-03 10:11:19'),
(61, 3, 'Kursi Lipat', 2, 1, 20000, 10000, 'COD', 'alat_683dd474eda5f2.74398306.jpg', '2025-06-30', 'Dibatalkan', '2025-06-30 10:57:11'),
(62, 3, 'Gas portabel', 2, 2, 40000, 10000, 'COD', 'alat_6833dbe50e61e6.98844109.jpg', '2025-06-30', 'Dibatalkan', '2025-07-04 10:13:41'),
(68, 42, 'Jaket ', 2, 1, 40000, 10000, 'COD', 'alat_6833da70c0be82.39220847.jpg', '2026-11-22', 'Dibatalkan', '2026-08-22 05:39:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `alamat` text NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `email`, `password`, `no_hp`, `created_at`, `alamat`, `foto`) VALUES
(30, 'cek', 'cek@gmail.com', '$2y$10$SXddxjJRAdmaS07fcKyEFOtUVx74am4RWRpiLLMCDlEpE0CyAKrLG', '098766554', '2026-05-02 23:36:35', 'kp.cibagogog', 'Screenshot 2026-05-02 220210.png'),
(36, 'armagedhon', 'armagedhon@gmail.com', '$2y$10$Yi/oNSQh4mAzMaKwYxcydODZsoHAYb41u2Nv1zV.D2onmi47CDA.K', '086796546', '2026-05-02 23:36:13', 'kp.kubang koak', NULL),
(42, 'Salman_Af', 'salmanaf083@gmail.com', '$2y$10$nN.SUn4DgUKppRfOJK91..9cA5gOJzw13i2rSoexo716IPlCLqTuO', '+62885672231', '2026-08-21 22:29:33', 'jnhbgvfdsw', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `alat`
--
ALTER TABLE `alat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_users` (`id_users`),
  ADD KEY `id_alat` (`id_alat`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pembayaran_users` (`id_users`),
  ADD KEY `fk_pembayaran_sewa` (`id_sewa`);

--
-- Indexes for table `sewa`
--
ALTER TABLE `sewa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sewa_dibatalkan`
--
ALTER TABLE `sewa_dibatalkan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `alat`
--
ALTER TABLE `alat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `sewa`
--
ALTER TABLE `sewa`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `sewa_dibatalkan`
--
ALTER TABLE `sewa_dibatalkan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD CONSTRAINT `keranjang_ibfk_1` FOREIGN KEY (`id_users`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `keranjang_ibfk_2` FOREIGN KEY (`id_alat`) REFERENCES `alat` (`id`);

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `fk_pembayaran_sewa` FOREIGN KEY (`id_sewa`) REFERENCES `sewa` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pembayaran_users` FOREIGN KEY (`id_users`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
