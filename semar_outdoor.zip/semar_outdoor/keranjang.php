<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include './koneksi.php';

$id_user = $_SESSION['id_users'] ?? null;
if (!$id_user) {
    $_SESSION['error'] = "Anda harus login terlebih dahulu.";
    header("Location: login.php");
    exit;
}

// Query dengan perhitungan sisa stok dinamis berdasarkan status sewa
$sql = "SELECT k.id, k.jumlah, k.total_harga,
               a.nama, a.gambar, a.harga_per_hari AS harga,
               (a.stok_awal - IFNULL(s.total_disewa, 0)) AS stok
        FROM keranjang k
        JOIN alat a ON k.id_alat = a.id
        LEFT JOIN (
            SELECT id_alat, SUM(qty) AS total_disewa
            FROM sewa
            WHERE status IN ('siap diambil', 'diantar', 'berlangsung')
            GROUP BY id_alat
        ) s ON a.id = s.id_alat
        WHERE k.id_users = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();

$keranjang = [];
while ($row = $result->fetch_assoc()) {
    // Memastikan nilai stok minimal 0 (tidak minus)
    $row['stok'] = max(0, (int)$row['stok']);
    $keranjang[] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Keranjang Sewa - Semar Outdoor</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

  <style> 
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
    }

    .page-header {
      background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
      color: #ffffff;
      padding: 120px 20px 50px;
      text-align: center;
    }

    .page-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(2rem, 4vw, 2.7rem);
      font-weight: 800;
      margin-bottom: 8px;
    }

    .page-subtitle {
      color: #cbd5e1;
      font-size: 1.02rem;
      max-width: 600px;
      margin: 0 auto;
    }

    .cart-section {
      padding: 40px 0 80px;
    }

    .cart-item-card {
      background-color: #ffffff;
      border-radius: 18px;
      border: 1px solid rgba(0, 0, 0, 0.06);
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.04);
      margin-bottom: 18px;
      padding: 20px;
      display: flex;
      gap: 20px;
      align-items: center;
      transition: all 0.25s ease;
    }

    .cart-item-card:hover {
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.07);
      border-color: rgba(194, 120, 3, 0.3);
    }

    .cart-checkbox {
      width: 22px;
      height: 22px;
      accent-color: var(--brand-green);
      cursor: pointer;
      flex-shrink: 0;
    }

    .cart-img-wrap {
      width: 100px;
      height: 100px;
      border-radius: 14px;
      overflow: hidden;
      flex-shrink: 0;
      background: #f1f5f9;
    }

    .cart-img-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .cart-info {
      flex-grow: 1;
    }

    .cart-item-title {
      font-size: 1.15rem;
      font-weight: 700;
      color: var(--brand-teal);
      margin-bottom: 4px;
      font-family: 'Quicksand', sans-serif;
    }

    .cart-price-rate {
      font-size: 0.95rem;
      color: var(--brand-gold);
      font-weight: 700;
      margin-bottom: 8px;
    }

    .btn-qty {
      width: 32px;
      height: 32px;
      border: none;
      background-color: #e2e8f0;
      color: var(--brand-dark);
      font-weight: 700;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s ease;
      cursor: pointer;
    }

    .btn-qty:hover:not(:disabled) {
      background-color: var(--brand-teal);
      color: #ffffff;
    }

    .btn-qty:disabled {
      opacity: 0.4 !important;
      cursor: not-allowed;
    }

    .qty-number {
      font-weight: 700;
      min-width: 28px;
      text-align: center;
    }

    .cart-summary-card {
      background: #ffffff;
      border-radius: 20px;
      padding: 28px;
      border: 1px solid rgba(0,0,0,0.06);
      box-shadow: 0 6px 20px rgba(0,0,0,0.05);
      position: sticky;
      top: 100px;
    }

    .btn-checkout-cta {
      background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
      color: #ffffff;
      font-weight: 700;
      padding: 14px 20px;
      border-radius: 12px;
      border: none;
      width: 100%;
      font-size: 1.05rem;
      transition: all 0.25s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }

    .btn-checkout-cta:hover:not(:disabled) {
      background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
      transform: translateY(-2px);
      box-shadow: 0 6px 18px rgba(194, 120, 3, 0.4);
      color: #ffffff;
    }

    .btn-checkout-cta:disabled {
      background: #94a3b8;
      cursor: not-allowed;
      box-shadow: none;
    }

    .empty-cart-card {
      background: #ffffff;
      border-radius: 20px;
      padding: 60px 20px;
      text-align: center;
      border: 1px dashed rgba(0,0,0,0.12);
    }

    /* Footer */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 65px;
    }

    .footer-brand-logo {
      height: 42px;
      width: auto;
      max-height: 42px;
      object-fit: contain;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: 0.4px;
    }

    .footer-title {
      color: #ffffff;
      font-size: 1.05rem;
      font-weight: 700;
      margin-bottom: 18px;
      position: relative;
      padding-bottom: 8px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 32px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 10px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-links-list a:hover {
      color: #fde047;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 4px;
    }

    .footer-contact-item a {
      color: #cbd5e1;
      text-decoration: none;
    }

    .footer-contact-item a:hover {
      color: #fde047;
    }

    .footer-map-container {
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 170px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 20px 0;
      margin-top: 50px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.85rem;
      color: #64748b;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Keranjang Sewa</h1>
      <p class="page-subtitle">Periksa perlengkapan yang ingin Anda sewa sebelum melanjutkan ke formulir pemesanan.</p>
    </div>
  </section>

  <!-- Cart Content -->
  <section class="cart-section">
    <div class="container">
      <?php if (empty($keranjang)): ?>
        <div class="empty-cart-card">
          <i class="fas fa-shopping-basket fs-1 text-muted mb-3 d-block"></i>
          <h4 class="fw-bold mb-2">Keranjang Anda Masih Kosong</h4>
          <p class="text-muted mb-4">Yuk, temukan perlengkapan camping dan outdoor favorit Anda sekarang!</p>
          <a href="alat.php" class="btn btn-dark px-4 py-2" style="background-color: var(--brand-teal); border-radius: 10px;">
            <i class="fas fa-compass me-1"></i> Jelajahi Katalog Alat
          </a>
        </div>
      <?php else: ?>
        <div class="row g-4">
          <!-- Kolom Daftar Item Keranjang -->
          <div class="col-lg-8">
            <div class="d-flex justify-content-between align-items-center mb-3">
              <span class="fw-bold text-muted small">DAFTAR PERLENGKAPAN</span>
              <a href="alat.php" class="text-decoration-none small fw-semibold text-success">
                <i class="fas fa-plus-circle me-1"></i> Tambah Alat Lain
              </a>
            </div>

            <?php foreach ($keranjang as $item): ?>
              <?php $subtotal = $item['harga'] * $item['jumlah']; ?>
              <div class="cart-item-card">
                <input 
                  type="checkbox" 
                  class="cart-checkbox item-checkbox" 
                  value="<?= $item['id'] ?>" 
                  data-total="<?= $subtotal ?>"
                  <?= ($item['stok'] <= 0) ? 'disabled' : 'checked' ?>
                >
                
                <div class="cart-img-wrap">
                  <?php
                  $imgSrc = 'admin/uploads/alat/' . $item['gambar'];
                  if (!empty($item['gambar']) && file_exists($imgSrc)): ?>
                    <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($item['nama']) ?>">
                  <?php else: ?>
                    <img src="https://via.placeholder.com/100?text=Semar" alt="<?= htmlspecialchars($item['nama']) ?>">
                  <?php endif; ?>
                </div>

                <div class="cart-info">
                  <div class="d-flex justify-content-between align-items-start">
                    <div>
                      <h5 class="cart-item-title">
                        <?= htmlspecialchars($item['nama']) ?>
                        <?php if ($item['stok'] <= 0): ?>
                          <span class="badge bg-danger ms-2 small">Stok Habis</span>
                        <?php endif; ?>
                      </h5>
                      <div class="cart-price-rate">
                        Rp<?= number_format($item['harga'], 0, ',', '.') ?> <span class="text-muted small fw-normal">/ hari</span>
                      </div>
                    </div>
                    
                    <!-- Tombol Hapus Item -->
                    <form action="aksi_keranjang.php" method="POST" onsubmit="return confirm('Hapus item ini dari keranjang?');" class="m-0">
                      <input type="hidden" name="id" value="<?= $item['id'] ?>">
                      <input type="hidden" name="action" value="hapus">
                      <button type="submit" class="btn btn-light btn-sm text-danger rounded-circle border" style="width:34px;height:34px;display:flex;align-items:center;justify-content:center;" title="Hapus">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    </form>
                  </div>

                  <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                    <!-- Tombol Ubah Kuantitas -->
                    <form action="aksi_keranjang.php" method="POST" class="d-flex align-items-center gap-2 m-0">
                      <input type="hidden" name="id" value="<?= $item['id'] ?>">
                      <button 
                        type="submit" 
                        name="action" 
                        value="minus" 
                        class="btn-qty"
                        <?= ($item['jumlah'] <= 1) ? 'disabled' : '' ?>
                      ><i class="fas fa-minus small"></i></button>
                      
                      <span class="qty-number"><?= $item['jumlah'] ?></span>
                      
                      <button 
                        type="submit" 
                        name="action" 
                        value="plus" 
                        class="btn-qty"
                        <?= ($item['jumlah'] >= $item['stok']) ? 'disabled' : '' ?>
                      ><i class="fas fa-plus small"></i></button>
                    </form>

                    <div class="text-end">
                      <small class="text-muted d-block" style="font-size: 0.78rem;">Subtotal</small>
                      <span class="fw-bold" style="color: var(--brand-teal);">Rp<?= number_format($subtotal, 0, ',', '.') ?></span>
                    </div>
                  </div>

                  <?php if ($item['stok'] > 0): ?>
                    <small class="text-muted mt-2 d-block" style="font-size: 0.78rem;">
                      <i class="fas fa-info-circle text-success me-1"></i> Tersedia <?= $item['stok'] ?> unit
                    </small>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <!-- Kolom Ringkasan Total & Checkout -->
          <div class="col-lg-4">
            <div class="cart-summary-card">
              <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
                Ringkasan Sewa
              </h5>
              
              <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Total Terpilih</span>
                <span class="fs-4 fw-bold text-success" id="totalHargaDisplay">Rp0</span>
              </div>
              
              <p class="text-muted small mb-4">
                *Total di atas adalah tarif sewa 1 hari untuk item yang dicentang. Durasi hari dan tanggal sewa akan ditentukan pada langkah formulir checkout.
              </p>

              <button id="checkoutButton" class="btn-checkout-cta mb-3" disabled>
                <i class="fas fa-arrow-right"></i> Lanjut ke Checkout
              </button>

              <a href="alat.php" class="btn btn-outline-secondary w-100 py-2" style="border-radius: 12px; font-weight: 600;">
                <i class="fas fa-plus me-1"></i> Tambah Item Lain
              </a>
            </div>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    const totalHargaDisplay = document.getElementById('totalHargaDisplay');
    const checkoutButton = document.getElementById('checkoutButton');

    function updateTotal() {
      let total = 0;
      checkboxes.forEach(cb => {
        if (cb.checked && !cb.disabled) {
          total += parseInt(cb.dataset.total) || 0;
        }
      });
      if (totalHargaDisplay) {
        totalHargaDisplay.textContent = 'Rp' + total.toLocaleString('id-ID');
      }
      if (checkoutButton) {
        checkoutButton.disabled = (total === 0);
      }
    }

    checkboxes.forEach(cb => {
      cb.addEventListener('change', updateTotal);
    });

    updateTotal();

    if (checkoutButton) {
      checkoutButton.addEventListener('click', function () {
        const selected = [];
        checkboxes.forEach(cb => {
          if (cb.checked && !cb.disabled) selected.push(cb.value);
        });

        if (selected.length === 0) {
          Swal.fire({
            icon: 'warning',
            title: 'Pilih Item',
            text: 'Silakan pilih minimal 1 item untuk melanjutkan checkout.',
            confirmButtonColor: '#162d2f'
          });
          return;
        }

        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'checkout.php';

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_items_json';
        input.value = JSON.stringify(selected);
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
      });
    }

    <?php if (!empty($_SESSION['error'])): ?>
    Swal.fire({
      icon: 'error',
      title: 'Pemberitahuan',
      text: '<?= addslashes($_SESSION['error']); ?>',
      confirmButtonColor: '#162d2f'
    });
    <?php unset($_SESSION['error']); endif; ?>

    <?php if (!empty($_SESSION['success'])): ?>
    Swal.fire({
      icon: 'success',
      title: 'Berhasil',
      text: '<?= addslashes($_SESSION['success']); ?>',
      confirmButtonColor: '#162d2f'
    });
    <?php unset($_SESSION['success']); endif; ?>
  });
  </script>
</body>
</html>