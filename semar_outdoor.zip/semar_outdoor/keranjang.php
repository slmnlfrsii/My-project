<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include './koneksi.php';

$id_user = $_SESSION['id_users'] ?? null;
if (!$id_user) {
    $_SESSION['error'] = "Anda harus login terlebih dahulu.";
    header("Location: login.php");
    exit;
}

// Query dengan perhitungan sisa stok dinamis berdasarkan status sewa
$sql = "SELECT k.id, k.jumlah, k.total_harga,
               a.nama, a.gambar, a.harga_per_hari AS harga,
               (a.stok_awal - IFNULL(s.total_disewa, 0)) AS stok
        FROM keranjang k
        JOIN alat a ON k.id_alat = a.id
        LEFT JOIN (
            SELECT id_alat, SUM(qty) AS total_disewa
            FROM sewa
            WHERE status IN ('siap diambil', 'diantar', 'berlangsung')
            GROUP BY id_alat
        ) s ON a.id = s.id_alat
        WHERE k.id_users = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();

$keranjang = [];
while ($row = $result->fetch_assoc()) {
    // Memastikan nilai stok minimal 0 (tidak minus)
    $row['stok'] = max(0, (int)$row['stok']);
    $keranjang[] = $row;
}

// Cek apakah user memiliki tagihan yang masih 'Menunggu konfirmasi', 'Belum lunas', atau 'Menunggu pembayaran'
$q_blocking_cart = mysqli_query($conn, "
    SELECT s.id, s.no_tagihan, s.status AS status_sewa,
    (
        SELECT status FROM pembayaran 
        WHERE (id_sewa = s.id OR FIND_IN_SET(s.id, id_sewa) OR (s.no_tagihan IS NOT NULL AND s.no_tagihan != '' AND EXISTS (
            SELECT 1 FROM sewa s2 WHERE s2.no_tagihan = s.no_tagihan AND (pembayaran.id_sewa = s2.id OR FIND_IN_SET(s2.id, pembayaran.id_sewa))
        )))
        ORDER BY tanggal_bayar DESC, id DESC LIMIT 1
    ) AS status_pembayaran
    FROM sewa s
    WHERE s.id_users = $id_user
    AND s.status NOT IN ('Dibatalkan', 'dibatalkan', 'selesai', 'Selesai')
");

$has_blocking_transaksi = false;
$blocking_reason = '';

if ($q_blocking_cart && mysqli_num_rows($q_blocking_cart) > 0) {
    while ($bRow = mysqli_fetch_assoc($q_blocking_cart)) {
        $stPay = strtolower(trim($bRow['status_pembayaran'] ?? ''));
        $stSewa = strtolower(trim($bRow['status_sewa'] ?? ''));

        if ($stPay === 'menunggu konfirmasi') {
            $has_blocking_transaksi = true;
            $blocking_reason = "Anda memiliki transaksi yang sedang berstatus 'Menunggu Konfirmasi' admin. Mohon tunggu konfirmasi admin terlebih dahulu sebelum melakukan checkout baru.";
            break;
        } elseif ($stPay === 'belum lunas' || $stSewa === 'belum lunas') {
            $has_blocking_transaksi = true;
            $blocking_reason = "Anda masih memiliki tagihan yang berstatus 'Belum Lunas'. Silakan lakukan pelunasan tagihan terlebih dahulu sebelum melakukan checkout baru.";
            break;
        } elseif (empty($stPay) || $stSewa === 'menunggu pembayaran') {
            $has_blocking_transaksi = true;
            $blocking_reason = "Anda masih memiliki tagihan sewa aktif yang belum dibayar. Silakan lakukan pembayaran tagihan Anda terlebih dahulu.";
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Keranjang Sewa - Semar Outdoor</title>
  
  <!-- CSS & Fonts -->
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Quicksand:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

  <style> 
    :root {
      --brand-dark: #12282a;
      --brand-teal: #162d2f;
      --brand-green: #0e4430;
      --brand-gold: #c27803;
      --brand-gold-glow: #ffc107;
      --bg-body: #f8fafc;
      --text-main: #1e293b;
      --text-muted: #64748b;
    }

    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-body);
      color: var(--text-main);
      overflow-x: hidden;
    }

    .page-header {
      background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
      color: #ffffff;
      padding: 95px 20px 30px;
      text-align: center;
    }

    .page-title {
      font-family: 'Quicksand', sans-serif;
      font-size: clamp(1.5rem, 3vw, 2.1rem);
      font-weight: 800;
      margin-bottom: 6px;
    }

    .page-subtitle {
      color: #cbd5e1;
      font-size: 0.9rem;
      max-width: 540px;
      margin: 0 auto;
    }

    .cart-section {
      padding: 28px 0 60px;
    }

    .cart-item-card {
      background-color: #ffffff;
      border-radius: 12px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
      padding: 10px 12px;
      display: flex;
      flex-direction: column;
      height: 100%;
      transition: all 0.22s ease;
      position: relative;
    }

    .cart-item-card:hover {
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.07);
      border-color: rgba(194, 120, 3, 0.35);
      transform: translateY(-2px);
    }

    .cart-card-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 8px;
      padding-bottom: 6px;
      border-bottom: 1px dashed #f1f5f9;
    }

    .cart-checkbox {
      width: 16px;
      height: 16px;
      accent-color: var(--brand-green);
      cursor: pointer;
      flex-shrink: 0;
    }

    .cart-card-mid {
      display: flex;
      gap: 10px;
      align-items: center;
      margin-bottom: 8px;
    }

    .cart-img-wrap {
      width: 52px;
      height: 52px;
      border-radius: 8px;
      overflow: hidden;
      flex-shrink: 0;
      background: #f1f5f9;
      border: 1px solid #e2e8f0;
    }

    .cart-img-wrap img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .cart-info {
      flex: 1;
      min-width: 0;
    }

    .cart-item-title {
      font-size: 0.86rem;
      font-weight: 700;
      color: var(--brand-teal);
      margin-bottom: 2px;
      line-height: 1.25;
      font-family: 'Quicksand', sans-serif;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .cart-price-rate {
      font-size: 0.78rem;
      color: var(--brand-gold);
      font-weight: 700;
      margin-bottom: 0;
    }

    .cart-card-bot {
      margin-top: auto;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding-top: 8px;
      border-top: 1px solid #f1f5f9;
    }

    .btn-qty {
      width: 22px;
      height: 22px;
      border: none;
      background-color: #e2e8f0;
      color: var(--brand-dark);
      font-weight: 700;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s ease;
      cursor: pointer;
      font-size: 0.72rem;
    }

    .btn-qty:hover:not(:disabled) {
      background-color: var(--brand-teal);
      color: #ffffff;
    }

    .btn-qty:disabled {
      opacity: 0.4 !important;
      cursor: not-allowed;
    }

    .qty-number {
      font-weight: 700;
      min-width: 18px;
      text-align: center;
      font-size: 0.78rem;
    }

    .cart-subtotal-val {
      font-size: 0.85rem;
      font-weight: 800;
      color: #0e4430;
    }

    .cart-summary-card {
      background: #ffffff;
      border-radius: 14px;
      padding: 18px 20px;
      border: 1px solid rgba(0,0,0,0.06);
      box-shadow: 0 4px 16px rgba(0,0,0,0.04);
      position: sticky;
      top: 90px;
    }

    .btn-checkout-cta {
      background: linear-gradient(135deg, #c27803 0%, #d97706 100%);
      color: #ffffff;
      font-weight: 700;
      padding: 10px 16px;
      border-radius: 8px;
      border: none;
      width: 100%;
      font-size: 0.92rem;
      transition: all 0.25s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .btn-checkout-cta:hover:not(:disabled) {
      background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
      transform: translateY(-1px);
      box-shadow: 0 4px 14px rgba(194, 120, 3, 0.35);
      color: #ffffff;
    }

    .btn-checkout-cta:disabled {
      background: #94a3b8;
      cursor: not-allowed;
      box-shadow: none;
    }

    .empty-cart-card {
      background: #ffffff;
      border-radius: 20px;
      padding: 60px 20px;
      text-align: center;
      border: 1px dashed rgba(0,0,0,0.12);
    }

    /* Footer */
    footer {
      background: #0b1d1f;
      color: #e2e8f0;
      padding-top: 65px;
    }

    .footer-brand-logo {
      height: 42px;
      width: auto;
      max-height: 42px;
      object-fit: contain;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .footer-brand-name {
      font-family: 'Quicksand', sans-serif;
      font-size: 1.25rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: 0.4px;
    }

    .footer-title {
      color: #ffffff;
      font-size: 1.05rem;
      font-weight: 700;
      margin-bottom: 18px;
      position: relative;
      padding-bottom: 8px;
    }

    .footer-title::after {
      content: "";
      position: absolute;
      bottom: 0;
      left: 0;
      width: 32px;
      height: 2px;
      background: #f59e0b;
      border-radius: 2px;
    }

    .footer-links-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .footer-links-list li {
      margin-bottom: 10px;
    }

    .footer-links-list a {
      color: #cbd5e1;
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .footer-links-list a:hover {
      color: #fde047;
    }

    .footer-contact-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 14px;
      font-size: 0.9rem;
      color: #cbd5e1;
    }

    .footer-contact-item i {
      color: #fde047;
      margin-top: 4px;
    }

    .footer-contact-item a {
      color: #cbd5e1;
      text-decoration: none;
    }

    .footer-contact-item a:hover {
      color: #fde047;
    }

    .footer-map-container {
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .footer-map-container iframe {
      display: block;
      width: 100%;
      height: 170px;
      border: 0;
    }

    .footer-copy-bar {
      background: #061112;
      padding: 20px 0;
      margin-top: 50px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
      text-align: center;
      font-size: 0.85rem;
      color: #64748b;
    }

    /* Mobile Responsiveness */
    @media (max-width: 768px) {
      .page-header {
        padding: 85px 16px 20px !important;
      }
      .page-title {
        font-size: 1.35rem !important;
      }
      .page-subtitle {
        font-size: 0.82rem !important;
      }
      .cart-section {
        padding: 16px 0 40px !important;
      }
      .select-all-card {
        padding: 8px 12px !important;
        margin-bottom: 8px !important;
        font-size: 0.78rem !important;
      }
      .cart-item-card {
        padding: 8px 10px !important;
        border-radius: 10px !important;
      }
      .cart-img-wrap {
        width: 44px !important;
        height: 44px !important;
        border-radius: 6px !important;
      }
      .cart-item-title {
        font-size: 0.80rem !important;
      }
      .cart-price-rate {
        font-size: 0.74rem !important;
      }
      .btn-qty {
        width: 20px !important;
        height: 20px !important;
        font-size: 0.68rem !important;
      }
      .qty-number {
        font-size: 0.76rem !important;
        min-width: 16px !important;
      }
      .cart-subtotal-val {
        font-size: 0.78rem !important;
      }
      .cart-summary-card {
        padding: 14px 16px !important;
        margin-top: 12px !important;
        position: static !important;
        border-radius: 12px !important;
      }
      .btn-checkout-cta {
        padding: 8px 14px !important;
        font-size: 0.85rem !important;
      }
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <?php include 'navbar.php'; ?>

  <!-- Header -->
  <section class="page-header">
    <div class="container">
      <h1 class="page-title">Keranjang Sewa</h1>
      <p class="page-subtitle">Periksa perlengkapan yang ingin Anda sewa sebelum melanjutkan ke formulir pemesanan.</p>
    </div>
  </section>

  <!-- Cart Content -->
  <section class="cart-section">
    <div class="container">
      <?php if (empty($keranjang)): ?>
        <div class="empty-cart-card">
          <i class="fas fa-shopping-basket fs-1 text-muted mb-3 d-block"></i>
          <h4 class="fw-bold mb-2">Keranjang Anda Masih Kosong</h4>
          <p class="text-muted mb-4">Yuk, temukan perlengkapan camping dan outdoor favorit Anda sekarang!</p>
          <a href="alat.php" class="btn btn-dark px-4 py-2" style="background-color: var(--brand-teal); border-radius: 10px;">
            <i class="fas fa-compass me-1"></i> Jelajahi Katalog Alat
          </a>
        </div>
      <?php else: ?>
        <div class="row g-4">
          <!-- Kolom Daftar Item Keranjang -->
          <div class="col-lg-8">
            <div class="d-flex justify-content-between align-items-center mb-2 px-1">
              <div class="form-check d-flex align-items-center gap-2 m-0">
                <input class="form-check-input" type="checkbox" id="selectAllKeranjang" style="cursor: pointer; width: 18px; height: 18px; accent-color: var(--brand-green);" checked>
                <label class="form-check-label fw-bold text-muted small" for="selectAllKeranjang" style="cursor: pointer; user-select: none;">
                  PILIH SEMUA (<span id="selectedCountText">0</span>/<?= count($keranjang) ?>)
                </label>
              </div>
            </div>

            <div class="row g-2.5" id="cartItemsGrid">
            <?php foreach ($keranjang as $item): ?>
              <?php $subtotal = $item['harga'] * $item['jumlah']; ?>
              <div class="col-xl-4 col-lg-6 col-md-6 col-6">
                <div class="cart-item-card">
                  
                  <!-- Top Row: Checkbox, Status & Delete -->
                  <div class="cart-card-top">
                    <div class="d-flex align-items-center gap-1.5">
                      <input 
                        type="checkbox" 
                        class="cart-checkbox item-checkbox" 
                        value="<?= $item['id'] ?>" 
                        data-total="<?= $subtotal ?>"
                        <?= ($item['stok'] <= 0) ? 'disabled' : 'checked' ?>
                      >
                      <?php if ($item['stok'] <= 0): ?>
                        <span class="badge bg-danger py-0.5 px-1.5" style="font-size: 0.65rem;">Habis</span>
                      <?php else: ?>
                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 py-0.5 px-1.5" style="font-size: 0.65rem;">
                          <?= $item['stok'] ?> Unit
                        </span>
                      <?php endif; ?>
                    </div>

                    <!-- Tombol Hapus Item -->
                    <form action="aksi_keranjang.php" method="POST" onsubmit="return confirm('Hapus item ini dari keranjang?');" class="m-0">
                      <input type="hidden" name="id" value="<?= $item['id'] ?>">
                      <input type="hidden" name="action" value="hapus">
                      <button type="submit" class="btn btn-light btn-sm text-danger rounded-circle border p-0" style="width:24px;height:24px;display:flex;align-items:center;justify-content:center;font-size:0.70rem;" title="Hapus">
                        <i class="fas fa-trash-alt"></i>
                      </button>
                    </form>
                  </div>

                  <!-- Mid Row: Foto & Judul -->
                  <div class="cart-card-mid">
                    <div class="cart-img-wrap">
                      <?php
                      $imgSrc = 'admin/uploads/alat/' . $item['gambar'];
                      if (!empty($item['gambar']) && file_exists($imgSrc)): ?>
                        <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($item['nama']) ?>">
                      <?php else: ?>
                        <img src="https://via.placeholder.com/100?text=Semar" alt="<?= htmlspecialchars($item['nama']) ?>">
                      <?php endif; ?>
                    </div>

                    <div class="cart-info">
                      <h5 class="cart-item-title" title="<?= htmlspecialchars($item['nama']) ?>">
                        <?= htmlspecialchars($item['nama']) ?>
                      </h5>
                      <div class="cart-price-rate">
                        Rp<?= number_format($item['harga'], 0, ',', '.') ?> <span class="text-muted small fw-normal">/ hari</span>
                      </div>
                    </div>
                  </div>

                  <!-- Bottom Row: Stepper & Subtotal -->
                  <div class="cart-card-bot">
                    <form action="aksi_keranjang.php" method="POST" class="d-flex align-items-center gap-1 m-0">
                      <input type="hidden" name="id" value="<?= $item['id'] ?>">
                      <button 
                        type="submit" 
                        name="action" 
                        value="minus" 
                        class="btn-qty"
                        <?= ($item['jumlah'] <= 1) ? 'disabled' : '' ?>
                      ><i class="fas fa-minus small" style="font-size: 0.65rem;"></i></button>
                      
                      <span class="qty-number"><?= $item['jumlah'] ?></span>
                      
                      <button 
                        type="submit" 
                        name="action" 
                        value="plus" 
                        class="btn-qty"
                        <?= ($item['jumlah'] >= $item['stok']) ? 'disabled' : '' ?>
                      ><i class="fas fa-plus small" style="font-size: 0.65rem;"></i></button>
                    </form>

                    <div class="text-end">
                      <small class="text-muted d-block" style="font-size: 0.68rem; line-height: 1;">Subtotal</small>
                      <span class="cart-subtotal-val">Rp<?= number_format($subtotal, 0, ',', '.') ?></span>
                    </div>
                  </div>

                </div>
              </div>
            <?php endforeach; ?>
            </div>
          </div>

          <!-- Kolom Ringkasan Total & Checkout -->
          <div class="col-lg-4">
            <div class="cart-summary-card">
              <h5 class="fw-bold mb-3 pb-2 border-bottom" style="color: var(--brand-teal); font-family: 'Quicksand', sans-serif;">
                Ringkasan Sewa
              </h5>

              <?php if ($has_blocking_transaksi): ?>
                <div class="alert alert-warning py-2.5 px-3 rounded-3 mb-3 border border-warning border-opacity-50" style="font-size: 0.80rem;">
                  <div class="d-flex align-items-start gap-2">
                    <i class="fas fa-exclamation-triangle text-warning fs-5 flex-shrink-0 mt-0.5"></i>
                    <div>
                      <strong class="d-block text-dark mb-1">Checkout Ditangguhkan</strong>
                      <span class="text-secondary d-block mb-2"><?= htmlspecialchars($blocking_reason) ?></span>
                      <a href="tagihan.php" class="btn btn-warning btn-sm fw-bold w-100 py-1 text-dark" style="font-size: 0.76rem; border-radius: 6px;">
                        <i class="fas fa-receipt me-1"></i> Buka Halaman Tagihan
                      </a>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
              
              <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Total Terpilih</span>
                <span class="fs-4 fw-bold text-success" id="totalHargaDisplay">Rp0</span>
              </div>
              
              <p class="text-muted small mb-4">
                *Total di atas adalah tarif sewa 1 hari untuk item yang dicentang. Durasi hari dan tanggal sewa akan ditentukan pada langkah formulir checkout.
              </p>

              <button id="checkoutButton" class="btn-checkout-cta mb-3" disabled>
                <i class="fas fa-arrow-right"></i> Lanjut ke Checkout
              </button>

              <a href="alat.php" class="btn btn-outline-secondary w-100 py-2" style="border-radius: 12px; font-weight: 600;">
                <i class="fas fa-plus me-1"></i> Tambah Item Lain
              </a>
            </div>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <!-- Footer -->
  <footer id="kontak">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4 col-md-6">
          <div class="d-flex align-items-center gap-2 mb-3">
            <img src="assets/images/logo.png" alt="Logo Semar Outdoor" class="footer-brand-logo">
            <span class="footer-brand-name">Semar Outdoor</span>
          </div>
          <p class="text-muted small leading-relaxed" style="color: #94a3b8 !important;">
            Platform penyedia jasa sewa perlengkapan outdoor & camping terpercaya dengan harga bersahabat dan peralatan dalam kondisi prima.
          </p>
          <div class="d-flex gap-2 mt-3">
            <a href="https://instagram.com/semaroutdoor" target="_blank" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Instagram">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="mailto:semaroutdoor@gmail.com" class="text-white bg-dark p-2 rounded-circle border border-secondary" style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;text-decoration:none;" title="Email">
              <i class="fas fa-envelope"></i>
            </a>
          </div>
        </div>

        <div class="col-lg-2 col-md-6">
          <h5 class="footer-title">Menu</h5>
          <ul class="footer-links-list">
            <li><a href="index.php"><i class="fas fa-chevron-right small text-warning"></i> Beranda</a></li>
            <li><a href="ketentuan.php"><i class="fas fa-chevron-right small text-warning"></i> Ketentuan</a></li>
            <li><a href="alat.php"><i class="fas fa-chevron-right small text-warning"></i> Katalog Alat</a></li>
            <li><a href="keranjang.php"><i class="fas fa-chevron-right small text-warning"></i> Keranjang</a></li>
            <li><a href="riwayat_sewa.php"><i class="fas fa-chevron-right small text-warning"></i> Riwayat Sewa</a></li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Kontak</h5>
          <div class="footer-contact-item">
            <i class="fas fa-envelope"></i>
            <span>semaroutdoor@gmail.com</span>
          </div>
          <div class="footer-contact-item">
            <i class="fab fa-instagram"></i>
            <a href="https://instagram.com/semaroutdoor" target="_blank">@semaroutdoor</a>
          </div>
          <div class="footer-contact-item">
            <i class="fas fa-map-marker-alt"></i>
            <span>Jl. Cisinga, Cilampunghilir, Kec. Padakembang, Kabupaten Tasikmalaya, Jawa Barat 46466</span>
          </div>
        </div>

        <div class="col-lg-3 col-md-6">
          <h5 class="footer-title">Lokasi Toko</h5>
          <div class="footer-map-container">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.094988272086!2d108.12367287403836!3d-7.343229592665433!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f55603c48fdab%3A0x8285bdf531fac8fc!2sSemar%20Outdoor%20equipment!5e0!3m2!1sid!2sid!4v1779196661484!5m2!1sid!2sid"
              loading="lazy" referrerpolicy="no-referrer-when-downgrade">
            </iframe>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-copy-bar">
      <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> Semar Outdoor Equipment. All Rights Reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const selectAllCheckbox = document.getElementById('selectAllKeranjang');
    const checkboxes = Array.from(document.querySelectorAll('.item-checkbox:not(:disabled)'));
    const selectedCountText = document.getElementById('selectedCountText');
    const totalHargaDisplay = document.getElementById('totalHargaDisplay');
    const checkoutButton = document.getElementById('checkoutButton');

    function updateTotal() {
      let total = 0;
      let checkedCount = 0;
      checkboxes.forEach(cb => {
        if (cb.checked) {
          total += parseInt(cb.dataset.total) || 0;
          checkedCount++;
        }
      });

      if (selectedCountText) {
        selectedCountText.textContent = checkedCount;
      }
      if (totalHargaDisplay) {
        totalHargaDisplay.textContent = 'Rp' + total.toLocaleString('id-ID');
      }
      if (checkoutButton) {
        checkoutButton.disabled = (checkedCount === 0 || total === 0);
      }
      if (selectAllCheckbox) {
        selectAllCheckbox.checked = (checkedCount === checkboxes.length && checkboxes.length > 0);
        selectAllCheckbox.indeterminate = (checkedCount > 0 && checkedCount < checkboxes.length);
      }
    }

    if (selectAllCheckbox) {
      selectAllCheckbox.addEventListener('change', function () {
        const isChecked = this.checked;
        checkboxes.forEach(cb => {
          cb.checked = isChecked;
        });
        updateTotal();
      });
    }

    checkboxes.forEach(cb => {
      cb.addEventListener('change', updateTotal);
    });

    updateTotal();

    if (checkoutButton) {
      checkoutButton.addEventListener('click', function () {
        const hasBlocking = <?= $has_blocking_transaksi ? 'true' : 'false' ?>;
        const blockingReason = <?= json_encode($blocking_reason) ?>;

        if (hasBlocking) {
          Swal.fire({
            icon: 'warning',
            title: 'Checkout Tidak Diizinkan!',
            text: blockingReason,
            confirmButtonColor: '#0e4430',
            confirmButtonText: 'Ke Halaman Tagihan',
            showCancelButton: true,
            cancelButtonText: 'Tutup'
          }).then((res) => {
            if (res.isConfirmed) {
              window.location = 'tagihan.php';
            }
          });
          return;
        }

        const selected = [];
        checkboxes.forEach(cb => {
          if (cb.checked) selected.push(cb.value);
        });

        if (selected.length === 0) {
          Swal.fire({
            icon: 'warning',
            title: 'Pilih Item',
            text: 'Silakan pilih minimal 1 item untuk melanjutkan checkout.',
            confirmButtonColor: '#162d2f'
          });
          return;
        }

        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'checkout.php';

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_items_json';
        input.value = JSON.stringify(selected);
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
      });
    }

    <?php if (!empty($_SESSION['error'])): ?>
    Swal.fire({
      icon: 'error',
      title: 'Pemberitahuan',
      text: '<?= addslashes($_SESSION['error']); ?>',
      confirmButtonColor: '#162d2f'
    });
    <?php unset($_SESSION['error']); endif; ?>

    <?php if (!empty($_SESSION['success'])): ?>
    Swal.fire({
      icon: 'success',
      title: 'Berhasil',
      text: '<?= addslashes($_SESSION['success']); ?>',
      confirmButtonColor: '#162d2f'
    });
    <?php unset($_SESSION['success']); endif; ?>
  });
  </script>
</body>
</html>