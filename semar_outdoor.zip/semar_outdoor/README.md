# 🏕️ Dokumentasi Sistem - Semar Outdoor (Rental Alat Outdoor)

Dokumentasi komprehensif mengenai arsitektur, alur bisnis, struktur direktori, skema basis data, dan antarmuka API untuk proyek **Semar Outdoor**.

---

## 📌 1. Gambaran Umum Proyek

**Semar Outdoor** adalah aplikasi berbasis web yang dirancang untuk mengelola persewaan peralatan luar ruangan (camping, mendaki gunung, dan kegiatan outdoor lainnya). Sistem ini mencakup portal untuk pelanggan, panel admin untuk operasional toko, serta sekumpulan REST API untuk integrasi aplikasi mobile / klien pihak ketiga.

### 🛠️ Teknologi yang Digunakan
- **Backend**: PHP Native (Procedural & MySQLi Prepared Statements)
- **Database**: MySQL (`db_semar`)
- **Frontend Web**: HTML5, CSS3, Bootstrap 5.3, JavaScript, FontAwesome 6, SweetAlert2, jsPDF
- **Web Server Local**: Laragon / XAMPP (Apache, MySQL, PHP 7.4 - 8.x)
- **Format API**: JSON (RESTful endpoints di `/api`)

---

## 📁 2. Struktur Direktori & File

```text
semar_outdoor/
├── admin/                               # Portal Manajemen Admin
│   ├── alat/
│   │   ├── aksi_alat.php                # Handler CRUD data alat & upload gambar
│   │   └── list_alat.php                # Halaman daftar tabel alat & form modal
│   ├── dashboard/
│   │   └── dashboard.php                # Dashboard grafik pendapatan tahunan/bulanan & statistik
│   ├── pembayaran/
│   │   ├── aksi_pembayaran.php          # Logika alokasi pembayaran & verifikasi (Terima/Tolak)
│   │   ├── cetak_semua_pembayaran.php   # Laporan cetak seluruh pembayaran
│   │   └── pembayaran.php               # Halaman kelola data pembayaran & cetak nota
│   ├── pengembalian/
│   │   ├── aksi_pengembalian.php        # Update status sewa -> 'selesai' (restok otomatis)
│   │   └── pengembalian.php             # Halaman tabel pengembalian alat
│   ├── pengguna/
│   │   ├── aksi_pengguna.php            # CRUD akun user/pelanggan & upload foto
│   │   └── pengguna.php                 # Halaman daftar pelanggan
│   ├── riwayat/
│   │   ├── aksi_riwayat.php             # Handler riwayat sewa & tambah sewa manual
│   │   └── riwayat.php                  # Halaman riwayat penyewaan lengkap (Berlangsung & Dibatalkan)
│   ├── uploads/                         # Direktori file upload admin
│   │   ├── admin/                       # Foto profil admin / logo
│   │   ├── alat/                        # Gambar produk alat outdoor
│   │   └── pengguna/                    # Foto profil pelanggan
│   ├── cek_login.php                    # Middleware pengecekan session admin
│   ├── index.php                        # Form login admin
│   ├── logout_admin.php                 # Handler logout admin
│   ├── profile_admin.php                # Manajemen profil admin
│   ├── proses_login_admin.php           # Validasi login admin (password_verify)
│   └── sidebar.php                      # Komponen navigasi sidebar admin
│
├── api/                                 # Kumpulan REST API Endpoint (Format JSON)
│   ├── api_checkout.php                 # API Checkout keranjang ke transaksi sewa
│   ├── batalkan_sewa.php                # API Pembatalan pesanan sewa
│   ├── get_alat.php                     # API Daftar alat outdoor
│   ├── get_keranjang.php                # API Mengambil data keranjang user
│   ├── get_rekap_pembayaran.php         # API Rekap pembayaran
│   ├── get_riwayat.php                  # API Riwayat sewa user
│   ├── get_tagihan_user.php             # API Tagihan aktif beserta denda
│   ├── get_user.php                     # API Detail profil user
│   ├── hapus_keranjang.php              # API Hapus item dari keranjang
│   ├── login.php                        # API Login autentikasi user
│   ├── pembayaran.php                   # API Upload bukti pembayaran & alokasi DP
│   ├── register.php                     # API Pendaftaran akun user baru
│   ├── rekap_pembayaran.php             # API Rekapitulasi pembayaran user
│   ├── tambah_keranjang.php             # API Tambah item ke keranjang
│   └── update_users.php                 # API Update data profil user
│
├── assets/                              # Aset Statis (CSS, Javascript, Foto Tema)
│   ├── css/
│   │   └── navbar.css                   # Gaya navigasi customer
│   └── images/                          # Gambar pendukung tampilan
│
├── bukti_pembayaran/                    # Direktori penyimpanan bukti transfer pembayaran user
├── aksi_keranjang.php                   # Handler aksi update qty & hapus item keranjang
├── aksi_riwayat.php                     # Handler aksi riwayat sewa user
├── alat.php                             # Halaman katalog alat outdoor & tombol sewa
├── batalkan_sewa.php                    # Handler pembatalan sewa (Rollback + Restok barang)
├── checkout.php                         # Halaman formulir checkout sewa
├── index.php                            # Halaman beranda (Hero banner, Tentang, Lokasi Google Maps)
├── keranjang.php                        # Halaman keranjang belanja pelanggan
├── ketentuan.php                        # Halaman syarat dan ketentuan persewaan
├── koneksi.php                          # Konfigurasi koneksi MySQL
├── login.php                            # Halaman login pelanggan
├── logout.php                           # Handler logout pelanggan
├── navbar.php                           # Komponen header / navigasi pelanggan
├── pembayaran.php                       # Halaman formulir pembayaran / upload bukti transfer
├── profile.php                          # Halaman profil & edit akun pelanggan
├── proses_checkout.php                  # Halaman konfirmasi sukses checkout
├── proses_login.php                     # Handler validasi login pelanggan
├── proses_pembayaran.php                # Handler proses upload & alokasi pembayaran
├── proses_register.php                  # Handler registrasi pelanggan baru
├── proses_sewa.php                      # Handler penambahan produk langsung ke keranjang
├── register.php                         # Halaman registrasi pelanggan baru
├── riwayat_sewa.php                     # Halaman riwayat sewa (Berlangsung, Selesai, Dibatalkan)
├── tagihan.php                          # Halaman daftar tagihan sewa & hitung denda
└── db_semar.sql                         # File dump SQL database terbaru
```

---

## 🗄️ 3. Skema Basis Data (`db_semar`)

Berikut adalah representasi relasi dan tabel database:

```mermaid
erDiagram
    ADMIN {
        int id PK
        varchar nama
        varchar email
        varchar password
        varchar foto
    }

    USERS {
        int id PK
        varchar nama
        varchar email
        varchar password
        varchar no_hp
        text alamat
        varchar foto
        datetime created_at
    }

    ALAT {
        int id PK
        varchar nama
        text deskripsi
        int stok
        decimal harga_per_hari
        varchar gambar
    }

    KERANJANG {
        int id PK
        int id_users FK
        int id_alat FK
        int jumlah
        decimal total_harga
        datetime tanggal_ditambahkan
    }

    SEWA {
        int id PK
        int id_users FK
        int id_alat FK
        varchar nama_produk
        decimal total_harga
        varchar gambar
        int qty
        date tanggal_sewa
        int durasi
        varchar metode_pengambilan
        decimal biaya_pengambilan
        varchar status
    }

    SEWA_DIBATALKAN {
        int id PK
        int id_users FK
        varchar nama_produk
        decimal total_harga
        varchar gambar
        int qty
        date tanggal_sewa
        int durasi
        decimal biaya_pengambilan
        varchar metode_pengambilan
        varchar status
        datetime dibatalkan_pada
    }

    PEMBAYARAN {
        int id PK
        int id_users FK
        varchar id_sewa
        varchar metode
        varchar bukti_pembayaran
        decimal jumlah_bayar
        decimal total_tagihan
        varchar status
        datetime tanggal_bayar
    }

    USERS ||--o{ KERANJANG : "memiliki"
    ALAT ||--o{ KERANJANG : "disimpan di"
    USERS ||--o{ SEWA : "menyewa"
    ALAT ||--o{ SEWA : "disewa dalam"
    USERS ||--o{ PEMBAYARAN : "membayar"
    SEWA ||--o{ PEMBAYARAN : "dibayar oleh"
    USERS ||--o{ SEWA_DIBATALKAN : "membatalkan"
```

### Penjelasan Status Data:
1. **Status Sewa (`sewa.status`)**:
   - `Menunggu pembayaran` : Pesanan baru dibuat, belum ada pembayaran sah/DP.
   - `Berlangsung` / `Siap di ambil` / `Di antar` : Sedang diproses / barang dibawa penyewa.
   - `Belum lunas` : Pembayaran telah diverifikasi namun masih berupa DP / belum lunas.
   - `Lunas` : Seluruh total tagihan + denda telah terbayar lunas.
   - `selesai` : Barang telah dikembalikan ke toko (stok alat otomatis bertambah).
   - `Dibatalkan` : Pesanan dibatalkan sebelum diproses.

2. **Status Pembayaran (`pembayaran.status`)**:
   - `Menunggu konfirmasi` : User sudah mengunggah bukti bayar, menunggu verifikasi admin.
   - `Belum lunas` : Pembayaran diterima sebagai DP (Down Payment).
   - `Lunas` : Pembayaran diterima dan mencukupi total seluruh tagihan.
   - `Ditolak` : Bukti pembayaran tidak valid / ditolak oleh admin.

---

## 💡 4. Logika Bisnis, Rumus & Implementasi Sistem

### A. Nomor Tagihan (No. Invoice)
- Setiap transaksi sewa memiliki **Nomor Tagihan** unik dengan format:
  $$\text{No. Tagihan} = \text{INV-YYYYMMDD-ID}$$
  *(Contoh: `INV-20260822-0110`)*
- Nomor tagihan ini terintegrasi di seluruh alur transaksi: konfirmasi checkout, bukti pembayaran, tab tagihan aktif, struk pembayaran lunas, hingga laporan admin.

### B. Perhitungan Total Tagihan & Subtotal
- **Alat Umum**:
  $$\text{Subtotal} = (\text{Harga per Hari} \times \text{Qty} \times \text{Durasi Hari}) + \text{Biaya Pengambilan}$$
- **Gas Portabel (Barang Habis Pakai)**:
  $$\text{Subtotal} = (\text{Harga} \times \text{Qty}) + \text{Biaya Pengambilan}$$
  *(Harga gas portabel tidak dikalikan dengan durasi sewa)*
- **Metode Pengambilan**:
  - `Ambil Ke toko` : $\text{Biaya} = \text{Rp } 0$
  - `COD` : $\text{Biaya} = \text{Rp } 10.000$

### C. Perhitungan Denda Keterlambatan
Jika tanggal saat ini melebihi $(\text{Tanggal Sewa} + \text{Durasi})$, maka:
$$\text{Hari Terlambat} = \text{Tanggal Sekarang} - (\text{Tanggal Sewa} + \text{Durasi})$$
$$\text{Denda} = \text{Hari Terlambat} \times \text{Rp } 10.000$$
$$\text{Total Tagihan Akhir} = \text{Subtotal} + \text{Denda}$$

### D. Validasi & Alokasi Pembayaran DP (Down Payment)
- **Batas Pembayaran DP**:
  - **Minimal**: **Rp 10.000**
  - **Maksimal**: **Tidak boleh melebihi sisa total tagihan** ($10.000 \le \text{Jumlah Bayar} \le \text{Sisa Tagihan}$).
  - Tervalidasi pada *frontend* (input `max` & validasi JS) serta *backend* ([`proses_pembayaran.php`](file:///D:/laragon/www/Back%20up%20project/semar_outdoor/proses_pembayaran.php)).
- **Alokasi Pembayaran Multi-Item (FIFO Pembayaran)**:
  - Ketika user melakukan satu transfer untuk beberapa item sewa, sistem secara otomatis mengalokasikan dana ke item dengan prioritas sewa ber-denda tertinggi dan tanggal sewa tertua terlebih dahulu.

### E. Implementasi Alur FIFO (First-In, First-Out)
Sistem menerapkan 3 prinsip FIFO yang terintegrasi:
1. **FIFO Antrian Pemrosesan Pesanan**:
   - Pesanan diurutkan secara kronologis berdasarkan waktu checkout (`tanggal_buat ASC, id ASC`).
   - Setiap pesanan memiliki nomor antrian (`#1`, `#2`, `#3`, ...).
   - Pesanan pada antrian berikutnya dalam status `Menunggu pembayaran` terkunci (tombol edit status dinonaktifkan) hingga pesanan pada antrian sebelumnya telah diproses menjadi status aktif (`Siap di ambil`, `Di antar`, `Berlangsung`) atau `Selesai`.
2. **FIFO Alokasi Stok Alat**:
   - Stok dialokasikan pertama kali kepada pesanan yang masuk lebih awal saat pesanan disiapkan oleh admin.
3. **FIFO Alokasi Pelunasan Tagihan**:
   - Pembayaran diprioritaskan untuk melunasi tagihan yang paling mendesak/lama terlebih dahulu.

### F. Manajemen Stok Awal & Sisa Stok
- Pada panel admin ([`list_alat.php`](file:///D:/laragon/www/Back%20up%20project/semar_outdoor/admin/alat/list_alat.php)), alat memiliki 2 atribut stok yang terpisah:
  - **Stok Awal**: Total kapasitas inventaris fisik yang dimiliki toko.
  - **Sisa Stok**: Jumlah unit yang saat ini tersedia dan siap disewa ($\text{Sisa Stok} \le \text{Stok Awal}$).
- **Siklus Stok**:
  - **Checkout (`Menunggu pembayaran`)**: Stok belum berkurang.
  - **Status Aktif (`Siap di ambil`, `Di antar`, `Berlangsung`)**: Stok otomatis berkurang sejumlah kuantitas (Qty).
  - **Status Berakhir (`Selesai` atau `Dibatalkan`)**: Stok otomatis dikembalikan dengan batas maksimal tidak melebihi stok awal (`LEAST(stok_awal, stok + qty)`).

### G. Pemisahan Status Pembayaran (Tagihan, Lunas, Ditolak)
Pada halaman [tagihan.php](file:///D:/laragon/www/Back%20up%20project/semar_outdoor/tagihan.php), transaksi dikelompokkan secara tegas menjadi 4 tab:
1. **Tagihan Aktif**: Menampilkan tagihan yang belum dibayar / sisa DP beserta tombol pembayaran.
2. **Menunggu Konfirmasi**: Menampilkan bukti transfer yang sedang dalam antrian verifikasi admin.
3. **Selesai Dibayar / Lunas**: Menampilkan riwayat pembayaran yang telah diverifikasi dan lunas lengkap dengan struk/detail.
4. **Pembayaran Ditolak**: Menampilkan bukti transfer yang ditolak admin beserta alasan penolakan dan tombol **"Bayar Ulang"**.

### H. Sistem Auto-Batal (Automatic Expiration)
- Pesanan dengan status `Menunggu pembayaran` yang tidak diselesaikan pembayarannya dalam waktu **24 jam** atau telah **melewati tanggal sewa** (`tanggal_sewa < CURDATE()`) akan **dibatalkan secara otomatis oleh sistem**.
- Pesanan yang dibatalkan otomatis dialihkan ke riwayat `sewa_dibatalkan` dengan status `Dibatalkan (Otomatis Kadaluarsa)` sehingga tidak menumpuk dalam antrian.

---

## 🌐 5. Ringkasan Endpoint REST API (`/api`)

Semua endpoint menerima input `POST` atau `GET` dan mengembalikan respons berformat `application/json`.

| Endpoint | Method | Parameter Utama | Deskripsi |
|---|:---:|---|---|
| `api/register.php` | `POST` | `nama`, `email`, `password`, `no_hp`, `alamat` | Mendaftarkan akun pelanggan baru |
| `api/login.php` | `POST` | `email`, `password` | Autentikasi dan mengembalikan info user |
| `api/get_user.php` | `GET` / `POST` | `id_users` | Mengambil detail profil pengguna |
| `api/update_users.php` | `POST` | `id_users`, `nama`, `email`, `no_hp`, `alamat`, `foto` | Mengubah profil pelanggan |
| `api/get_alat.php` | `GET` | - | Mengambil seluruh katalog alat & stok |
| `api/get_keranjang.php` | `GET` / `POST` | `id_users` | Mengambil daftar barang di keranjang |
| `api/tambah_keranjang.php`| `POST` | `id_users`, `id_alat`, `jumlah` | Menambah barang ke keranjang |
| `api/hapus_keranjang.php` | `POST` | `id_keranjang`, `id_users` | Menghapus item dari keranjang |
| `api/api_checkout.php` | `POST` | `id_users`, `selected_ids`, `tanggal_sewa`, `durasi`, `metode_pengambilan` | Memproses checkout dan mengurangi stok |
| `api/get_tagihan_user.php`| `GET` / `POST` | `id_users` | Mengambil rincian tagihan aktif + denda |
| `api/pembayaran.php` | `POST` | `id_users`, `id_sewa[]`, `metode`, `jumlah_bayar`, `bukti` | Mengunggah bukti bayar & alokasi tagihan |
| `api/get_riwayat.php` | `GET` / `POST` | `id_users` | Riwayat sewa aktif, selesai, & batal |
| `api/batalkan_sewa.php` | `POST` | `id_sewa`, `id_users` | Membatalkan pesanan & restok barang |

---

## 🚀 6. Panduan Menjalankan Proyek

1. **Persiapan Web Server**:
   - Pastikan **Laragon** atau **XAMPP** telah berjalan (Apache & MySQL aktif).
   - Letakkan folder proyek di dalam direktori `www/` (Laragon) atau `htdocs/` (XAMPP).
2. **Import Database (`db_semar.sql`)**:
   - Buka `phpMyAdmin` (biasanya di `http://localhost/phpmyadmin`).
   - Buat database baru dengan nama `db_semar`.
   - Pilih menu **Import** dan pilih file [`db_semar.sql`](file:///D:/laragon/www/Back%20up%20project/semar_outdoor/db_semar.sql).
   - Klik **Go / Kirim** hingga proses import berhasil.
   - Pastikan konfigurasi di [`koneksi.php`](file:///D:/laragon/www/Back%20up%20project/semar_outdoor/koneksi.php) sesuai dengan kredensial MySQL lokal:
     ```php
     $host = "localhost";
     $user = "root";
     $pass = "";
     $db   = "db_semar";
     ```
3. **Akun Pengujian Bawaan (Dari `db_semar.sql`)**:
   - **Admin**:
     - Email: `admin@gmail.com`
     - URL Login: `http://localhost/semar_outdoor/admin/`
   - **Customer / Pelanggan**:
     - Email: `salmanaf083@gmail.com` atau `cek@gmail.com`
     - URL Login: `http://localhost/semar_outdoor/login.php`
4. **Mengakses Aplikasi**:
   - **Portal Pelanggan**: `http://localhost/semar_outdoor/`
   - **Portal Admin**: `http://localhost/semar_outdoor/admin/`

