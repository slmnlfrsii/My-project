<?php
session_start();
if (!isset($_SESSION['id_users'])) {
    header('Location: login.php');
    exit();
}
include 'koneksi.php';

$user_id = (int)$_SESSION['id_users'];

// 1. UPDATE DATA PROFIL TERPADU (NAMA, EMAIL, NO HP, ALAMAT & FOTO)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $nama   = trim($_POST['nama'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $no_hp  = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');

    if (empty($nama) || empty($email) || empty($no_hp) || empty($alamat)) {
        $_SESSION['flash_error'] = "Semua kolom data diri wajib diisi.";
    } else {
        // Ambil data user saat ini untuk foto lama
        $stmt_cur = $conn->prepare("SELECT foto FROM users WHERE id = ?");
        $stmt_cur->bind_param("i", $user_id);
        $stmt_cur->execute();
        $cur_user = $stmt_cur->get_result()->fetch_assoc();
        $foto_name = $cur_user['foto'] ?? null;

        // Cek apakah ada upload foto baru
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $target_dir = "admin/uploads/pengguna/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            $file_ext = strtolower(pathinfo($_FILES["foto"]["name"], PATHINFO_EXTENSION));
            $file_name = uniqid("user_") . "." . $file_ext;
            $target_file = $target_dir . $file_name;
            $check = getimagesize($_FILES["foto"]["tmp_name"]);

            if ($check === false) {
                $_SESSION['flash_error'] = "File yang diunggah bukan gambar valid.";
            } elseif ($_FILES["foto"]["size"] > 2097152) {
                $_SESSION['flash_error'] = "Ukuran file foto maksimal 2MB.";
            } elseif (!in_array($file_ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'])) {
                $_SESSION['flash_error'] = "Format foto harus JPG, PNG, WEBP, atau GIF.";
            } else {
                if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                    if (!empty($foto_name) && file_exists($target_dir . $foto_name)) {
                        @unlink($target_dir . $foto_name);
                    }
                    $foto_name = $file_name;
                } else {
                    $_SESSION['flash_error'] = "Gagal mengunggah foto profil.";
                }
            }
        }

        if (empty($_SESSION['flash_error'])) {
            $stmt = $conn->prepare("UPDATE users SET nama = ?, email = ?, no_hp = ?, alamat = ?, foto = ? WHERE id = ?");
            $stmt->bind_param("sssssi", $nama, $email, $no_hp, $alamat, $foto_name, $user_id);
            if ($stmt->execute()) {
                $_SESSION['flash_success'] = "Profil Anda berhasil diperbarui!";
            } else {
                $_SESSION['flash_error'] = "Gagal memperbarui profil: " . $conn->error;
            }
            header("Location: profile.php");
            exit();
        }
    }
}

// 2. HAPUS FOTO PROFIL
if (isset($_POST['hapus_foto'])) {
    $stmt_cur = $conn->prepare("SELECT foto FROM users WHERE id = ?");
    $stmt_cur->bind_param("i", $user_id);
    $stmt_cur->execute();
    $cur_user = $stmt_cur->get_result()->fetch_assoc();

    if (!empty($cur_user['foto']) && file_exists("admin/uploads/pengguna/" . $cur_user['foto'])) {
        @unlink("admin/uploads/pengguna/" . $cur_user['foto']);
    }
    $stmt = $conn->prepare("UPDATE users SET foto = NULL WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $_SESSION['flash_success'] = "Foto profil telah dihapus.";
    header("Location: profile.php");
    exit();
}

// 3. UBAH PASSWORD
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ubah_password'])) {
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();

    if (!$data || !password_verify($current, $data['password'])) {
        $_SESSION['flash_error'] = "Password saat ini salah.";
    } elseif ($new !== $confirm) {
        $_SESSION['flash_error'] = "Konfirmasi password baru tidak cocok.";
    } elseif (strlen($new) < 6) {
        $_SESSION['flash_error'] = "Password baru minimal 6 karakter.";
    } else {
        $new_hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $new_hash, $user_id);
        if ($stmt->execute()) {
            $_SESSION['flash_success'] = "Password berhasil diubah!";
        } else {
            $_SESSION['flash_error'] = "Gagal memperbarui password.";
        }
        header("Location: profile.php?tab=password");
        exit();
    }
}

// Ambil data user terbaru
$stmt = $conn->prepare("SELECT nama, email, no_hp, alamat, foto FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    header('Location: login.php');
    exit();
}

$active_tab = (isset($_GET['tab']) && $_GET['tab'] === 'password') ? 'password' : 'info';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Profil Saya - Semar Outdoor</title>
  <link rel="stylesheet" href="assets/css/navbar.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
      background-color: #f4f6f8;
      padding-top: 90px;
      padding-bottom: 50px;
      min-height: 100vh;
    }

    .profile-card {
      max-width: 580px;
      margin: 0 auto;
      background: #ffffff;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
      border: 1px solid rgba(0,0,0,0.06);
      overflow: hidden;
    }

    .profile-header {
      background: linear-gradient(135deg, #162d2f 0%, #0e4430 100%);
      color: white;
      padding: 22px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .btn-back-header {
      color: white;
      background: rgba(255, 255, 255, 0.15);
      border: 1px solid rgba(255, 255, 255, 0.25);
      border-radius: 8px;
      padding: 6px 14px;
      font-size: 0.88rem;
      font-weight: 500;
      text-decoration: none;
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .btn-back-header:hover {
      background: rgba(255, 255, 255, 0.28);
      color: white;
      transform: translateX(-2px);
    }

    .nav-profile-tabs {
      border-bottom: 1px solid #e2e8f0;
      background: #fafbfc;
      padding: 0 16px;
    }

    .nav-profile-tabs .nav-link {
      color: #64748b;
      font-weight: 600;
      font-size: 0.92rem;
      padding: 14px 18px;
      border: none;
      border-bottom: 2px solid transparent;
      border-radius: 0;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }

    .nav-profile-tabs .nav-link.active {
      color: #162d2f;
      background: transparent;
      border-bottom: 2px solid #8e5a12;
    }

    .card-body-content {
      padding: 26px 28px 30px;
    }

    /* Avatar Interactive Area */
    .avatar-container {
      position: relative;
      width: 110px;
      height: 110px;
      margin: 0 auto 12px;
    }

    .profile-avatar-img {
      width: 110px;
      height: 110px;
      object-fit: cover;
      border-radius: 50%;
      border: 3px solid #fff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      display: block;
    }

    .avatar-edit-badge {
      position: absolute;
      bottom: 2px;
      right: 2px;
      background: #8e5a12;
      color: white;
      width: 34px;
      height: 34px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,0.25);
      border: 2px solid white;
      transition: transform 0.2s ease, background-color 0.2s ease;
    }

    .avatar-edit-badge:hover {
      transform: scale(1.1);
      background: #162d2f;
    }

    .btn-delete-avatar {
      font-size: 0.8rem;
      color: #dc3545;
      background: none;
      border: none;
      padding: 0;
      text-decoration: underline;
      cursor: pointer;
    }
    .btn-delete-avatar:hover {
      color: #a71d2a;
    }

    .form-label {
      font-weight: 600;
      font-size: 0.88rem;
      color: #334155;
      margin-bottom: 6px;
    }

    .form-control {
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 0.93rem;
      border: 1.5px solid #cbd5e1;
    }

    .form-control:focus {
      border-color: #8e5a12;
      box-shadow: 0 0 0 3px rgba(142, 90, 18, 0.15);
    }

    .btn-primary-action {
      background: #162d2f;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 11px 20px;
      font-size: 0.95rem;
      font-weight: 600;
      width: 100%;
      transition: background-color 0.2s ease, transform 0.1s ease;
    }

    .btn-primary-action:hover {
      background: #8e5a12;
      color: white;
    }

    .btn-primary-action:active {
      transform: scale(0.99);
    }
  </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="container">
  <div class="profile-card">
    <!-- Header with Back Button -->
    <div class="profile-header">
      <a href="index.php" onclick="if(window.history.length > 1){ window.history.back(); return false; }" class="btn-back-header" title="Kembali ke halaman sebelumnya">
        <i class="fas fa-arrow-left"></i> Kembali
      </a>
      <h5 class="mb-0 fw-bold">Pengaturan Profil</h5>
      <div style="width: 80px;"></div>
    </div>

    <!-- Tab Navigation -->
    <ul class="nav nav-profile-tabs" id="userProfileTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($active_tab === 'info') ? 'active' : '' ?>" id="user-info-tab" data-bs-toggle="tab" data-bs-target="#user-info-pane" type="button" role="tab" aria-controls="user-info-pane" aria-selected="<?= ($active_tab === 'info') ? 'true' : 'false' ?>">
          <i class="fas fa-user-circle"></i> Data Diri
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link <?= ($active_tab === 'password') ? 'active' : '' ?>" id="user-password-tab" data-bs-toggle="tab" data-bs-target="#user-password-pane" type="button" role="tab" aria-controls="user-password-pane" aria-selected="<?= ($active_tab === 'password') ? 'true' : 'false' ?>">
          <i class="fas fa-lock"></i> Ganti Password
        </button>
      </li>
    </ul>

    <!-- Card Content -->
    <div class="card-body-content">
      <!-- Flash Alert Messages -->
      <?php if (!empty($_SESSION['flash_success'])): ?>
        <div class="alert alert-success alert-dismissible fade show py-2 px-3 mb-3 small" role="alert">
          <i class="fas fa-check-circle me-1"></i> <?= $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
          <button type="button" class="btn-close py-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>

      <?php if (!empty($_SESSION['flash_error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2 px-3 mb-3 small" role="alert">
          <i class="fas fa-exclamation-triangle me-1"></i> <?= $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
          <button type="button" class="btn-close py-2" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endif; ?>

      <div class="tab-content" id="userProfileTabContent">
        <!-- TAB 1: INFORMASI DATA DIRI & FOTO TERPADU -->
        <div class="tab-pane fade <?= ($active_tab === 'info') ? 'show active' : '' ?>" id="user-info-pane" role="tabpanel" aria-labelledby="user-info-tab">
          <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="update_profile" value="1">

            <!-- Interactive Avatar Preview -->
            <div class="text-center mb-3">
              <div class="avatar-container">
                <img id="userAvatarPreview" 
                     src="<?= !empty($user['foto']) ? 'admin/uploads/pengguna/' . htmlspecialchars($user['foto']) : 'assets/images/default-profile.jpg' ?>" 
                     class="profile-avatar-img" 
                     alt="Foto Profil">
                <label for="userFotoInput" class="avatar-badge" title="Klik untuk ganti foto profil">
                  <i class="fas fa-camera"></i>
                </label>
                <input type="file" id="userFotoInput" name="foto" class="d-none" accept="image/*" onchange="previewUserAvatar(this)">
              </div>

              <?php if (!empty($user['foto'])): ?>
                <button type="button" class="btn-delete-avatar" onclick="if(confirm('Hapus foto profil Anda?')) document.getElementById('formHapusUserFoto').submit();">
                  <i class="fas fa-trash-alt me-1"></i> Hapus Foto
                </button>
              <?php else: ?>
                <small class="text-muted" style="font-size:0.8rem;">Klik ikon kamera untuk memilih foto baru</small>
              <?php endif; ?>
            </div>

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-user me-1 text-muted"></i> Nama Lengkap</label>
              <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($user['nama']); ?>" required placeholder="Masukkan nama lengkap">
            </div>

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-envelope me-1 text-muted"></i> Alamat Email</label>
              <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']); ?>" required placeholder="Masukkan email aktif">
            </div>

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-phone me-1 text-muted"></i> Nomor WhatsApp / HP</label>
              <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($user['no_hp']); ?>" required placeholder="08xxxxxxxxxx">
            </div>

            <div class="mb-4">
              <label class="form-label"><i class="fas fa-map-marker-alt me-1 text-muted"></i> Alamat Lengkap</label>
              <textarea name="alamat" class="form-control" rows="3" required placeholder="Masukkan alamat lengkap"><?= htmlspecialchars($user['alamat']); ?></textarea>
            </div>

            <button type="submit" class="btn-primary-action">
              <i class="fas fa-save me-1"></i> Simpan Perubahan
            </button>
          </form>

          <!-- Hidden Form for Delete Photo -->
          <form id="formHapusUserFoto" method="POST" class="d-none">
            <input type="hidden" name="hapus_foto" value="1">
          </form>
        </div>

        <!-- TAB 2: GANTI PASSWORD -->
        <div class="tab-pane fade <?= ($active_tab === 'password') ? 'show active' : '' ?>" id="user-password-pane" role="tabpanel" aria-labelledby="user-password-tab">
          <form method="POST">
            <input type="hidden" name="ubah_password" value="1">

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-key me-1 text-muted"></i> Password Saat Ini</label>
              <input type="password" name="current_password" class="form-control" placeholder="Masukkan password saat ini" required>
            </div>

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-lock me-1 text-muted"></i> Password Baru</label>
              <input type="password" name="new_password" class="form-control" placeholder="Minimal 6 karakter" required minlength="6">
            </div>

            <div class="mb-4">
              <label class="form-label"><i class="fas fa-check-double me-1 text-muted"></i> Konfirmasi Password Baru</label>
              <input type="password" name="confirm_password" class="form-control" placeholder="Ketik ulang password baru" required minlength="6">
            </div>

            <button type="submit" class="btn-primary-action">
              <i class="fas fa-shield-alt me-1"></i> Perbarui Password
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
<script>
function previewUserAvatar(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      document.getElementById('userAvatarPreview').src = e.target.result;
    }
    reader.readAsDataURL(input.files[0]);
  }
}
</script>
</body>
</html>
