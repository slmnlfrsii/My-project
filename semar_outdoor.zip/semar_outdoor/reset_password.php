<?php
session_start();
include 'koneksi.php';

$token = trim($_GET['token'] ?? $_SESSION['reset_token'] ?? '');
$email = trim($_GET['email'] ?? $_SESSION['reset_email'] ?? '');
$otpPreview = $_SESSION['reset_otp_preview'] ?? '';

if (empty($email) && empty($token)) {
    header("Location: lupa_password.php");
    exit;
}

// Cek token/email di database apakah ada yang aktif
$stmt = $conn->prepare("SELECT * FROM password_resets WHERE (token = ? OR email = ?) AND expires_at >= NOW() ORDER BY id DESC LIMIT 1");
$stmt->bind_param("ss", $token, $email);
$stmt->execute();
$res = $stmt->get_result();
$resetData = $res ? $res->fetch_assoc() : null;

if (!$resetData) {
    // Jika tidak ada data reset yang valid/sudah kadaluarsa
    header("Location: lupa_password.php?status=token_kadaluarsa");
    exit;
}

$emailVal = $resetData['email'];
$tokenVal = $resetData['token'];
$otpVal = $resetData['otp'] ?? $otpPreview ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>Reset Kata Sandi – Semar Outdoor</title>
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    *, *::before, *::after {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    html, body {
      min-height: 100vh;
    }

    body {
      background: url('assets/images/g.jpg') center/cover no-repeat fixed;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px 14px;
    }

    .wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      max-width: 440px;
      width: 100%;
      margin: auto;
    }

    .auth-card {
      width: 100%;
      background: #fff;
      padding: 28px 24px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18);
    }

    .auth-card h2 {
      font-size: 23px;
      color: rgb(0, 0, 0);
      font-weight: 700;
      text-align: center;
      margin-bottom: 2px;
    }

    .auth-card p.subtitle {
      font-size: 13px;
      color: #64748b;
      text-align: center;
      margin-bottom: 4px;
      line-height: 1.45;
    }

    .email-badge {
      background: #e6f4f2;
      color: rgb(25, 76, 84);
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 12.5px;
      font-weight: 600;
      display: inline-block;
      margin: 0 auto 6px auto;
      text-align: center;
      word-break: break-all;
    }

    form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    form input {
      width: 100%;
      padding: 10px 20px;
      font-size: 14px;
      border: 1px solid #c1c1c1;
      border-radius: 30px;
      outline: none;
      transition: border 0.25s, box-shadow 0.25s;
      background-color: #fff;
    }

    form input.otp-input {
      text-align: center;
      letter-spacing: 6px;
      font-size: 18px;
      font-weight: 700;
      padding: 10px 20px;
    }

    form input:focus {
      border-color: rgb(25, 76, 84);
      box-shadow: 0 0 0 3px rgba(25, 76, 84, 0.12);
    }

    .btn.submit-btn {
      width: 100%;
      padding: 11px 0;
      font-size: 14.5px;
      font-weight: 600;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      background: rgb(25, 76, 84);
      color: #fff;
      transition: transform 0.15s, opacity 0.15s;
      margin-top: 4px;
    }

    .btn.submit-btn:hover {
      opacity: 0.92;
      color: #fff;
    }

    .btn.submit-btn:active {
      transform: scale(0.98);
    }

    .back-prompt {
      text-align: center;
      font-size: 13px;
      color: #64748b;
      margin-top: 4px;
    }

    .back-prompt a {
      color: rgb(25, 76, 84);
      font-weight: 700;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .back-prompt a:hover {
      text-decoration: underline;
      color: #102123;
    }

    @media (max-width: 480px) {
      body {
        padding: 16px 12px;
      }

      .auth-card {
        padding: 22px 18px;
        border-radius: 16px;
        gap: 14px;
      }

      .auth-card h2 {
        font-size: 20px;
      }

      .auth-card p.subtitle {
        font-size: 12px;
      }

      form input {
        padding: 9.5px 18px;
        font-size: 13.5px;
        border-radius: 25px;
      }

      form input.otp-input {
        padding: 9.5px 18px;
        font-size: 16px;
        letter-spacing: 4px;
      }

      .btn.submit-btn {
        padding: 10px 0;
        font-size: 14px;
        border-radius: 25px;
      }

      .back-prompt {
        font-size: 12px;
      }
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="auth-card">
      <h2>Ganti Kata Sandi</h2>
      <div class="text-center">
        <span class="email-badge"><?= htmlspecialchars($emailVal) ?></span>
      </div>
      <p class="subtitle">Kode OTP telah disiapkan. Silakan buat kata sandi baru untuk akun Anda.</p>

      <form action="proses_reset_password.php" method="post" onsubmit="return validateResetForm(event)">
        <input type="hidden" name="email" value="<?= htmlspecialchars($emailVal) ?>" />
        <input type="hidden" name="token" value="<?= htmlspecialchars($tokenVal) ?>" />

        <!-- Input Kode OTP Otomatis Terisi -->
        <div>
          <input type="text" id="otp_input" name="otp" class="otp-input" value="<?= htmlspecialchars($otpVal) ?>" placeholder="Kode OTP (6 digit)" maxlength="6" inputmode="numeric" autocomplete="one-time-code" required />
          <?php if (!empty($otpVal)): ?>
          <div class="text-center mt-1">
            <small class="text-success fw-semibold">&#10003; Kode OTP otomatis terisi</small>
          </div>
          <?php endif; ?>
        </div>

        <!-- Input Password Baru -->
        <input type="password" id="password" name="password" placeholder="Kata Sandi Baru (min. 6 karakter)" minlength="6" autocomplete="new-password" required />

        <!-- Input Konfirmasi Password Baru -->
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi Kata Sandi Baru" minlength="6" autocomplete="new-password" required />

        <button type="submit" class="btn submit-btn">Simpan Kata Sandi Baru</button>

        <div class="back-prompt">
          Batal? <a href="login.php">Kembali ke halaman Login</a>
        </div>
      </form>
    </div>
  </div>

  <script>
    function validateResetForm(e) {
      const otp = document.querySelector('input[name="otp"]').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm_password').value;

      if (otp.length !== 6) {
        e.preventDefault();
        Swal.fire({
          icon: 'warning',
          title: 'Kode OTP Tidak Lengkap',
          text: 'Harap masukkan 6 digit kode OTP verifikasi.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
        return false;
      }

      if (password.length < 6) {
        e.preventDefault();
        Swal.fire({
          icon: 'error',
          title: 'Kata Sandi Kurang',
          text: 'Kata sandi baru minimal harus 6 karakter.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
        return false;
      }

      if (password !== confirmPassword) {
        e.preventDefault();
        Swal.fire({
          icon: 'error',
          title: 'Konfirmasi Sandi Salah',
          text: 'Kata sandi baru dan konfirmasi kata sandi tidak sama.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
        return false;
      }

      return true;
    }

    document.addEventListener("DOMContentLoaded", function () {
      const otpField = document.getElementById('otp_input');
      const pwdField = document.getElementById('password');
      
      // Jika kode OTP sudah terisi otomatis, langsung fokuskan kursor ke input password baru
      if (otpField && otpField.value.trim().length === 6 && pwdField) {
        setTimeout(function () {
          pwdField.focus();
        }, 400);
      }

      const urlParams = new URLSearchParams(window.location.search);
      const status = urlParams.get('status');

      if (status) {
        if (status === 'kode_terkirim') {
          Swal.fire({
            icon: 'success',
            title: 'Kode OTP Siap',
            text: 'Kode verifikasi otomatis terisi ke formulir. Silakan masukkan kata sandi baru Anda.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'otp_salah') {
          Swal.fire({
            icon: 'error',
            title: 'Kode OTP Salah / Kadaluarsa',
            text: 'Kode verifikasi tidak sesuai atau masa berlaku telah habis.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'password_pendek') {
          Swal.fire({
            icon: 'error',
            title: 'Kata Sandi Pendek',
            text: 'Kata sandi baru minimal harus 6 karakter.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'password_tidak_sama') {
          Swal.fire({
            icon: 'error',
            title: 'Konfirmasi Tidak Cocok',
            text: 'Kata sandi baru dan konfirmasi tidak sesuai.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'gagal') {
          Swal.fire({
            icon: 'error',
            title: 'Gagal Memperbarui',
            text: 'Terjadi kesalahan sistem saat memperbarui kata sandi. Silakan coba lagi.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        }
      }
    });
  </script>
</body>
</html>
