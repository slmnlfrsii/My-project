<?php
session_start();
if (isset($_SESSION['id_users']) || (isset($_SESSION['role']) && $_SESSION['role'] === 'users')) {
  header("Location: index.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>Register – Healing Outdoor</title>
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    *, *::before, *::after {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    html, body {
      min-height: 100vh;
    }

    body {
      background: url('assets/images/g.jpg') center/cover no-repeat fixed;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px 14px;
    }

    .wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      max-width: 440px;
      width: 100%;
      margin: auto;
    }

    .register-card {
      width: 100%;
      background: #fff;
      padding: 28px 24px;
      display: flex;
      flex-direction: column;
      gap: 18px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18);
    }

    .register-card h2 {
      font-size: 24px;
      color: rgb(0, 0, 0);
      font-weight: 700;
      text-align: center;
      margin-bottom: 0;
    }

    form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    form input {
      width: 100%;
      padding: 10px 20px;
      font-size: 14px;
      border: 1px solid #c1c1c1;
      border-radius: 30px;
      outline: none;
      transition: border 0.25s, box-shadow 0.25s;
      background-color: #fff;
    }

    form input:focus {
      border-color: rgb(25, 76, 84);
      box-shadow: 0 0 0 3px rgba(25, 76, 84, 0.12);
    }

    .btn.register {
      width: 100%;
      padding: 11px 0;
      font-size: 14.5px;
      font-weight: 600;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      background: rgb(25, 76, 84);
      color: #fff;
      transition: transform 0.15s, opacity 0.15s;
      margin-top: 4px;
    }

    .btn.register:hover {
      opacity: 0.92;
      color: #fff;
    }

    .btn.register:active {
      transform: scale(0.98);
    }

    .login-prompt {
      text-align: center;
      font-size: 13.5px;
      color: #64748b;
      margin-top: 4px;
    }

    .login-prompt a {
      color: rgb(25, 76, 84);
      font-weight: 700;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .login-prompt a:hover {
      text-decoration: underline;
      color: #102123;
    }

    @media (max-width: 480px) {
      body {
        padding: 16px 12px;
      }

      .register-card {
        padding: 22px 18px;
        border-radius: 16px;
        gap: 14px;
      }

      .register-card h2 {
        font-size: 21px;
      }

      form {
        gap: 10px;
      }

      form input {
        padding: 9px 18px;
        font-size: 13.5px;
        border-radius: 25px;
      }

      .btn.register {
        padding: 10px 0;
        font-size: 14px;
        border-radius: 25px;
      }

      .login-prompt {
        font-size: 12.5px;
      }
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <!-- Card Register -->
    <div class="register-card">
      <h2>Register</h2>
      <form action="proses_register.php" method="post" onsubmit="return validateRegisterForm(event)">
        <input type="text" name="nama" placeholder="Nama Lengkap" autocomplete="name" required />
        <input type="email" name="email" placeholder="Email" autocomplete="email" inputmode="email" required />
        <input type="text" name="no_hp" placeholder="Nomor HP" inputmode="tel" required />
        <input type="text" name="alamat" placeholder="Alamat Lengkap" required />
        <input type="password" id="password" name="password" placeholder="Password (min. 6 karakter)" minlength="6" autocomplete="new-password" required />
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Konfirmasi Password" minlength="6" autocomplete="new-password" required /> 
        
        <button type="submit" class="btn register">Register</button>
        
        <div class="login-prompt">
          Sudah punya akun? <a href="login.php">Login di sini</a>
        </div>
      </form>
    </div>
  </div>

  <!-- Validasi & SweetAlert2 Notifikasi -->
  <script>
    function validateRegisterForm(e) {
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm_password').value;

      if (password.length < 6) {
        e.preventDefault();
        Swal.fire({
          icon: 'error',
          title: 'Registrasi Gagal',
          text: 'Password minimal harus 6 karakter.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
        return false;
      }

      if (password !== confirmPassword) {
        e.preventDefault();
        Swal.fire({
          icon: 'error',
          title: 'Registrasi Gagal',
          text: 'Password dan konfirmasi password tidak sama.',
          confirmButtonColor: 'rgb(25, 76, 84)'
        });
        return false;
      }

      return true;
    }

    document.addEventListener("DOMContentLoaded", function () {
      const urlParams = new URLSearchParams(window.location.search);
      const status = urlParams.get('status');

      if (status) {
        if (status === 'success' || status === 'berhasil') {
          Swal.fire({
            icon: 'success',
            title: 'Registrasi Berhasil',
            text: 'Silakan login untuk melanjutkan.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'password_pendek') {
          Swal.fire({
            icon: 'error',
            title: 'Registrasi Gagal',
            text: 'Password minimal harus 6 karakter.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'password_tidak_sama') {
          Swal.fire({
            icon: 'error',
            title: 'Registrasi Gagal',
            text: 'Password dan konfirmasi password tidak sama.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'email_sudah_terdaftar') {
          Swal.fire({
            icon: 'error',
            title: 'Registrasi Gagal',
            text: 'Email sudah terdaftar.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'invalid_email') {
          Swal.fire({
            icon: 'error',
            title: 'Registrasi Gagal',
            text: 'Format email tidak valid.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'data_tidak_lengkap') {
          Swal.fire({
            icon: 'error',
            title: 'Registrasi Gagal',
            text: 'Mohon lengkapi semua data formulir.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        } else if (status === 'failed' || status === 'gagal') {
          Swal.fire({
            icon: 'error',
            title: 'Registrasi Gagal',
            text: 'Terjadi kesalahan saat mendaftar. Silakan coba lagi.',
            confirmButtonColor: 'rgb(25, 76, 84)'
          });
        }
      }
    });
  </script>
</body>
</html>
