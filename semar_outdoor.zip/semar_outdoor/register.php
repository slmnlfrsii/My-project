<?php
session_start();
if (isset($_SESSION['role']) && $_SESSION['role'] === 'users') {
  header("Location: id_users.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register – Healing Outdoor</title>
  <!-- Google Font -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    /* ... (style kamu yang sama persis) ... */
    *, *::before, *::after {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    html, body {
      height: 100%;
    }

    body {
      background: url('assets/images/g.jpg') center/cover no-repeat fixed;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
    }

    .wrapper {
      display: flex;
      gap: 50px;
      background: rgba(255, 255, 255, 0.0);
      padding: 20px;
      border-radius: 16px;
      align-items: center;
      flex-wrap: wrap;
      max-width: 900px;
      width: 100%;
    }

    .banner {
      flex: 1;
      min-width: 240px;
      color: #fff;
      text-align: center;
    }

    .banner .logo {
      width: 150px;
      margin-bottom: 12px;
    }

    .banner h2 {
      font-size: 32px;
      font-weight: 700;
    }

    .banner p {
      font-size: 14px;
      opacity: 0.9;
    }

    .register-card {
      flex: 1;
      min-width: 300px;
      background: #fff;
      padding: 40px 36px;
      display: flex;
      flex-direction: column;
      gap: 26px;
      border-radius: 20px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    }

    .register-card h2 {
      font-size: 28px;
      color: rgb(0, 0, 0);
      font-weight: 700;
      text-align: center;
    }

    form {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    form input {
      width: 100%;
      padding: 13px 24px;
      font-size: 15px;
      border: 1px solid #c1c1c1;
      border-radius: 32px;
      outline: none;
      transition: border 0.25s;
    }

    form input:focus {
      border-color: rgb(25, 76, 84);
    }

    .actions {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin-top: 6px;
    }

    .btn {
      flex: 1;
      padding: 12px 0;
      font-size: 15px;
      font-weight: 600;
      border: none;
      border-radius: 32px;
      cursor: pointer;
      transition: transform 0.15s, box-shadow 0.15s;
    }

    .btn:active {
      transform: translateY(1px);
      box-shadow: none;
    }

    .register {
      background: rgb(25, 76, 84);
      color: #fff;
    }

    .login {
      background: #d10d1d;
      color: #fff;
    }

    @media(max-width: 768px) {
      .wrapper {
        flex-direction: column;
        text-align: center;
        gap: 30px;
      }

      .banner h2 {
        font-size: 26px;
      }

      .banner p {
        font-size: 13px;
      }

      .register-card {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <!-- Card Register -->
    <div class="register-card">
      <h2>Register</h2>
      <form action="proses_register.php" method="post">
      <input type="text" name="nama" placeholder="Nama Lengkap" required />
      <input type="email" name="email" placeholder="Email" required />
      <input type="text" name="no_hp" placeholder="Nomor HP" required />
      <input type="text" name="alamat" placeholder="Alamat Lengkap" required />
      <input type="password" name="password" placeholder="Password" required />
      <input type="password" name="confirm_password" placeholder="Konfirmasi Password" required /> 
        <div class="actions">
          <button type="submit" class="btn register">Register</button>
          <button type="button" class="btn login" onclick="window.location.href='login.php'">Login</button>
        </div>
      </form>
    </div>
  </div>

  <!-- SweetAlert2 untuk popup notifikasi -->
  <?php if (isset($_GET['status'])): ?>
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      <?php if ($_GET['status'] === 'success' || $_GET['status'] === 'berhasil'): ?>
        Swal.fire({
          icon: 'success',
          title: 'Registrasi Berhasil',
          text: 'Silakan login untuk melanjutkan.'
        });
      <?php elseif ($_GET['status'] === 'failed'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Registrasi Gagal',
          text: 'Email sudah terdaftar atau data tidak valid.',
          confirmButtonColor: '#d10d1d'
        });
      <?php elseif ($_GET['status'] === 'invalid_email'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Registrasi Gagal',
          text: 'Email tidak valid.',
          confirmButtonColor: '#d10d1d'
        });
      <?php elseif ($_GET['status'] === 'email_sudah_terdaftar'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Registrasi Gagal',
          text: 'Email sudah terdaftar.',
          confirmButtonColor: '#d10d1d'
        });
      <?php elseif ($_GET['status'] === 'password_tidak_sama'): ?>
        Swal.fire({
          icon: 'error',
          title: 'Registrasi Gagal',
          text: 'Password dan konfirmasi password tidak sama.',
          confirmButtonColor: '#d10d1d'
        });
      <?php endif; ?>
    });
  </script>
  <?php endif; ?>
</body>
</html>
