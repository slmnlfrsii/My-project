<?php
session_start();
include 'koneksi.php';

$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($email) || empty($password)) {
    header("Location: login.php?status=failed");
    exit;
}

// Cek di tabel users
$stmt = $conn->prepare("SELECT id, nama, email, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['password'])) {
        $_SESSION['id_users'] = $user['id'];
        $_SESSION['nama_users'] = $user['nama'];
        $_SESSION['role'] = 'users';
        header("Location: index.php?status=success");
        exit;
    }
}

// Gagal login
header("Location: login.php?status=failed");
exit;
?>
