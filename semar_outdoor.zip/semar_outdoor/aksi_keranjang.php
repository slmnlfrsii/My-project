<?php
session_start();
include './koneksi.php';

$id_user = $_SESSION['id_users'] ?? null;
if (!$id_user) {
    $_SESSION['error'] = "Anda harus login terlebih dahulu.";
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_keranjang = intval($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    // Ambil data keranjang + sisa_stok
    $cek = $conn->prepare("SELECT k.*, a.harga_per_hari, a.sisa_stok 
                           FROM keranjang k 
                           JOIN alat a ON k.id_alat = a.id 
                           WHERE k.id = ? AND k.id_users = ?");
    $cek->bind_param("ii", $id_keranjang, $id_user);
    $cek->execute();
    $result = $cek->get_result();
    $item = $result->fetch_assoc();

    if (!$item) {
        $_SESSION['error'] = "Data tidak ditemukan.";
        header("Location: keranjang.php");
        exit;
    }

    // ❌ Jika stok habis
    if ($item['sisa_stok'] <= 0) {
        $_SESSION['error'] = "Stok alat habis!";
        header("Location: keranjang.php");
        exit;
    }

    $jumlah_baru = $item['jumlah'];

    // ➕ Tambah
    if ($action === 'plus') {
        if ($item['jumlah'] < $item['sisa_stok']) {
            $jumlah_baru += 1;
        } else {
            $_SESSION['error'] = "Jumlah melebihi stok tersedia!";
        }
    }

    // ➖ Kurang
    elseif ($action === 'minus') {
        if ($item['jumlah'] > 1) {
            $jumlah_baru -= 1;
        }
    }

    // 🗑 Hapus
    elseif ($action === 'hapus') {
        $stmt = $conn->prepare("DELETE FROM keranjang WHERE id = ?");
        $stmt->bind_param("i", $id_keranjang);
        $stmt->execute();
        header("Location: keranjang.php");
        exit;
    }

    // 🔒 VALIDASI FINAL (WAJIB)
    if ($jumlah_baru > $item['sisa_stok']) {
        $jumlah_baru = $item['sisa_stok'];
    }

    if ($jumlah_baru < 1) {
        $jumlah_baru = 1;
    }

    // 💰 Hitung ulang total harga
    $total_harga_baru = $jumlah_baru * $item['harga_per_hari'];

    // 💾 Update database
    $stmt = $conn->prepare("UPDATE keranjang SET jumlah = ?, total_harga = ? WHERE id = ?");
    $stmt->bind_param("iii", $jumlah_baru, $total_harga_baru, $id_keranjang);
    $stmt->execute();
}

// 🔄 Redirect kembali
header("Location: keranjang.php");
exit;