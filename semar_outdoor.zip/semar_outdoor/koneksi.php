<?php
// Set timezone PHP ke WIB
date_default_timezone_set('Asia/Jakarta');

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_semar";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// 🛑 TAMBAHAN PENTING: Samakan jam database MySQL ke WIB (+07:00) agar pesanan baru tidak langsung terhapus AUTO-BATAL
mysqli_query($conn, "SET time_zone = '+07:00'");

// Pastikan kolom stok_awal dan sisa_stok ada di tabel alat
$checkStokAwal = @mysqli_query($conn, "SHOW COLUMNS FROM `alat` LIKE 'stok_awal'");
if ($checkStokAwal && mysqli_num_rows($checkStokAwal) == 0) {
    @mysqli_query($conn, "ALTER TABLE `alat` ADD `stok_awal` INT NOT NULL DEFAULT 0 AFTER `deskripsi`");
}
$checkSisaStok = @mysqli_query($conn, "SHOW COLUMNS FROM `alat` LIKE 'sisa_stok'");
if ($checkSisaStok && mysqli_num_rows($checkSisaStok) == 0) {
    @mysqli_query($conn, "ALTER TABLE `alat` ADD `sisa_stok` INT NOT NULL DEFAULT 0 AFTER `stok_awal`");
}

// Pastikan tipe kolom metode_pengambilan di sewa_dibatalkan adalah VARCHAR agar tidak error ENUM
@mysqli_query($conn, "ALTER TABLE `sewa_dibatalkan` MODIFY `metode_pengambilan` VARCHAR(50) DEFAULT 'Ambil Ke toko'");

// Pastikan kolom no_tagihan ada di sewa dan sewa_dibatalkan
$checkNoTagihanBatal = @mysqli_query($conn, "SHOW COLUMNS FROM `sewa_dibatalkan` LIKE 'no_tagihan'");
if ($checkNoTagihanBatal && mysqli_num_rows($checkNoTagihanBatal) == 0) {
    @mysqli_query($conn, "ALTER TABLE `sewa_dibatalkan` ADD `no_tagihan` VARCHAR(100) NULL AFTER `id_users`");
}
$checkNoTagihanSewa = @mysqli_query($conn, "SHOW COLUMNS FROM `sewa` LIKE 'no_tagihan'");
if ($checkNoTagihanSewa && mysqli_num_rows($checkNoTagihanSewa) == 0) {
    @mysqli_query($conn, "ALTER TABLE `sewa` ADD `no_tagihan` VARCHAR(100) NULL AFTER `id_users`");
}

// Hapus kolom 'stok' jika masih ada karena sudah digantikan oleh stok_awal dan sisa_stok
$checkStokCol = @mysqli_query($conn, "SHOW COLUMNS FROM `alat` LIKE 'stok'");
if ($checkStokCol && mysqli_num_rows($checkStokCol) > 0) {
    @mysqli_query($conn, "UPDATE `alat` SET `sisa_stok` = COALESCE(NULLIF(`sisa_stok`, 0), `stok`), `stok_awal` = COALESCE(NULLIF(`stok_awal`, 0), `stok`)");
    @mysqli_query($conn, "ALTER TABLE `alat` DROP COLUMN `stok`");
}

// Pastikan stok_awal dan sisa_stok tidak kosong jika salah satunya ada
@mysqli_query($conn, "UPDATE `alat` SET `stok_awal` = `sisa_stok` WHERE `stok_awal` = 0 AND `sisa_stok` > 0");
@mysqli_query($conn, "UPDATE `alat` SET `sisa_stok` = `stok_awal` WHERE `sisa_stok` = 0 AND `stok_awal` > 0");

// Pastikan tabel password_resets ada untuk fitur lupa kata sandi
@mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS `password_resets` (
      `id` INT AUTO_INCREMENT PRIMARY KEY,
      `email` VARCHAR(255) NOT NULL,
      `token` VARCHAR(100) NOT NULL,
      `otp` VARCHAR(10) NOT NULL,
      `created_at` DATETIME NOT NULL,
      `expires_at` DATETIME NOT NULL,
      INDEX (`email`),
      INDEX (`token`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// ==========================================
// ⏰ AUTO-BATAL: Batalkan pesanan 'Menunggu pembayaran' yang kadaluarsa (> 30 menit tanpa pembayaran sama sekali)
// ==========================================
$qAutoBatal = @mysqli_query($conn, "
    SELECT s.* 
    FROM `sewa` s
    WHERE LOWER(TRIM(s.status)) = 'menunggu pembayaran'
    AND (
        TIMESTAMPDIFF(MINUTE, COALESCE(s.tanggal_buat, NOW()), NOW()) >= 30
        OR s.tanggal_sewa < CURDATE()
    )
    AND NOT EXISTS (
        SELECT 1 FROM `pembayaran` p
        WHERE p.status IN ('Menunggu konfirmasi', 'Lunas', 'Belum lunas')
        AND (
            p.id_sewa = s.id 
            OR FIND_IN_SET(s.id, p.id_sewa)
            OR (s.no_tagihan IS NOT NULL AND s.no_tagihan != '' AND EXISTS (
                SELECT 1 FROM `sewa` s2 
                WHERE s2.no_tagihan = s.no_tagihan 
                AND (p.id_sewa = s2.id OR FIND_IN_SET(s2.id, p.id_sewa))
            ))
        )
    )
");

if ($qAutoBatal && mysqli_num_rows($qAutoBatal) > 0) {
    while ($batal = mysqli_fetch_assoc($qAutoBatal)) {
        $idBatal = (int)$batal['id'];
        $statusFix = 'Batal Otomatis';
        $noTagihan = !empty($batal['no_tagihan']) ? $batal['no_tagihan'] : ('INV-' . date('Ymd', strtotime($batal['tanggal_buat'] ?? 'now')) . '-' . sprintf('%04d', $idBatal));

        // Normalisasi metode_pengambilan
        $metodeRaw = strtolower(trim($batal['metode_pengambilan'] ?? ''));
        if (strpos($metodeRaw, 'cod') !== false || strpos($metodeRaw, 'antar') !== false) {
            $metodeFix = 'COD';
        } else {
            $metodeFix = 'Ambil Ke toko';
        }

        // Insert ke sewa_dibatalkan
        $stmtIns = $conn->prepare("
            INSERT INTO sewa_dibatalkan 
            (id_users, no_tagihan, nama_produk, qty, durasi, total_harga, biaya_pengambilan, metode_pengambilan, gambar, tanggal_sewa, status, dibatalkan_pada) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        if ($stmtIns) {
            $stmtIns->bind_param(
                "issiiidssss",
                $batal['id_users'],
                $noTagihan,
                $batal['nama_produk'],
                $batal['qty'],
                $batal['durasi'],
                $batal['total_harga'],
                $batal['biaya_pengambilan'],
                $metodeFix,
                $batal['gambar'],
                $batal['tanggal_sewa'],
                $statusFix
            );
            $stmtIns->execute();
            $stmtIns->close();
        }

        // Hapus dari sewa
        @mysqli_query($conn, "DELETE FROM sewa WHERE id = $idBatal");
    }
}

// Sinkronisasi otomatis sisa_stok: stok_awal dikurangi total Qty pesanan aktif (siap di ambil, di antar, berlangsung)
@mysqli_query($conn, "
    UPDATE `alat` a
    SET a.sisa_stok = GREATEST(0, a.stok_awal - COALESCE((
        SELECT SUM(s.qty) 
        FROM `sewa` s 
        WHERE s.id_alat = a.id 
        AND LOWER(TRIM(s.status)) IN ('siap di ambil', 'di antar', 'diantar', 'berlangsung')
    ), 0))
    WHERE a.stok_awal > 0
");
?>